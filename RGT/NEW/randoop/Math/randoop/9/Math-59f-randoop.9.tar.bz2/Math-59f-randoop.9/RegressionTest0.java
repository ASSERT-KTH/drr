import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 100L, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test007");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.12326315995183912d + "'", double0 == 0.12326315995183912d);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.floor(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.0d + "'", double1 == 11013.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.12326315995183912d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.062458834686373d + "'", double1 == 7.062458834686373d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 100, (double) 16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1630432221962219593L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8280937250720333d + "'", double1 == 0.8280937250720333d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1630432221962219593L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.212302749637146d + "'", double1 == 18.212302749637146d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.asinh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-6107792616609456200L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-6107792616609456200L), (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.1077926E18f) + "'", float2 == (-6.1077926E18f));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.ceil(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        java.lang.Throwable[] throwableArray2 = mathRuntimeException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = mathRuntimeException1.getSuppressed();
        java.lang.String str4 = mathRuntimeException1.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathRuntimeException1.getGeneralPattern();
        java.lang.Object[] objArray6 = mathRuntimeException1.getArguments();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str4.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.sinh(11013.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-6.1077926E18f), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.1077925898538189E18d) + "'", double2 == (-6.1077925898538189E18d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        long long1 = org.apache.commons.math.util.FastMath.round(0.8280937250720333d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(11013.232920103323d, (double) (-6.1077926E18f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.23292010332d + "'", double2 == 11013.23292010332d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.sinh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1630432221962219593L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 104.94395132690269d + "'", double1 == 104.94395132690269d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 10, (-6107792616609456200L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 607762227);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.07762227E8d + "'", double1 == 6.07762227E8d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3006322420239034d + "'", double1 == 0.3006322420239034d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 18.212302749637146d, (java.lang.Number) 11013.23292010332d, false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int2 = org.apache.commons.math.util.FastMath.min(10, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.0d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0000000000000004d + "'", double2 == 3.0000000000000004d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.82679529269723d) + "'", double1 == (-1.82679529269723d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1 };
        mersenneTwister0.nextBytes(byteArray3);
        mersenneTwister0.setSeed((-7818156871194313210L));
        long long7 = mersenneTwister0.nextLong();
        float float8 = mersenneTwister0.nextFloat();
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8268936713059271116L + "'", long7 == 8268936713059271116L);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.22283256f + "'", float8 == 0.22283256f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.515343893088381d + "'", double1 == 4.515343893088381d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7790688011124847161L + "'", long1 == 7790688011124847161L);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.POSITIVE_INFINITY, 7.062458834686373d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.062458834686373d + "'", double2 == 7.062458834686373d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-6107792616609456200L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 5);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.0f + "'", float1 == 5.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int int3 = mersenneTwister1.nextInt(8);
        mersenneTwister1.setSeed((int) (short) 10);
        int int6 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-982170359) + "'", int6 == (-982170359));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-6107792616609456200L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.atanh(18.212302749637146d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        long long1 = org.apache.commons.math.util.FastMath.round(100.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException(throwable3);
        java.lang.Throwable[] throwableArray5 = mathRuntimeException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = mathRuntimeException4.getSuppressed();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathRuntimeException4);
        boolean boolean8 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5.916079783099616d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int2 = org.apache.commons.math.util.FastMath.min(1, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.log1p(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.306943617238488d + "'", double1 == 9.306943617238488d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-4218389569722409859L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 1, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1630432221962219593L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.63043222196221952E18d + "'", double1 == 1.63043222196221952E18d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.tan(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9262160379374064d + "'", double1 == 0.9262160379374064d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.7615941559557649d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3130352854993315d + "'", double2 == 1.3130352854993315d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 3, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.ulp(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int[] intArray7 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
        mersenneTwister1.setSeed(intArray7);
        long long9 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2621438453848704568L) + "'", long9 == (-2621438453848704568L));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.abs(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1 };
        mersenneTwister0.nextBytes(byteArray3);
        mersenneTwister0.setSeed((-7818156871194313210L));
        double double7 = mersenneTwister0.nextGaussian();
        float float8 = mersenneTwister0.nextFloat();
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.6420579237750788d) + "'", double7 == (-1.6420579237750788d));
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.59986246f + "'", float8 == 0.59986246f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        java.lang.Throwable[] throwableArray2 = mathRuntimeException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = mathRuntimeException1.getSuppressed();
        java.lang.String str4 = mathRuntimeException1.toString();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathRuntimeException1.getGeneralPattern();
        java.lang.Throwable[] throwableArray6 = mathRuntimeException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str4.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-4218389569722409859L), (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.21838961E18f) + "'", float2 == (-4.21838961E18f));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 137.38927884571783d + "'", double1 == 137.38927884571783d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.asin(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.ceil(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11014.0d + "'", double1 == 11014.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.acos(10.000000000000002d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int int3 = mersenneTwister1.nextInt(8);
        mersenneTwister1.setSeed((int) (short) 10);
        long long6 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed(1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4218389569722409859L) + "'", long6 == (-4218389569722409859L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.515343893088381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.40899553966355d + "'", double1 == 90.40899553966355d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.String str4 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: � is smaller than, or equal to, the minimum (0)" + "'", str4.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: � is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-6.1077926E18f), (java.lang.Number) 2.302585092994046d, true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 100, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1411200080598672d + "'", double1 == 0.1411200080598672d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8849970445005177d + "'", double1 == 0.8849970445005177d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.6420579237750788d));
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getSpecificPattern();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException4);
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double2 = org.apache.commons.math.util.FastMath.min((double) '4', (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.000000000000001d + "'", double1 == 3.000000000000001d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 957059063);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.670383178540184E7d + "'", double1 == 1.670383178540184E7d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.82679529269723d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable12);
        java.lang.Throwable[] throwableArray14 = mathRuntimeException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException13.getSuppressed();
        java.lang.String str16 = mathRuntimeException13.toString();
        java.lang.Throwable[] throwableArray17 = mathRuntimeException13.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException5, localizable8, localizable11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException26.getGeneralPattern();
        java.lang.Throwable throwable28 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException(throwable28);
        java.lang.Throwable[] throwableArray30 = mathRuntimeException29.getSuppressed();
        java.lang.Throwable[] throwableArray31 = mathRuntimeException29.getSuppressed();
        java.lang.String str32 = mathRuntimeException29.toString();
        java.lang.Throwable[] throwableArray33 = mathRuntimeException29.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException21, localizable24, localizable27, (java.lang.Object[]) throwableArray33);
        java.lang.Throwable throwable35 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.exception.MathRuntimeException(throwable35);
        java.lang.Throwable[] throwableArray37 = mathRuntimeException36.getSuppressed();
        java.lang.Throwable[] throwableArray38 = mathRuntimeException36.getSuppressed();
        java.lang.Class<?> wildcardClass39 = throwableArray38.getClass();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable8, localizable27, (java.lang.Object[]) throwableArray38);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str32.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-6.1077926E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.1077925898538189E18d) + "'", double1 == (-6.1077925898538189E18d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-4218389569722409859L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.ceil();
        int int4 = dfp3.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 32760, 0.8849970445005177d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9909.82534330317d + "'", double2 == 9909.82534330317d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-2L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double2 = org.apache.commons.math.util.FastMath.min(11013.0d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        int int2 = org.apache.commons.math.util.FastMath.max(5, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1630432221962219593L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.63043222196221952E18d + "'", double1 == 1.63043222196221952E18d);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        byte[] byteArray2 = new byte[] {};
//        mersenneTwister0.nextBytes(byteArray2);
//        mersenneTwister0.setSeed((long) (short) 10);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4123940248069760846L + "'", long1 == 4123940248069760846L);
//        org.junit.Assert.assertNotNull(byteArray2);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-982170359));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int2 = org.apache.commons.math.util.FastMath.max(100, (-32767));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-4.21838961E18f), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.2183896096602849E18d) + "'", double2 == (-4.2183896096602849E18d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 957059063, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.5705907E8f + "'", float2 == 9.5705907E8f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8726936208978296d + "'", double1 == 0.8726936208978296d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        long long1 = org.apache.commons.math.util.FastMath.round(0.007988474493854092d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.sqrt();
        java.lang.String str29 = dfp23.toString();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp23.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp32 = dfp23.ceil();
        boolean boolean33 = dfp16.greaterThan(dfp23);
        try {
            org.apache.commons.math.dfp.Dfp dfp34 = org.apache.commons.math.dfp.DfpField.computeLn(dfp8, dfp9, dfp16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str29.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test172");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1 };
//        mersenneTwister0.nextBytes(byteArray3);
//        int int6 = mersenneTwister0.nextInt((int) (short) 100);
//        java.lang.Class<?> wildcardClass7 = mersenneTwister0.getClass();
//        org.junit.Assert.assertNotNull(byteArray3);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
//        org.junit.Assert.assertNotNull(wildcardClass7);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.log(90.40899553966355d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.504343770629639d + "'", double1 == 4.504343770629639d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp18);
        try {
            org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.rint(99.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        long long2 = org.apache.commons.math.util.FastMath.min(35L, (long) 8);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1425631994344677482L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1425631994344677376L) + "'", long1 == (-1425631994344677376L));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-6.1077925898538189E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.499507375399025E20d) + "'", double1 == (-3.499507375399025E20d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        boolean boolean12 = dfp10.equals((java.lang.Object) Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0.22283256f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2228325605392456d + "'", double1 == 0.2228325605392456d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 4123940248069760846L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4123940248069761024L + "'", long1 == 4123940248069761024L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.util.FastMath.acosh(9909.82534330317d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.894429180894686d + "'", double1 == 9.894429180894686d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int[] intArray7 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
        mersenneTwister1.setSeed(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-4218389569722409859L), (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.21838956972241E18d) + "'", double2 == (-4.21838956972241E18d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-4.2183896096602849E18d), (java.lang.Number) (-1425631994344677376L), false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9030899869919435d + "'", double1 == 0.9030899869919435d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        int int3 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) ' ', (-6.1077925898538189E18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        int int20 = dfp11.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.rint((-6.1077925898538189E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.1077925898538189E18d) + "'", double1 == (-6.1077925898538189E18d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.3006322420239034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0052470224609695755d + "'", double1 == 0.0052470224609695755d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, (long) 12);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        mersenneTwister1.setSeed((int) (short) 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(6.07762227E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 847.0542677499278d + "'", double1 == 847.0542677499278d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int int3 = mersenneTwister1.nextInt(8);
        mersenneTwister1.setSeed((int) (short) 10);
        long long6 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed((long) (short) 100);
        boolean boolean9 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4218389569722409859L) + "'", long6 == (-4218389569722409859L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0);
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        java.lang.Throwable[] throwableArray12 = mathRuntimeException11.getSuppressed();
        java.lang.Throwable[] throwableArray13 = mathRuntimeException11.getSuppressed();
        java.lang.String str14 = mathRuntimeException11.toString();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException11.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable9, (java.lang.Object[]) throwableArray15);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathIllegalArgumentException16);
        java.lang.Object[] objArray18 = mathIllegalArgumentException16.getArguments();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str14.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException(throwable6);
        java.lang.Throwable[] throwableArray8 = mathRuntimeException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = mathRuntimeException7.getSuppressed();
        java.lang.String str10 = mathRuntimeException7.toString();
        java.lang.Throwable[] throwableArray11 = mathRuntimeException7.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable5, (java.lang.Object[]) throwableArray11);
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException(throwable13);
        java.lang.Throwable[] throwableArray15 = mathRuntimeException14.getSuppressed();
        java.lang.Throwable[] throwableArray16 = mathRuntimeException14.getSuppressed();
        java.lang.String str17 = mathRuntimeException14.toString();
        java.lang.Throwable[] throwableArray18 = mathRuntimeException14.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException14);
        java.lang.Class<?> wildcardClass20 = mathRuntimeException14.getClass();
        mathIllegalArgumentException12.addSuppressed((java.lang.Throwable) mathRuntimeException14);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str10.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str17.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 10, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 8, (java.lang.Number) 4.504343770629639d, true);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 8 is smaller than the minimum (4.504)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 8 is smaller than the minimum (4.504)"));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.rint(9909.82534330317d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9910.0d + "'", double1 == 9910.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.newInstance((int) (byte) -1);
        boolean boolean9 = dfp2.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister();
//        long long2 = mersenneTwister1.nextLong();
//        byte[] byteArray3 = new byte[] {};
//        mersenneTwister1.nextBytes(byteArray3);
//        mersenneTwister0.nextBytes(byteArray3);
//        double double6 = mersenneTwister0.nextGaussian();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2703834685075141616L) + "'", long2 == (-2703834685075141616L));
//        org.junit.Assert.assertNotNull(byteArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6557719587665403d + "'", double6 == 0.6557719587665403d);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.8280937250720333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8280937250720334d + "'", double1 == 0.8280937250720334d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        float float2 = org.apache.commons.math.util.FastMath.max(9.5705907E8f, (float) 32760);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.5705907E8f + "'", float2 == 9.5705907E8f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8849970445005177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.422977230367018d + "'", double1 == 2.422977230367018d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5908569019008935d) + "'", double1 == (-0.5908569019008935d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9086743489308475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        float float2 = org.apache.commons.math.util.FastMath.max(0.22283256f, (float) 16);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16.0f + "'", float2 == 16.0f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.11827639714183447d) + "'", double1 == (-0.11827639714183447d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3953649341158527d + "'", double1 == 1.3953649341158527d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36221568869946325d + "'", double1 == 0.36221568869946325d);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextDouble();
//        int int2 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9404884198265686d + "'", double1 == 0.9404884198265686d);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46777259 + "'", int2 == 46777259);
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.6557719587665403d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9266292217829109d + "'", double1 == 0.9266292217829109d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.2228325605392456d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2228325605392456d + "'", double2 == 0.2228325605392456d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.nextAfter(dfp9);
        boolean boolean11 = dfp3.lessThan(dfp10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 100);
        mathRuntimeException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException4);
        boolean boolean6 = notStrictlyPositiveException4.getBoundIsAllowed();
        boolean boolean7 = notStrictlyPositiveException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.acosh(18.212302749637146d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5944899475286767d + "'", double1 == 3.5944899475286767d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        int int14 = dfp13.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-4) + "'", int14 == (-4));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-7818156871194313210L));
        mersenneTwister1.setSeed((int) (byte) 2);
        int int5 = mersenneTwister1.nextInt(3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.1411200080598672d, 11014.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2812784460881131E-5d + "'", double2 == 1.2812784460881131E-5d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 100);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int[] intArray7 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
        mersenneTwister1.setSeed(intArray7);
        int int10 = mersenneTwister1.nextInt(10);
        boolean boolean11 = mersenneTwister1.nextBoolean();
        long long12 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-4405082484239668943L) + "'", long12 == (-4405082484239668943L));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 647325673);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.47325673E8d + "'", double1 == 6.47325673E8d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance(100L);
        java.lang.String str11 = dfp10.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100." + "'", str11.equals("100."));
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test235");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1 };
//        mersenneTwister0.nextBytes(byteArray3);
//        mersenneTwister0.setSeed((-7818156871194313210L));
//        long long7 = mersenneTwister0.nextLong();
//        long long8 = mersenneTwister0.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(0L);
//        double double11 = mersenneTwister10.nextDouble();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister();
//        long long13 = mersenneTwister12.nextLong();
//        byte[] byteArray14 = new byte[] {};
//        mersenneTwister12.nextBytes(byteArray14);
//        mersenneTwister10.nextBytes(byteArray14);
//        mersenneTwister0.nextBytes(byteArray14);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
//        int[] intArray25 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
//        mersenneTwister19.setSeed(intArray25);
//        mersenneTwister0.setSeed(intArray25);
//        org.junit.Assert.assertNotNull(byteArray3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8268936713059271116L + "'", long7 == 8268936713059271116L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4110537376165046573L + "'", long8 == 4110537376165046573L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.15071724896777527d + "'", double11 == 0.15071724896777527d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-6369652980407488457L) + "'", long13 == (-6369652980407488457L));
//        org.junit.Assert.assertNotNull(byteArray14);
//        org.junit.Assert.assertNotNull(intArray25);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextDouble();
//        int int3 = mersenneTwister0.nextInt((int) (byte) 2);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31986901238711507d + "'", double1 == 0.31986901238711507d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-7818156871194313210L));
//        mersenneTwister1.setSeed((int) (byte) 2);
//        boolean boolean4 = mersenneTwister1.nextBoolean();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        long long6 = mersenneTwister5.nextLong();
//        byte[] byteArray7 = new byte[] {};
//        mersenneTwister5.nextBytes(byteArray7);
//        mersenneTwister1.nextBytes(byteArray7);
//        mersenneTwister1.setSeed((long) 5);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3534866348766186856L + "'", long6 == 3534866348766186856L);
//        org.junit.Assert.assertNotNull(byteArray7);
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 4749738130787047444L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.7497381307870474E18d + "'", double1 == 4.7497381307870474E18d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) -1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        int int2 = org.apache.commons.math.util.FastMath.min((-4), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-4) + "'", int2 == (-4));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 2, (long) (-4));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4L) + "'", long2 == (-4L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5403023058681398d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        java.lang.Throwable[] throwableArray2 = mathRuntimeException1.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathRuntimeException1.getSpecificPattern();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        int int9 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 25 + "'", int9 == 25);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.894429180894686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1455411586712207d + "'", double1 == 3.1455411586712207d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn10();
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int int3 = mersenneTwister1.nextInt(8);
        mersenneTwister1.setSeed((int) (short) 10);
        long long6 = mersenneTwister1.nextLong();
        java.lang.Class<?> wildcardClass7 = mersenneTwister1.getClass();
        int[] intArray11 = new int[] { 1, '4', 'a' };
        mersenneTwister1.setSeed(intArray11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4218389569722409859L) + "'", long6 == (-4218389569722409859L));
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7440230792707043d) + "'", double1 == (-0.7440230792707043d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(9.306943617238488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1624368094182825d + "'", double1 == 0.1624368094182825d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01745417862959511d + "'", double1 == 0.01745417862959511d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        int[] intArray6 = new int[] { 0, (short) 10, '4', (byte) 100 };
//        mersenneTwister0.setSeed(intArray6);
//        int int8 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed(0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-328395919939559869L) + "'", long1 == (-328395919939559869L));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 607762227 + "'", int8 == 607762227);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.7497381307870474E18d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-328395919939559869L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.01745417862959511d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2593979097038225d + "'", double1 == 0.2593979097038225d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math.util.FastMath.signum(9.306943617238488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-7818156871194313210L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5953988114176215d) + "'", double1 == (-0.5953988114176215d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-4));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.0d) + "'", double1 == (-4.0d));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.nextAfter(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp28.getField();
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.sqrt();
        java.lang.String str51 = dfp45.toString();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp54 = dfp45.ceil();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp42.add(dfp54);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp11.dotrap((int) (byte) 0, "org.apache.commons.math.exception.NotStrictlyPositiveException: � is smaller than, or equal to, the minimum (0)", dfp33, dfp54);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField58.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        org.apache.commons.math.dfp.DfpField dfpField73 = dfp72.getField();
        int int74 = dfpField73.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField73.getLn2();
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField58.newDfp(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp33.nextAfter(dfp76);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp77.floor();
        double double79 = dfp78.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str51.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfpField73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 16 + "'", int74 == 16);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + (-1.0d) + "'", double79 == (-1.0d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.acos(11014.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.791759469228055d + "'", double1 == 1.791759469228055d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 25, (long) (-982170359));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-982170359L) + "'", long2 == (-982170359L));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-2703834685075141616L), 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.7038346850751411E18d) + "'", double2 == (-2.7038346850751411E18d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.5908569019008935d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.nextAfter(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp28.getField();
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.sqrt();
        java.lang.String str51 = dfp45.toString();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp54 = dfp45.ceil();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp42.add(dfp54);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp11.dotrap((int) (byte) 0, "org.apache.commons.math.exception.NotStrictlyPositiveException: � is smaller than, or equal to, the minimum (0)", dfp33, dfp54);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField58.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        org.apache.commons.math.dfp.DfpField dfpField73 = dfp72.getField();
        int int74 = dfpField73.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField73.getLn2();
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField58.newDfp(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp33.nextAfter(dfp76);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp77.floor();
        double[] doubleArray79 = dfp77.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str51.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfpField73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 16 + "'", int74 == 16);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((long) 8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        int int18 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.nextAfter(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField31 = dfp30.getField();
        int int32 = dfp30.log10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp37.nextAfter(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp37.sqrt();
        java.lang.String str43 = dfp37.toString();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp37.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp46 = dfp37.ceil();
        boolean boolean47 = dfp30.greaterThan(dfp37);
        boolean boolean48 = dfp19.greaterThan(dfp30);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp19.newInstance((double) 16);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp53.nextAfter(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField58 = dfp57.getField();
        int int59 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.getLn2();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp60.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp67.nextAfter(dfp70);
        org.apache.commons.math.dfp.DfpField dfpField72 = dfp71.getField();
        int int73 = dfp71.log10();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp71.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField77.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField80.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp82 = dfp78.nextAfter(dfp81);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.sqrt();
        java.lang.String str84 = dfp78.toString();
        org.apache.commons.math.dfp.Dfp dfp86 = dfp78.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp87 = dfp78.ceil();
        boolean boolean88 = dfp71.greaterThan(dfp78);
        boolean boolean89 = dfp60.greaterThan(dfp71);
        org.apache.commons.math.dfp.Dfp dfp91 = dfp71.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp92 = dfp19.newInstance(dfp71);
        org.apache.commons.math.dfp.Dfp dfp93 = dfpField7.newDfp(dfp92);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpField31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str43.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfpField58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfpField72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str84.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.power10K((-32767));
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.538970890562367d) + "'", double1 == (-1.538970890562367d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        java.lang.Throwable[] throwableArray2 = mathRuntimeException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = mathRuntimeException1.getSuppressed();
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException(throwable4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 100);
        mathRuntimeException5.addSuppressed((java.lang.Throwable) notStrictlyPositiveException8);
        boolean boolean10 = notStrictlyPositiveException8.getBoundIsAllowed();
        mathRuntimeException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException8);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.5953988114176215d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 904260081111781427L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0426008111178138E17d + "'", double1 == 9.0426008111178138E17d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-6369652980407488457L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test281");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        int[] intArray6 = new int[] { 0, (short) 10, '4', (byte) 100 };
//        mersenneTwister0.setSeed(intArray6);
//        double double8 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 794707398774706940L + "'", long1 == 794707398774706940L);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.1415056727533026d + "'", double8 == 0.1415056727533026d);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray1 = null;
        mersenneTwister0.setSeed(intArray1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.59986246f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8218681967033049d + "'", double1 == 0.8218681967033049d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.8280937250720333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.014452962017611698d + "'", double1 == 0.014452962017611698d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.sinh(9910.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable9);
        java.lang.Throwable[] throwableArray11 = mathRuntimeException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException10.getSuppressed();
        java.lang.String str13 = mathRuntimeException10.toString();
        java.lang.Throwable[] throwableArray14 = mathRuntimeException10.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable5, localizable8, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException(throwable27);
        java.lang.Throwable[] throwableArray29 = mathRuntimeException28.getSuppressed();
        java.lang.Throwable[] throwableArray30 = mathRuntimeException28.getSuppressed();
        java.lang.String str31 = mathRuntimeException28.toString();
        java.lang.Throwable[] throwableArray32 = mathRuntimeException28.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException20, localizable23, localizable26, (java.lang.Object[]) throwableArray32);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable23, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = mathIllegalArgumentException35.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str31.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-6.1077926E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.1077925898538189E18d) + "'", double1 == (-6.1077925898538189E18d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.7497381307870474E18d, (double) 16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.709878534901637E298d + "'", double2 == 6.709878534901637E298d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int[] intArray7 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
        mersenneTwister1.setSeed(intArray7);
        int int10 = mersenneTwister1.nextInt(10);
        mersenneTwister1.setSeed(7790688011124847161L);
        double double13 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.7905639000715652d + "'", double13 == 0.7905639000715652d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-2621438453848704568L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.signum(104.94395132690269d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException(throwable2);
        java.lang.Throwable[] throwableArray4 = mathRuntimeException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = mathRuntimeException3.getSuppressed();
        java.lang.String str6 = mathRuntimeException3.toString();
        java.lang.Throwable[] throwableArray7 = mathRuntimeException3.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException8);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str6.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5574077246549023d, 6.709878534901637E298d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3210669411584705E-299d + "'", double2 == 2.3210669411584705E-299d);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        int[] intArray6 = new int[] { 0, (short) 10, '4', (byte) 100 };
//        mersenneTwister0.setSeed(intArray6);
//        int int8 = mersenneTwister0.nextInt();
//        float float9 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2734267132836942420L) + "'", long1 == (-2734267132836942420L));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 607762227 + "'", int8 == 607762227);
//        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.9480299f + "'", float9 == 0.9480299f);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable9);
        java.lang.Throwable[] throwableArray11 = mathRuntimeException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException10.getSuppressed();
        java.lang.String str13 = mathRuntimeException10.toString();
        java.lang.Throwable[] throwableArray14 = mathRuntimeException10.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable5, localizable8, (java.lang.Object[]) throwableArray14);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException(throwable16);
        java.lang.Throwable[] throwableArray18 = mathRuntimeException17.getSuppressed();
        java.lang.Throwable[] throwableArray19 = mathRuntimeException17.getSuppressed();
        java.lang.String str20 = mathRuntimeException17.toString();
        org.apache.commons.math.exception.util.Localizable localizable21 = mathRuntimeException17.getGeneralPattern();
        mathRuntimeException15.addSuppressed((java.lang.Throwable) mathRuntimeException17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (-4.21838956972241E18d), (java.lang.Number) 5.0f, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException34.getGeneralPattern();
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException(throwable36);
        java.lang.Throwable[] throwableArray38 = mathRuntimeException37.getSuppressed();
        java.lang.Throwable[] throwableArray39 = mathRuntimeException37.getSuppressed();
        java.lang.String str40 = mathRuntimeException37.toString();
        java.lang.Throwable[] throwableArray41 = mathRuntimeException37.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable35, (java.lang.Object[]) throwableArray41);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException(throwable43);
        java.lang.Throwable[] throwableArray45 = mathRuntimeException44.getSuppressed();
        java.lang.Throwable[] throwableArray46 = mathRuntimeException44.getSuppressed();
        java.lang.Class<?> wildcardClass47 = throwableArray46.getClass();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException17, localizable25, localizable32, (java.lang.Object[]) throwableArray46);
        java.lang.Object[] objArray49 = mathRuntimeException48.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str20.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str40.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNotNull(objArray49);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1 };
//        mersenneTwister0.nextBytes(byteArray3);
//        mersenneTwister0.setSeed((-7818156871194313210L));
//        long long7 = mersenneTwister0.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(0L);
//        double double10 = mersenneTwister9.nextDouble();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister();
//        long long12 = mersenneTwister11.nextLong();
//        byte[] byteArray13 = new byte[] {};
//        mersenneTwister11.nextBytes(byteArray13);
//        mersenneTwister9.nextBytes(byteArray13);
//        mersenneTwister0.nextBytes(byteArray13);
//        org.junit.Assert.assertNotNull(byteArray3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8268936713059271116L + "'", long7 == 8268936713059271116L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.15071724896777527d + "'", double10 == 0.15071724896777527d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2704279721829509803L + "'", long12 == 2704279721829509803L);
//        org.junit.Assert.assertNotNull(byteArray13);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException(throwable1);
        java.lang.Throwable[] throwableArray3 = mathRuntimeException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = mathRuntimeException2.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray4);
        java.lang.String str6 = mathIllegalArgumentException5.toString();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str6.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp("hi!");
        dfpField9.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.getSqr2Reciprocal();
        boolean boolean17 = dfp7.lessThan(dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math.util.FastMath.abs(11013.23292010332d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.23292010332d + "'", double1 == 11013.23292010332d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.nextAfter(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        int int11 = dfp9.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.floor();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.nextAfter(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.nextAfter(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField20 = dfp19.getField();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.subtract(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.Dfp.copysign(dfp2, dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.newInstance((byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpField20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        int int7 = dfp6.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-4) + "'", int7 == (-4));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.power10(46777259);
        int int24 = dfp23.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 25 + "'", int24 == 25);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        long long2 = org.apache.commons.math.util.FastMath.min((-1425631994344677376L), (-1425631994344677376L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1425631994344677376L) + "'", long2 == (-1425631994344677376L));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (byte) 0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.7497381307870474E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.7497381307870474E18d + "'", double1 == 4.7497381307870474E18d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        java.lang.Throwable[] throwableArray2 = mathRuntimeException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = mathRuntimeException1.getSuppressed();
        java.lang.String str4 = mathRuntimeException1.toString();
        java.lang.Throwable[] throwableArray5 = mathRuntimeException1.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathRuntimeException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathRuntimeException1.getGeneralPattern();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str4.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9319894568729709d + "'", double1 == 0.9319894568729709d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1024.0d, number1, true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.3358343618944353d), (-2.7038346850751411E18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3358343618944353d) + "'", double2 == (-1.3358343618944353d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        int int2 = mersenneTwister1.nextInt();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 647325673 + "'", int2 == 647325673);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp15 = dfp13.nextAfter(dfp14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.log(0.8218681967033049d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.19617524142571516d) + "'", double1 == (-0.19617524142571516d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.8280937250720333d + "'", number2.equals(0.8280937250720333d));
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        dfpField7.clearIEEEFlags();
        dfpField7.setIEEEFlagsBits((-982170359));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp15 = dfp13.subtract(dfp14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        long long2 = org.apache.commons.math.util.FastMath.max((-4218389569722409859L), (-4L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4L) + "'", long2 == (-4L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp17.getField();
        int int19 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField32 = dfp31.getField();
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.nextAfter(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp38.sqrt();
        java.lang.String str44 = dfp38.toString();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp38.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp47 = dfp38.ceil();
        boolean boolean48 = dfp31.greaterThan(dfp38);
        boolean boolean49 = dfp20.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp31.newInstance("hi!");
        boolean boolean52 = dfp6.unequal(dfp51);
        int int53 = dfp6.classify();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp6.multiply((int) (byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str44.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.nextAfter(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        double double2 = mersenneTwister1.nextGaussian();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0553194731804223d + "'", double2 == 1.0553194731804223d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4663742953783592d + "'", double3 == 1.4663742953783592d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        dfpField7.setIEEEFlagsBits((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(647325673);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp9.newInstance((double) 16);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.nextAfter(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField48 = dfp47.getField();
        int int49 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn2();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp57.nextAfter(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField62 = dfp61.getField();
        int int63 = dfp61.log10();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp61.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp68.sqrt();
        java.lang.String str74 = dfp68.toString();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp68.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp77 = dfp68.ceil();
        boolean boolean78 = dfp61.greaterThan(dfp68);
        boolean boolean79 = dfp50.greaterThan(dfp61);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp61.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp82 = dfp9.newInstance(dfp61);
        int int83 = dfp9.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpField62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str74.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 25 + "'", int83 == 25);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-4.21838961E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.2183896096602849E18d) + "'", double1 == (-4.2183896096602849E18d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9404884198265686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.floor();
        int int4 = dfp3.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        int int19 = dfp18.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(37);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-3711296198877327745L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 512.0d + "'", double1 == 512.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.ceil();
        double double4 = dfp2.toDouble();
        double[] doubleArray5 = dfp2.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.732050807569d + "'", double4 == 1.732050807569d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 904260081111781427L, 9.306943617238488d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.0426008111178138E17d + "'", double2 == 9.0426008111178138E17d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2704279721829509803L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999932988344528d + "'", double1 == 0.9999932988344528d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 904260081111781427L, (java.lang.Number) 6.07762227E8d, false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.nextAfter(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        int int11 = dfp9.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        boolean boolean13 = dfp12.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-6.1077926E18f), 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.1077925898538189E18d) + "'", double2 == (-6.1077925898538189E18d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        int int1 = org.apache.commons.math.util.FastMath.abs((-32767));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32767 + "'", int1 == 32767);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(37);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) 16);
        int int11 = dfp8.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp(100);
        dfpField7.setIEEEFlags(32768);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1 };
//        mersenneTwister0.nextBytes(byteArray3);
//        float float5 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertNotNull(byteArray3);
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.109633684f + "'", float5 == 0.109633684f);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable9);
        java.lang.Throwable[] throwableArray11 = mathRuntimeException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException10.getSuppressed();
        java.lang.String str13 = mathRuntimeException10.toString();
        java.lang.Throwable[] throwableArray14 = mathRuntimeException10.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable5, localizable8, (java.lang.Object[]) throwableArray14);
        java.lang.Object[] objArray16 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable9);
        java.lang.Throwable[] throwableArray11 = mathRuntimeException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException10.getSuppressed();
        java.lang.String str13 = mathRuntimeException10.toString();
        java.lang.Throwable[] throwableArray14 = mathRuntimeException10.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable5, localizable8, (java.lang.Object[]) throwableArray14);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException(throwable16);
        java.lang.Throwable[] throwableArray18 = mathRuntimeException17.getSuppressed();
        java.lang.Throwable[] throwableArray19 = mathRuntimeException17.getSuppressed();
        java.lang.String str20 = mathRuntimeException17.toString();
        org.apache.commons.math.exception.util.Localizable localizable21 = mathRuntimeException17.getGeneralPattern();
        mathRuntimeException15.addSuppressed((java.lang.Throwable) mathRuntimeException17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (-4.21838956972241E18d), (java.lang.Number) 5.0f, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException34.getGeneralPattern();
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException(throwable36);
        java.lang.Throwable[] throwableArray38 = mathRuntimeException37.getSuppressed();
        java.lang.Throwable[] throwableArray39 = mathRuntimeException37.getSuppressed();
        java.lang.String str40 = mathRuntimeException37.toString();
        java.lang.Throwable[] throwableArray41 = mathRuntimeException37.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable35, (java.lang.Object[]) throwableArray41);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException(throwable43);
        java.lang.Throwable[] throwableArray45 = mathRuntimeException44.getSuppressed();
        java.lang.Throwable[] throwableArray46 = mathRuntimeException44.getSuppressed();
        java.lang.Class<?> wildcardClass47 = throwableArray46.getClass();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException17, localizable25, localizable32, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.util.Localizable localizable49 = mathRuntimeException17.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str20.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str40.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertNull(localizable49);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        int int2 = mersenneTwister1.nextInt();
        java.lang.Class<?> wildcardClass3 = mersenneTwister1.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 647325673 + "'", int2 == 647325673);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.sqrt();
        java.lang.String str8 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField19 = dfp18.getField();
        int int20 = dfpField19.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.nextAfter(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField33 = dfp32.getField();
        int int34 = dfp32.log10();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp32.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.nextAfter(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.sqrt();
        java.lang.String str45 = dfp39.toString();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp39.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp48 = dfp39.ceil();
        boolean boolean49 = dfp32.greaterThan(dfp39);
        boolean boolean50 = dfp21.greaterThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp32.power10K((-32767));
        boolean boolean53 = dfp2.greaterThan(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp56.nextAfter(dfp59);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp56.sqrt();
        java.lang.String str62 = dfp56.toString();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp56.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp65 = dfp32.multiply(dfp64);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str8.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpField33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str45.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str62.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp(100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        java.lang.Throwable throwable7 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException(throwable7);
        java.lang.Throwable[] throwableArray9 = mathRuntimeException8.getSuppressed();
        java.lang.Throwable[] throwableArray10 = mathRuntimeException8.getSuppressed();
        java.lang.String str11 = mathRuntimeException8.toString();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException8.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException24.getGeneralPattern();
        java.lang.Throwable throwable26 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.exception.MathRuntimeException(throwable26);
        java.lang.Throwable[] throwableArray28 = mathRuntimeException27.getSuppressed();
        java.lang.Throwable[] throwableArray29 = mathRuntimeException27.getSuppressed();
        java.lang.String str30 = mathRuntimeException27.toString();
        java.lang.Throwable[] throwableArray31 = mathRuntimeException27.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException19, localizable22, localizable25, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 0.8726936208978296d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable37 = notStrictlyPositiveException36.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField39.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray44 = dfpField39.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException16, localizable22, localizable37, (java.lang.Object[]) dfpArray44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode49 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField47.setRoundingMode(roundingMode49);
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField47.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable6, localizable22, (java.lang.Object[]) dfpArray51);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str11.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str30.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfpArray44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + roundingMode49 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode49.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfpArray51);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int int3 = mersenneTwister1.nextInt(8);
        mersenneTwister1.setSeed((int) (short) 10);
        long long6 = mersenneTwister1.nextLong();
        mersenneTwister1.setSeed((long) (short) 100);
        float float9 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4218389569722409859L) + "'", long6 == (-4218389569722409859L));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.07871711f + "'", float9 == 0.07871711f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr2();
        double double21 = dfp20.toDouble();
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp20);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable12);
        java.lang.Throwable[] throwableArray14 = mathRuntimeException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException13.getSuppressed();
        java.lang.String str16 = mathRuntimeException13.toString();
        java.lang.Throwable[] throwableArray17 = mathRuntimeException13.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException5, localizable8, localizable11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 0.8726936208978296d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField25.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable8, localizable23, (java.lang.Object[]) dfpArray30);
        java.lang.String str32 = mathIllegalArgumentException2.toString();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str32.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.nextAfter(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp4.greaterThan(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        java.lang.Throwable[] throwableArray2 = mathRuntimeException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = mathRuntimeException1.getSuppressed();
        java.lang.String str4 = mathRuntimeException1.toString();
        java.lang.Throwable[] throwableArray5 = mathRuntimeException1.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathRuntimeException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException(throwable16);
        java.lang.Throwable[] throwableArray18 = mathRuntimeException17.getSuppressed();
        java.lang.Throwable[] throwableArray19 = mathRuntimeException17.getSuppressed();
        java.lang.String str20 = mathRuntimeException17.toString();
        java.lang.Throwable[] throwableArray21 = mathRuntimeException17.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException9, localizable12, localizable15, (java.lang.Object[]) throwableArray21);
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException(throwable23);
        java.lang.Throwable[] throwableArray25 = mathRuntimeException24.getSuppressed();
        java.lang.Throwable[] throwableArray26 = mathRuntimeException24.getSuppressed();
        java.lang.String str27 = mathRuntimeException24.toString();
        org.apache.commons.math.exception.util.Localizable localizable28 = mathRuntimeException24.getGeneralPattern();
        mathRuntimeException22.addSuppressed((java.lang.Throwable) mathRuntimeException24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable32, (java.lang.Number) (-4.21838956972241E18d), (java.lang.Number) 5.0f, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable39 = notStrictlyPositiveException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getGeneralPattern();
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException(throwable43);
        java.lang.Throwable[] throwableArray45 = mathRuntimeException44.getSuppressed();
        java.lang.Throwable[] throwableArray46 = mathRuntimeException44.getSuppressed();
        java.lang.String str47 = mathRuntimeException44.toString();
        java.lang.Throwable[] throwableArray48 = mathRuntimeException44.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable42, (java.lang.Object[]) throwableArray48);
        java.lang.Throwable throwable50 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.exception.MathRuntimeException(throwable50);
        java.lang.Throwable[] throwableArray52 = mathRuntimeException51.getSuppressed();
        java.lang.Throwable[] throwableArray53 = mathRuntimeException51.getSuppressed();
        java.lang.Class<?> wildcardClass54 = throwableArray53.getClass();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException24, localizable32, localizable39, (java.lang.Object[]) throwableArray53);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable58 = notStrictlyPositiveException57.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable61 = notStrictlyPositiveException60.getGeneralPattern();
        java.lang.Throwable throwable62 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException63 = new org.apache.commons.math.exception.MathRuntimeException(throwable62);
        java.lang.Throwable[] throwableArray64 = mathRuntimeException63.getSuppressed();
        java.lang.Throwable[] throwableArray65 = mathRuntimeException63.getSuppressed();
        java.lang.String str66 = mathRuntimeException63.toString();
        java.lang.Throwable[] throwableArray67 = mathRuntimeException63.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable61, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 100L, (-6107792616609456200L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray72);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException1, localizable32, localizable58, objArray72);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException74);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str4.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str20.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str27.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable28);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str47.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str66.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getTwo();
        int int8 = dfp7.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 25 + "'", int8 == 25);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999500037496876d + "'", double1 == 0.9999500037496876d);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-7818156871194313210L));
//        mersenneTwister1.setSeed((int) (byte) 2);
//        boolean boolean4 = mersenneTwister1.nextBoolean();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        long long6 = mersenneTwister5.nextLong();
//        byte[] byteArray7 = new byte[] {};
//        mersenneTwister5.nextBytes(byteArray7);
//        mersenneTwister1.nextBytes(byteArray7);
//        long long10 = mersenneTwister1.nextLong();
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1277750592439784075L) + "'", long6 == (-1277750592439784075L));
//        org.junit.Assert.assertNotNull(byteArray7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 478254495130285640L + "'", long10 == 478254495130285640L);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        dfpField7.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp((-0.8390715290764524d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.1624368094182825d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15051849951230298d + "'", double1 == 0.15051849951230298d);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test370");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        byte[] byteArray2 = new byte[] {};
//        mersenneTwister0.nextBytes(byteArray2);
//        mersenneTwister0.setSeed((-982170359));
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 373282293730354937L + "'", long1 == 373282293730354937L);
//        org.junit.Assert.assertNotNull(byteArray2);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1517226581673408134L, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1630432221962219593L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double1 = org.apache.commons.math.util.FastMath.signum(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-328395919939559869L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1 };
        mersenneTwister0.nextBytes(byteArray3);
        mersenneTwister0.setSeed((-7818156871194313210L));
        long long7 = mersenneTwister0.nextLong();
        long long8 = mersenneTwister0.nextLong();
        double double9 = mersenneTwister0.nextDouble();
        int int10 = mersenneTwister0.nextInt();
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8268936713059271116L + "'", long7 == 8268936713059271116L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4110537376165046573L + "'", long8 == 4110537376165046573L);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5998625503980863d + "'", double9 == 0.5998625503980863d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 129442498 + "'", int10 == 129442498);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.nextAfter(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        int int11 = dfp9.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((double) (-2734267132836942420L));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp2.getField();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.newInstance((byte) 3, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.newInstance();
        int int14 = dfp12.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.000000000000001d + "'", double1 == 4.000000000000001d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.63043222196221952E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1425631994344677482L));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        int int2 = org.apache.commons.math.util.FastMath.max(46777259, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46777259 + "'", int2 == 46777259);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9319894568729709d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7315200982219324d + "'", double1 == 0.7315200982219324d);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1 };
//        mersenneTwister0.nextBytes(byteArray3);
//        mersenneTwister0.setSeed((-7818156871194313210L));
//        long long7 = mersenneTwister0.nextLong();
//        int int8 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed(100L);
//        double double11 = mersenneTwister0.nextGaussian();
//        byte[] byteArray15 = new byte[] { (byte) 1, (byte) 3, (byte) 1 };
//        mersenneTwister0.nextBytes(byteArray15);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister();
//        long long18 = mersenneTwister17.nextLong();
//        byte[] byteArray19 = new byte[] {};
//        mersenneTwister17.nextBytes(byteArray19);
//        mersenneTwister0.nextBytes(byteArray19);
//        org.junit.Assert.assertNotNull(byteArray3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8268936713059271116L + "'", long7 == 8268936713059271116L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 957059063 + "'", int8 == 957059063);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9086743489308475d + "'", double11 == 0.9086743489308475d);
//        org.junit.Assert.assertNotNull(byteArray15);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 106109283382440669L + "'", long18 == 106109283382440669L);
//        org.junit.Assert.assertNotNull(byteArray19);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int2 = org.apache.commons.math.util.FastMath.max(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        float float2 = org.apache.commons.math.util.FastMath.max(0.9480299f, 3.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.154262241479262d + "'", double1 == 14.154262241479262d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.sqrt();
        java.lang.String str8 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((-1L));
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp17.getField();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField26 = dfp25.getField();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.subtract(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp10.newInstance(dfp27);
        double[] doubleArray29 = dfp28.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str8.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpField26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        int int9 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getE();
        double double12 = dfp11.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 25 + "'", int9 == 25);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.718281828459045d + "'", double12 == 2.718281828459045d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.01745417862959511d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5533412618126596d + "'", double1 == 1.5533412618126596d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.6420579237750788d));
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1.642 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1.642 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-2621438453848704568L), (float) 8L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.62143858E18f) + "'", float2 == (-2.62143858E18f));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 8 is smaller than the minimum (4.504)");
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 0, (byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) '#');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 8268936713059271116L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math.util.FastMath.log(0.7315200982219324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.31263058354474055d) + "'", double1 == (-0.31263058354474055d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp15 = dfp10.divide(dfp14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.nextAfter(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp28.getField();
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.sqrt();
        java.lang.String str51 = dfp45.toString();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp54 = dfp45.ceil();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp42.add(dfp54);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp11.dotrap((int) (byte) 0, "org.apache.commons.math.exception.NotStrictlyPositiveException: � is smaller than, or equal to, the minimum (0)", dfp33, dfp54);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField58.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        org.apache.commons.math.dfp.DfpField dfpField73 = dfp72.getField();
        int int74 = dfpField73.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField73.getLn2();
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField58.newDfp(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp33.nextAfter(dfp76);
        java.lang.String str78 = dfp33.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str51.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfpField73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 16 + "'", int74 == 16);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "-1." + "'", str78.equals("-1."));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        java.lang.Throwable[] throwableArray12 = mathRuntimeException11.getSuppressed();
        java.lang.Throwable[] throwableArray13 = mathRuntimeException11.getSuppressed();
        java.lang.String str14 = mathRuntimeException11.toString();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException11.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable9, (java.lang.Object[]) throwableArray15);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathIllegalArgumentException16);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str14.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 3534866348766186856L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.40235434509963d + "'", double1 == 43.40235434509963d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-2.142400300691264d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9728216820437663d) + "'", double1 == (-0.9728216820437663d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.floor();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10000);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10000L + "'", long1 == 10000L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251568E-16d + "'", double1 == 1.1102230246251568E-16d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int int3 = mersenneTwister1.nextInt(8);
        mersenneTwister1.setSeed((int) (short) 10);
        boolean boolean6 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int[] intArray14 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
        mersenneTwister8.setSeed(intArray14);
        int int17 = mersenneTwister8.nextInt(10);
        mersenneTwister8.setSeed(7790688011124847161L);
        byte[] byteArray20 = new byte[] {};
        mersenneTwister8.nextBytes(byteArray20);
        mersenneTwister1.nextBytes(byteArray20);
        int int24 = mersenneTwister1.nextInt(1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(byteArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(37);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) 16);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.power10(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.newInstance((-982170359));
        int int15 = dfp8.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(100L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.newInstance();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9999932988344528d, (java.lang.Number) 32760, true);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        dfpField1.setIEEEFlags(32760);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        int int4 = dfp3.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable9);
        java.lang.Throwable[] throwableArray11 = mathRuntimeException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException10.getSuppressed();
        java.lang.String str13 = mathRuntimeException10.toString();
        java.lang.Throwable[] throwableArray14 = mathRuntimeException10.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable5, localizable8, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = mathRuntimeException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = mathRuntimeException16.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertNull(localizable18);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.538970890562367d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.2225952648614675d) + "'", double1 == (-2.2225952648614675d));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        int int1 = org.apache.commons.math.util.FastMath.round(0.9480299f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp6.sqrt();
        org.apache.commons.math.dfp.Dfp dfp12 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp13 = dfp6.divide(dfp12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        int[] intArray6 = new int[] { 0, (short) 10, '4', (byte) 100 };
//        mersenneTwister0.setSeed(intArray6);
//        long long8 = mersenneTwister0.nextLong();
//        byte[] byteArray9 = null;
//        try {
//            mersenneTwister0.nextBytes(byteArray9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1369387637387361113L + "'", long1 == 1369387637387361113L);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2610318892780885621L + "'", long8 == 2610318892780885621L);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 100);
        mathRuntimeException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException4);
        java.lang.Number number6 = notStrictlyPositiveException4.getArgument();
        java.lang.Number number7 = notStrictlyPositiveException4.getArgument();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100 + "'", number6.equals(100));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100 + "'", number7.equals(100));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        double double2 = mersenneTwister1.nextGaussian();
        double double3 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0553194731804223d + "'", double2 == 1.0553194731804223d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1653253813890907d + "'", double3 == 0.1653253813890907d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.nextAfter(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        int int11 = dfpField10.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getLn2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp17.nextAfter(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.sqrt();
        java.lang.String str32 = dfp26.toString();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp26.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp35 = dfp26.ceil();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp23.add(dfp35);
        boolean boolean37 = dfp12.unequal(dfp23);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp23.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField1.newDfp(dfp39);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 16 + "'", int11 == 16);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str32.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-6.1077925898538189E18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.newInstance("hi!");
        boolean boolean41 = dfp40.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49536728921867335d + "'", double1 == 0.49536728921867335d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 0.9262160379374064d);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3Reciprocal();
        int int12 = dfpField7.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(25);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        long long1 = org.apache.commons.math.util.FastMath.round(9910.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9910L + "'", long1 == 9910L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        long long2 = org.apache.commons.math.util.FastMath.max(8268936713059271116L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8268936713059271116L + "'", long2 == 8268936713059271116L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp17.getField();
        int int19 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField32 = dfp31.getField();
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.nextAfter(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp38.sqrt();
        java.lang.String str44 = dfp38.toString();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp38.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp47 = dfp38.ceil();
        boolean boolean48 = dfp31.greaterThan(dfp38);
        boolean boolean49 = dfp20.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp31.newInstance("hi!");
        boolean boolean52 = dfp6.unequal(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.newInstance(10L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str44.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.109633684f);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable12);
        java.lang.Throwable[] throwableArray14 = mathRuntimeException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException13.getSuppressed();
        java.lang.String str16 = mathRuntimeException13.toString();
        java.lang.Throwable[] throwableArray17 = mathRuntimeException13.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException5, localizable8, localizable11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable29 = notStrictlyPositiveException28.getGeneralPattern();
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException(throwable30);
        java.lang.Throwable[] throwableArray32 = mathRuntimeException31.getSuppressed();
        java.lang.Throwable[] throwableArray33 = mathRuntimeException31.getSuppressed();
        java.lang.String str34 = mathRuntimeException31.toString();
        java.lang.Throwable[] throwableArray35 = mathRuntimeException31.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException23, localizable26, localizable29, (java.lang.Object[]) throwableArray35);
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable26, objArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3);
        java.lang.Object[] objArray42 = notStrictlyPositiveException41.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException43 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable26, localizable39, objArray42);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str34.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        int int1 = org.apache.commons.math.util.FastMath.round(52.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.util.FastMath.acosh(11013.23292010332d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.6420579237750788d));
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.0d), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 100);
        mathRuntimeException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException4);
        java.lang.Number number6 = notStrictlyPositiveException4.getArgument();
        java.lang.String str7 = notStrictlyPositiveException4.toString();
        java.lang.Throwable[] throwableArray8 = notStrictlyPositiveException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100 + "'", number6.equals(100));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str7.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((double) (-1L));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-328395919939559869L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 64.0d + "'", double1 == 64.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        dfpField7.clearIEEEFlags();
        dfpField7.setIEEEFlagsBits((-982170359));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField7.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int int3 = mersenneTwister1.nextInt(8);
        mersenneTwister1.setSeed((int) (short) 10);
        long long6 = mersenneTwister1.nextLong();
        long long7 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4218389569722409859L) + "'", long6 == (-4218389569722409859L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 382805850191655439L + "'", long7 == 382805850191655439L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = new org.apache.commons.math.dfp.Dfp(dfp18);
        java.lang.String str20 = dfp18.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2." + "'", str20.equals("2."));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        java.lang.Throwable[] throwableArray2 = mathRuntimeException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = mathRuntimeException1.getSuppressed();
        java.lang.String str4 = mathRuntimeException1.toString();
        java.lang.Throwable[] throwableArray5 = mathRuntimeException1.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathRuntimeException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException(throwable16);
        java.lang.Throwable[] throwableArray18 = mathRuntimeException17.getSuppressed();
        java.lang.Throwable[] throwableArray19 = mathRuntimeException17.getSuppressed();
        java.lang.String str20 = mathRuntimeException17.toString();
        java.lang.Throwable[] throwableArray21 = mathRuntimeException17.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException9, localizable12, localizable15, (java.lang.Object[]) throwableArray21);
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException(throwable23);
        java.lang.Throwable[] throwableArray25 = mathRuntimeException24.getSuppressed();
        java.lang.Throwable[] throwableArray26 = mathRuntimeException24.getSuppressed();
        java.lang.String str27 = mathRuntimeException24.toString();
        org.apache.commons.math.exception.util.Localizable localizable28 = mathRuntimeException24.getGeneralPattern();
        mathRuntimeException22.addSuppressed((java.lang.Throwable) mathRuntimeException24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable32, (java.lang.Number) (-4.21838956972241E18d), (java.lang.Number) 5.0f, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable39 = notStrictlyPositiveException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getGeneralPattern();
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException(throwable43);
        java.lang.Throwable[] throwableArray45 = mathRuntimeException44.getSuppressed();
        java.lang.Throwable[] throwableArray46 = mathRuntimeException44.getSuppressed();
        java.lang.String str47 = mathRuntimeException44.toString();
        java.lang.Throwable[] throwableArray48 = mathRuntimeException44.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable42, (java.lang.Object[]) throwableArray48);
        java.lang.Throwable throwable50 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.exception.MathRuntimeException(throwable50);
        java.lang.Throwable[] throwableArray52 = mathRuntimeException51.getSuppressed();
        java.lang.Throwable[] throwableArray53 = mathRuntimeException51.getSuppressed();
        java.lang.Class<?> wildcardClass54 = throwableArray53.getClass();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException24, localizable32, localizable39, (java.lang.Object[]) throwableArray53);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable58 = notStrictlyPositiveException57.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable61 = notStrictlyPositiveException60.getGeneralPattern();
        java.lang.Throwable throwable62 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException63 = new org.apache.commons.math.exception.MathRuntimeException(throwable62);
        java.lang.Throwable[] throwableArray64 = mathRuntimeException63.getSuppressed();
        java.lang.Throwable[] throwableArray65 = mathRuntimeException63.getSuppressed();
        java.lang.String str66 = mathRuntimeException63.toString();
        java.lang.Throwable[] throwableArray67 = mathRuntimeException63.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable61, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 100L, (-6107792616609456200L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray72);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException74 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException1, localizable32, localizable58, objArray72);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) (-6369652980407488457L));
        boolean boolean77 = notStrictlyPositiveException76.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str4.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str20.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str27.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable28);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str47.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray64);
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str66.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp9.newInstance((double) 16);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.nextAfter(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField48 = dfp47.getField();
        int int49 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn2();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp57.nextAfter(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField62 = dfp61.getField();
        int int63 = dfp61.log10();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp61.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp68.sqrt();
        java.lang.String str74 = dfp68.toString();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp68.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp77 = dfp68.ceil();
        boolean boolean78 = dfp61.greaterThan(dfp68);
        boolean boolean79 = dfp50.greaterThan(dfp61);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp61.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp82 = dfp9.newInstance(dfp61);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp85 = dfp83.newInstance((long) 32768);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpField62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str74.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp85);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable9);
        java.lang.Throwable[] throwableArray11 = mathRuntimeException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException10.getSuppressed();
        java.lang.String str13 = mathRuntimeException10.toString();
        java.lang.Throwable[] throwableArray14 = mathRuntimeException10.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable5, localizable8, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException(throwable27);
        java.lang.Throwable[] throwableArray29 = mathRuntimeException28.getSuppressed();
        java.lang.Throwable[] throwableArray30 = mathRuntimeException28.getSuppressed();
        java.lang.String str31 = mathRuntimeException28.toString();
        java.lang.Throwable[] throwableArray32 = mathRuntimeException28.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException20, localizable23, localizable26, (java.lang.Object[]) throwableArray32);
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable23, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException37.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField40.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField40.newDfp(37);
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField40.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable38, (java.lang.Object[]) dfpArray48);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str31.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray48);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math.util.FastMath.cos(11013.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14642450064787196d + "'", double1 == 0.14642450064787196d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 647325673);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.98150726496074d + "'", double1 == 20.98150726496074d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.sqrt();
        java.lang.String str8 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField19 = dfp18.getField();
        int int20 = dfpField19.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getLn2();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.nextAfter(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField33 = dfp32.getField();
        int int34 = dfp32.log10();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp32.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp39.nextAfter(dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.sqrt();
        java.lang.String str45 = dfp39.toString();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp39.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp48 = dfp39.ceil();
        boolean boolean49 = dfp32.greaterThan(dfp39);
        boolean boolean50 = dfp21.greaterThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp32.power10K((-32767));
        boolean boolean53 = dfp2.greaterThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp32.newInstance(1.0553194731804223d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str8.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpField33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str45.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getLn10();
        int int21 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.732511156817248d + "'", double1 == 3.732511156817248d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 5.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1277750592439784075L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.27775059243978419E18d) + "'", double1 == (-1.27775059243978419E18d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.negate();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.DfpField.computeExp(dfp10, dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 25 + "'", int6 == 25);
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextGaussian();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.312790981236238d) + "'", double1 == (-0.312790981236238d));
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.026870329829671d + "'", double1 == 0.026870329829671d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp6.sqrt();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(10000);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.floor();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(0.2593979097038225d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.sqrt();
        java.lang.String str17 = dfp11.toString();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp20 = dfp11.ceil();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp8.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance((byte) -1, (byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str17.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.rint();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        dfpField7.clearIEEEFlags();
        dfpField7.setIEEEFlagsBits((-982170359));
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField7.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp17.getField();
        int int19 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.divide(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.negate();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField28.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField28.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getZero();
        int int37 = dfp36.classify();
        boolean boolean38 = dfp24.unequal(dfp36);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8342233605065102d + "'", double1 == 0.8342233605065102d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 90.0d + "'", double1 == 90.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math.util.FastMath.abs(847.0542677499278d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 847.0542677499278d + "'", double1 == 847.0542677499278d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        int int1 = org.apache.commons.math.util.FastMath.abs(129442498);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 129442498 + "'", int1 == 129442498);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.rint();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        double double25 = dfp24.toDouble();
        boolean boolean26 = dfp21.greaterThan(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = null;
        try {
            boolean boolean28 = dfp24.greaterThan(dfp27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.4142135623730951d + "'", double25 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 106109283382440669L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 39.203245933238755d + "'", double1 == 39.203245933238755d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 187580283381577613L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) (-4.21838956972241E18d), (java.lang.Number) 5.0f, false);
        java.lang.Number number7 = numberIsTooSmallException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException12.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException15.getGeneralPattern();
        java.lang.Throwable throwable17 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException(throwable17);
        java.lang.Throwable[] throwableArray19 = mathRuntimeException18.getSuppressed();
        java.lang.Throwable[] throwableArray20 = mathRuntimeException18.getSuppressed();
        java.lang.String str21 = mathRuntimeException18.toString();
        java.lang.Throwable[] throwableArray22 = mathRuntimeException18.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException10, localizable13, localizable16, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable31 = notStrictlyPositiveException30.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        java.lang.Throwable throwable35 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.exception.MathRuntimeException(throwable35);
        java.lang.Throwable[] throwableArray37 = mathRuntimeException36.getSuppressed();
        java.lang.Throwable[] throwableArray38 = mathRuntimeException36.getSuppressed();
        java.lang.String str39 = mathRuntimeException36.toString();
        java.lang.Throwable[] throwableArray40 = mathRuntimeException36.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException28, localizable31, localizable34, (java.lang.Object[]) throwableArray40);
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable31, objArray42);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) 2.302585092994046d, (java.lang.Number) 0.7615941559557649d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Throwable throwable53 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.exception.MathRuntimeException(throwable53);
        java.lang.Throwable[] throwableArray55 = mathRuntimeException54.getSuppressed();
        java.lang.Throwable[] throwableArray56 = mathRuntimeException54.getSuppressed();
        java.lang.String str57 = mathRuntimeException54.toString();
        java.lang.Throwable[] throwableArray58 = mathRuntimeException54.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable52, (java.lang.Object[]) throwableArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, (java.lang.Object[]) throwableArray58);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray64 = new java.lang.Object[] { 100L, (-6107792616609456200L) };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable61, objArray64);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException66 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException6, localizable31, localizable50, objArray64);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-4.21838956972241E18d) + "'", number7.equals((-4.21838956972241E18d)));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str21.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str39.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str57.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(objArray64);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100L, (float) 4749738130787047444L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable12);
        java.lang.Throwable[] throwableArray14 = mathRuntimeException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException13.getSuppressed();
        java.lang.String str16 = mathRuntimeException13.toString();
        java.lang.Throwable[] throwableArray17 = mathRuntimeException13.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException5, localizable8, localizable11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 0.8726936208978296d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField25.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable8, localizable23, (java.lang.Object[]) dfpArray30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField33.newDfp(37);
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField33.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, (java.lang.Object[]) dfpArray41);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpArray41);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        dfpField7.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        dfpField1.setIEEEFlags(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getZero();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        int int18 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.nextAfter(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.sqrt();
        java.lang.String str39 = dfp33.toString();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp33.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp42 = dfp33.ceil();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp30.add(dfp42);
        boolean boolean44 = dfp19.unequal(dfp30);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp30.divide(8);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp49.nextAfter(dfp52);
        org.apache.commons.math.dfp.DfpField dfpField54 = dfp53.getField();
        int int55 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getLn2();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp56.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField60.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp61.nextAfter(dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp58.add(dfp65);
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.DfpField.computeLn(dfp9, dfp46, dfp58);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp73.newInstance((double) 37);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp75.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp67.newInstance(dfp77);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str39.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpField54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 16 + "'", int55 == 16);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.floor();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.nextAfter(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp12.getField();
        int int14 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.getLn10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.negate();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeExp(dfp16, dfp20);
        int int22 = dfp20.intValue();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 10);
        boolean boolean28 = dfp20.unequal(dfp27);
        boolean boolean29 = dfp2.greaterThan(dfp20);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn10();
        boolean boolean19 = dfp8.unequal(dfp18);
        int int20 = dfp8.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(35L);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.nextAfter(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField20 = dfp19.getField();
        int int21 = dfpField20.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.getLn10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp((double) (-2.62143858E18f));
        org.apache.commons.math.dfp.Dfp dfp25 = dfp12.subtract(dfp24);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 16 + "'", int21 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-982170359L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.63043222196221952E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.63043222196221952E18d + "'", double1 == 1.63043222196221952E18d);
    }
}

