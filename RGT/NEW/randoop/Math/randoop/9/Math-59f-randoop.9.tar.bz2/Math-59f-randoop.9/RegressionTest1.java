import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
//        int int3 = mersenneTwister1.nextInt(8);
//        mersenneTwister1.setSeed((int) (short) 10);
//        boolean boolean6 = mersenneTwister1.nextBoolean();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
//        int[] intArray14 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
//        mersenneTwister8.setSeed(intArray14);
//        int int17 = mersenneTwister8.nextInt(10);
//        mersenneTwister8.setSeed(7790688011124847161L);
//        byte[] byteArray20 = new byte[] {};
//        mersenneTwister8.nextBytes(byteArray20);
//        mersenneTwister1.nextBytes(byteArray20);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister();
//        double double24 = mersenneTwister23.nextDouble();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister26 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
//        int[] intArray32 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
//        mersenneTwister26.setSeed(intArray32);
//        int int35 = mersenneTwister26.nextInt(10);
//        mersenneTwister26.setSeed(7790688011124847161L);
//        byte[] byteArray38 = new byte[] {};
//        mersenneTwister26.nextBytes(byteArray38);
//        mersenneTwister23.nextBytes(byteArray38);
//        mersenneTwister1.nextBytes(byteArray38);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertNotNull(byteArray20);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.386661622254703d + "'", double24 == 0.386661622254703d);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 8 + "'", int35 == 8);
//        org.junit.Assert.assertNotNull(byteArray38);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.14642450064787196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.389505904433651d + "'", double1 == 8.389505904433651d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-2703834685075141616L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp("100.");
        boolean boolean12 = dfp11.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp39 = new org.apache.commons.math.dfp.Dfp(dfp20);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField22.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp32.nextAfter(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        int int38 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getLn2();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField22.newDfp(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.nextAfter(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField48 = dfp47.getField();
        int int49 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn2();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp39.multiply(dfp50);
        boolean boolean54 = dfp20.lessThan(dfp53);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp53.power10(12);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getTwo();
        java.lang.String str20 = dfp19.toString();
        boolean boolean21 = dfp10.lessThan(dfp19);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2." + "'", str20.equals("2."));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.48045301391820144d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6168066722416747d + "'", double1 == 1.6168066722416747d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int1 = org.apache.commons.math.util.FastMath.abs(607762227);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 607762227 + "'", int1 == 607762227);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable9);
        java.lang.Throwable[] throwableArray11 = mathRuntimeException10.getSuppressed();
        java.lang.Throwable[] throwableArray12 = mathRuntimeException10.getSuppressed();
        java.lang.String str13 = mathRuntimeException10.toString();
        java.lang.Throwable[] throwableArray14 = mathRuntimeException10.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2, localizable5, localizable8, (java.lang.Object[]) throwableArray14);
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException(throwable16);
        java.lang.Throwable[] throwableArray18 = mathRuntimeException17.getSuppressed();
        java.lang.Throwable[] throwableArray19 = mathRuntimeException17.getSuppressed();
        java.lang.String str20 = mathRuntimeException17.toString();
        org.apache.commons.math.exception.util.Localizable localizable21 = mathRuntimeException17.getGeneralPattern();
        mathRuntimeException15.addSuppressed((java.lang.Throwable) mathRuntimeException17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (-4.21838956972241E18d), (java.lang.Number) 5.0f, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException34.getGeneralPattern();
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException(throwable36);
        java.lang.Throwable[] throwableArray38 = mathRuntimeException37.getSuppressed();
        java.lang.Throwable[] throwableArray39 = mathRuntimeException37.getSuppressed();
        java.lang.String str40 = mathRuntimeException37.toString();
        java.lang.Throwable[] throwableArray41 = mathRuntimeException37.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable35, (java.lang.Object[]) throwableArray41);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.exception.MathRuntimeException(throwable43);
        java.lang.Throwable[] throwableArray45 = mathRuntimeException44.getSuppressed();
        java.lang.Throwable[] throwableArray46 = mathRuntimeException44.getSuppressed();
        java.lang.Class<?> wildcardClass47 = throwableArray46.getClass();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException17, localizable25, localizable32, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException53 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable54 = notStrictlyPositiveException53.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException56.getGeneralPattern();
        java.lang.Throwable throwable58 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.exception.MathRuntimeException(throwable58);
        java.lang.Throwable[] throwableArray60 = mathRuntimeException59.getSuppressed();
        java.lang.Throwable[] throwableArray61 = mathRuntimeException59.getSuppressed();
        java.lang.String str62 = mathRuntimeException59.toString();
        java.lang.Throwable[] throwableArray63 = mathRuntimeException59.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException64 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException51, localizable54, localizable57, (java.lang.Object[]) throwableArray63);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable57, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable67, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable72 = notStrictlyPositiveException71.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable75 = notStrictlyPositiveException74.getGeneralPattern();
        java.lang.Throwable throwable76 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.exception.MathRuntimeException(throwable76);
        java.lang.Throwable[] throwableArray78 = mathRuntimeException77.getSuppressed();
        java.lang.Throwable[] throwableArray79 = mathRuntimeException77.getSuppressed();
        java.lang.String str80 = mathRuntimeException77.toString();
        java.lang.Throwable[] throwableArray81 = mathRuntimeException77.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException82 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException69, localizable72, localizable75, (java.lang.Object[]) throwableArray81);
        java.lang.Object[] objArray83 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable72, objArray83);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Throwable throwable86 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException87 = new org.apache.commons.math.exception.MathRuntimeException(throwable86);
        java.lang.Throwable[] throwableArray88 = mathRuntimeException87.getSuppressed();
        java.lang.Throwable[] throwableArray89 = mathRuntimeException87.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable85, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable72, (java.lang.Object[]) throwableArray89);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str20.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str40.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str62.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable75.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertNotNull(throwableArray79);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str80.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray81);
        org.junit.Assert.assertNotNull(throwableArray88);
        org.junit.Assert.assertNotNull(throwableArray89);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 100);
        mathRuntimeException1.addSuppressed((java.lang.Throwable) notStrictlyPositiveException4);
        java.lang.Throwable[] throwableArray6 = mathRuntimeException1.getSuppressed();
        java.lang.Object[] objArray7 = mathRuntimeException1.getArguments();
        java.lang.Throwable[] throwableArray8 = mathRuntimeException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray3 = new byte[] { (byte) 100, (byte) -1 };
        mersenneTwister0.nextBytes(byteArray3);
        mersenneTwister0.setSeed((-7818156871194313210L));
        long long7 = mersenneTwister0.nextLong();
        long long8 = mersenneTwister0.nextLong();
        double double9 = mersenneTwister0.nextGaussian();
        double double10 = mersenneTwister0.nextDouble();
        int int12 = mersenneTwister0.nextInt(46777259);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8268936713059271116L + "'", long7 == 8268936713059271116L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4110537376165046573L + "'", long8 == 4110537376165046573L);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.142400300691264d) + "'", double9 == (-2.142400300691264d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.13159516695465978d + "'", double10 == 0.13159516695465978d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3984269 + "'", int12 == 3984269);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.732511156817248d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06514460905388338d + "'", double1 == 0.06514460905388338d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField22.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp32.nextAfter(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField37 = dfp36.getField();
        int int38 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getLn2();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField22.newDfp(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.nextAfter(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField48 = dfp47.getField();
        int int49 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn2();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp39.multiply(dfp50);
        boolean boolean54 = dfp20.lessThan(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = new org.apache.commons.math.dfp.Dfp(dfp53);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpField37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 16 + "'", int38 == 16);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        java.lang.Throwable[] throwableArray2 = mathRuntimeException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = mathRuntimeException1.getSuppressed();
        java.lang.String str4 = mathRuntimeException1.toString();
        java.lang.String str5 = mathRuntimeException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str4.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int1 = org.apache.commons.math.util.FastMath.abs(647325673);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 647325673 + "'", int1 == 647325673);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 16);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.99627207622075d + "'", double1 == 0.99627207622075d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed((-7818156871194313210L));
//        int int4 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8436211382915257318L + "'", long1 == 8436211382915257318L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1925261857 + "'", int4 == 1925261857);
//    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
//        double double2 = mersenneTwister1.nextDouble();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
//        long long4 = mersenneTwister3.nextLong();
//        byte[] byteArray5 = new byte[] {};
//        mersenneTwister3.nextBytes(byteArray5);
//        mersenneTwister1.nextBytes(byteArray5);
//        int int9 = mersenneTwister1.nextInt(2);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15071724896777527d + "'", double2 == 0.15071724896777527d);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3727654167419583162L + "'", long4 == 3727654167419583162L);
//        org.junit.Assert.assertNotNull(byteArray5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10000, (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        dfpField8.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.nextAfter(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp25.add(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = new org.apache.commons.math.dfp.Dfp(dfp33);
        try {
            org.apache.commons.math.dfp.Dfp dfp35 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp13, dfp33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        dfpField7.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp(0);
        dfpField7.setIEEEFlagsBits(647325673);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.newDfp(4749738130787047444L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.109633684f);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) '#');
        dfpField43.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.getLn2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField43.newDfp(1.791759469228055d);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.getTwo();
        boolean boolean51 = dfp20.lessThan(dfp50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp20.multiply(100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.27775059243978419E18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        float float2 = org.apache.commons.math.util.FastMath.max(0.9480299f, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField43.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField43.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp53.nextAfter(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField58 = dfp57.getField();
        int int59 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.getLn2();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField43.newDfp(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp64.nextAfter(dfp67);
        org.apache.commons.math.dfp.DfpField dfpField69 = dfp68.getField();
        int int70 = dfpField69.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField69.getLn2();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp60.multiply(dfp71);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp20.multiply(dfp71);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp75.newInstance((byte) 100, (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfpField58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfpField69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 16 + "'", int70 == 16);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp78);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        dfpField7.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) -1 };
        mersenneTwister2.nextBytes(byteArray5);
        mersenneTwister2.setSeed((-7818156871194313210L));
        long long9 = mersenneTwister2.nextLong();
        int int10 = mersenneTwister2.nextInt();
        mersenneTwister2.setSeed(100L);
        double double13 = mersenneTwister2.nextGaussian();
        byte[] byteArray17 = new byte[] { (byte) 1, (byte) 3, (byte) 1 };
        mersenneTwister2.nextBytes(byteArray17);
        mersenneTwister1.nextBytes(byteArray17);
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8268936713059271116L + "'", long9 == 8268936713059271116L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 957059063 + "'", int10 == 957059063);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9086743489308475d + "'", double13 == 0.9086743489308475d);
        org.junit.Assert.assertNotNull(byteArray17);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.nextAfter(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        int int11 = dfp9.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.floor((-4.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.0d) + "'", double1 == (-4.0d));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.rint();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        double double25 = dfp24.toDouble();
        boolean boolean26 = dfp21.greaterThan(dfp24);
        java.lang.Class<?> wildcardClass27 = dfp21.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.4142135623730951d + "'", double25 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp44.nextAfter(dfp47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp44.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField51 = dfp44.getField();
        boolean boolean52 = dfp20.lessThan(dfp44);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpField51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getSqr2();
        dfpField4.setIEEEFlagsBits(37);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.remainder(dfp14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.power10K((-32767));
        org.apache.commons.math.dfp.Dfp dfp42 = dfp20.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.power10(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        dfpField7.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField7.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.cos((-3.499507375399025E20d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8918644438309452d + "'", double1 == 0.8918644438309452d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9319894568729709d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03058900057283153d) + "'", double1 == (-0.03058900057283153d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100 + "'", number3.equals(100));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int int3 = mersenneTwister1.nextInt(8);
        mersenneTwister1.setSeed((int) (short) 10);
        boolean boolean6 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int[] intArray14 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
        mersenneTwister8.setSeed(intArray14);
        mersenneTwister1.setSeed(intArray14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 5 + "'", int3 == 5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        dfpField7.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        long long2 = org.apache.commons.math.util.FastMath.max(4123940248069761024L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4123940248069761024L + "'", long2 == 4123940248069761024L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(1.791759469228055d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException(throwable3);
        try {
            notStrictlyPositiveException1.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 5 + "'", number2.equals(5));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int1 = org.apache.commons.math.util.FastMath.round(5.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        java.lang.Throwable[] throwableArray12 = mathRuntimeException11.getSuppressed();
        java.lang.Throwable[] throwableArray13 = mathRuntimeException11.getSuppressed();
        java.lang.String str14 = mathRuntimeException11.toString();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException11.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable9, (java.lang.Object[]) throwableArray15);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathIllegalArgumentException16);
        java.lang.String str18 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str14.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: � is smaller than, or equal to, the minimum (0)" + "'", str18.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: � is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        float float2 = org.apache.commons.math.util.FastMath.min(10.0f, (float) 8L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(37);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((long) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp17.getField();
        int int19 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField32 = dfp31.getField();
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.nextAfter(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp38.sqrt();
        java.lang.String str44 = dfp38.toString();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp38.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp47 = dfp38.ceil();
        boolean boolean48 = dfp31.greaterThan(dfp38);
        boolean boolean49 = dfp20.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp31.newInstance("hi!");
        boolean boolean52 = dfp6.unequal(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.newInstance((long) 957059063);
        int int55 = dfp51.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str44.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable12);
        java.lang.Throwable[] throwableArray14 = mathRuntimeException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException13.getSuppressed();
        java.lang.String str16 = mathRuntimeException13.toString();
        java.lang.Throwable[] throwableArray17 = mathRuntimeException13.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException5, localizable8, localizable11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 0.8726936208978296d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField25.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable8, localizable23, (java.lang.Object[]) dfpArray30);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 0.3006322420239034d);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8280937250720333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int[] intArray7 = new int[] { 'a', (-32767), (-982170359), ' ', 1 };
        mersenneTwister1.setSeed(intArray7);
        boolean boolean9 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(46777259);
        org.apache.commons.math.dfp.Dfp dfp13 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp14 = dfp12.subtract(dfp13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.newInstance((int) (byte) -1);
        double[] doubleArray9 = dfp2.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        int int20 = dfp11.classify();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.ceil();
        boolean boolean25 = dfp11.lessThan(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField27.getLn2Split();
        boolean boolean34 = dfp24.equals((java.lang.Object) dfpArray33);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        int int9 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getE();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField19 = dfp18.getField();
        int int20 = dfpField19.getIEEEFlags();
        dfpField19.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField19.getRoundingMode();
        dfpField7.setRoundingMode(roundingMode23);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 25 + "'", int9 == 25);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfpField19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.03097623837805985d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((long) 8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        int int18 = dfpField17.getIEEEFlags();
        dfpField17.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.floor();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.newInstance((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp20.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.remainder(dfp24);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        int int2 = mersenneTwister1.nextInt();
        double double3 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 647325673 + "'", int2 == 647325673);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.3358343618944353d) + "'", double3 == (-1.3358343618944353d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField43.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField43.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp53.nextAfter(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField58 = dfp57.getField();
        int int59 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.getLn2();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField43.newDfp(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp64.nextAfter(dfp67);
        org.apache.commons.math.dfp.DfpField dfpField69 = dfp68.getField();
        int int70 = dfpField69.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField69.getLn2();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp60.multiply(dfp71);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp20.multiply(dfp71);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField77.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField80.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp82 = dfp78.nextAfter(dfp81);
        org.apache.commons.math.dfp.DfpField dfpField83 = dfp82.getField();
        int int84 = dfpField83.getIEEEFlags();
        dfpField83.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp86 = dfpField83.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField88 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField88.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp90 = dfp89.floor();
        org.apache.commons.math.dfp.Dfp dfp93 = dfp90.newInstance((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp94 = dfp86.divide(dfp90);
        boolean boolean95 = dfp20.equals((java.lang.Object) dfp86);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfpField58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfpField69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 16 + "'", int70 == 16);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfpField83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 16 + "'", int84 == 16);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.sqrt();
        java.lang.String str8 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp11 = dfp2.ceil();
        java.lang.Class<?> wildcardClass12 = dfp2.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str8.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0.59986246f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403183590760151d + "'", double1 == 0.5403183590760151d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        dfpField1.setIEEEFlagsBits(37);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(14.154262241479262d);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.sqrt();
        java.lang.String str8 = dfp2.toString();
        int int9 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp2.newInstance((byte) 10, (byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str8.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 8436211382915257318L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2035709.5673202416d + "'", double1 == 2035709.5673202416d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(46777259);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.floor();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfpField21.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.nextAfter(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField35 = dfp34.getField();
        int int36 = dfp34.log10();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp34.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp41.nextAfter(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.sqrt();
        java.lang.String str47 = dfp41.toString();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp41.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp50 = dfp41.ceil();
        boolean boolean51 = dfp34.greaterThan(dfp41);
        boolean boolean52 = dfp23.greaterThan(dfp34);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp23.newInstance((double) 16);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp10.newInstance(dfp55);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 16 + "'", int22 == 16);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str47.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2246467991473532E-16d + "'", double1 == 1.2246467991473532E-16d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        int int11 = dfp10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp13 = dfp10.subtract(dfp12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 25 + "'", int11 == 25);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        int int17 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.nextAfter(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp28.getField();
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp33.add(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = new org.apache.commons.math.dfp.Dfp(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.rint();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr2();
        double double47 = dfp46.toDouble();
        boolean boolean48 = dfp43.greaterThan(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.getTwo();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField1.newDfp(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp53.nextAfter(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField58 = dfp57.getField();
        int int59 = dfpField58.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.getPi();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.getLn10();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.newDfp((byte) 3);
        boolean boolean64 = dfp46.lessThan(dfp63);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.4142135623730951d + "'", double47 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfpField58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        int int18 = dfpField17.getIEEEFlags();
        dfpField17.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.floor();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.newInstance((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp20.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.add(dfp28);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.504343770629639d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.ceil();
        boolean boolean5 = dfp3.equals((java.lang.Object) 8.389505904433651d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = new org.apache.commons.math.dfp.Dfp(dfp2);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp17.getField();
        int int19 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.divide(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.negate();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.nextAfter(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.newInstance((int) (byte) -1);
        int int9 = dfp8.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp((double) 4);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.add(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.nextAfter(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp28.getField();
        int int30 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.sqrt();
        java.lang.String str51 = dfp45.toString();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp54 = dfp45.ceil();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp42.add(dfp54);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp11.dotrap((int) (byte) 0, "org.apache.commons.math.exception.NotStrictlyPositiveException: � is smaller than, or equal to, the minimum (0)", dfp33, dfp54);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField58.newDfp(37);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        org.apache.commons.math.dfp.DfpField dfpField73 = dfp72.getField();
        int int74 = dfpField73.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField73.getLn2();
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField58.newDfp(dfp75);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp33.nextAfter(dfp76);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException79 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3);
        org.apache.commons.math.exception.util.Localizable localizable80 = notStrictlyPositiveException79.getGeneralPattern();
        boolean boolean81 = dfp33.equals((java.lang.Object) notStrictlyPositiveException79);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 16 + "'", int30 == 16);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str51.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfpField73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 16 + "'", int74 == 16);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        dfpField7.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField7.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        dfpField1.setIEEEFlagsBits(37);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(14.154262241479262d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.1624368094182825d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1617234159568008d + "'", double1 == 0.1617234159568008d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) Double.NaN);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable10);
        java.lang.Throwable[] throwableArray12 = mathRuntimeException11.getSuppressed();
        java.lang.Throwable[] throwableArray13 = mathRuntimeException11.getSuppressed();
        java.lang.String str14 = mathRuntimeException11.toString();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException11.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable9, (java.lang.Object[]) throwableArray15);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) mathIllegalArgumentException16);
        boolean boolean18 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str14.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', 0.07871711f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.07871711f + "'", float2 == 0.07871711f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.nextAfter(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        int int15 = dfpField14.getIEEEFlags();
        dfpField14.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField14.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField14.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode20);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp9.newInstance((double) 16);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.nextAfter(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField48 = dfp47.getField();
        int int49 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn2();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp57.nextAfter(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField62 = dfp61.getField();
        int int63 = dfp61.log10();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp61.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp68.sqrt();
        java.lang.String str74 = dfp68.toString();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp68.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp77 = dfp68.ceil();
        boolean boolean78 = dfp61.greaterThan(dfp68);
        boolean boolean79 = dfp50.greaterThan(dfp61);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp61.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp82 = dfp9.newInstance(dfp61);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp84 = dfp83.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpField62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str74.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        float float2 = org.apache.commons.math.util.FastMath.min(10.0f, 0.22283256f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.22283256f + "'", float2 == 0.22283256f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 32760, (-4.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32760.0d + "'", double2 == 32760.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField7.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getSqr2();
        dfpField4.setIEEEFlagsBits(37);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp10.multiply(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.newInstance(3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1277750592439784075L), 9909.82534330317d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.27775059243978419E18d) + "'", double2 == (-1.27775059243978419E18d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp10.getField();
        int int12 = dfpField11.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getLn2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.divide(0);
        int int18 = dfp13.log10K();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp13.newInstance((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp13.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp13.newInstance((byte) 10, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField1.newDfp(dfp13);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        dfpField7.setIEEEFlags((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3534866348766186856L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp2.sqrt();
        java.lang.String str8 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp2.newInstance((-1L));
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp17.getField();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField26 = dfp25.getField();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.subtract(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp10.newInstance(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp10.getTwo();
        boolean boolean31 = dfp29.equals((java.lang.Object) 46777259);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField35.newDfp("hi!");
        dfpField35.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField35.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField35.newDfp(37);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField35.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp48.nextAfter(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp48.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField55 = dfp48.getField();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp48.newInstance((byte) 3, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp29.dotrap(0, "", dfp45, dfp58);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str8.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpField26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfpField55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.floor();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.newInstance((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        dfpField7.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField7.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.sqrt();
        java.lang.String str17 = dfp11.toString();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp20 = dfp11.ceil();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp8.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.newInstance(0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str17.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.302585092994046d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException9.getGeneralPattern();
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException(throwable11);
        java.lang.Throwable[] throwableArray13 = mathRuntimeException12.getSuppressed();
        java.lang.Throwable[] throwableArray14 = mathRuntimeException12.getSuppressed();
        java.lang.String str15 = mathRuntimeException12.toString();
        java.lang.Throwable[] throwableArray16 = mathRuntimeException12.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException4, localizable7, localizable10, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException(throwable24);
        java.lang.Throwable[] throwableArray26 = mathRuntimeException25.getSuppressed();
        java.lang.Throwable[] throwableArray27 = mathRuntimeException25.getSuppressed();
        java.lang.String str28 = mathRuntimeException25.toString();
        java.lang.Throwable[] throwableArray29 = mathRuntimeException25.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable23, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField32.newDfp((byte) 2, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField32.newDfp(37);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField32.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable7, localizable23, (java.lang.Object[]) dfpArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp48.nextAfter(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField53 = dfp52.getField();
        int int54 = dfpField53.getIEEEFlags();
        dfpField53.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField53.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode57 = dfpField53.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField53.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException41, localizable42, localizable45, (java.lang.Object[]) dfpArray58);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str15.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str28.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpField53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 16 + "'", int54 == 16);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + roundingMode57 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode57.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray58);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3534866348766186856L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3534866348766187008L + "'", long1 == 3534866348766187008L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6557719587665403d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6557719587665404d + "'", double2 == 0.6557719587665404d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) -1);
        int int3 = mersenneTwister1.nextInt((int) (short) 1);
        double double4 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5928446161030136d + "'", double4 == 0.5928446161030136d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3.0000000000000004d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        java.lang.Throwable[] throwableArray3 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 3.0000000000000004d + "'", number2.equals(3.0000000000000004d));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1630432221962219593L, 43.40235434509963d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9999500037496876d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9950127279292548d + "'", double2 == 0.9950127279292548d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.49536728921867335d, (java.lang.Number) (byte) 2, false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 8);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.power10K((-32767));
        org.apache.commons.math.dfp.Dfp dfp42 = dfp20.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        long long2 = org.apache.commons.math.util.FastMath.min((-982170359L), (-2734267132836942420L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2734267132836942420L) + "'", long2 == (-2734267132836942420L));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 3);
        int int13 = dfp12.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 25 + "'", int13 == 25);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.sqrt();
        java.lang.String str17 = dfp11.toString();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp11.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp20 = dfp11.ceil();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp8.add(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp8.getOne();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp8.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str17.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        long long1 = org.apache.commons.math.util.FastMath.round(0.7905639000715652d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp41 = dfp20.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.getSqr2();
        dfpField43.setIEEEFlagsBits(37);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField43.getOne();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp41.remainder(dfp48);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable12);
        java.lang.Throwable[] throwableArray14 = mathRuntimeException13.getSuppressed();
        java.lang.Throwable[] throwableArray15 = mathRuntimeException13.getSuppressed();
        java.lang.String str16 = mathRuntimeException13.toString();
        java.lang.Throwable[] throwableArray17 = mathRuntimeException13.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException5, localizable8, localizable11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException25.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.8280937250720333d);
        org.apache.commons.math.exception.util.Localizable localizable29 = notStrictlyPositiveException28.getGeneralPattern();
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException31 = new org.apache.commons.math.exception.MathRuntimeException(throwable30);
        java.lang.Throwable[] throwableArray32 = mathRuntimeException31.getSuppressed();
        java.lang.Throwable[] throwableArray33 = mathRuntimeException31.getSuppressed();
        java.lang.String str34 = mathRuntimeException31.toString();
        java.lang.Throwable[] throwableArray35 = mathRuntimeException31.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException23, localizable26, localizable29, (java.lang.Object[]) throwableArray35);
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable26, objArray37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp41.nextAfter(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField46 = dfp45.getField();
        int int47 = dfpField46.getIEEEFlags();
        dfpField46.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode50 = dfpField46.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField46.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable11, (java.lang.Object[]) dfpArray51);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str34.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfpField46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 16 + "'", int47 == 16);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + roundingMode50 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode50.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray51);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.386661622254703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3866616222547031d + "'", double1 == 0.3866616222547031d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp17.getField();
        int int19 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField32 = dfp31.getField();
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.nextAfter(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp38.sqrt();
        java.lang.String str44 = dfp38.toString();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp38.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp47 = dfp38.ceil();
        boolean boolean48 = dfp31.greaterThan(dfp38);
        boolean boolean49 = dfp20.greaterThan(dfp31);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp31.newInstance("hi!");
        boolean boolean52 = dfp6.unequal(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.newInstance((long) 957059063);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp51.newInstance((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpField32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str44.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.newInstance((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp2.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(8);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 25);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25L + "'", long1 == 25L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(0.15051849951230298d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4641016151377544d + "'", double1 == 3.4641016151377544d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        int int8 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        int int22 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.sqrt();
        java.lang.String str33 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp27.ceil();
        boolean boolean37 = dfp20.greaterThan(dfp27);
        boolean boolean38 = dfp9.greaterThan(dfp20);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp9.newInstance((double) 16);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.nextAfter(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField48 = dfp47.getField();
        int int49 = dfpField48.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getLn2();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp57.nextAfter(dfp60);
        org.apache.commons.math.dfp.DfpField dfpField62 = dfp61.getField();
        int int63 = dfp61.log10();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp61.newInstance(100L);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp68.sqrt();
        java.lang.String str74 = dfp68.toString();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp68.newInstance((-1L));
        org.apache.commons.math.dfp.Dfp dfp77 = dfp68.ceil();
        boolean boolean78 = dfp61.greaterThan(dfp68);
        boolean boolean79 = dfp50.greaterThan(dfp61);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp61.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp82 = dfp9.newInstance(dfp61);
        org.apache.commons.math.dfp.Dfp dfp84 = dfp82.newInstance((byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str33.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpField48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 16 + "'", int49 == 16);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpField62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642" + "'", str74.equals("1.414213562373095048801688724209698078569671875376948073176679737990732478462107038850387534327642"));
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp84);
    }
}

