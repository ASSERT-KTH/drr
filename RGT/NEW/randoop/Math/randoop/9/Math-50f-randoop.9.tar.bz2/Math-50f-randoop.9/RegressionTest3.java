import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.9999999999244973d, (-6.7071922204187224E16d), (double) 10, (-1.2194330274671845E142d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.1959373998615497E165d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(8102.846845413955d, 1.8014398509481984E16d, 0.0d, 0.7853981633974483d, 0.3138514858166541d, 81377.39570642984d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4596791213458597E20d + "'", double6 == 1.4596791213458597E20d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 35.0d, 0.0d, 1.475295763429613E15d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', 1131171778);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1023), (-127));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 40250L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.asin(35356.9314718056d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray15 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int[] intArray23 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 'a', int24, localizedFormats25, 10L, localizedFormats27, localizedFormats28 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray29);
        org.apache.commons.math.exception.NoBracketingException noBracketingException31 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray29);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 350, objArray29);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext33 = notFiniteNumberException32.getContext();
        java.lang.Object obj35 = exceptionContext33.getValue("org.apache.commons.math.exception.NumberIsTooSmallException: a 141.421x-1 matrix cannot be a rotation matrix");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        exceptionContext33.setValue("org.apache.commons.math.exception.NoBracketingException: cannot compute beta density at 1 when beta = %.3g", (java.lang.Object) localizedFormats37);
        java.util.Set<java.lang.String> strSet39 = exceptionContext33.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(exceptionContext33);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertNotNull(strSet39);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0E-14d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double5 = regulaFalsiSolver1.solve((int) 'a', univariateRealFunction3, (double) 233.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (-2147483648));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1023), (-2013937194));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for binomial coefficient (n, k), got n = -1,023");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1113965065230054d, (java.lang.Number) 20.09975124224178d, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray4 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray8 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, true, false);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray8);
        double[][] doubleArray15 = null;
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray8, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.9999876882679306d);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1024, (java.lang.Number) 0.3138514858166541d, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.131171778E9d, 72.87006611748394d, 1.0265883698834815E160d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 97, 1.7763568394002505E-15d, (-0.5440211108893698d));
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray26 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray34 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 'a', int35, localizedFormats36, 10L, localizedFormats38, localizedFormats39 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray40);
        org.apache.commons.math.exception.NoBracketingException noBracketingException42 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray40);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException43 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray40);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException44 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) (-35L), objArray40);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray58 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray58);
        int[] intArray66 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray66);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats68 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats71 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 'a', int67, localizedFormats68, 10L, localizedFormats70, localizedFormats71 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException73 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats50, objArray72);
        org.apache.commons.math.exception.NoBracketingException noBracketingException74 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats45, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray72);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) allowedSolution9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray72);
        double double76 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(110, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 0.04428604238812435d, (double) (-52.0f), 141.4213562373095d, allowedSolution9);
        double double77 = regulaFalsiSolver5.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 99 + "'", int67 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats68.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats70.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats71.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.04428604238812435d + "'", double76 == 0.04428604238812435d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + (-0.5440211108893698d) + "'", double77 == (-0.5440211108893698d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray15 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int[] intArray23 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 'a', int24, localizedFormats25, 10L, localizedFormats27, localizedFormats28 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray29);
        java.lang.Throwable[] throwableArray31 = mathIllegalStateException30.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException32 = new org.apache.commons.math.exception.MathArithmeticException(localizable6, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray45 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray45);
        int[] intArray53 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray53);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 'a', int54, localizedFormats55, 10L, localizedFormats57, localizedFormats58 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException60 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray59);
        java.lang.Throwable[] throwableArray61 = mathIllegalStateException60.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException62 = new org.apache.commons.math.exception.MathArithmeticException(localizable36, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException63 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException64 = new org.apache.commons.math.exception.MathArithmeticException(localizable34, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException65 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1025.9027123470714d, (double) 100, 0.0d, 1.2130532941206642d, (java.lang.Object[]) throwableArray61);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 99 + "'", int54 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(throwableArray61);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1023), (java.lang.Number) (-14L), 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, number1, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (short) 100, (double) 100.0f);
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1870418611);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray15 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray19 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray23 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray19);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray15);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray28 = null;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 101.98573884555135d + "'", double26 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 141.4213562373095d + "'", double27 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1, 406551964L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 406551964L + "'", long2 == 406551964L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) 1077936128);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str1.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        int int3 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (-1.0f), false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 1 is smaller than, or equal to, the minimum (-1)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 1 is smaller than, or equal to, the minimum (-1)"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        int[] intArray11 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray19 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray19);
        int[] intArray27 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray46 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray47 = org.apache.commons.math.util.MathUtils.copyOf(intArray46);
        int[] intArray54 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray54);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 'a', int55, localizedFormats56, 10L, localizedFormats58, localizedFormats59 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException61 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray60);
        org.apache.commons.math.exception.NoBracketingException noBracketingException62 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray60);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException63 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray60);
        java.lang.Object[] objArray65 = new java.lang.Object[] { intArray28, localizedFormats30, localizedFormats31, localizedFormats32, 1 };
        java.lang.Object[] objArray66 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray65);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException67 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray66);
        java.lang.Object[] objArray68 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray66);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException69 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, number3, objArray66);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException70 = new org.apache.commons.math.exception.MathArithmeticException(localizable1, objArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray66);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 99 + "'", int20 == 99);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 99 + "'", int55 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats56.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats59.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 0.0f, 2.683052061545682E13d, 2.7159673813711397E7d, (-2147483648));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 0.0d, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) -1, 300032);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 300031 + "'", int2 == 300031);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 300031, (long) (-700));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-210021700L) + "'", long2 == (-210021700L));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '4', 0.0d);
        double double3 = regulaFalsiSolver2.getStartValue();
        double double4 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 2763397029420859393L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 960965831 + "'", int1 == 960965831);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(2.993222846126381d, (double) 4.06551968E8f, 17.982365531204298d, 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-2013937194), 1.13117171E9f, (float) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1024.0001f);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double9 = regulaFalsiSolver1.solve(32, univariateRealFunction5, 2.8120005234678474E51d, (double) 2.2183888E31f, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) (-1.58456325E29f), 8.0d, 1.1547819846894583d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 20.0d);
        org.apache.commons.math.exception.MathInternalError mathInternalError2 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notStrictlyPositiveException1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(10.04987562112089d, 0.0d, (double) (-2013937194));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 10150L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double double2 = org.apache.commons.math.util.FastMath.max(2.7159673813711397E7d, (double) 1077936126);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.077936126E9d + "'", double2 == 1.077936126E9d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.2645189576252271d, (double) 1475295763334400L, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(11.548739357257746d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray13 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray21 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 'a', int22, localizedFormats23, 10L, localizedFormats25, localizedFormats26 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray27);
        double double30 = noBracketingException29.getFHi();
        org.apache.commons.math.exception.MathInternalError mathInternalError31 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException29);
        double double32 = noBracketingException29.getHi();
        double double33 = noBracketingException29.getFLo();
        double double34 = noBracketingException29.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 99 + "'", int22 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-1.0d) + "'", double32 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.3552073238292501d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35520732382925013d + "'", double1 == 0.35520732382925013d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray5 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray9 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray13 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray17 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray21 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray25 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[][] doubleArray26 = new double[][] { doubleArray5, doubleArray9, doubleArray13, doubleArray17, doubleArray21, doubleArray25 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray1, doubleArray26);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray26);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
        double[] doubleArray36 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray40 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray44 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray40);
        double[] doubleArray53 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray57 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray61 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray57);
        double[] doubleArray67 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray71 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray71);
        double[] doubleArray79 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray83 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray87 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray83, doubleArray87);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray79, doubleArray83);
        double double90 = org.apache.commons.math.util.MathUtils.distance(doubleArray67, doubleArray79);
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double double92 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray57, doubleArray67);
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray67);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 101.98573884555135d + "'", double90 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 141.4213562373095d + "'", double91 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 20000.0d + "'", double92 == 20000.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.3138514858166541d, 0.0d, (double) 1131171778);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 21L, 141.4213562373095d, 1870418611);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 97L, 1.3455368082272225E26d, 4.983606621708336d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1024458752, (float) 3, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1024.0001f);
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        int int3 = regulaFalsiSolver1.getEvaluations();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver1.solve((-2013937194), univariateRealFunction6, 3.1622776601683795d, 0.0d, 2.993222846126381d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 0.0d, 1.3455368082272225E26d, 0.0d, 0.0d, 0.9579913551199332d, 35356.9314718056d, 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 419L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException8 = new org.apache.commons.math.exception.DimensionMismatchException(32, 100000);
        java.lang.Throwable[] throwableArray9 = dimensionMismatchException8.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException10 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) 1077936128, 2.1959373998615497E165d, 0.0d, (double) 104.0f, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray16 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        int[] intArray24 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 'a', int25, localizedFormats26, 10L, localizedFormats28, localizedFormats29 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray30);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray30);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray30);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math.exception.MathIllegalStateException(throwable2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray30);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException35 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray30);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext36 = mathArithmeticException35.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext37 = mathArithmeticException35.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        java.lang.Object[] objArray39 = null;
        exceptionContext37.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "empty polynomials coefficients array" + "'", str1.equals("empty polynomials coefficients array"));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 99 + "'", int25 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(exceptionContext36);
        org.junit.Assert.assertNotNull(exceptionContext37);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2250738585072014E-308d + "'", double1 == 2.2250738585072014E-308d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 110);
        java.lang.Throwable[] throwableArray4 = maxCountExceededException3.getSuppressed();
        exceptionContext0.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray4);
        exceptionContext0.setValue("", (java.lang.Object) (-2.5663706143591725d));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver1.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver1.solve((-127), univariateRealFunction6, (double) (-0.99999994f), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.967161317E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9671613169999998E9d) + "'", double1 == (-1.9671613169999998E9d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver7 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 97, 1.7763568394002505E-15d, (-0.5440211108893698d));
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution11 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray28 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray28);
        int[] intArray36 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray36);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 'a', int37, localizedFormats38, 10L, localizedFormats40, localizedFormats41 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray42);
        org.apache.commons.math.exception.NoBracketingException noBracketingException44 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray42);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException45 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray42);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException46 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) (-35L), objArray42);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray60 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray61 = org.apache.commons.math.util.MathUtils.copyOf(intArray60);
        int[] intArray68 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray68);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats73 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 'a', int69, localizedFormats70, 10L, localizedFormats72, localizedFormats73 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException75 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray74);
        org.apache.commons.math.exception.NoBracketingException noBracketingException76 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats47, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray74);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) allowedSolution11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray74);
        double double78 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(110, univariateRealFunction3, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver7, 0.04428604238812435d, (double) (-52.0f), 141.4213562373095d, allowedSolution11);
        double double79 = regulaFalsiSolver7.getMin();
        double double80 = regulaFalsiSolver7.getMax();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution84 = null;
        try {
            double double85 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1077936126, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver7, 8.0d, 2.440227671403022E33d, 0.0d, allowedSolution84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution11 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution11.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 99 + "'", int37 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 99 + "'", int69 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats70.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats72.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats73.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.04428604238812435d + "'", double78 == 0.04428604238812435d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.6819643974304199d, 11013.232874703393d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0E-6d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999997E-7d + "'", double2 == 9.999999999999997E-7d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9036922050915067d, (double) 350);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(419.0011933157231d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 419.0011933157232d + "'", double1 == 419.0011933157232d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(2.0d, (double) 5, (double) (byte) 0, Double.NEGATIVE_INFINITY);
        java.lang.String str5 = noBracketingException4.toString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        int[] intArray16 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        int[] intArray24 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray32 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray51 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray51);
        int[] intArray59 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray59);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 'a', int60, localizedFormats61, 10L, localizedFormats63, localizedFormats64 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException66 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray65);
        org.apache.commons.math.exception.NoBracketingException noBracketingException67 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray65);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException68 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray65);
        java.lang.Object[] objArray70 = new java.lang.Object[] { intArray33, localizedFormats35, localizedFormats36, localizedFormats37, 1 };
        java.lang.Object[] objArray71 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray70);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException72 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10.0f, objArray71);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray71);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats74 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException76 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 110);
        java.lang.Throwable[] throwableArray77 = maxCountExceededException76.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException78 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalArgumentException73, (org.apache.commons.math.exception.util.Localizable) localizedFormats74, (java.lang.Object[]) throwableArray77);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException79 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray77);
        java.lang.String str80 = mathIllegalStateException79.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [2, 5], values: [0, -∞]" + "'", str5.equals("org.apache.commons.math.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [2, 5], values: [0, -∞]"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 99 + "'", int25 == 99);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 99 + "'", int60 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats61.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats63.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats64.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertTrue("'" + localizedFormats74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats74.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(throwableArray77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "org.apache.commons.math.exception.MathIllegalStateException: cannot normalize a zero norm vector" + "'", str80.equals("org.apache.commons.math.exception.MathIllegalStateException: cannot normalize a zero norm vector"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-1L), (-0.9999999f), 2.2183886E31f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1023), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 0, n = -1,023");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-3), (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f), (java.lang.Number) 101.98573884555135d, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        double double3 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1967161317), (-700));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = -700, n = -1,967,161,317");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.440227671403022E33d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.440227671403022E33d + "'", double1 == 2.440227671403022E33d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1967161317));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        int int3 = incrementor0.getMaximalCount();
        incrementor0.incrementCount((-1023));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double double1 = org.apache.commons.math.util.FastMath.exp(359.1342053695755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395465E155d + "'", double1 == 9.332621544395465E155d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.95012437887911d, (double) (-3842938066129721103L), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray9 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        int[] intArray17 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 'a', int18, localizedFormats19, 10L, localizedFormats21, localizedFormats22 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray23);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException25 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray23);
        java.lang.Throwable[] throwableArray26 = mathArithmeticException25.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 99 + "'", int18 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray26);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray14 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int[] intArray22 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 'a', int23, localizedFormats24, 10L, localizedFormats26, localizedFormats27 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray28);
        org.apache.commons.math.exception.NoBracketingException noBracketingException30 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray28);
        double double31 = noBracketingException30.getHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext32 = noBracketingException30.getContext();
        java.lang.Object obj34 = exceptionContext32.getValue("hi!");
        exceptionContext32.setValue("", (java.lang.Object) 419.0d);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray53 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray54 = org.apache.commons.math.util.MathUtils.copyOf(intArray53);
        int[] intArray61 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray54, intArray61);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats66 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray67 = new java.lang.Object[] { 'a', int62, localizedFormats63, 10L, localizedFormats65, localizedFormats66 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException68 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats45, objArray67);
        org.apache.commons.math.exception.NoBracketingException noBracketingException69 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats40, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray67);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException70 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray67);
        exceptionContext32.addMessage(localizable38, objArray67);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException72 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-6.7071922204187224E16d), objArray67);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.0d) + "'", double31 == (-1.0d));
        org.junit.Assert.assertNotNull(exceptionContext32);
        org.junit.Assert.assertNull(obj34);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 99 + "'", int62 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats63.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats65.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats66.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0, 21);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 21 + "'", int4 == 21);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-2.349824875421102d), 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(4.282357203266032E47d, (double) 2147483647, (double) 350.00003f, 1.08086391056891904E17d, (-0.0d), (double) 1, 0.0d, (double) 115L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.19629206462646E56d + "'", double8 == 9.19629206462646E56d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(32.0d, 3.4657359027997265d, (-2));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943298d + "'", double1 == 0.17453292519943298d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2, 1635593510);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1635593508) + "'", int2 == (-1635593508));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1.13117171E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.6882447980166425E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f));
        java.lang.String str3 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "unable to solve: singular problem" + "'", str3.equals("unable to solve: singular problem"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(0.8813735870195429d, (double) (-52521875L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0.881, -52,521,875]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray15 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray19 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray23 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray19);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray15);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray31 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray35 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray35);
        double[] doubleArray43 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray47 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray51 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray47);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray43);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray31);
        double[] doubleArray59 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray63 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray63);
        double[] doubleArray68 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray72 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray72);
        double[] doubleArray80 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray84 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray88 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray88);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray80, doubleArray84);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray80);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double double93 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray59, doubleArray68);
        double[] doubleArray95 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 0.0d);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray95);
        double double97 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray96);
        double double98 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray96);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 101.98573884555135d + "'", double26 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 141.4213562373095d + "'", double27 == 141.4213562373095d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 101.98573884555135d + "'", double54 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 101.98573884555135d + "'", double91 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 141.4213562373095d + "'", double92 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 20000.0d + "'", double93 == 20000.0d);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 141.4213562373095d + "'", double98 == 141.4213562373095d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 2, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 100, (-2013937194));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        double double2 = org.apache.commons.math.util.FastMath.copySign(9.640359519517816E30d, (double) (-0.9999999f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.640359519517816E30d) + "'", double2 == (-9.640359519517816E30d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(10);
        incrementor0.incrementCount();
        incrementor0.setMaximalCount((int) (byte) 10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray13 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray21 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 'a', int22, localizedFormats23, 10L, localizedFormats25, localizedFormats26 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray27);
        double double30 = noBracketingException29.getHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext31 = noBracketingException29.getContext();
        double double32 = noBracketingException29.getFHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext33 = noBracketingException29.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, (java.lang.Number) 141.4213562373095d, (java.lang.Number) (byte) -1, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats39);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException42 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 110);
        java.lang.Throwable[] throwableArray43 = maxCountExceededException42.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, (java.lang.Object[]) throwableArray43);
        exceptionContext33.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats34, (java.lang.Object[]) throwableArray43);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 99 + "'", int22 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(exceptionContext31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(exceptionContext33);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertNotNull(throwableArray43);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray23 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray27 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray31 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray27);
        double[] doubleArray37 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray41);
        double[] doubleArray49 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray53 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray57 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray53);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray49);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double62 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray27, doubleArray37);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray37);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 0.0d);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray67 = new double[] {};
        double[] doubleArray71 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray75 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray79 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray83 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray87 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray91 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[][] doubleArray92 = new double[][] { doubleArray71, doubleArray75, doubleArray79, doubleArray83, doubleArray87, doubleArray91 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray67, doubleArray92);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray66, doubleArray92);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray66);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.98573884555135d + "'", double60 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 141.4213562373095d + "'", double61 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 20000.0d + "'", double62 == 20000.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52.0f, (java.lang.Number) 11.296012463252339d, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.0d, (double) 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-2147483648), 99);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 19999.999999999996d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(800.0004485450899d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        long long1 = org.apache.commons.math.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 2.718281828459045d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray20 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray24 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray24);
        double[] doubleArray32 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray36 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray40 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray36);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray32);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double45 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray10, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection46, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 101.98573884555135d + "'", double43 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 141.4213562373095d + "'", double44 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 20000.0d + "'", double45 == 20000.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 419L, 419.0011933157232d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException(localizable0, (java.lang.Number) 2.220446049250313E-16d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.7071067811865475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.15051499783199063d) + "'", double1 == (-0.15051499783199063d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int[] intArray0 = null;
        int[] intArray7 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray15 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, (int) (byte) 100);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray16);
        int[] intArray26 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray34 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray34);
        int[] intArray37 = org.apache.commons.math.util.MathUtils.copyOf(intArray35, (int) (byte) 100);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray35);
        int[] intArray45 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray45);
        int[] intArray48 = org.apache.commons.math.util.MathUtils.copyOf(intArray46, (int) (byte) 100);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray46);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray46);
        int[] intArray57 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray57);
        int[] intArray60 = org.apache.commons.math.util.MathUtils.copyOf(intArray58, (int) (byte) 100);
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray60);
        int[] intArray63 = org.apache.commons.math.util.MathUtils.copyOf(intArray60, 0);
        try {
            int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(11.591953275521519d, (double) 10150L, (double) (-350L));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver3.solve(1024458752, univariateRealFunction5, (double) (-831359905));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 21, (double) (-3.842938E18f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.8429379997340795E18d + "'", double2 == 3.8429379997340795E18d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.8429379997340795E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7889016378532744d + "'", double1 == 0.7889016378532744d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        int int3 = incrementor0.getMaximalCount();
        incrementor0.incrementCount((-2013937194));
        int int6 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int[] intArray6 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) (byte) 100);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, (int) (byte) 0);
        int[] intArray18 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray18);
        int[] intArray26 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray27, (int) (byte) 100);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray27);
        int[] intArray37 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray38 = org.apache.commons.math.util.MathUtils.copyOf(intArray37);
        int[] intArray45 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray45);
        int[] intArray48 = org.apache.commons.math.util.MathUtils.copyOf(intArray46, (int) (byte) 100);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray46);
        int[] intArray56 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray56);
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray57, (int) (byte) 100);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray57);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray57);
        int[] intArray68 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray69 = org.apache.commons.math.util.MathUtils.copyOf(intArray68);
        int[] intArray71 = org.apache.commons.math.util.MathUtils.copyOf(intArray69, (int) (byte) 100);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray71);
        int[] intArray74 = org.apache.commons.math.util.MathUtils.copyOf(intArray57, 52);
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray57);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 110, (long) 1024);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 112640L + "'", long2 == 112640L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray15 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray19 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray23 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray19);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray15);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray34 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray38 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray42 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray38);
        double[] doubleArray48 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray52 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray52);
        double[] doubleArray60 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray64 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray68 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray64);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray60);
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double73 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray38, doubleArray48);
        try {
            double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 101.98573884555135d + "'", double26 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 433.43280909501993d + "'", double27 == 433.43280909501993d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 101.98573884555135d + "'", double71 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 141.4213562373095d + "'", double72 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 20000.0d + "'", double73 == 20000.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double double1 = org.apache.commons.math.util.FastMath.acos(360.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (-0.6080080866568005d), (-0.7510136006188721d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1635593510);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 1870418611);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 128.0f + "'", float1 == 128.0f);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) 10.000000000000002d, true);
        java.lang.Number number7 = numberIsTooLargeException6.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.000000000000002d + "'", number7.equals(10.000000000000002d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException(number0);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        java.lang.Number number3 = tooManyEvaluationsException1.getMax();
        java.lang.Number number4 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray15 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int[] intArray23 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 'a', int24, localizedFormats25, 10L, localizedFormats27, localizedFormats28 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray29);
        org.apache.commons.math.exception.NoBracketingException noBracketingException31 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray29);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.1102230246251565E-16d, objArray29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (-1.0f), false);
        notFiniteNumberException32.addSuppressed((java.lang.Throwable) numberIsTooSmallException36);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray57 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray57);
        int[] intArray65 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray65);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats67 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats69 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray71 = new java.lang.Object[] { 'a', int66, localizedFormats67, 10L, localizedFormats69, localizedFormats70 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException72 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray71);
        org.apache.commons.math.exception.NoBracketingException noBracketingException73 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray71);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException74 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray71);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException75 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, (java.lang.Number) (-35L), objArray71);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException76 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (byte) -1, objArray71);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException77 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray71);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException78 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException36, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray71);
        java.lang.String str79 = numberIsTooSmallException36.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 99 + "'", int66 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats67.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats69.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats70.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 1 is smaller than, or equal to, the minimum (-1)" + "'", str79.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 1 is smaller than, or equal to, the minimum (-1)"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 7.975118810729068E216d, number2, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double2 = org.apache.commons.math.util.FastMath.max(2.220446049250313E-16d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.220446049250313E-16d + "'", double2 == 2.220446049250313E-16d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5707963250268189d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19611987654131371d + "'", double1 == 0.19611987654131371d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-104));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray12 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray16);
        double[] doubleArray24 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray28 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray32 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray24);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double37 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray12);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5703080455837017d), (java.lang.Number) 1.61650502030123104E17d, 10, orderDirection42, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection42, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.98573884555135d + "'", double35 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 141.4213562373095d + "'", double36 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 20000.0d + "'", double37 == 20000.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-831359905) + "'", int38 == (-831359905));
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(350, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double2 = org.apache.commons.math.util.FastMath.min(4.0d, 0.35520732382925013d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.35520732382925013d + "'", double2 == 0.35520732382925013d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        int int3 = incrementor0.getMaximalCount();
        int int4 = incrementor0.getCount();
        incrementor0.incrementCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError(throwable0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 115, 9.306852936588191d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-127), (-51.999996f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-127.0f) + "'", float2 == (-127.0f));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        long long2 = org.apache.commons.math.util.FastMath.min(406551963L, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-0.0f), (double) 21, (double) 233.0f, 2.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        int[] intArray6 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray14 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray15, (int) (byte) 100);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray15);
        int[] intArray25 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray25);
        int[] intArray33 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray33);
        int[] intArray36 = org.apache.commons.math.util.MathUtils.copyOf(intArray34, (int) (byte) 100);
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray34);
        int[] intArray44 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray44);
        int[] intArray47 = org.apache.commons.math.util.MathUtils.copyOf(intArray45, (int) (byte) 100);
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray45);
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray45);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) double49);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        int int2 = org.apache.commons.math.util.FastMath.min((-1332031919), 1131171743);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1332031919) + "'", int2 == (-1332031919));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.1693827632223651d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray8 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, true, false);
        double[] doubleArray20 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray24 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray28 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray24);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray20);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 201.00454536063498d + "'", double31 == 201.00454536063498d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 700L, (-935062423), 1024458752);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) 10, 0.7080784171785247d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 4.641588833612779d, (double) 110L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        double double1 = org.apache.commons.math.util.FastMath.sin(201.00454536063498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.05735298000456796d) + "'", double1 == (-0.05735298000456796d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray23 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray27 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray31 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray27);
        double[] doubleArray37 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray41);
        double[] doubleArray49 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray53 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray57 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray53);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray49);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double62 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray27, doubleArray37);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray37);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37, 110);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (short) 0, (int) (byte) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = nonMonotonousSequenceException73.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 2.2183888E31f, (int) (byte) 10, orderDirection74, false);
        java.lang.Number number77 = nonMonotonousSequenceException76.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = nonMonotonousSequenceException76.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray66, orderDirection78, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.98573884555135d + "'", double60 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 141.4213562373095d + "'", double61 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 20000.0d + "'", double62 == 20000.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-831359905) + "'", int64 == (-831359905));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + 2.2183888E31f + "'", number77.equals(2.2183888E31f));
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.5576619350218566E49d, (java.lang.Number) 8.005819039744E12d, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray23 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray27 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray31 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray27);
        double[] doubleArray37 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray41);
        double[] doubleArray49 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray53 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray57 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray53);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray49);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double62 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray27, doubleArray37);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray37);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37, 110);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.98573884555135d + "'", double60 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 141.4213562373095d + "'", double61 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 20000.0d + "'", double62 == 20000.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-831359905) + "'", int64 == (-831359905));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 20.0d, (java.lang.Number) 419L, true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1, 478);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        float float2 = org.apache.commons.math.util.MathUtils.round(9.999999f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 35, (float) (-35L), 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(97, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(6.283185307179586d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double5 = regulaFalsiSolver1.solve((-3), univariateRealFunction3, 4.983606621708336d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.7071067811865475d, 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.707d + "'", double2 == 0.707d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.21076237708990136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0222927285353687d + "'", double1 == 1.0222927285353687d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double1 = org.apache.commons.math.util.FastMath.abs(101.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 101.0d + "'", double1 == 101.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        java.lang.Object obj0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray17 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        int[] intArray25 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 'a', int26, localizedFormats27, 10L, localizedFormats29, localizedFormats30 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray31);
        org.apache.commons.math.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray31);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException34 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray31);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException35 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.3455368082272225E26d, objArray31);
        try {
            org.apache.commons.math.util.MathUtils.checkNotNull(obj0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: initial column 99 after final column a");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray31);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray12 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray20 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 'a', int21, localizedFormats22, 10L, localizedFormats24, localizedFormats25 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray26);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 350, objArray26);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 4.944515159673473E42d, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '4', (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        int int2 = org.apache.commons.math.util.MathUtils.pow(233, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-474910967) + "'", int2 == (-474910967));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS;
        float[] floatArray6 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray12 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(floatArray6, floatArray12);
        float[] floatArray18 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray24 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray30 = new java.lang.Object[] { localizedFormats29 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 0.0d, (org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE;
        java.lang.Object[] objArray35 = new java.lang.Object[] { floatArray18, objArray30, "hi!", localizedFormats33, localizedFormats34 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException36 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray35);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException37 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (-1820.0d), objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS));
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE));
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-0.99999994f));
        org.apache.commons.math.exception.MathInternalError mathInternalError2 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) maxCountExceededException1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-350L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.1086523819801535d) + "'", double1 == (-6.1086523819801535d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 10.000000000000002d, 1.4676622301554424E45d, (double) 350.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.1102230246251565E-16d, 1.5430806348152437d, (double) (byte) 1);
        double double4 = regulaFalsiSolver3.getFunctionValueAccuracy();
        double double5 = regulaFalsiSolver3.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.5430806348152437d + "'", double5 == 1.5430806348152437d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.9501243788791103d, (double) (-0.9999999f), 1.5407904953140532d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        int int3 = incrementor0.getMaximalCount();
        int int4 = incrementor0.getCount();
        try {
            incrementor0.incrementCount(406551963);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray16 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        int[] intArray24 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 'a', int25, localizedFormats26, 10L, localizedFormats28, localizedFormats29 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray30);
        org.apache.commons.math.exception.NoBracketingException noBracketingException32 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray30);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray30);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, localizable1, objArray30);
        org.apache.commons.math.exception.NotPositiveException notPositiveException36 = new org.apache.commons.math.exception.NotPositiveException(localizable1, (java.lang.Number) 1.5576619350218566E49d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 99 + "'", int25 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        float[] floatArray5 = new float[] { 52, (byte) 100, (byte) 100, (byte) 1, 700L };
        float[] floatArray6 = null;
        float[] floatArray11 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray17 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(floatArray6, floatArray11);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray11);
        float[] floatArray21 = new float[] {};
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray21);
        float[] floatArray23 = null;
        float[] floatArray29 = new float[] { 2.2183888E31f, (-2), 100.0f, (byte) 1, (-2) };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray23, floatArray29);
        float[] floatArray35 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray41 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(floatArray35, floatArray41);
        float[] floatArray47 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray53 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(floatArray47, floatArray53);
        float[] floatArray59 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray65 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(floatArray59, floatArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray53, floatArray59);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray41, floatArray59);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray29, floatArray59);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray21, floatArray29);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(6.4812307E18f, (-2147483648), 1077936126);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,077,936,126, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double2 = org.apache.commons.math.util.FastMath.scalb((-4.9E-324d), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 21L, 1.5707963267948966d, (double) 2763397029420859393L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1332031919));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 350.00003f, 350);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.027245855885482E107d + "'", double2 == 8.027245855885482E107d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1300);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.1622776601683795d, (java.lang.Number) (-1024.0d), false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) (byte) -1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray22 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        int[] intArray30 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 'a', int31, localizedFormats32, 10L, localizedFormats34, localizedFormats35 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray36);
        org.apache.commons.math.exception.NoBracketingException noBracketingException38 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray36);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray36);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray36);
        java.lang.Number number41 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 99 + "'", int31 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (-1024.0d) + "'", number41.equals((-1024.0d)));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-2147483648), 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: overflow: lcm(-2,147,483,648, 2) is 2^31");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray4 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray8 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, true, false);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray8);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 2.2183886E31f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        int int2 = org.apache.commons.math.util.MathUtils.pow(99, 2763397029420859393L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-536870813) + "'", int2 == (-536870813));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 0.7071067811865475d, 35.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getCount();
        incrementor0.resetCount();
        int int4 = incrementor0.getCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.000001f + "'", float1 == 10.000001f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(2.2250738585072014E-308d, (double) 10L, (-5.252187499999999E7d), (double) (-1967161317));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0331900079630936E17d + "'", double4 == 1.0331900079630936E17d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(11.296012463252339d, 11013.234187583144d, (double) 1.2296211E32f, 81377.0d, (-0.1693827632223651d), 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0006287480792945E37d + "'", double6 == 1.0006287480792945E37d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray15 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int[] intArray23 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 'a', int24, localizedFormats25, 10L, localizedFormats27, localizedFormats28 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray29);
        java.lang.Throwable[] throwableArray31 = mathIllegalStateException30.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException32 = new org.apache.commons.math.exception.MathArithmeticException(localizable6, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 0.6819643974304199d, 11.548739357257746d, (double) (-52521875L), 4.983606621708336d, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(throwableArray31);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver1.solve((-1635593508), univariateRealFunction6, 2.220446049250313E-16d, 0.9036922050915067d, 8.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double2 = org.apache.commons.math.util.FastMath.copySign(108.06656506470014d, 363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 108.06656506470014d + "'", double2 == 108.06656506470014d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray23 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        int[] intArray31 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray31);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 'a', int32, localizedFormats33, 10L, localizedFormats35, localizedFormats36 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray37);
        org.apache.commons.math.exception.NoBracketingException noBracketingException39 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray37);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException40 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray37);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException41 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) (-35L), objArray37);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException42 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (byte) -1, objArray37);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray37);
        org.apache.commons.math.exception.NoBracketingException noBracketingException44 = new org.apache.commons.math.exception.NoBracketingException(localizable0, Double.NEGATIVE_INFINITY, 11.591953275521519d, (-1820.0d), (double) (-104), objArray37);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext45 = noBracketingException44.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 99 + "'", int32 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(exceptionContext45);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, (double) 300032);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1300);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 350L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 115L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 10150L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(350, (-935062423));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-935062073) + "'", int2 == (-935062073));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 7.896296018268069E13d, 0.6819643974304199d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.FastMath.asin(11.833336070820506d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        int int2 = org.apache.commons.math.util.FastMath.max(300031, (-935062423));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 300031 + "'", int2 == 300031);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray17 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        int[] intArray25 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 'a', int26, localizedFormats27, 10L, localizedFormats29, localizedFormats30 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray31);
        org.apache.commons.math.exception.NoBracketingException noBracketingException33 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray31);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException34 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1.1102230246251565E-16d, objArray31);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray31);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Object[] objArray39 = new java.lang.Object[] { localizedFormats36, localizedFormats37, 1.1113965065230054d };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray39);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.1693827632223651d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver1.solve(0, univariateRealFunction4, 2.718281828459045d, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 233, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1632570001522275361L + "'", long2 == 1632570001522275361L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) Double.NaN);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 406551963, 97);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray19 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray19);
        int[] intArray27 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 'a', int28, localizedFormats29, 10L, localizedFormats31, localizedFormats32 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray33);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray33);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray33);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math.exception.MathIllegalStateException(throwable5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray33);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException38 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.2183885503994E31d, objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 99 + "'", int28 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5.655859600022727E8d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1438683501 + "'", int1 == 1438683501);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.1102230246251565E-16d, 1.5430806348152437d, (double) (byte) 1);
        double double6 = regulaFalsiSolver5.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double11 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-3), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, (double) Float.NaN, 31.4789883982983d, 28.0d, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (short) 0, (int) (byte) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 2.2183888E31f, (int) (byte) 10, orderDirection7, false);
        int int10 = nonMonotonousSequenceException9.getIndex();
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        int int12 = nonMonotonousSequenceException9.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.2183888E31f + "'", number11.equals(2.2183888E31f));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5860134523134298E15d, (-0.9999902065507035d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray12 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray16);
        double[] doubleArray24 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray28 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray32 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray24);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double37 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray12);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.0d);
        double[] doubleArray40 = null;
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray40);
        try {
            double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 3.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.98573884555135d + "'", double35 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 141.4213562373095d + "'", double36 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 20000.0d + "'", double37 == 20000.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-1L));
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.283185307179587d, (java.lang.Number) 0.9999999958776927d, 300032, orderDirection3, true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 700L, (double) 1077936126);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0779361236012812E9d + "'", double2 == 1.0779361236012812E9d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2013937194), (long) 1438683501);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray23 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray27 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray31 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray27);
        double[] doubleArray37 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray41);
        double[] doubleArray49 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray53 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray57 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray53);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray49);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double62 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray27, doubleArray37);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray37);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException67 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (short) 0, (int) (byte) 100);
        java.lang.Number number68 = nonMonotonousSequenceException67.getPrevious();
        int int69 = nonMonotonousSequenceException67.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = nonMonotonousSequenceException67.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection70, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.98573884555135d + "'", double60 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 141.4213562373095d + "'", double61 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 20000.0d + "'", double62 == 20000.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + (short) 0 + "'", number68.equals((short) 0));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 100 + "'", int69 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection70.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double double1 = org.apache.commons.math.util.FastMath.signum((-6.7071922204187224E16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 478, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException(number0);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        java.lang.Object obj4 = exceptionContext2.getValue("empty polynomials coefficients array");
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-2013937194));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double1 = org.apache.commons.math.util.FastMath.expm1(5.729577951308233E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.729577951308397E-14d + "'", double1 == 5.729577951308397E-14d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray8 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray8);
        double[] doubleArray16 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray20 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray24 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray20);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray16);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray16);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray30);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 101.98573884555135d + "'", double27 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 433.43280909501993d + "'", double28 == 433.43280909501993d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-2013937194) + "'", int29 == (-2013937194));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 52.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f), (java.lang.Number) 101.98573884555135d, true);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.87041869E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 406551964L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats3 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 0.0d, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray4);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 108.06656506470014d, (java.lang.Number) (short) 100, false);
        org.apache.commons.math.exception.NotPositiveException notPositiveException12 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0300865288174967d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-52521875L), 2.683052061545682E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.2521875E7d) + "'", double2 == (-5.2521875E7d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (byte) 10);
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (byte) 10 + "'", number2.equals((byte) 10));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5.393606884554982d, (java.lang.Number) (-0.6098494453571888d), false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(20000.0d, 1.1102230246251565E-16d, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException2 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (short) 100);
        java.lang.Throwable[] throwableArray3 = maxCountExceededException2.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException4 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 181.18516357615334d, (java.lang.Object[]) throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-2013937194), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) '#');
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 0.7853981633974483d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray12 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray16);
        double[] doubleArray24 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray28 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray32 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray24);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double37 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray12);
        double[] doubleArray41 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray45 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.98573884555135d + "'", double35 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 141.4213562373095d + "'", double36 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 20000.0d + "'", double37 == 20000.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 173.20508075688772d + "'", double47 == 173.20508075688772d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray10, (int) '#');
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 141.4213562373095d + "'", double19 == 141.4213562373095d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1024, (java.lang.Number) 0.3138514858166541d, (int) ' ');
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 32 + "'", int4 == 32);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.3138514858166541d + "'", number5.equals(0.3138514858166541d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (short) 0, (int) (byte) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 112640L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 112640.0d + "'", double2 == 112640.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(10150L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        int[] intArray6 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray14 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray15, (int) (byte) 100);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray15);
        int[] intArray25 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray25);
        int[] intArray33 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray33);
        int[] intArray36 = org.apache.commons.math.util.MathUtils.copyOf(intArray34, (int) (byte) 100);
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray34);
        int[] intArray44 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray44);
        int[] intArray47 = org.apache.commons.math.util.MathUtils.copyOf(intArray45, (int) (byte) 100);
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray45);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray45);
        int[] intArray56 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray56);
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray57, (int) (byte) 100);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray59);
        int[] intArray61 = org.apache.commons.math.util.MathUtils.copyOf(intArray45);
        int[] intArray63 = org.apache.commons.math.util.MathUtils.copyOf(intArray45, 97);
        int[] intArray64 = null;
        try {
            int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (-831359905), 300000);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution3 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray20 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray28 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 'a', int29, localizedFormats30, 10L, localizedFormats32, localizedFormats33 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray34);
        org.apache.commons.math.exception.NoBracketingException noBracketingException36 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray34);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException37 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray34);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException38 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (-35L), objArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray52 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray53 = org.apache.commons.math.util.MathUtils.copyOf(intArray52);
        int[] intArray60 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray60);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats62 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 'a', int61, localizedFormats62, 10L, localizedFormats64, localizedFormats65 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException67 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, objArray66);
        org.apache.commons.math.exception.NoBracketingException noBracketingException68 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray66);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) allowedSolution3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray66);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException70 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray66);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + allowedSolution3 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution3.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 99 + "'", int29 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 99 + "'", int61 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats62.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats64.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats65.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9579913551199332d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9787703280749438d + "'", double1 == 0.9787703280749438d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 2.0000000000000004d, 35.0d, 3.465735902799727d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.06551936E8f, (float) (short) 1, 1131171743);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.610125138662288d + "'", double1 == 7.610125138662288d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) 10, (-640097421));
        java.lang.Class<?> wildcardClass4 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, 26.491182765602147d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        long long2 = org.apache.commons.math.util.FastMath.max(101L, 21L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double double2 = org.apache.commons.math.util.FastMath.pow(72.87006611748394d, 11.296012463252339d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0949103602489965E21d + "'", double2 == 1.0949103602489965E21d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.13117171E9f, 128.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4.983606621708336d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.4337808304830271d, 0.0d, 2.7159673813711397E7d, (double) (byte) 10);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        int[] intArray6 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray9 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, (int) (byte) 100);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, (int) (byte) 0);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 100);
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1300);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        double double3 = regulaFalsiSolver1.getRelativeAccuracy();
        double double4 = regulaFalsiSolver1.getMin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        long long1 = org.apache.commons.math.util.FastMath.abs(406551963L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 406551963L + "'", long1 == 406551963L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        int int4 = regulaFalsiSolver1.getEvaluations();
        int int5 = regulaFalsiSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-3), 1131171743);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        double double1 = org.apache.commons.math.util.FastMath.atanh(108.06656506470014d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray12 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray16);
        double[] doubleArray24 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray28 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray32 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray24);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double37 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray12);
        double[] doubleArray41 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray45 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray45);
        double[] doubleArray50 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray54 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray54);
        double[] doubleArray62 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray66 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray70 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray70);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray66);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray50, doubleArray62);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double double75 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray41, doubleArray50);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 0.0d);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.98573884555135d + "'", double35 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 141.4213562373095d + "'", double36 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 20000.0d + "'", double37 == 20000.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 101.98573884555135d + "'", double73 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 141.4213562373095d + "'", double74 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 20000.0d + "'", double75 == 20000.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(2763397029420859393L, (long) 1104156384);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        int int2 = incrementor0.getCount();
        incrementor0.resetCount();
        int int4 = incrementor0.getCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 99);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = notPositiveException1.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (byte) -1);
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray20 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray20);
        int[] intArray28 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 'a', int29, localizedFormats30, 10L, localizedFormats32, localizedFormats33 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray34);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray34);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats8, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray34);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math.exception.MathIllegalStateException(throwable6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray34);
        exceptionContext2.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray34);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 99 + "'", int29 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray23 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray27 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray31 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray27);
        double[] doubleArray37 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray41 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray41);
        double[] doubleArray49 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray53 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray57 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray53);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray49);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double62 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray27, doubleArray37);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray37);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray37, 110);
        double[] doubleArray67 = null;
        try {
            double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 101.98573884555135d + "'", double60 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 141.4213562373095d + "'", double61 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 20000.0d + "'", double62 == 20000.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-831359905) + "'", int64 == (-831359905));
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1300);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 350L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0);
        double[] doubleArray21 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray25 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray29 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray25);
        double[] doubleArray38 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray42 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray46 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray42);
        double[] doubleArray52 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray56 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray56);
        double[] doubleArray64 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray68 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray72 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray64, doubleArray68);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray64);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double double77 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray42, doubleArray52);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray52);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray83 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray87 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray83, doubleArray87);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection89 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean92 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray87, orderDirection89, true, false);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection89, true, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException97 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.729577951308397E-14d, (java.lang.Number) 0, 350, orderDirection89, true);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 101.98573884555135d + "'", double75 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 141.4213562373095d + "'", double76 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 20000.0d + "'", double77 == 20000.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-831359905) + "'", int79 == (-831359905));
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + orderDirection89 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection89.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray8 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray8);
        double[] doubleArray13 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray17 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray17);
        double[] doubleArray25 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray29 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray33 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray29);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray25);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double38 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray4, doubleArray13);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 101.98573884555135d + "'", double36 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 141.4213562373095d + "'", double37 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 20000.0d + "'", double38 == 20000.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.2183885503994E31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3713630196806786d + "'", double1 == 0.3713630196806786d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 21L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 112640L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math.exception.util.ExceptionContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 110);
        java.lang.Throwable[] throwableArray5 = maxCountExceededException4.getSuppressed();
        exceptionContext1.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException7 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.3138514858166541d, (-1967161317), 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (-1023), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1300);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 350L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 115L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 115);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException17 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 115);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) 0.9092974268256817d, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.9092974268256817d + "'", number5.equals(0.9092974268256817d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(419.0d, 0.0d, (-0.29100670860274475d));
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.0E-6d, 3.8429379997340795E18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.0974438963008897d) + "'", double2 == (-3.0974438963008897d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray12 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray20 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 'a', int21, localizedFormats22, 10L, localizedFormats24, localizedFormats25 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray26);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 350, objArray26);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1L, objArray26);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException30 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray26);
        org.apache.commons.math.exception.MathInternalError mathInternalError31 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) mathArithmeticException30);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext32 = mathArithmeticException30.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(exceptionContext32);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        int[] intArray10 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        int[] intArray18 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray18);
        int[] intArray26 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray45 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray45);
        int[] intArray53 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray53);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 'a', int54, localizedFormats55, 10L, localizedFormats57, localizedFormats58 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException60 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray59);
        org.apache.commons.math.exception.NoBracketingException noBracketingException61 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray59);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException62 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray59);
        java.lang.Object[] objArray64 = new java.lang.Object[] { intArray27, localizedFormats29, localizedFormats30, localizedFormats31, 1 };
        java.lang.Object[] objArray65 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray64);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException66 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 10.0f, objArray65);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException67 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 35, objArray65);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException68 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 20000.0d, objArray65);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 99 + "'", int19 == 99);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 99 + "'", int54 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray65);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        int int2 = org.apache.commons.math.util.FastMath.max((-3), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray15 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int[] intArray23 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 'a', int24, localizedFormats25, 10L, localizedFormats27, localizedFormats28 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray29);
        org.apache.commons.math.exception.NoBracketingException noBracketingException31 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray29);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException(localizable0, (java.lang.Number) 350, objArray29);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext33 = notFiniteNumberException32.getContext();
        java.lang.Object obj35 = exceptionContext33.getValue("org.apache.commons.math.exception.NumberIsTooSmallException: a 141.421x-1 matrix cannot be a rotation matrix");
        java.util.Set<java.lang.String> strSet36 = exceptionContext33.getKeys();
        java.util.Set<java.lang.String> strSet37 = exceptionContext33.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(exceptionContext33);
        org.junit.Assert.assertNull(obj35);
        org.junit.Assert.assertNotNull(strSet36);
        org.junit.Assert.assertNotNull(strSet37);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.440227671403022E33d, 7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        long long2 = org.apache.commons.math.util.MathUtils.pow(406551963L, 406551964L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6256967040896757615L) + "'", long2 == (-6256967040896757615L));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 1077936126L, (java.lang.Number) 3628800L, true);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0E-14d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double7 = regulaFalsiSolver1.solve(1024458752, univariateRealFunction3, 4.282357203266032E47d, (-0.6098494453571888d), (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 115);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.7535901911063645d + "'", double1 == 4.7535901911063645d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) (-0.9999999f), (double) (byte) 1, 7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.625d + "'", double3 == 0.625d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-5.2521875E7d), (double) 112640L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.252187499999999E7d) + "'", double2 == (-5.252187499999999E7d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        int int3 = regulaFalsiSolver1.getEvaluations();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        double double5 = regulaFalsiSolver1.getAbsoluteAccuracy();
        double double6 = regulaFalsiSolver1.getMin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray13 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray21 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 'a', int22, localizedFormats23, 10L, localizedFormats25, localizedFormats26 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray27);
        double double30 = noBracketingException29.getHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext31 = noBracketingException29.getContext();
        double double32 = noBracketingException29.getFHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext33 = noBracketingException29.getContext();
        double double34 = noBracketingException29.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 99 + "'", int22 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(exceptionContext31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(exceptionContext33);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.0d, 4.282357203266032E47d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        double double2 = org.apache.commons.math.util.FastMath.copySign(20.0d, (double) 1.87041869E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.0d + "'", double2 == 20.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(1.5707963267948966d, 32.0d, (-1.967161317E9d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [32, -1,967,161,317]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-52.0f));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-3), 0.625d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.13617560368711d + "'", double1 == 92.13617560368711d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-700), 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-77000) + "'", int2 == (-77000));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-52521875L), (long) 350);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-52522225L) + "'", long2 == (-52522225L));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.201531174560813d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 800.0004485450899d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) '#', 21);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.340032E7d + "'", double2 == 7.340032E7d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.04428604238812435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04425712435723665d + "'", double1 == 0.04425712435723665d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (short) 0, (int) (byte) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1438416812 + "'", int1 == 1438416812);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 419L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6843418860808015E-14d + "'", double1 == 5.6843418860808015E-14d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int int1 = org.apache.commons.math.util.MathUtils.sign(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 1.915710547374109E22d, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.915710547374109E22d + "'", number5.equals(1.915710547374109E22d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 0.0f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(3.8429379997340795E18d, (double) 10150L, 11.548739357257746d, (-0.05735298000456796d), (double) '4', 1.0d, 10.000000000000002d, 1.3455368082272225E26d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.34557581404792E27d + "'", double8 == 1.34557581404792E27d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double1 = org.apache.commons.math.util.FastMath.sinh(112640.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray12 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray16);
        double[] doubleArray24 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray28 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray32 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray24);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double37 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray12);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 0.0d);
        double[] doubleArray40 = null;
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray40);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.98573884555135d + "'", double35 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 141.4213562373095d + "'", double36 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 20000.0d + "'", double37 == 20000.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray15 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int[] intArray23 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 'a', int24, localizedFormats25, 10L, localizedFormats27, localizedFormats28 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray29);
        org.apache.commons.math.exception.NoBracketingException noBracketingException31 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray29);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.1102230246251565E-16d, objArray29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (-1.0f), false);
        notFiniteNumberException32.addSuppressed((java.lang.Throwable) numberIsTooSmallException36);
        java.lang.Number number38 = numberIsTooSmallException36.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (-1.0f) + "'", number38.equals((-1.0f)));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.4718880042803011d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) (-935062073), (double) 960965831);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        int[] intArray12 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray20 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        int[] intArray28 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray29);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray47 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray48 = org.apache.commons.math.util.MathUtils.copyOf(intArray47);
        int[] intArray55 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray55);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 'a', int56, localizedFormats57, 10L, localizedFormats59, localizedFormats60 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException62 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray61);
        org.apache.commons.math.exception.NoBracketingException noBracketingException63 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray61);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException64 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray61);
        java.lang.Object[] objArray66 = new java.lang.Object[] { intArray29, localizedFormats31, localizedFormats32, localizedFormats33, 1 };
        java.lang.Object[] objArray67 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray66);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException68 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 10.0f, objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray67);
        exceptionContext1.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray67);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 99 + "'", int56 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats59.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 101L, (double) 3628800L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.0d + "'", double2 == 101.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        int int5 = regulaFalsiSolver3.getEvaluations();
        double double6 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver15 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 97, 1.7763568394002505E-15d, (-0.5440211108893698d));
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution19 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray36 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray37 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int[] intArray44 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray44);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 'a', int45, localizedFormats46, 10L, localizedFormats48, localizedFormats49 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException51 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray50);
        org.apache.commons.math.exception.NoBracketingException noBracketingException52 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray50);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException53 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray50);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException54 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) (-35L), objArray50);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray68 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray69 = org.apache.commons.math.util.MathUtils.copyOf(intArray68);
        int[] intArray76 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray69, intArray76);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats78 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats80 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats81 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray82 = new java.lang.Object[] { 'a', int77, localizedFormats78, 10L, localizedFormats80, localizedFormats81 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException83 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats60, objArray82);
        org.apache.commons.math.exception.NoBracketingException noBracketingException84 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats55, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray82);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) allowedSolution19, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray82);
        double double86 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(110, univariateRealFunction11, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver15, 0.04428604238812435d, (double) (-52.0f), 141.4213562373095d, allowedSolution19);
        double double87 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1300, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver3, (double) 3, (-0.5440211108893698d), 0.0d, allowedSolution19);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution19 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution19.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 99 + "'", int45 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 99 + "'", int77 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats78.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats80.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats81.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray82);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.04428604238812435d + "'", double86 == 0.04428604238812435d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 3.0d + "'", double87 == 3.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.NaN);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        long long1 = org.apache.commons.math.util.FastMath.abs(145L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 145L + "'", long1 == 145L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 700L, (float) 3, (float) 1632570001522275361L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int[] intArray6 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray14 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray14);
        int[] intArray22 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        int[] intArray30 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray30);
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray31, (int) (byte) 100);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray31);
        int[] intArray41 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray41);
        int[] intArray49 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray50 = org.apache.commons.math.util.MathUtils.copyOf(intArray49);
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray50, (int) (byte) 100);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray50);
        int[] intArray60 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray61 = org.apache.commons.math.util.MathUtils.copyOf(intArray60);
        int[] intArray63 = org.apache.commons.math.util.MathUtils.copyOf(intArray61, (int) (byte) 100);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray61);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray61);
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray31);
        int[] intArray73 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray74 = org.apache.commons.math.util.MathUtils.copyOf(intArray73);
        int[] intArray81 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray74, intArray81);
        int[] intArray89 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray90 = org.apache.commons.math.util.MathUtils.copyOf(intArray89);
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray90);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray74);
        java.lang.Class<?> wildcardClass93 = intArray7.getClass();
        int[] intArray94 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray96 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, 300032);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 99 + "'", int15 == 99);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 99 + "'", int82 == 99);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertNotNull(wildcardClass93);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertNotNull(intArray96);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray3 = new java.lang.Object[] { localizedFormats2 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 0.0d, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray3);
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = localizedFormats1.getLocalizedString(locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double double1 = org.apache.commons.math.util.FastMath.log10(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray13 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray21 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 'a', int22, localizedFormats23, 10L, localizedFormats25, localizedFormats26 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray27);
        double double30 = noBracketingException29.getHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext31 = noBracketingException29.getContext();
        double double32 = noBracketingException29.getFLo();
        java.lang.Throwable[] throwableArray33 = noBracketingException29.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 99 + "'", int22 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(exceptionContext31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertNotNull(throwableArray33);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        float float2 = org.apache.commons.math.util.FastMath.max(4.0f, (float) (-350L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getCount();
        incrementor0.incrementCount(0);
        incrementor0.resetCount();
        incrementor0.resetCount();
        int int7 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray14 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int[] intArray22 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 'a', int23, localizedFormats24, 10L, localizedFormats26, localizedFormats27 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray28);
        java.lang.Throwable[] throwableArray30 = mathIllegalStateException29.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException31 = new org.apache.commons.math.exception.MathArithmeticException(localizable5, (java.lang.Object[]) throwableArray30);
        org.apache.commons.math.exception.NoBracketingException noBracketingException32 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.6819643974304199d, 11.548739357257746d, (double) (-52521875L), 4.983606621708336d, (java.lang.Object[]) throwableArray30);
        double double33 = noBracketingException32.getLo();
        double double34 = noBracketingException32.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.6819643974304199d + "'", double33 == 0.6819643974304199d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.6819643974304199d + "'", double34 == 0.6819643974304199d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bad value for maximum iterations number: {0}" + "'", str1.equals("bad value for maximum iterations number: {0}"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3.1701538797227005d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 8, 3.4657359027997265d, (double) 1.47529576E15f, (double) (-0.9999999f));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1077936126L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.8014398509481984E16d, (java.lang.Number) (-1.58456325E29f), true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.58456325E29f) + "'", number4.equals((-1.58456325E29f)));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-2147483648));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.147483648E9d) + "'", double1 == (-2.147483648E9d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        double double3 = regulaFalsiSolver1.getFunctionValueAccuracy();
        int int4 = regulaFalsiSolver1.getEvaluations();
        int int5 = regulaFalsiSolver1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS;
        float[] floatArray6 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray12 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(floatArray6, floatArray12);
        float[] floatArray18 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray24 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray30 = new java.lang.Object[] { localizedFormats29 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 0.0d, (org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE;
        java.lang.Object[] objArray35 = new java.lang.Object[] { floatArray18, objArray30, "hi!", localizedFormats33, localizedFormats34 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException36 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray35);
        double[] doubleArray40 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray44 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray44);
        double[] doubleArray52 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray56 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray60 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray56);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray52);
        double[] doubleArray64 = new double[] {};
        double[] doubleArray68 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray72 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray76 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray80 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray84 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[] doubleArray88 = new double[] { (-0.7510136006188721d), 1.4210854715202004E-14d, 350L };
        double[][] doubleArray89 = new double[][] { doubleArray68, doubleArray72, doubleArray76, doubleArray80, doubleArray84, doubleArray88 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray64, doubleArray89);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray89);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException92 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) doubleArray89);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray89);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS));
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 101.98573884555135d + "'", double63 == 101.98573884555135d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getCount();
        incrementor0.incrementCount(0);
        int int5 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 100);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 97, 1.7763568394002505E-15d, (-0.5440211108893698d));
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray26 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray34 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 'a', int35, localizedFormats36, 10L, localizedFormats38, localizedFormats39 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray40);
        org.apache.commons.math.exception.NoBracketingException noBracketingException42 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray40);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException43 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray40);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException44 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) (-35L), objArray40);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray58 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray58);
        int[] intArray66 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray66);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats68 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats71 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 'a', int67, localizedFormats68, 10L, localizedFormats70, localizedFormats71 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException73 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats50, objArray72);
        org.apache.commons.math.exception.NoBracketingException noBracketingException74 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats45, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray72);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) allowedSolution9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray72);
        double double76 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(110, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 0.04428604238812435d, (double) (-52.0f), 141.4213562373095d, allowedSolution9);
        double double77 = regulaFalsiSolver5.getMin();
        double double78 = regulaFalsiSolver5.getMax();
        double double79 = regulaFalsiSolver5.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 99 + "'", int67 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats68.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats70.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats71.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.04428604238812435d + "'", double76 == 0.04428604238812435d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.7763568394002505E-15d + "'", double79 == 1.7763568394002505E-15d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        int[] intArray0 = null;
        int[] intArray7 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray15 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, (int) (byte) 100);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray16);
        int[] intArray26 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray34 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray34);
        int[] intArray37 = org.apache.commons.math.util.MathUtils.copyOf(intArray35, (int) (byte) 100);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray35);
        int[] intArray45 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray46 = org.apache.commons.math.util.MathUtils.copyOf(intArray45);
        int[] intArray48 = org.apache.commons.math.util.MathUtils.copyOf(intArray46, (int) (byte) 100);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray46);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray46);
        try {
            double double51 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray13 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray21 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 'a', int22, localizedFormats23, 10L, localizedFormats25, localizedFormats26 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray27);
        double double30 = noBracketingException29.getHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext31 = noBracketingException29.getContext();
        java.lang.Object obj33 = exceptionContext31.getValue("");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 99 + "'", int22 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
        org.junit.Assert.assertNotNull(exceptionContext31);
        org.junit.Assert.assertNull(obj33);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(11.548739357257746d, (double) 5L, 0.0d, (-40107.04565915762d));
        double double5 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.04428604238812435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21044249187871814d + "'", double1 == 0.21044249187871814d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.9579913551199332d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1113965065230056d + "'", double1 == 1.1113965065230056d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(81377.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.334510158704106d + "'", double1 == 43.334510158704106d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 31, (double) 1079738368, (-0.6098494453571887d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(110);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        float float2 = org.apache.commons.math.util.FastMath.min(35.0f, (float) (-35L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-35.0f) + "'", float2 == (-35.0f));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number2);
        org.apache.commons.math.exception.NotPositiveException notPositiveException5 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0.10589443039179369d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray27 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        int[] intArray35 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 'a', int36, localizedFormats37, 10L, localizedFormats39, localizedFormats40 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException42 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray41);
        org.apache.commons.math.exception.NoBracketingException noBracketingException43 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray41);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException44 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray41);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException45 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) (-35L), objArray41);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray59 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray60 = org.apache.commons.math.util.MathUtils.copyOf(intArray59);
        int[] intArray67 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray67);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats69 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats71 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray73 = new java.lang.Object[] { 'a', int68, localizedFormats69, 10L, localizedFormats71, localizedFormats72 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException74 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats51, objArray73);
        org.apache.commons.math.exception.NoBracketingException noBracketingException75 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats46, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray73);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) allowedSolution10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray73);
        org.apache.commons.math.exception.NoBracketingException noBracketingException77 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (-0.7510136006188721d), 1.95012437887911d, 3.9928775355694E158d, (double) 4.06551936E8f, objArray73);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException78 = new org.apache.commons.math.exception.MathIllegalStateException(localizable0, objArray73);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 99 + "'", int36 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 99 + "'", int68 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats69.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats71.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats72.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray73);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        int int2 = org.apache.commons.math.util.FastMath.max((-640097421), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        int int3 = incrementor0.getMaximalCount();
        int int4 = incrementor0.getCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 173.20508075688772d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.8014398509481984E16d, (java.lang.Number) (-1.58456325E29f), true);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        int int2 = incrementor0.getCount();
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount((int) (short) 1);
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5430806348152437d, (java.lang.Number) 1.077936126E9d, 52);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 21, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21L + "'", long2 == 21L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.4360530864024404E78d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 180.4920163955934d + "'", double1 == 180.4920163955934d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 406551964L, 31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1300);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-935062073), (float) 35, 1870418611);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-9.6073451653243034E17d), (double) 52.0f, 1079738368);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5407904953140532d, 1.0E-6d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 2, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.552713678800501E-15d, (java.lang.Number) (-3.842938E18f), 1079738368);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2.349824875421102d), (java.lang.Number) 8.0d, 0, orderDirection7, true);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.000004f + "'", float1 == 32.000004f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11.296012463252339d, (double) (-700));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 10, 110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 3, 0.0d, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        double double1 = org.apache.commons.math.util.FastMath.acos((-52.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        float[] floatArray5 = new float[] { 52, (byte) 100, (byte) 100, (byte) 1, 700L };
        float[] floatArray6 = null;
        float[] floatArray11 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray17 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(floatArray6, floatArray11);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray11);
        float[] floatArray26 = new float[] { 52, (byte) 100, (byte) 100, (byte) 1, 700L };
        float[] floatArray27 = null;
        float[] floatArray32 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray38 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray32, floatArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(floatArray27, floatArray32);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(floatArray26, floatArray32);
        float[] floatArray42 = new float[] {};
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray32, floatArray42);
        float[] floatArray48 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray54 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(floatArray48, floatArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray32, floatArray48);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray48);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1300);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1300);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 350L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 115L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 115);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(100.00005606813623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        double double2 = org.apache.commons.math.util.FastMath.pow((-52.71428580082049d), (-1.4920006428759682d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        float[] floatArray4 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray10 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray10);
        float[] floatArray17 = new float[] { 52, (byte) 100, (byte) 100, (byte) 1, 700L };
        float[] floatArray18 = null;
        float[] floatArray23 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray29 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(floatArray23, floatArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray23);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(floatArray17, floatArray23);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray10, floatArray23);
        float[] floatArray38 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray44 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(floatArray38, floatArray44);
        float[] floatArray50 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray56 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(floatArray50, floatArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray44, floatArray50);
        float[] floatArray63 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray69 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(floatArray63, floatArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray50, floatArray63);
        float[] floatArray77 = new float[] { 52, (byte) 100, (byte) 100, (byte) 1, 700L };
        float[] floatArray78 = null;
        float[] floatArray83 = new float[] { 100.0f, '4', (short) 0, (short) 100 };
        float[] floatArray89 = new float[] { 'a', 10, (-1L), (-1L), 100L };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(floatArray83, floatArray89);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(floatArray78, floatArray83);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(floatArray77, floatArray83);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray63, floatArray77);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(floatArray23, floatArray63);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(floatArray77);
        org.junit.Assert.assertNotNull(floatArray83);
        org.junit.Assert.assertNotNull(floatArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, objArray1);
        java.lang.Throwable[] throwableArray3 = notFiniteNumberException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1300);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 350L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 115L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 115);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 9.19629206462646E56d, (java.lang.Number) bigInteger17, true);
        java.lang.Number number20 = numberIsTooLargeException19.getArgument();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9.19629206462646E56d + "'", number20.equals(9.19629206462646E56d));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 359.1342053695755d, number2, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-640097421), (float) (byte) 1, (float) 1870418611);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        float float1 = org.apache.commons.math.util.FastMath.abs(21.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 21.0f + "'", float1 == 21.0f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-2));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9640275800758169d) + "'", double1 == (-0.9640275800758169d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 2.05819810795577952E17d, true);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray13 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray21 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 'a', int22, localizedFormats23, 10L, localizedFormats25, localizedFormats26 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray27);
        java.lang.Throwable[] throwableArray29 = mathIllegalStateException28.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException30 = new org.apache.commons.math.exception.MathArithmeticException(localizable4, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException32 = new org.apache.commons.math.exception.MathArithmeticException(localizable2, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException33 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        java.lang.Object[] objArray38 = new java.lang.Object[] { localizedFormats37 };
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 0.0d, (org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray38);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException40 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, objArray38);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException41 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 99 + "'", int22 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertNotNull(objArray38);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.1091326487692777E156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) '#', 4.3937508179185116E49d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.3937508179185116E49d + "'", double2 == 4.3937508179185116E49d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.1113965065230054d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1113965065230056d + "'", double1 == 1.1113965065230056d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 35, (long) 115);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-700), (float) (-6481230923761256927L), (float) 1475295763334400L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.8014398509481984E16d, (-104), 350);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(419L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number5 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) -1 + "'", number4.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) '4', 1635593510);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray12 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray20 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 'a', int21, localizedFormats22, 10L, localizedFormats24, localizedFormats25 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray26);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray26);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray26);
        java.lang.Object[] objArray31 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.4360530864024404E78d, objArray31);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.14391156831212787d);
        java.lang.Number number35 = notStrictlyPositiveException34.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SELF_ADJOINT_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 0 + "'", number35.equals(0));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5576619350218566E49d, (-8.313599049999999E8d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray12 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray16);
        double[] doubleArray24 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray28 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray32 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray24);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double37 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray12);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.98573884555135d + "'", double35 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 141.4213562373095d + "'", double36 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 20000.0d + "'", double37 == 20000.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-831359905) + "'", int38 == (-831359905));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 7.340032E7d, 2.6830520615455938E13d, 0.6819643974304199d, (-104));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double2 = org.apache.commons.math.util.FastMath.copySign((-0.5756796352482382d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5756796352482382d + "'", double2 == 0.5756796352482382d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(9.999999f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-474910967), 970);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 970, n = -474,910,967");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        double[] doubleArray3 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray7 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray12 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray16 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray16);
        double[] doubleArray24 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray28 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray32 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray24);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double37 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray3, doubleArray12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (short) 0, (int) (byte) 100);
        java.lang.Number number42 = nonMonotonousSequenceException41.getPrevious();
        int int43 = nonMonotonousSequenceException41.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = nonMonotonousSequenceException41.getDirection();
        boolean boolean47 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection44, true, false);
        double[] doubleArray48 = null;
        double[] doubleArray52 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray56 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean61 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray56, orderDirection58, true, false);
        double[] doubleArray68 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray72 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray76 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray72, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray72);
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray68);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray56, (int) (byte) 0);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray56);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 101.98573884555135d + "'", double35 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 141.4213562373095d + "'", double36 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 20000.0d + "'", double37 == 20000.0d);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (short) 0 + "'", number42.equals((short) 0));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 100 + "'", int43 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 201.00454536063498d + "'", double79 == 201.00454536063498d);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1300);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 350L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 115L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 700L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.9640275800758169d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8557071411850466d) + "'", double1 == (-0.8557071411850466d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 700L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1368683772161603E-13d + "'", double1 == 1.1368683772161603E-13d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, 52.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        int int3 = regulaFalsiSolver1.getEvaluations();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        double double5 = regulaFalsiSolver1.getAbsoluteAccuracy();
        int int6 = regulaFalsiSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 8.096498475988433d, 7.930067261567155E14d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 300032, (-935062423));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.8387761814701147d, 0.0d, (double) 35L, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.8557071411850466d), (java.lang.Number) 10.00000011920929d, true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 145L, 233, 1131171778);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 1,131,171,778, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        double double1 = org.apache.commons.math.util.MathUtils.sign(8.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException2 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (short) 0, (int) (byte) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        boolean boolean8 = nonMonotonousSequenceException6.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1077936126, (java.lang.Number) 700L, (-2147483648), orderDirection9, false);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-2147483648));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.35520732382925013d, (java.lang.Number) (-0.0f), true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1023), 1.8387761814701147d, 0.9579913551199332d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray1 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(145L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 145L + "'", long2 == 145L);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.7159673813711397E7d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-595783431) + "'", int1 == (-595783431));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 6.4812307E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100000, 2.718281828459045d, 110360.9054464095d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.1102230246251565E-16d, 1.5430806348152437d, (double) (byte) 1);
        double double4 = regulaFalsiSolver3.getMin();
        double double5 = regulaFalsiSolver3.getMax();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1300);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) '4');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.7080784171785247d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6161271693491127d + "'", double1 == 0.6161271693491127d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1131171743L, (float) (-1332031919));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.13117171E9f + "'", float2 == 1.13117171E9f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-127), 112640L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2601197212333244415L) + "'", long2 == (-2601197212333244415L));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(Double.NaN, (double) 100);
        double double3 = regulaFalsiSolver2.getStartValue();
        double double4 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double5 = regulaFalsiSolver2.getMax();
        double double6 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1.0f), (double) 1077936126L, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.9200378500616133d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray15 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray15);
        int[] intArray23 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 'a', int24, localizedFormats25, 10L, localizedFormats27, localizedFormats28 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray29);
        org.apache.commons.math.exception.NoBracketingException noBracketingException31 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray29);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.1102230246251565E-16d, objArray29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (-1.0f), false);
        notFiniteNumberException32.addSuppressed((java.lang.Throwable) numberIsTooSmallException36);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray57 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray57);
        int[] intArray65 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray65);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats67 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats69 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray71 = new java.lang.Object[] { 'a', int66, localizedFormats67, 10L, localizedFormats69, localizedFormats70 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException72 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray71);
        org.apache.commons.math.exception.NoBracketingException noBracketingException73 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray71);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException74 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 700L, objArray71);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException75 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, (java.lang.Number) (-35L), objArray71);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException76 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (byte) -1, objArray71);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException77 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray71);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException78 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException36, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray71);
        org.apache.commons.math.exception.MathInternalError mathInternalError79 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooSmallException36);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext80 = mathInternalError79.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 99 + "'", int66 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats67.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats69.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats70.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(exceptionContext80);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(32, 100000);
        int int3 = dimensionMismatchException2.getDimension();
        int int4 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100000 + "'", int3 == 100000);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100000 + "'", int4 == 100000);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 129.77179386174797d, (java.lang.Number) 0.8791941103356559d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8791941103356559d + "'", number4.equals(0.8791941103356559d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-210021700L), 0.0d, 0.01081551766930477d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '4', 0.0d);
        double double3 = regulaFalsiSolver2.getMin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-9.6073451653243034E17d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.04425712435723665d, (double) 52, (-2147483648));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(10, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 1024, (float) 52, 4.06551968E8f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        int[] intArray6 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray14 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray14);
        int[] intArray22 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray22);
        int[] intArray30 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray30);
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray31, (int) (byte) 100);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray31);
        int[] intArray41 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray41);
        int[] intArray49 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray50 = org.apache.commons.math.util.MathUtils.copyOf(intArray49);
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray50, (int) (byte) 100);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray50);
        int[] intArray60 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray61 = org.apache.commons.math.util.MathUtils.copyOf(intArray60);
        int[] intArray63 = org.apache.commons.math.util.MathUtils.copyOf(intArray61, (int) (byte) 100);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray61);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray61);
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray31);
        int[] intArray73 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray74 = org.apache.commons.math.util.MathUtils.copyOf(intArray73);
        int[] intArray76 = org.apache.commons.math.util.MathUtils.copyOf(intArray74, (int) (byte) 100);
        int[] intArray83 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray84 = org.apache.commons.math.util.MathUtils.copyOf(intArray83);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray84);
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray84);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 99 + "'", int15 == 99);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray4 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray8 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection10, true, false);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5703080455837017d), (java.lang.Number) 1.61650502030123104E17d, 10, orderDirection18, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection18, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (100 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 11.296012463252339d, (java.lang.Number) 108.06656506470014d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 108.06656506470014d + "'", number5.equals(108.06656506470014d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException();
        java.lang.Throwable[] throwableArray8 = nullArgumentException7.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 5.393606884554982d, (double) (-1023), 72.87006611748394d, (double) (-52.0f), (java.lang.Object[]) throwableArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double2 = org.apache.commons.math.util.MathUtils.round(286.4788975654116d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 286.5d + "'", double2 == 286.5d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1300);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 350L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 100);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 300031);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 21);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(8.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 360.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray9 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        int[] intArray17 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 'a', int18, localizedFormats19, 10L, localizedFormats21, localizedFormats22 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray23);
        java.lang.Throwable[] throwableArray25 = mathIllegalStateException24.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext27 = mathArithmeticException26.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext28 = mathArithmeticException26.getContext();
        java.lang.Object obj30 = exceptionContext28.getValue("empty polynomials coefficients array");
        java.util.Set<java.lang.String> strSet31 = exceptionContext28.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 99 + "'", int18 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNotNull(exceptionContext27);
        org.junit.Assert.assertNotNull(exceptionContext28);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertNotNull(strSet31);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1024.0001f);
        int int2 = regulaFalsiSolver1.getEvaluations();
        double double3 = regulaFalsiSolver1.getRelativeAccuracy();
        double double4 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        int[] intArray6 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray14 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray14);
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14);
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, 0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 99 + "'", int15 == 99);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(300000, 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 300000 + "'", int2 == 300000);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f));
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        int int3 = regulaFalsiSolver1.getEvaluations();
        double double4 = regulaFalsiSolver1.getRelativeAccuracy();
        double double5 = regulaFalsiSolver1.getStartValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray13 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray21 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 'a', int22, localizedFormats23, 10L, localizedFormats25, localizedFormats26 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.0d, (double) (-1), (double) (short) 100, Double.NaN, objArray27);
        double double30 = noBracketingException29.getFHi();
        double double31 = noBracketingException29.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 99 + "'", int22 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        int[] intArray11 = new int[] { (byte) 1, '4', (short) 1, 'a', (byte) -1, (short) 10 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray19 = new int[] { 100, ' ', (short) 100, (byte) 100, 0, (-1) };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 'a', int20, localizedFormats21, 10L, localizedFormats23, localizedFormats24 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray25);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 350, objArray25);
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray25);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 99 + "'", int20 == 99);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) (-2147483648));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.14748365E9f) + "'", float2 == (-2.14748365E9f));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0949103602489965E21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 49.13810663056612d + "'", double1 == 49.13810663056612d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray10);
        double[] doubleArray24 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray28 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray32 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double[] doubleArray41 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray45 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray49 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray45);
        double[] doubleArray55 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray59 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray59);
        double[] doubleArray67 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray71 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray75 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray71, doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray67, doubleArray71);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray55, doubleArray67);
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double double80 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray45, doubleArray55);
        double double81 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray55);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double double83 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 101.98573884555135d + "'", double78 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 141.4213562373095d + "'", double79 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 20000.0d + "'", double80 == 20000.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-831359905) + "'", int82 == (-831359905));
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (-0.15051499783199063d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException7 = new org.apache.commons.math.exception.NullArgumentException();
        java.lang.Throwable[] throwableArray8 = nullArgumentException7.getSuppressed();
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 5.393606884554982d, (double) (-1023), 72.87006611748394d, (double) (-52.0f), (java.lang.Object[]) throwableArray8);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray8);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.4E-45f, (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) (short) 0, (int) (byte) 100);
        int int4 = nonMonotonousSequenceException3.getIndex();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException3.getContext();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(exceptionContext6);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.1701538797227005d, (java.lang.Number) 1.077936128E9d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        double[] doubleArray6 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray10 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray14 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray20 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray24 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray24);
        double[] doubleArray29 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray33 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray41 = new double[] { (-1.0f), (byte) 10, 110.00454536063498d, 419.0d, 1L, 10.000000000000002d };
        double[] doubleArray45 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray49 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray49);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray45);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray41);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double54 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray20, doubleArray29);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray29);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray29);
        double[] doubleArray60 = new double[] { 100.0f, (byte) 0, (byte) 100 };
        double[] doubleArray64 = new double[] { 1.1102230246251565E-16d, 100L, 0.0d };
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray56, doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 101.98573884555135d + "'", double52 == 101.98573884555135d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 141.4213562373095d + "'", double53 == 141.4213562373095d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 20000.0d + "'", double54 == 20000.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.1102230246251565E-14d + "'", double66 == 1.1102230246251565E-14d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 5.655859600022727E8d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(286.4788975654116d, 2.683052061545682E13d, 0.0d, (double) 419L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.686377967022119E15d + "'", double4 == 7.686377967022119E15d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 3, true);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (short) 100);
        java.lang.Throwable[] throwableArray7 = maxCountExceededException6.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.2645189576252271d, 433.43280909501993d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2645189576252274d + "'", double2 == 1.2645189576252274d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 110, (java.lang.Number) 359.1342053695755d, 1024);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 21L, (-127));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2342690683634019E-37d + "'", double2 == 1.2342690683634019E-37d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.6098494453571887d), 0.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 100L, 0.0d);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        double double4 = regulaFalsiSolver2.getMin();
        double double5 = regulaFalsiSolver2.getAbsoluteAccuracy();
        int int6 = regulaFalsiSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        double double1 = org.apache.commons.math.util.FastMath.signum(81377.39570642984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '4', 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5148 + "'", int2 == 5148);
    }
}

