import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double2 = org.apache.commons.math.util.FastMath.copySign(100.0d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.tan(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray7 = new double[] { (short) 100, (short) 0, 100, ' ', (-0.5872139151569291d) };
        try {
            double[] doubleArray8 = parametric0.gradient((double) (short) 1, doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 5 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((-0.5872139151569291d), (double) 100L, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.analysis.function.Gaussian gaussian0 = new org.apache.commons.math.analysis.function.Gaussian();
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-0.99999994f) + "'", float1 == (-0.99999994f));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        java.lang.String str2 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RandomKeyMutation works only with RandomKeys, not {0}" + "'", str2.equals("RandomKeyMutation works only with RandomKeys, not {0}"));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        float float2 = org.apache.commons.math.util.FastMath.copySign(0.0f, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.0f) + "'", float2 == (-0.0f));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray7 = new double[] { 1.1752011936438014d, (byte) 10, (byte) -1, 100, 2.718281828459045d };
        try {
            double double8 = parametric0.value((double) (short) -1, doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 5 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (-127), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        org.apache.commons.math.exception.ConvergenceException convergenceException13 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric3 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray8 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray9 = gaussianFitter2.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric3, doubleArray8);
        double[] doubleArray10 = null;
        try {
            double[] doubleArray11 = gaussianFitter2.fit(doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        float float2 = org.apache.commons.math.util.FastMath.scalb(10.0f, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 5.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(10.0d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        java.lang.String str4 = mathIllegalArgumentException3.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: cannot compute beta density at 0 when alpha = {0}: illegal state" + "'", str4.equals("org.apache.commons.math.exception.MathIllegalArgumentException: cannot compute beta density at 0 when alpha = {0}: illegal state"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 6, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 0, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (short) 0, 100.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 5.0f, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        float float1 = org.apache.commons.math.util.FastMath.ulp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray3 = new double[] { (short) 0 };
        try {
            double[] doubleArray4 = parametric0.gradient((double) (short) 0, doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.5872139151569291d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (short) 10, 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 640.0d + "'", double2 == 640.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.exception.ConvergenceException convergenceException0 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, localizable4, objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) '4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 53248.0f + "'", float2 == 53248.0f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (byte) -1, (-0.0d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100L, (-0.99999994f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (byte) 100, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-0.5872139151569291d), 100.0d, (double) (short) 0);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = null;
        levenbergMarquardtOptimizer3.setConvergenceChecker(vectorialPointValuePairConvergenceChecker4);
        try {
            double[] doubleArray6 = levenbergMarquardtOptimizer3.getStartPoint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0d, (double) (-0.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 5.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        float float2 = org.apache.commons.math.util.FastMath.scalb(0.0f, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray0 = null;
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser1 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed: input array");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(10.0f, (double) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.999999f + "'", float2 == 9.999999f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric3 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int5 = levenbergMarquardtOptimizer4.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter6 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer4);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer7 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int8 = levenbergMarquardtOptimizer7.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter9 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer7);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric10 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray15 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray16 = gaussianFitter9.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric10, doubleArray15);
        double[] doubleArray17 = gaussianFitter6.fit(doubleArray16);
        double[] doubleArray18 = gaussianFitter2.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric3, doubleArray16);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer20 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int21 = levenbergMarquardtOptimizer20.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter22 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer20);
        gaussianFitter22.clearObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer24 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int25 = levenbergMarquardtOptimizer24.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter26 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer24);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric27 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray32 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray33 = gaussianFitter26.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric27, doubleArray32);
        double[] doubleArray36 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray36, true);
        double[] doubleArray39 = gaussianFitter22.fit(doubleArray36);
        try {
            double[] doubleArray40 = parametric3.gradient((double) 100L, doubleArray39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 2 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) 10, (double) (-0.0f), (double) ' ');
        try {
            double[] doubleArray4 = levenbergMarquardtOptimizer3.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-127));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-127.0d) + "'", double1 == (-127.0d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.exp(640.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881133903158874E277d + "'", double1 == 8.881133903158874E277d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 100, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (short) 1, (double) (short) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (-0.5872139151569291d), true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-0.5872139151569291d) + "'", number6.equals((-0.5872139151569291d)));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 10, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.000000000000001d + "'", double1 == 5.000000000000001d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) ' ', (double) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.999998f + "'", float2 == 31.999998f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int3 = levenbergMarquardtOptimizer2.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer2);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric5 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray10 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray11 = gaussianFitter4.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric5, doubleArray10);
        double[] doubleArray14 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray14, true);
        double[] doubleArray17 = vectorialPointValuePair16.getPoint();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer18 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int19 = levenbergMarquardtOptimizer18.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter20 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer18);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric21 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray26 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray27 = gaussianFitter20.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric21, doubleArray26);
        double[] doubleArray30 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair32 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray30, true);
        boolean boolean33 = simpleVectorialValueChecker0.converged(1, vectorialPointValuePair16, vectorialPointValuePair32);
        double double34 = simpleVectorialValueChecker0.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.1102230246251565E-14d + "'", double34 == 1.1102230246251565E-14d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        double double2 = levenbergMarquardtOptimizer0.getRMS();
        int int3 = levenbergMarquardtOptimizer0.getEvaluations();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction5 = null;
        double[] doubleArray6 = null;
        double[] doubleArray8 = new double[] { (byte) -1 };
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer9 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int10 = levenbergMarquardtOptimizer9.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter11 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer9);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric12 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray17 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray18 = gaussianFitter11.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric12, doubleArray17);
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = levenbergMarquardtOptimizer0.optimize(1, differentiableMultivariateVectorialFunction5, doubleArray6, doubleArray8, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        float float2 = org.apache.commons.math.util.FastMath.min(5.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException4);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        java.lang.Object[] objArray12 = mathIllegalArgumentException11.getArguments();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.8708170232237885d + "'", double0 == 0.8708170232237885d);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.1102230246251565E-14d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException1 = new org.apache.commons.math.exception.NullArgumentException(localizable0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) '4', (-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.00557687073941d + "'", double2 == 52.00557687073941d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: ");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray11 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray12 = gaussianFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray11);
        double[] doubleArray13 = gaussianFitter2.fit(doubleArray12);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = gaussianFitter2.getObservations();
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser15 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math.exception.NullArgumentException();
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException8, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray23);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException20, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray23);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException(objArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException31);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.apache.commons.math.exception.ConvergenceException convergenceException34 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException34, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray36);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException41);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, objArray45);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException47 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException42, (org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray45);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException48 = new org.apache.commons.math.exception.MathIllegalStateException(objArray45);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException48);
        java.lang.Object[] objArray50 = new java.lang.Object[] { mathIllegalStateException31, localizedFormats33, convergenceException34, localizedFormats38, mathIllegalStateException48 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException51 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalStateException26, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, localizable28, objArray50);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException52 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException14, localizable15, localizable16, objArray50);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException53 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray50);
        java.lang.String str55 = convergenceException54.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction." + "'", str55.equals("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction."));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 10.0f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 5.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28366218546322625d + "'", double1 == 0.28366218546322625d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10L, (double) 9.999999f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 53248.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 929.3529201019406d + "'", double1 == 929.3529201019406d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((double) 0L, (-127.0d), 1.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 31.999998f, (double) 53248.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 53248.0096153826d + "'", double2 == 53248.0096153826d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialPointValuePairConvergenceChecker2);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter4 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        double double5 = levenbergMarquardtOptimizer0.getChiSquare();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker6 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer8 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int9 = levenbergMarquardtOptimizer8.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter10 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer8);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric11 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray16 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray17 = gaussianFitter10.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric11, doubleArray16);
        double[] doubleArray20 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair22 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray20, true);
        double[] doubleArray23 = vectorialPointValuePair22.getPoint();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer24 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int25 = levenbergMarquardtOptimizer24.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter26 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer24);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric27 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray32 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray33 = gaussianFitter26.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric27, doubleArray32);
        double[] doubleArray36 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray36, true);
        boolean boolean39 = simpleVectorialValueChecker6.converged(1, vectorialPointValuePair22, vectorialPointValuePair38);
        levenbergMarquardtOptimizer0.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialPointValuePairConvergenceChecker2);
        int int4 = levenbergMarquardtOptimizer0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cannot access {0} method in percentile implementation {1}" + "'", str1.equals("cannot access {0} method in percentile implementation {1}"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric3 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int5 = levenbergMarquardtOptimizer4.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter6 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer4);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer7 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int8 = levenbergMarquardtOptimizer7.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter9 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer7);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric10 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray15 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray16 = gaussianFitter9.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric10, doubleArray15);
        double[] doubleArray17 = gaussianFitter6.fit(doubleArray16);
        double[] doubleArray18 = gaussianFitter2.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric3, doubleArray16);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer20 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int21 = levenbergMarquardtOptimizer20.getMaxEvaluations();
        double double22 = levenbergMarquardtOptimizer20.getRMS();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter23 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer20);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer24 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int25 = levenbergMarquardtOptimizer24.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter26 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer24);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric27 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer28 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int29 = levenbergMarquardtOptimizer28.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter30 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer28);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer31 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int32 = levenbergMarquardtOptimizer31.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter33 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer31);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric34 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray39 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray40 = gaussianFitter33.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric34, doubleArray39);
        double[] doubleArray41 = gaussianFitter30.fit(doubleArray40);
        double[] doubleArray42 = gaussianFitter26.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric27, doubleArray40);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer43 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int44 = levenbergMarquardtOptimizer43.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter45 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer43);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric46 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray51 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray52 = gaussianFitter45.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric46, doubleArray51);
        double[] doubleArray53 = curveFitter23.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric27, doubleArray52);
        try {
            double[] doubleArray54 = parametric3.gradient((double) (byte) 0, doubleArray52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 4 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertEquals((double) double22, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 100L, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.4987562112089d + "'", double2 == 100.4987562112089d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(0.0d, 0.0d, 4.641588833612779d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException(number0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double2 = org.apache.commons.math.util.FastMath.max(100.0d, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.ceil(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11014.0d + "'", double1 == 11014.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (-1.0f), 100.0d, (double) (byte) -1, 1.0d, (double) 100L);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter6 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        double double7 = levenbergMarquardtOptimizer5.getChiSquare();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction9 = null;
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer11 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int12 = levenbergMarquardtOptimizer11.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter13 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer11);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric14 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray19 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray20 = gaussianFitter13.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric14, doubleArray19);
        double[] doubleArray23 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray23, true);
        double[] doubleArray26 = vectorialPointValuePair25.getValueRef();
        double[] doubleArray27 = vectorialPointValuePair25.getPointRef();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer28 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int29 = levenbergMarquardtOptimizer28.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter30 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer28);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric31 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray36 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray37 = gaussianFitter30.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric31, doubleArray36);
        double[] doubleArray40 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray40, true);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer43 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int44 = levenbergMarquardtOptimizer43.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter45 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer43);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric46 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray51 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray52 = gaussianFitter45.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric46, doubleArray51);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair53 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray40, doubleArray52);
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair54 = levenbergMarquardtOptimizer5.optimize((int) (short) 0, differentiableMultivariateVectorialFunction9, doubleArray10, doubleArray27, doubleArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((double) (short) 0, 0.0d, (double) 9.999999f);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = gaussian3.derivative();
        org.junit.Assert.assertNotNull(univariateRealFunction4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathIllegalStateException2.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (-1.0f), 100.0d, (double) (byte) -1, 1.0d, (double) 100L);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter6 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        curveFitter6.addObservedPoint(1.5707963267948966d, (double) '4', 5.000000000000001d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian(Double.NEGATIVE_INFINITY, (double) (short) 1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: ");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 6);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 6, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.000000000000001d + "'", double2 == 6.000000000000001d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException(objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException29);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.apache.commons.math.exception.ConvergenceException convergenceException32 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException39);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray43);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException45 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException40, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray43);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math.exception.MathIllegalStateException(objArray43);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException46);
        java.lang.Object[] objArray48 = new java.lang.Object[] { mathIllegalStateException29, localizedFormats31, convergenceException32, localizedFormats36, mathIllegalStateException46 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalStateException24, (org.apache.commons.math.exception.util.Localizable) localizedFormats25, localizable26, objArray48);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException12, localizable13, localizable14, objArray48);
        org.apache.commons.math.optimization.OptimizationException optimizationException51 = new org.apache.commons.math.optimization.OptimizationException("", objArray48);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException52 = new org.apache.commons.math.exception.MathIllegalStateException(objArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.0d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.03520653267642995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.144699134146741E-4d + "'", double1 == 6.144699134146741E-4d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray6);
        org.apache.commons.math.exception.ConvergenceException convergenceException9 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9);
        convergenceException3.addSuppressed((java.lang.Throwable) mathException10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) 100L, (-1.0d), (double) '4');
        double double4 = weightedObservedPoint3.getWeight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double double1 = simpleVectorialValueChecker0.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-14d + "'", double1 == 1.1102230246251565E-14d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException3 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException3);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathRuntimeException5.getSpecificPattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathRuntimeException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray14);
        org.apache.commons.math.optimization.OptimizationException optimizationException18 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math.util.FastMath.tanh(8.881133903158874E277d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric3 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int5 = levenbergMarquardtOptimizer4.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter6 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer4);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer7 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int8 = levenbergMarquardtOptimizer7.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter9 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer7);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric10 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray15 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray16 = gaussianFitter9.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric10, doubleArray15);
        double[] doubleArray17 = gaussianFitter6.fit(doubleArray16);
        double[] doubleArray18 = gaussianFitter2.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric3, doubleArray16);
        try {
            double[] doubleArray19 = gaussianFitter2.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 'a', (double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 96.99999f + "'", float2 == 96.99999f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-0.5872139151569291d), 100.0d, (double) (short) 0);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = null;
        levenbergMarquardtOptimizer3.setConvergenceChecker(vectorialPointValuePairConvergenceChecker4);
        double double6 = levenbergMarquardtOptimizer3.getRMS();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction3 = null;
        double[] doubleArray7 = new double[] { (-0.5872139151569291d), 1.1752011936438014d, 0 };
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer8 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int9 = levenbergMarquardtOptimizer8.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter10 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer8);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer11 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int12 = levenbergMarquardtOptimizer11.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter13 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer11);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric14 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray19 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray20 = gaussianFitter13.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric14, doubleArray19);
        double[] doubleArray21 = gaussianFitter10.fit(doubleArray20);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray21, true);
        double[] doubleArray24 = null;
        double[] doubleArray25 = null;
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = levenbergMarquardtOptimizer0.optimize(10, differentiableMultivariateVectorialFunction3, doubleArray7, doubleArray24, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, 0, (int) (short) 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-0.5872139151569291d), 100.0d, (double) (short) 0);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = null;
        levenbergMarquardtOptimizer3.setConvergenceChecker(vectorialPointValuePairConvergenceChecker4);
        double double6 = levenbergMarquardtOptimizer3.getChiSquare();
        double double7 = levenbergMarquardtOptimizer3.getChiSquare();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-0.5872139151569291d), 100.0d, (double) (short) 0);
        int int4 = levenbergMarquardtOptimizer3.getJacobianEvaluations();
        try {
            double[] doubleArray5 = levenbergMarquardtOptimizer3.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((-127.0d), (double) (-1L));
        double double3 = simpleVectorialValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-127.0d) + "'", double3 == (-127.0d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        try {
            double[] doubleArray2 = levenbergMarquardtOptimizer0.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialPointValuePairConvergenceChecker2);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter4 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        curveFitter5.clearObservations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        float float2 = org.apache.commons.math.util.FastMath.max(5.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.exception.ConvergenceException convergenceException0 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException0.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.00001f);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException(objArray9);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException12);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) convergenceException13);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 100.00001f + "'", number2.equals(100.00001f));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        float float1 = org.apache.commons.math.util.FastMath.ulp(1.4E-45f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.sinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter1 = new org.apache.commons.math.optimization.fitting.GaussianFitter(differentiableMultivariateVectorialOptimizer0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.exp(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException(objArray10);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException2, "hi!", objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException15 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) mathIllegalStateException2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        double double2 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter3 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        int int4 = levenbergMarquardtOptimizer0.getJacobianEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.exception.ConvergenceException convergenceException0 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException7, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException0, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, localizable3, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException18);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathRuntimeException20.getSpecificPattern();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer25 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-0.5872139151569291d), 100.0d, (double) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray34);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException36 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) 0.0f, (double) (short) 1, 100.0d);
        java.lang.Object[] objArray44 = new java.lang.Object[] { mathRuntimeException20, levenbergMarquardtOptimizer25, localizedFormats26, localizedFormats38, (-1.5707963267948966d), 0.0f };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException45 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) (short) -1, objArray44);
        java.lang.Number number46 = maxCountExceededException45.getMax();
        mathIllegalStateException13.addSuppressed((java.lang.Throwable) maxCountExceededException45);
        java.lang.Number number48 = maxCountExceededException45.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + (short) -1 + "'", number46.equals((short) -1));
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + (short) -1 + "'", number48.equals((short) -1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray12);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray12);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray12);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNull(localizable18);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.log10(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.041914822473389d + "'", double1 == 4.041914822473389d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) ' ', 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2048.0f + "'", float2 == 2048.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.ConvergenceException convergenceException0 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        java.lang.Object[] objArray4 = mathException3.getArguments();
        org.apache.commons.math.exception.ConvergenceException convergenceException5 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray7);
        mathException3.addSuppressed((java.lang.Throwable) mathException8);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException5);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException(objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException29);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.apache.commons.math.exception.ConvergenceException convergenceException32 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException32, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException39);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray43);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException45 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException40, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray43);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math.exception.MathIllegalStateException(objArray43);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException46);
        java.lang.Object[] objArray48 = new java.lang.Object[] { mathIllegalStateException29, localizedFormats31, convergenceException32, localizedFormats36, mathIllegalStateException46 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalStateException24, (org.apache.commons.math.exception.util.Localizable) localizedFormats25, localizable26, objArray48);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException50 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException12, localizable13, localizable14, objArray48);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.", objArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: ");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.0d, Double.NEGATIVE_INFINITY, (double) 31.999998f, (-0.7615941559557649d), (double) 0.0f);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray11 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray12 = gaussianFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray11);
        double[] doubleArray13 = gaussianFitter2.fit(doubleArray12);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer14 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int15 = levenbergMarquardtOptimizer14.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter16 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer14);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric17 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray22 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray23 = gaussianFitter16.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric17, doubleArray22);
        double[] doubleArray26 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray26, true);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer29 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int30 = levenbergMarquardtOptimizer29.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter31 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer29);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric32 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray37 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray38 = gaussianFitter31.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric32, doubleArray37);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray38);
        double[] doubleArray40 = vectorialPointValuePair39.getPoint();
        double[] doubleArray41 = gaussianFitter2.fit(doubleArray40);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray42 = gaussianFitter2.getObservations();
        gaussianFitter2.addObservedPoint((double) (byte) 10, (double) (byte) -1);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray46 = gaussianFitter2.getObservations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(weightedObservedPointArray42);
        org.junit.Assert.assertNotNull(weightedObservedPointArray46);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (short) 100, 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.2676506E32f + "'", float2 == 1.2676506E32f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException1 = new org.apache.commons.math.optimization.OptimizationException(throwable0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 100, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 31.999998f, 0.28366218546322625d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5619321151443613d + "'", double2 == 1.5619321151443613d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1.0f, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.574681148648784d + "'", double2 == 2.574681148648784d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-0.5872139151569291d), 100.0d, (double) (short) 0);
        int int4 = levenbergMarquardtOptimizer3.getJacobianEvaluations();
        int int5 = levenbergMarquardtOptimizer3.getJacobianEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) 0.0f, (double) (short) 1, 100.0d);
        double double4 = weightedObservedPoint3.getX();
        double double5 = weightedObservedPoint3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException1 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray5);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException(objArray5);
        java.lang.Object[] objArray8 = mathIllegalStateException7.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException9 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) nullArgumentException1, "org.apache.commons.math.exception.MathIllegalArgumentException: cannot compute beta density at 0 when alpha = {0}: illegal state", objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(1.1102230246251565E-14d, (-0.0d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 6, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) ' ', 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-127.0d), (double) 0L, 22026.465794806718d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((double) (byte) 0, (double) 10.0f);
        double double4 = gaussian2.value(5.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = gaussian2.derivative();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.03520653267642995d + "'", double4 == 0.03520653267642995d);
        org.junit.Assert.assertNotNull(univariateRealFunction5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1.4E-45f, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-1L), number2, (java.lang.Number) (-0.0d));
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3, localizable4, objArray13);
        try {
            java.lang.String str18 = mathException17.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.apache.commons.math.exception.ConvergenceException convergenceException2 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray4);
        java.lang.Object[] objArray6 = mathException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
        org.apache.commons.math.exception.ConvergenceException convergenceException8 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-14d + "'", double1 == 1.1102230246251565E-14d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException4);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray20);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray20);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException(objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.apache.commons.math.exception.ConvergenceException convergenceException31 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray37 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException38);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray42);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException39, (org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray42);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException45 = new org.apache.commons.math.exception.MathIllegalStateException(objArray42);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException45);
        java.lang.Object[] objArray47 = new java.lang.Object[] { mathIllegalStateException28, localizedFormats30, convergenceException31, localizedFormats35, mathIllegalStateException45 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalStateException23, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, localizable25, objArray47);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException49 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException11, localizable12, localizable13, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathRuntimeException49);
        java.lang.Object[] objArray51 = mathRuntimeException49.getArguments();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 1, (int) (short) -1);
        org.apache.commons.math.exception.ZeroException zeroException4 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        try {
            org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((double) 5.0f, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((double) (-127), (double) 6.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        float float2 = org.apache.commons.math.util.FastMath.max(32.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) 10, (double) (-0.0f), (double) ' ');
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction5 = null;
        double[] doubleArray6 = null;
        double[] doubleArray7 = null;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer8 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int9 = levenbergMarquardtOptimizer8.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter10 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer8);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric11 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray16 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray17 = gaussianFitter10.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric11, doubleArray16);
        double[] doubleArray20 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair22 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray20, true);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer23 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int24 = levenbergMarquardtOptimizer23.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter25 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer23);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric26 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray31 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray32 = gaussianFitter25.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric26, doubleArray31);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray32);
        double[] doubleArray34 = vectorialPointValuePair33.getPoint();
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = levenbergMarquardtOptimizer3.optimize(0, differentiableMultivariateVectorialFunction5, doubleArray6, doubleArray7, doubleArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        double double2 = levenbergMarquardtOptimizer0.getRMS();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter3 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        try {
            double[] doubleArray5 = gaussianFitter4.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) (-127));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-0.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 53248.0f, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.floor(53248.0096153826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53248.0d + "'", double1 == 53248.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double2 = org.apache.commons.math.util.FastMath.min(100.4987562112089d, 53248.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.4987562112089d + "'", double2 == 100.4987562112089d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0f), (double) 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        float float2 = org.apache.commons.math.util.FastMath.copySign(53248.0f, (float) (-127));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-53248.0f) + "'", float2 == (-53248.0f));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException1 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(640.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36669.29888837269d + "'", double1 == 36669.29888837269d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(0.28366218546322625d, 1.5430806348152437d, 1.5707963267948966d, 53248.0096153826d, (-0.7615941559557649d));
        int int6 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(7.930067261567154E14d, 5.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.375d + "'", double2 == 0.375d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 1L, (double) 53248.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.0000001f);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) 10.0f, (double) 0L, 0.0d);
        double double4 = weightedObservedPoint3.getY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.atanh(929.3529201019406d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((double) (byte) 0, (double) 10.0f);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = gaussian2.derivative();
        org.junit.Assert.assertNotNull(univariateRealFunction3);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 31.999998f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896280957293019E13d + "'", double1 == 7.896280957293019E13d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.03520653267642995d, (java.lang.Number) 8.881133903158874E277d, (java.lang.Number) 22026.465794806718d);
        java.lang.Number number6 = outOfRangeException5.getLo();
        java.lang.Number number7 = outOfRangeException5.getLo();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray22);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException19, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray22);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException12, localizable13, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray22);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 8.881133903158874E277d + "'", number6.equals(8.881133903158874E277d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 8.881133903158874E277d + "'", number7.equals(8.881133903158874E277d));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian(11014.0d, 8.881133903158874E277d);
        double double4 = gaussian2.value((double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.492019653701376E-279d + "'", double4 == 4.492019653701376E-279d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        float float1 = org.apache.commons.math.util.FastMath.signum(53248.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathRuntimeException12.getSpecificPattern();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer17 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-0.5872139151569291d), 100.0d, (double) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray26);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException23, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray26);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint35 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) 0.0f, (double) (short) 1, 100.0d);
        java.lang.Object[] objArray36 = new java.lang.Object[] { mathRuntimeException12, levenbergMarquardtOptimizer17, localizedFormats18, localizedFormats30, (-1.5707963267948966d), 0.0f };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) (short) -1, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("{0}", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray36);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.000000000000001d, (double) (-53248.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double2 = org.apache.commons.math.util.FastMath.scalb(4.641588833612779d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.283177667225559d + "'", double2 == 9.283177667225559d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int3 = levenbergMarquardtOptimizer2.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = null;
        levenbergMarquardtOptimizer2.setConvergenceChecker(vectorialPointValuePairConvergenceChecker4);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter6 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer2);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray7 = curveFitter6.getObservations();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) weightedObservedPointArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray7);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 2048.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException8, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray11);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) 1.0f, 4.492019653701376E-279d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double2 = org.apache.commons.math.util.FastMath.max(36669.29888837269d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 36669.29888837269d + "'", double2 == 36669.29888837269d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException(localizable0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((double) 5.0f, (double) 1.2676506E32f, 22026.465794806718d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        float float2 = org.apache.commons.math.util.FastMath.copySign(96.99999f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 96.99999f + "'", float2 == 96.99999f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(11014.0d, 2.718281828459045d);
        double double3 = simpleVectorialValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.718281828459045d + "'", double3 == 2.718281828459045d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8373830985134536d) + "'", double1 == (-0.8373830985134536d));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.0f), (java.lang.Number) 0.28366218546322625d, true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 31.999998f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896280957292919E13d + "'", double1 == 7.896280957292919E13d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (short) 0, (-0.99999994f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.0f) + "'", float2 == (-0.0f));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 5.0d, (java.lang.Number) 0.0f, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0f + "'", number6.equals(0.0f));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.floor(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.8373830985134536d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9924780633545829d) + "'", double1 == (-0.9924780633545829d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(1, 6);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian(4.041914822473389d, 0.375d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (-1.0f), 100.0d, (double) (byte) -1, 1.0d, (double) 100L);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter6 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        double double7 = levenbergMarquardtOptimizer5.getChiSquare();
        try {
            double[] doubleArray8 = levenbergMarquardtOptimizer5.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.cosh(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray3);
        java.lang.Object[] objArray5 = mathException4.getArguments();
        java.lang.Object[] objArray6 = mathException4.getArguments();
        org.apache.commons.math.optimization.OptimizationException optimizationException7 = new org.apache.commons.math.optimization.OptimizationException("cannot access {0} method in percentile implementation {1}", objArray6);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException(objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable12, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.MathIllegalStateException: illegal state: map has been modified while iterating", objArray16);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalStateException8, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(53248.0096153826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 929.3530879220259d + "'", double1 == 929.3530879220259d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException1 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "cannot convert given object to a fraction number: {0}" + "'", str1.equals("cannot convert given object to a fraction number: {0}"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8373830985134536d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 9.999999f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialPointValuePairConvergenceChecker2);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter4 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter5 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter6 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException3 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(31.999998f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.asin(11014.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray11 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray12 = gaussianFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray11);
        double[] doubleArray13 = gaussianFitter2.fit(doubleArray12);
        gaussianFitter2.addObservedPoint((double) 53248.0f, (double) (-127));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric3 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray8 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray9 = gaussianFitter2.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric3, doubleArray8);
        double[] doubleArray12 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray12, true);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer15 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int16 = levenbergMarquardtOptimizer15.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter17 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer15);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric18 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray23 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray24 = gaussianFitter17.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric18, doubleArray23);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray24);
        double[] doubleArray26 = vectorialPointValuePair25.getPoint();
        double[] doubleArray27 = vectorialPointValuePair25.getValue();
        double[] doubleArray28 = vectorialPointValuePair25.getValueRef();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (-1.0f), 100.0d, (double) (byte) -1, 1.0d, (double) 100L);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter6 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        int int7 = levenbergMarquardtOptimizer5.getEvaluations();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((-0.5872139151569291d), 100.0d, (double) (short) 0);
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = null;
        levenbergMarquardtOptimizer3.setConvergenceChecker(vectorialPointValuePairConvergenceChecker4);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter6 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        int int7 = levenbergMarquardtOptimizer3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int6 = levenbergMarquardtOptimizer5.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = null;
        levenbergMarquardtOptimizer5.setConvergenceChecker(vectorialPointValuePairConvergenceChecker7);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter9 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray10 = curveFitter9.getObservations();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) optimizationException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, localizable4, (java.lang.Object[]) weightedObservedPointArray10);
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser12 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 53248.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.882715524180881d + "'", double1 == 10.882715524180881d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        float float2 = org.apache.commons.math.util.FastMath.scalb((-0.0f), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.0f) + "'", float2 == (-0.0f));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        try {
            org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((-0.9924780633545829d), (-0.5872139151569291d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.587 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray11 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray12 = gaussianFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray11);
        double[] doubleArray13 = gaussianFitter2.fit(doubleArray12);
        gaussianFitter2.addObservedPoint((double) 5.0f, (double) ' ', (double) (short) 1);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric19 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer20 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int21 = levenbergMarquardtOptimizer20.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter22 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer20);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric23 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray28 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray29 = gaussianFitter22.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric23, doubleArray28);
        double[] doubleArray32 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray29, doubleArray32, true);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer35 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int36 = levenbergMarquardtOptimizer35.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter37 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer35);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric38 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray43 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray44 = gaussianFitter37.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric38, doubleArray43);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair45 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray32, doubleArray44);
        try {
            double[] doubleArray46 = gaussianFitter2.fit(100, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric19, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 4 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 9.999999f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.999999f + "'", float2 == 9.999999f);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray11 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray12 = gaussianFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray11);
        double[] doubleArray13 = gaussianFitter2.fit(doubleArray12);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer14 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int15 = levenbergMarquardtOptimizer14.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter16 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer14);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric17 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray22 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray23 = gaussianFitter16.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric17, doubleArray22);
        double[] doubleArray26 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray26, true);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer29 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int30 = levenbergMarquardtOptimizer29.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter31 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer29);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric32 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray37 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray38 = gaussianFitter31.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric32, doubleArray37);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray38);
        double[] doubleArray40 = vectorialPointValuePair39.getPoint();
        double[] doubleArray41 = gaussianFitter2.fit(doubleArray40);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray42 = gaussianFitter2.getObservations();
        gaussianFitter2.addObservedPoint((double) 2048.0f, (double) 52L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(weightedObservedPointArray42);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-0.0f), (java.lang.Number) (-1.0f), true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.0f) + "'", number5.equals((-0.0f)));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable4, objArray8);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer2 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int3 = levenbergMarquardtOptimizer2.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer2);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric5 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray10 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray11 = gaussianFitter4.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric5, doubleArray10);
        double[] doubleArray14 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray14, true);
        double[] doubleArray17 = vectorialPointValuePair16.getPoint();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer18 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int19 = levenbergMarquardtOptimizer18.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter20 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer18);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric21 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray26 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray27 = gaussianFitter20.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric21, doubleArray26);
        double[] doubleArray30 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair32 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray30, true);
        boolean boolean33 = simpleVectorialValueChecker0.converged(1, vectorialPointValuePair16, vectorialPointValuePair32);
        double[] doubleArray34 = vectorialPointValuePair32.getValue();
        double[] doubleArray35 = vectorialPointValuePair32.getValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.1102230246251565E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5777218104420236E-30d + "'", double1 == 1.5777218104420236E-30d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.03520653267642995d, (java.lang.Number) 8.881133903158874E277d, (java.lang.Number) 22026.465794806718d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray21);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException11, localizable12, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("hi!", objArray21);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException(objArray21);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 8.881133903158874E277d + "'", number5.equals(8.881133903158874E277d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 8.881133903158874E277d + "'", number6.equals(8.881133903158874E277d));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math.util.FastMath.acosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double2 = org.apache.commons.math.util.FastMath.min(22026.465794806718d, 36669.29888837269d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22026.465794806718d + "'", double2 == 22026.465794806718d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathException1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray13);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.apache.commons.math.exception.ConvergenceException convergenceException19 = new org.apache.commons.math.exception.ConvergenceException(localizable0, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer22 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int23 = levenbergMarquardtOptimizer22.getMaxEvaluations();
        double double24 = levenbergMarquardtOptimizer22.getRMS();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter25 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer22);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray26 = curveFitter25.getObservations();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException19, localizable20, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) weightedObservedPointArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray26);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) (-1.0f), (java.lang.Number) 96.99999f);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 96.99999f + "'", number5.equals(96.99999f));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter2 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int4 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter5 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric6 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray11 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray12 = gaussianFitter5.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric6, doubleArray11);
        double[] doubleArray13 = gaussianFitter2.fit(doubleArray12);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer14 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int15 = levenbergMarquardtOptimizer14.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter16 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer14);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric17 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray22 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray23 = gaussianFitter16.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric17, doubleArray22);
        double[] doubleArray26 = new double[] { 1.0f, (-0.5872139151569291d) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair28 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray26, true);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer29 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int30 = levenbergMarquardtOptimizer29.getMaxEvaluations();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter31 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer29);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric32 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray37 = new double[] { 1L, 100L, (byte) 100, (-0.5872139151569291d) };
        double[] doubleArray38 = gaussianFitter31.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric32, doubleArray37);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray38);
        double[] doubleArray40 = vectorialPointValuePair39.getPoint();
        double[] doubleArray41 = gaussianFitter2.fit(doubleArray40);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray42 = gaussianFitter2.getObservations();
        gaussianFitter2.addObservedPoint((double) (byte) 10, (double) (byte) -1);
        try {
            double[] doubleArray46 = gaussianFitter2.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 1 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(weightedObservedPointArray42);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) ' ', (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-32.0d) + "'", double2 == (-32.0d));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 52.00557687073941d, (java.lang.Number) 1.1102230246251565E-14d, (java.lang.Number) 4.641588833612779d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 52.00557687073941d + "'", number5.equals(52.00557687073941d));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 5.0d, (java.lang.Number) 0.0f, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 5 is smaller than, or equal to, the minimum (0): unable to compute covariances: singular problem" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 5 is smaller than, or equal to, the minimum (0): unable to compute covariances: singular problem"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.7615941559557649d), (java.lang.Number) 0.8708170232237885d, (java.lang.Number) 100.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.abs(53248.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53248.0d + "'", double1 == 53248.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        int int1 = levenbergMarquardtOptimizer0.getMaxEvaluations();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker2 = null;
        levenbergMarquardtOptimizer0.setConvergenceChecker(vectorialPointValuePairConvergenceChecker2);
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter4 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer0);
        double double5 = levenbergMarquardtOptimizer0.getChiSquare();
        double double6 = levenbergMarquardtOptimizer0.getChiSquare();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }
}

