import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-1.4217874917791073d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.587431271429835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.016634177438072596d) + "'", double1 == (-0.016634177438072596d));
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) ' ');
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int6 = randomDataImpl0.nextPascal(32, (double) 9223372036854775807L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 9,223,372,036,854,776,000 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "84ce297fec8bdc89997e1a5b61af3cfd" + "'", str2.equals("84ce297fec8bdc89997e1a5b61af3cfd"));
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 327);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18735.71990077792d + "'", double1 == 18735.71990077792d);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (-1L), (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException5.getGeneralPattern();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1.0E-9d, number9, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (-1L), (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable17 = outOfRangeException16.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = outOfRangeException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) 2.1152039068646613d, (java.lang.Number) (-1L), true);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable18, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { '4', false, 0 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable28, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { "", 0.0f, 0.0d, 10.0f, 100.0f, 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException33, localizable34, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray47 = new java.lang.Object[] { localizable34, (-1L), convergenceException44, '#', 1.0E-9d };
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable26, objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable25, objArray47);
        java.lang.Throwable[] throwableArray50 = mathException49.getSuppressed();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException("b67768e92291a351eb71147b90d60623", (java.lang.Object[]) throwableArray50);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(throwableArray50);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 0, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (-1L), (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1.0E-9d, number8, false);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.5707963267948966d, (java.lang.Number) (-1L), (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException15.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = outOfRangeException15.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 2.1152039068646613d, (java.lang.Number) (-1L), true);
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable17, objArray22);
        java.lang.Object[] objArray24 = mathIllegalArgumentException23.getArguments();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 18.584386109373288d, (java.lang.Number) 1.1752011936438014d, (java.lang.Number) 0);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getArgument();
        java.lang.Number number7 = outOfRangeException4.getLo();
        java.lang.Object[] objArray8 = outOfRangeException4.getArguments();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 18.584386109373288d + "'", number6.equals(18.584386109373288d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.1752011936438014d + "'", number7.equals(1.1752011936438014d));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        double double1 = org.apache.commons.math.util.FastMath.asinh(5.834617425274539E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34.69314718055994d + "'", double1 == 34.69314718055994d);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        double double1 = org.apache.commons.math.util.FastMath.expm1(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.2350469597522027d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1740434439996548d + "'", double1 == 1.1740434439996548d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5604874136486533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1932602701465093d + "'", double1 == 0.1932602701465093d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 52L, (java.lang.Number) 0.9158371025980504d, false);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 97, 0.9615337877213337d);
        double double4 = normalDistributionImpl2.density(174.41665837770609d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure();
        try {
            long long4 = randomDataImpl0.nextLong(9L, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 9 is larger than, or equal to, the maximum (0): lower bound (9) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5157829425220266d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5157829425220267d + "'", double1 == 0.5157829425220267d);
    }

//    @Test
//    public void test19() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test19");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) ' ');
//        try {
//            double double5 = randomDataImpl0.nextWeibull(0.32200051966968707d, (-0.574344261009425d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.574 is smaller than, or equal to, the minimum (0): scale (-0.574)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "f1cfe641773ce92ad558024bf7306d94" + "'", str2.equals("f1cfe641773ce92ad558024bf7306d94"));
//    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        int int2 = org.apache.commons.math.util.FastMath.min(93, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

//    @Test
//    public void test21() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test21");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure((long) 0);
//        int int6 = randomDataImpl0.nextInt((-1), 0);
//        double double9 = randomDataImpl0.nextUniform(0.23581040215430327d, 1.3651715398380933d);
//        long long12 = randomDataImpl0.nextSecureLong((long) (short) -1, 7L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.7116596497616197d + "'", double9 == 0.7116596497616197d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4L + "'", long12 == 4L);
//    }

//    @Test
//    public void test22() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test22");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) ' ');
//        randomDataImpl0.reSeedSecure();
//        long long5 = randomDataImpl0.nextPoisson(0.5d);
//        double double7 = randomDataImpl0.nextT((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString(32);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2eaf36403619143c92311c61c439d59d" + "'", str2.equals("2eaf36403619143c92311c61c439d59d"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.7805197182103139d) + "'", double7 == (-0.7805197182103139d));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "c70b2919825b2034ffd240547c90a095" + "'", str9.equals("c70b2919825b2034ffd240547c90a095"));
//    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { '4', false, 0 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { "", 0.0f, 0.0d, 10.0f, 100.0f, 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException11, localizable12, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException21);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 6, (float) 34L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.7228199168788984E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { '4', false, 0 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable7, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { "", 0.0f, 0.0d, 10.0f, 100.0f, 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException12, localizable13, objArray20);
        java.lang.Throwable[] throwableArray22 = maxIterationsExceededException12.getSuppressed();
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException12, "", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { '4', false, 0 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable28, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException12, localizable26, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable38, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException34, "", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable5, objArray39);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable4, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { '4', false, 0 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable47, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { "", 0.0f, 0.0d, 10.0f, 100.0f, 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException52, localizable53, objArray60);
        java.lang.Throwable[] throwableArray62 = maxIterationsExceededException52.getSuppressed();
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException52, "", objArray64);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { '4', false, 0 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable68, objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException52, localizable66, objArray72);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray72);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable4, objArray72);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

//    @Test
//    public void test28() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test28");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure((long) 0);
//        java.lang.Class<?> wildcardClass4 = randomDataImpl0.getClass();
//        double double7 = randomDataImpl0.nextF((double) (byte) 100, (double) 10);
//        long long9 = randomDataImpl0.nextPoisson((double) 38);
//        org.junit.Assert.assertNotNull(wildcardClass4);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5905491452231812d + "'", double7 == 0.5905491452231812d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 47L + "'", long9 == 47L);
//    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test29");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString((int) ' ');
//        long long5 = randomDataImpl0.nextLong((long) 64, (long) 77);
//        try {
//            int int8 = randomDataImpl0.nextZipf(0, 1.0000000000000002d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "5e9464848fd9e367a097e85310375cf5" + "'", str2.equals("5e9464848fd9e367a097e85310375cf5"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 74L + "'", long5 == 74L);
//    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable3, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray4);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6);
        java.lang.Throwable[] throwableArray8 = mathException7.getSuppressed();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("ad3b760f7064afdaa81dd0d39ba8b1b1", (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(173.18131993533007d, (-0.9978237639278444d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { '4', false, 0 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable3, objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { "", 0.0f, 0.0d, 10.0f, 100.0f, 1.0f };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException8, localizable9, objArray16);
        java.lang.Throwable[] throwableArray18 = maxIterationsExceededException8.getSuppressed();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("78e9613132d3bbbf6e8a7871cac5a441", (java.lang.Object[]) throwableArray18);
        java.lang.Object[] objArray20 = mathException19.getArguments();
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray20);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }
}

