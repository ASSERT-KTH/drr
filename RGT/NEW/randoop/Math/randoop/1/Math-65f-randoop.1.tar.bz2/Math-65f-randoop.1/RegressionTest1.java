import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        double[] doubleArray4 = new double[] { 0, 0L };
        double[] doubleArray9 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray9, false);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.BigMatrix bigMatrix13 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray4);
        double[] doubleArray16 = new double[] { 0, 0L };
        double[] doubleArray21 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray21, false);
        double[] doubleArray24 = vectorialPointValuePair23.getValue();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray24);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        double double27 = array2DRowRealMatrix26.getFrobeniusNorm();
        double[][] doubleArray28 = array2DRowRealMatrix26.getDataRef();
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.linear.RealMatrix realMatrix30 = org.apache.commons.math.linear.MatrixUtils.createRealMatrix(doubleArray28);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math.linear.BlockRealMatrix(0, 100, doubleArray28, true);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(bigMatrix13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 141.77799547179387d + "'", double27 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.createMatrix((int) ' ', (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.getRowMatrix((int) '4');
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math.exception.Localizable localizable13 = null;
        double[] doubleArray16 = new double[] { 0, 0L };
        double[] doubleArray21 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray21, false);
        org.apache.commons.math.exception.Localizable localizable24 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray28 = new java.lang.Object[] { functionEvaluationException26, false };
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable24, objArray28);
        java.lang.Object[] objArray32 = new java.lang.Object[] { doubleArray21, objArray28, 10, (-1L) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable13, objArray28);
        org.apache.commons.math.exception.Localizable localizable34 = null;
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException33, localizable34, objArray35);
        boolean boolean37 = blockRealMatrix10.equals((java.lang.Object) maxIterationsExceededException33);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix38 = blockRealMatrix2.add(blockRealMatrix10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.apache.commons.math.linear.FieldMatrix<org.apache.commons.math.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.apache.commons.math.exception.Localizable localizable0 = null;
//        double[] doubleArray3 = new double[] { 0, 0L };
//        double[] doubleArray8 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
//        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray3, doubleArray8, false);
//        org.apache.commons.math.exception.Localizable localizable13 = null;
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { functionEvaluationException15, false };
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable13, objArray17);
//        java.lang.ArithmeticException arithmeticException19 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray17);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, "hi!", objArray17);
//        try {
//            java.util.ConcurrentModificationException concurrentModificationException21 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException(localizable0, objArray17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(doubleArray3);
//        org.junit.Assert.assertNotNull(doubleArray8);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(arithmeticException19);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double[] doubleArray2 = new double[] { 0, 0L };
        double[] doubleArray7 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getValue();
        double[] doubleArray11 = vectorialPointValuePair9.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray6 = new java.lang.Object[] { functionEvaluationException4, false };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable2, objArray6);
        java.lang.ArithmeticException arithmeticException8 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException(localizable0, objArray6);
        org.apache.commons.math.exception.Localizable localizable10 = matrixIndexException9.getLocalizablePattern();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.Localizable localizable14 = null;
        org.apache.commons.math.exception.Localizable localizable16 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray20 = new java.lang.Object[] { functionEvaluationException18, false };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable16, objArray20);
        java.lang.ArithmeticException arithmeticException22 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException23 = new org.apache.commons.math.linear.MatrixIndexException(localizable14, objArray20);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException24 = new org.apache.commons.math.linear.MatrixIndexException("", objArray20);
        org.apache.commons.math.exception.Localizable localizable25 = matrixIndexException24.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable27 = null;
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException31 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 100);
        org.apache.commons.math.optimization.OptimizationException optimizationException32 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException31);
        org.apache.commons.math.exception.Localizable localizable33 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray37 = new java.lang.Object[] { functionEvaluationException35, false };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable33, objArray37);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 'a', false, maxEvaluationsExceededException31, convergenceException38, (short) 0, (byte) 100 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable27, objArray41);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        org.apache.commons.math.exception.Localizable localizable46 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray50 = new java.lang.Object[] { functionEvaluationException48, false };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable46, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable45, objArray50);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException53 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray50);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException42, "", objArray50);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException42);
        java.lang.Object[] objArray56 = maxIterationsExceededException42.getArguments();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12, localizable25, objArray56);
        org.apache.commons.math.exception.Localizable localizable60 = null;
        org.apache.commons.math.exception.Localizable localizable62 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray66 = new java.lang.Object[] { functionEvaluationException64, false };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable62, objArray66);
        java.lang.ArithmeticException arithmeticException68 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray66);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException69 = new org.apache.commons.math.FunctionEvaluationException((double) 1.0f, localizable60, objArray66);
        org.apache.commons.math.exception.Localizable localizable72 = null;
        org.apache.commons.math.exception.Localizable localizable74 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray78 = new java.lang.Object[] { functionEvaluationException76, false };
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(localizable74, objArray78);
        java.lang.ArithmeticException arithmeticException80 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray78);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException81 = new org.apache.commons.math.linear.MatrixIndexException(localizable72, objArray78);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException82 = new org.apache.commons.math.linear.MatrixIndexException("", objArray78);
        org.apache.commons.math.exception.Localizable localizable83 = matrixIndexException82.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable84 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException86 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray88 = new java.lang.Object[] { functionEvaluationException86, false };
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException(localizable84, objArray88);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException90 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException69, (double) 10, localizable83, objArray88);
        java.io.EOFException eOFException91 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.ConvergenceException: maximal number of evaluations (100) exceeded", objArray88);
        java.lang.ArithmeticException arithmeticException92 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable25, objArray88);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException93 = new org.apache.commons.math.linear.MatrixIndexException("", objArray88);
        matrixIndexException9.addSuppressed((java.lang.Throwable) matrixIndexException93);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(arithmeticException22);
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(arithmeticException68);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(arithmeticException80);
        org.junit.Assert.assertNotNull(localizable83);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(eOFException91);
        org.junit.Assert.assertNotNull(arithmeticException92);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        double[] doubleArray2 = new double[] { 0, 0L };
        double[] doubleArray7 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray7, false);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.BigMatrix bigMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray2);
        double[] doubleArray14 = new double[] { 0, 0L };
        double[] doubleArray19 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray19, false);
        double[] doubleArray22 = vectorialPointValuePair21.getValue();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        org.apache.commons.math.linear.RealMatrix realMatrix25 = array2DRowRealMatrix24.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.transpose();
        array2DRowRealMatrix24.setEntry(0, 0, (double) 10);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(bigMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getRowMatrix((int) '4');
        double[] doubleArray6 = blockRealMatrix2.getColumn((int) (short) 1);
        double[] doubleArray8 = blockRealMatrix2.getRow(0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.getRowMatrix((int) '4');
        double[] doubleArray16 = blockRealMatrix12.getColumn((int) (short) 1);
        org.apache.commons.math.linear.RealVector realVector18 = blockRealMatrix12.getRowVector((int) (short) 0);
        try {
            blockRealMatrix2.setColumnVector(0, realVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.InvalidMatrixException; message: dimensions mismatch: got 100x1 but expected 97x1");
        } catch (org.apache.commons.math.linear.InvalidMatrixException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(100, (int) (byte) 1);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix0.getRowMatrix((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 0 out of allowed range [0, -1]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(realMatrix3);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.createMatrix((int) ' ', (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.subtract(blockRealMatrix5);
        double double10 = blockRealMatrix9.getNorm();
        double double11 = blockRealMatrix9.getNorm();
        double double12 = blockRealMatrix9.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.createMatrix((int) ' ', (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix9.copy();
        boolean boolean11 = blockRealMatrix10.isSquare();
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.createMatrix((int) ' ', (int) (short) 10);
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray12 = new java.lang.Object[] { functionEvaluationException10, false };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(localizable8, objArray12);
        java.lang.ArithmeticException arithmeticException14 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray12);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException15 = new org.apache.commons.math.linear.MatrixIndexException(localizable6, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) matrixIndexException15);
        boolean boolean17 = blockRealMatrix2.equals((java.lang.Object) convergenceException16);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(arithmeticException14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        double[] doubleArray2 = new double[] { 0, 0L };
        double[] doubleArray7 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getValue();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray10);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl12 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix11);
        org.apache.commons.math.linear.RealMatrix realMatrix13 = lUDecompositionImpl12.getU();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = lUDecompositionImpl12.getU();
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl15 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix14);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl16 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException6 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 100);
        org.apache.commons.math.optimization.OptimizationException optimizationException7 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException6);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray12 = new java.lang.Object[] { functionEvaluationException10, false };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(localizable8, objArray12);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 'a', false, maxEvaluationsExceededException6, convergenceException13, (short) 0, (byte) 100 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable2, objArray16);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray25 = new java.lang.Object[] { functionEvaluationException23, false };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable21, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable20, objArray25);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException28 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException17, "", objArray25);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException17);
        org.apache.commons.math.exception.Localizable localizable31 = mathException30.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable34 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray38 = new java.lang.Object[] { functionEvaluationException36, false };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable34, objArray38);
        java.util.NoSuchElementException noSuchElementException40 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray38);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException41 = new org.apache.commons.math.linear.MatrixIndexException("", objArray38);
        java.io.EOFException eOFException42 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable31, objArray38);
        java.lang.Object[] objArray43 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((double) 1000, localizable31, objArray43);
        org.apache.commons.math.exception.Localizable localizable45 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException47 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray49 = new java.lang.Object[] { functionEvaluationException47, false };
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable45, objArray49);
        org.apache.commons.math.exception.Localizable localizable53 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray57 = new java.lang.Object[] { functionEvaluationException55, false };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable53, objArray57);
        java.util.NoSuchElementException noSuchElementException59 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray57);
        org.apache.commons.math.MathRuntimeException mathRuntimeException60 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) convergenceException50, "org.apache.commons.math.ConvergenceException: maximal number of evaluations (100) exceeded", objArray57);
        java.util.NoSuchElementException noSuchElementException61 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable31, objArray57);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable31.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(noSuchElementException40);
        org.junit.Assert.assertNotNull(eOFException42);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(noSuchElementException59);
        org.junit.Assert.assertNotNull(noSuchElementException61);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        double[] doubleArray2 = new double[] { 0, 0L };
        double[] doubleArray7 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray7, false);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.BigMatrix bigMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray2);
        double[] doubleArray14 = new double[] { 0, 0L };
        double[] doubleArray19 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray19, false);
        double[] doubleArray22 = vectorialPointValuePair21.getValue();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        double double25 = array2DRowRealMatrix24.getFrobeniusNorm();
        double[][] doubleArray26 = array2DRowRealMatrix24.getDataRef();
        double[] doubleArray29 = new double[] { 0, 0L };
        double[] doubleArray34 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray29, doubleArray34, false);
        org.apache.commons.math.linear.RealMatrix realMatrix37 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray29);
        org.apache.commons.math.linear.BigMatrix bigMatrix38 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray29);
        double[] doubleArray41 = new double[] { 0, 0L };
        double[] doubleArray46 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair48 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray41, doubleArray46, false);
        double[] doubleArray49 = vectorialPointValuePair48.getValue();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair50 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray29, doubleArray49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math.linear.RealMatrix realMatrix52 = array2DRowRealMatrix51.transpose();
        org.apache.commons.math.linear.RealMatrix realMatrix53 = array2DRowRealMatrix51.transpose();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = array2DRowRealMatrix24.add(array2DRowRealMatrix51);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor55 = null;
        try {
            double double56 = array2DRowRealMatrix54.walkInColumnOrder(realMatrixPreservingVisitor55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(bigMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 141.77799547179387d + "'", double25 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(bigMatrix38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix53);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix54);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        double[] doubleArray2 = new double[] { 0, 0L };
        double[] doubleArray7 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getValue();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, 10);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException12, "org.apache.commons.math.ConvergenceException: maximal number of evaluations (100) exceeded", (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math.exception.Localizable localizable21 = null;
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray27 = new java.lang.Object[] { functionEvaluationException25, false };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable23, objArray27);
        java.lang.ArithmeticException arithmeticException29 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException30 = new org.apache.commons.math.FunctionEvaluationException((double) 1.0f, localizable21, objArray27);
        double[][] doubleArray34 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout((int) (byte) 0, (int) (byte) 10);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException30, "org.apache.commons.math.ConvergenceException: maximal number of evaluations (100) exceeded", (java.lang.Object[]) doubleArray34);
        try {
            array2DRowRealMatrix19.setSubMatrix(doubleArray34, (int) '4', (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(arithmeticException29);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.exception.Localizable localizable1 = null;
        org.apache.commons.math.exception.Localizable localizable2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray6 = new java.lang.Object[] { functionEvaluationException4, false };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable2, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable1, objArray6);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException9 = new org.apache.commons.math.linear.MatrixIndexException("hi!", objArray6);
        java.lang.String str10 = matrixIndexException9.getPattern();
        org.apache.commons.math.exception.Localizable localizable13 = null;
        org.apache.commons.math.exception.Localizable localizable15 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray19 = new java.lang.Object[] { functionEvaluationException17, false };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable15, objArray19);
        java.lang.ArithmeticException arithmeticException21 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((double) 1.0f, localizable13, objArray19);
        org.apache.commons.math.exception.Localizable localizable25 = null;
        org.apache.commons.math.exception.Localizable localizable27 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException29 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray31 = new java.lang.Object[] { functionEvaluationException29, false };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable27, objArray31);
        java.lang.ArithmeticException arithmeticException33 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray31);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException34 = new org.apache.commons.math.linear.MatrixIndexException(localizable25, objArray31);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException35 = new org.apache.commons.math.linear.MatrixIndexException("", objArray31);
        org.apache.commons.math.exception.Localizable localizable36 = matrixIndexException35.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable37 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray41 = new java.lang.Object[] { functionEvaluationException39, false };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable37, objArray41);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException22, (double) 10, localizable36, objArray41);
        double[] doubleArray46 = new double[] { 0, 0L };
        double[] doubleArray51 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair53 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray46, doubleArray51, false);
        org.apache.commons.math.exception.Localizable localizable56 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray60 = new java.lang.Object[] { functionEvaluationException58, false };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable56, objArray60);
        java.lang.ArithmeticException arithmeticException62 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(doubleArray46, "hi!", objArray60);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable36, objArray60);
        double[] doubleArray67 = new double[] { 0, 0L };
        double[] doubleArray72 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair74 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray67, doubleArray72, false);
        org.apache.commons.math.linear.RealMatrix realMatrix75 = org.apache.commons.math.linear.MatrixUtils.createRowRealMatrix(doubleArray67);
        org.apache.commons.math.linear.BigMatrix bigMatrix76 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray67);
        double[] doubleArray79 = new double[] { 0, 0L };
        double[] doubleArray84 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair86 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray79, doubleArray84, false);
        double[] doubleArray87 = vectorialPointValuePair86.getValue();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair88 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray67, doubleArray87);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix89 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray87);
        double double90 = array2DRowRealMatrix89.getFrobeniusNorm();
        double[][] doubleArray91 = array2DRowRealMatrix89.getDataRef();
        double[][] doubleArray92 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray91);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException93 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) matrixIndexException9, (double) 2147483647, localizable36, (java.lang.Object[]) doubleArray91);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException94 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) functionEvaluationException93);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(arithmeticException21);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(arithmeticException33);
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(arithmeticException62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(bigMatrix76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 141.77799547179387d + "'", double90 == 141.77799547179387d);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        double[] doubleArray2 = new double[] { 0, 0L };
        double[] doubleArray7 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getValue();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, 10);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException12, "org.apache.commons.math.ConvergenceException: maximal number of evaluations (100) exceeded", (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, false);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix26 = array2DRowRealMatrix21.getSubMatrix(0, (int) (short) 100, (int) (short) 10, 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 100 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getRowMatrix((int) '4');
        double[] doubleArray6 = blockRealMatrix2.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix8 = blockRealMatrix2.scalarMultiply((double) (short) 0);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        int int13 = blockRealMatrix12.getColumnDimension();
        int int14 = blockRealMatrix12.getColumnDimension();
        try {
            blockRealMatrix2.setRowMatrix((int) 'a', (org.apache.commons.math.linear.RealMatrix) blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 97 out of allowed range [0, 96]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        double[] doubleArray2 = new double[] { 0, 0L };
        double[] doubleArray7 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getValue();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, 10);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException12, "org.apache.commons.math.ConvergenceException: maximal number of evaluations (100) exceeded", (java.lang.Object[]) doubleArray16);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, true);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math.linear.BlockRealMatrix(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        double[] doubleArray2 = new double[] { 0, 0L };
        double[] doubleArray7 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getValue();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor14 = null;
        try {
            double double15 = array2DRowRealMatrix13.walkInColumnOrder(realMatrixChangingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        java.lang.String[] strArray2 = new java.lang.String[] { "maximal number of evaluations ({0}) exceeded", "evaluation failed for argument = {0}" };
        java.lang.String[] strArray5 = new java.lang.String[] { "maximal number of evaluations ({0}) exceeded", "evaluation failed for argument = {0}" };
        java.lang.String[] strArray8 = new java.lang.String[] { "maximal number of evaluations ({0}) exceeded", "evaluation failed for argument = {0}" };
        java.lang.String[] strArray11 = new java.lang.String[] { "maximal number of evaluations ({0}) exceeded", "evaluation failed for argument = {0}" };
        java.lang.String[] strArray14 = new java.lang.String[] { "maximal number of evaluations ({0}) exceeded", "evaluation failed for argument = {0}" };
        java.lang.String[] strArray17 = new java.lang.String[] { "maximal number of evaluations ({0}) exceeded", "evaluation failed for argument = {0}" };
        java.lang.String[][] strArray18 = new java.lang.String[][] { strArray2, strArray5, strArray8, strArray11, strArray14, strArray17 };
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix19 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(strArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        }
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertNotNull(strArray5);
        org.junit.Assert.assertNotNull(strArray8);
        org.junit.Assert.assertNotNull(strArray11);
        org.junit.Assert.assertNotNull(strArray14);
        org.junit.Assert.assertNotNull(strArray17);
        org.junit.Assert.assertNotNull(strArray18);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix5.createMatrix((int) ' ', (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix2.subtract(blockRealMatrix5);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double15 = blockRealMatrix9.walkInOptimizedOrder(realMatrixPreservingVisitor10, 0, (int) (byte) -1, 4, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index -1 out of allowed range [0, 96]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix8);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        double[] doubleArray2 = new double[] { 0, 0L };
        double[] doubleArray7 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray7, false);
        double[] doubleArray10 = vectorialPointValuePair9.getValue();
        org.apache.commons.math.linear.RealMatrix realMatrix11 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        double[][] doubleArray16 = org.apache.commons.math.linear.BlockRealMatrix.createBlocksLayout(10, 10);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException12, "org.apache.commons.math.ConvergenceException: maximal number of evaluations (100) exceeded", (java.lang.Object[]) doubleArray16);
        java.lang.Object[] objArray18 = functionEvaluationException12.getArguments();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) 'a', 100);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.getRowMatrix((int) '4');
        double double5 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor6 = null;
        try {
            double double11 = blockRealMatrix4.walkInOptimizedOrder(realMatrixPreservingVisitor6, 52, (int) (short) 10, (int) (short) -1, 4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException((int) (byte) 100);
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) maxEvaluationsExceededException1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxEvaluationsExceededException1);
        org.apache.commons.math.exception.Localizable localizable4 = maxEvaluationsExceededException1.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable6 = null;
        org.apache.commons.math.exception.Localizable localizable8 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray12 = new java.lang.Object[] { functionEvaluationException10, false };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(localizable8, objArray12);
        java.lang.ArithmeticException arithmeticException14 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((double) 1.0f, localizable6, objArray12);
        org.apache.commons.math.exception.Localizable localizable18 = null;
        org.apache.commons.math.exception.Localizable localizable20 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray24 = new java.lang.Object[] { functionEvaluationException22, false };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable20, objArray24);
        java.lang.ArithmeticException arithmeticException26 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException27 = new org.apache.commons.math.linear.MatrixIndexException(localizable18, objArray24);
        org.apache.commons.math.linear.MatrixIndexException matrixIndexException28 = new org.apache.commons.math.linear.MatrixIndexException("", objArray24);
        org.apache.commons.math.exception.Localizable localizable29 = matrixIndexException28.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable30 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray34 = new java.lang.Object[] { functionEvaluationException32, false };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable30, objArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException15, (double) 10, localizable29, objArray34);
        double[] doubleArray39 = new double[] { 0, 0L };
        double[] doubleArray44 = new double[] { 100, 1.0f, (byte) 100, 10.0d };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair46 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray39, doubleArray44, false);
        org.apache.commons.math.exception.Localizable localizable49 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException((double) (short) 0);
        java.lang.Object[] objArray53 = new java.lang.Object[] { functionEvaluationException51, false };
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable49, objArray53);
        java.lang.ArithmeticException arithmeticException55 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException(doubleArray39, "hi!", objArray53);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable29, objArray53);
        java.io.EOFException eOFException58 = org.apache.commons.math.MathRuntimeException.createEOFException(localizable4, objArray53);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(localizable4, objArray59);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizable4.equals(org.apache.commons.math.exception.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(arithmeticException14);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(arithmeticException26);
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(arithmeticException55);
        org.junit.Assert.assertNotNull(eOFException58);
    }
}

