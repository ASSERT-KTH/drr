import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double2 = org.apache.commons.math.util.FastMath.min(100.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38905609893065d + "'", double1 == 6.38905609893065d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '#', (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5515520672986852E154d + "'", double2 == 2.5515520672986852E154d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.848857801796104d + "'", double1 == 9.848857801796104d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.5515520672986852E154d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math.util.FastMath.min(9.848857801796104d, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 'a', (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 458.3662361046586d + "'", double1 == 458.3662361046586d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.610125138662287d + "'", double1 == 7.610125138662287d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.000000000000004d + "'", double1 == 16.000000000000004d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int2 = org.apache.commons.math.util.FastMath.max((-32767), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.36381231312127915d + "'", double0 == 0.36381231312127915d);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathIllegalArgumentException13.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException(throwable3, localizable4, localizable5, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray12);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, (int) (byte) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1L), (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 2, (java.lang.Number) (byte) -1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.5515520672986852E154d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681399d + "'", double1 == 0.5403023058681399d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41078129050290885d + "'", double1 == 0.41078129050290885d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.nextAfter(dfp9);
        boolean boolean11 = dfp10.isNaN();
        boolean boolean12 = dfp2.lessThan(dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp14 = dfp10.multiply(dfp13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 571.9094892935019d + "'", double1 == 571.9094892935019d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp4 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfp3.nextAfter(dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable1, localizable2, localizable3, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray10);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.08014278376996599d, (java.lang.Number) 10, true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100L, (double) 16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E32d + "'", double2 == 1.0E32d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 0);
        java.lang.String str9 = dfp6.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1.7320508075688772935274463415" + "'", str9.equals("1.7320508075688772935274463415"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.5515520672986852E154d, (java.lang.Number) 0.19453716f, false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.7705113220733022d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.160870872327503d + "'", double1 == 2.160870872327503d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int[] intArray1 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        long long4 = mersenneTwister2.nextLong();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.19453716f + "'", float3 == 0.19453716f);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 7912994101175981310L + "'", long4 == 7912994101175981310L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException25 = new org.apache.commons.math.exception.MathRuntimeException(throwable15, localizable16, localizable17, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray24);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException10, localizable11, localizable12, objArray24);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8, (float) 8);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double2 = org.apache.commons.math.util.FastMath.pow(32.0d, (double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32768.0d + "'", double2 == 32768.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField13.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.newDfp(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.nextAfter(dfp29);
        boolean boolean32 = dfp30.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp33 = dfp9.dotrap((int) (byte) 3, "hi!", dfp21, dfp30);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp21.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp6.subtract(dfp35);
        int int37 = dfp36.log10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray1 = null;
        try {
            mersenneTwister0.nextBytes(byteArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField22.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.newInstance();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField22.newDfp(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.nextAfter(dfp38);
        boolean boolean41 = dfp39.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp42 = dfp18.dotrap((int) (byte) 3, "hi!", dfp30, dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp11, dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp45 = dfp11.newInstance(dfp44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-32767));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32767) + "'", int2 == (-32767));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.nextAfter(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp26.subtract(dfp33);
        int int36 = dfp26.classify();
        java.lang.String str37 = dfp26.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "1.0000000000000000000000000000e-131104" + "'", str37.equals("1.0000000000000000000000000000e-131104"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        boolean boolean9 = dfp7.equals((java.lang.Object) (-1L));
        boolean boolean10 = dfp7.isInfinite();
        int int11 = dfp7.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) 32768);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32768.0f + "'", float2 == 32768.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 8.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray9);
        java.lang.Throwable[] throwableArray11 = mathRuntimeException10.getSuppressed();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        org.apache.commons.math.dfp.Dfp dfp11 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp12 = org.apache.commons.math.dfp.DfpField.computeLn(dfp9, dfp10, dfp11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 100.0f + "'", number2.equals(100.0f));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.610125138662287d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1529388524411384d + "'", double1 == 2.1529388524411384d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.41078129050290885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.39932574404189153d + "'", double1 == 0.39932574404189153d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 3, 32768.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32768.0d + "'", double2 == 32768.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        java.lang.String str18 = dfp16.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0." + "'", str18.equals("0."));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-9123799161329637972L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.1237991613296384E18d) + "'", double1 == (-9.1237991613296384E18d));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 0, (float) 8);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0f + "'", float2 == 8.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 3, (byte) 100);
        boolean boolean34 = dfp33.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.newInstance();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField36.newDfp(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp28.divide(dfp45);
        int int48 = dfp28.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 8 + "'", int48 == 8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-31.99967447585524d) + "'", double1 == (-31.99967447585524d));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((long) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        try {
            int int5 = mersenneTwister1.nextInt((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        mersenneTwister1.setSeed(0);
        long long6 = mersenneTwister1.nextLong();
        boolean boolean7 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-8322921849960486353L) + "'", long6 == (-8322921849960486353L));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass5 = dfp4.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) '4');
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.498986710526204d + "'", double1 == 50.498986710526204d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        java.lang.Class<?> wildcardClass10 = dfp9.getClass();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8d + "'", double1 == 0.8d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.expm1(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806754d + "'", double1 == 22025.465794806754d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-9123799161329637972L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 'a', (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 6.38905609893065d, (java.lang.Number) 0.8813735870195429d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 6.38905609893065d + "'", number5.equals(6.38905609893065d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.19453716f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.19453716f + "'", float1 == 0.19453716f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.floor();
        java.lang.String str10 = dfp9.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0." + "'", str10.equals("0."));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, 0.19453716f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray11);
        java.lang.Throwable[] throwableArray14 = mathIllegalArgumentException13.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable15 = mathIllegalArgumentException13.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNull(localizable15);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.548739357257746d + "'", double1 == 11.548739357257746d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((double) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getOne();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.floor();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp31.floor();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField34.getESplit();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField34.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.nextAfter(dfp48);
        boolean boolean51 = dfp49.equals((java.lang.Object) (-1L));
        boolean boolean52 = dfp49.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp55.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp56.nextAfter(dfp59);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField62.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp63.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp64.nextAfter(dfp67);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp68.getOne();
        boolean boolean70 = dfp60.lessThan(dfp68);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp49.divide(dfp60);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp41.nextAfter(dfp60);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp19.dotrap(0, "hi!", dfp32, dfp60);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '4', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField13.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.newDfp(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.nextAfter(dfp29);
        boolean boolean32 = dfp30.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp33 = dfp9.dotrap((int) (byte) 3, "hi!", dfp21, dfp30);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp21.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp6.subtract(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 3, (byte) 100);
        boolean boolean42 = dfp41.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField44.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.newInstance();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField44.newDfp(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp41.subtract(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp6.multiply(dfp53);
        int int56 = dfp6.log10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0E32d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.3758701563694d + "'", double1 == 74.3758701563694d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = null;
        dfpField2.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField2.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField2.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException7.getGeneralPattern();
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        double double2 = mersenneTwister1.nextDouble();
        double double3 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1129943035738381d + "'", double2 == 0.1129943035738381d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.41782887182714457d + "'", double3 == 0.41782887182714457d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.732668256045411d + "'", double1 == 0.732668256045411d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, number1, false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int[] intArray1 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        mersenneTwister2.setSeed((-8322921849960486353L));
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 3, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 8.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.446441332248135d + "'", double1 == 1.446441332248135d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.nextAfter(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp26.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.ceil();
        java.lang.String str37 = dfp36.toString();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "-0." + "'", str37.equals("-0."));
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        boolean boolean18 = dfp17.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 3, (byte) 100);
        boolean boolean24 = dfp23.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField26.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.newInstance();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField26.newDfp(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp23.subtract(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.negate();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getOne();
        org.apache.commons.math.dfp.Dfp dfp39 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeLn(dfp17, dfp37, dfp39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.cos(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        dfpField1.setIEEEFlagsBits(4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5403023058681399d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double2 = org.apache.commons.math.util.FastMath.max((double) ' ', (double) 97L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance(0.732668256045411d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(571.9094892935019d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.300592638253802d + "'", double1 == 8.300592638253802d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.tan(11.548739357257746d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6195157923977428d) + "'", double1 == (-1.6195157923977428d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32.0d, (java.lang.Number) (byte) 2, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 32 is smaller than, or equal to, the minimum (2)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 32 is smaller than, or equal to, the minimum (2)"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        int int10 = dfp9.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.41078129050290885d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4224317792764335d + "'", double1 == 0.4224317792764335d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        int int2 = org.apache.commons.math.util.FastMath.max((-32767), 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.732668256045411d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8559604290184278d + "'", double1 == 0.8559604290184278d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.4156546502537559d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.cos(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28366218546322625d + "'", double1 == 0.28366218546322625d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        boolean boolean8 = dfp6.isNaN();
        org.apache.commons.math.dfp.Dfp dfp9 = null;
        try {
            boolean boolean10 = dfp6.unequal(dfp9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        long long2 = mersenneTwister1.nextLong();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-8474271314106775063L) + "'", long3 == (-8474271314106775063L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn5();
        dfpField18.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp(0L);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.39720770839918d + "'", double1 == 10.39720770839918d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.tan(8.300592638253802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0881967013605216d) + "'", double1 == (-2.0881967013605216d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        dfpField1.setIEEEFlags((int) (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        float float2 = org.apache.commons.math.util.FastMath.min(1.0f, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 10, (byte) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.36381231312127915d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double2 = org.apache.commons.math.util.FastMath.min(0.28366218546322625d, 0.32030858424327757d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.28366218546322625d + "'", double2 == 0.28366218546322625d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32.0d, (java.lang.Number) (byte) 2, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 2 + "'", number6.equals((byte) 2));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField18.newDfp(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.nextAfter(dfp34);
        boolean boolean37 = dfp35.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp38 = dfp14.dotrap((int) (byte) 3, "hi!", dfp26, dfp35);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp26.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp40.add(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp((byte) 3, (byte) 100);
        int int52 = dfpField48.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField48.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField48.getLn10();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField48.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp40.add(dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp11.nextAfter(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp61 = dfp11.multiply(dfp60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 8 + "'", int52 == 8);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-9.1237991613296384E18d), 0.732668256045411d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.1237991613296374E18d) + "'", double2 == (-9.1237991613296374E18d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.floor();
        java.lang.String str10 = dfp8.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0." + "'", str10.equals("0."));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        int int6 = dfpField1.getIEEEFlags();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance(32768);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("-0.");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Object[] objArray6 = numberIsTooSmallException4.getArguments();
        java.lang.Number number7 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10L + "'", number7.equals(10L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = null;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits(1);
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("0.");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        mersenneTwister1.setSeed((long) (short) 100);
        double double4 = mersenneTwister1.nextDouble();
        double double5 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0787171938695459d + "'", double4 == 0.0787171938695459d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.6381276686402511d) + "'", double5 == (-0.6381276686402511d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.log(2.5515520672986852E154d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 355.53480614894136d + "'", double1 == 355.53480614894136d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.732668256045411d, 11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.atanh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((double) 0L);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        try {
            boolean boolean9 = dfp7.greaterThan(dfp8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10, (double) 8L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8960553845713439d + "'", double2 == 0.8960553845713439d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        java.lang.String str27 = dfp2.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "0.57735026918962576450914878050196" + "'", str27.equals("0.57735026918962576450914878050196"));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.floor();
        boolean boolean10 = dfp6.equals((java.lang.Object) 0.0787171938695459d);
        int int11 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 10.000000000000002d, true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) -1, (float) (-9123799161329637972L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.1237992E18f) + "'", float2 == (-9.1237992E18f));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 100L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = null;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.515449934959718d + "'", double1 == 4.515449934959718d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int[] intArray1 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        try {
            int int5 = mersenneTwister2.nextInt((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.19453716f + "'", float3 == 0.19453716f);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        long long1 = org.apache.commons.math.util.FastMath.abs((-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8474271314106775063L + "'", long1 == 8474271314106775063L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.7705113220733022d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8777877431778722d + "'", double1 == 0.8777877431778722d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.floor();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField10.getESplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10K((int) '#');
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp6.newInstance(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.newInstance((byte) 1, (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 16, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 35L, (double) (-8474271314106775063L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.4742713141067756E18d) + "'", double2 == (-8.4742713141067756E18d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 2, (java.lang.Number) (byte) -1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 2 + "'", number4.equals((byte) 2));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = null;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray13);
        java.lang.Throwable[] throwableArray15 = mathIllegalArgumentException14.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.515449934959718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6547010314013565d + "'", double1 == 0.6547010314013565d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.5063656411097588d), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.log1p(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.38405980272115d + "'", double1 == 2.38405980272115d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        dfpField1.setIEEEFlags((int) 'a');
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3006322420239034d + "'", double1 == 0.3006322420239034d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.add(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.nextAfter(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.getOne();
        boolean boolean44 = dfp34.unequal(dfp43);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.cosh(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9468.356509017014d + "'", double1 == 9468.356509017014d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        double double2 = mersenneTwister1.nextGaussian();
        float float3 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0019203836877835d + "'", double2 == 1.0019203836877835d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.016676307f + "'", float3 == 0.016676307f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = null;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 2.5515520672986852E154d, (java.lang.Number) 0.36381231312127915d, true);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((byte) 3, (byte) 100);
        int int30 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField26.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField26.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField26.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable20, (java.lang.Object[]) dfpArray35);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 32.0d, (java.lang.Number) (byte) 2, false);
        java.lang.Throwable[] throwableArray45 = numberIsTooSmallException44.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) throwableArray45);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertNotNull(throwableArray45);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(7912994101175981310L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (short) -1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance((byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-31.99967447585524d), (java.lang.Number) 0.4224317792764335d, false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.3006322420239034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0.19453716f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.085536923187668d + "'", double1 == 19.085536923187668d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 100, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((long) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10K(35);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.nextAfter(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getLn5Split();
        int int29 = dfpField24.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField24.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp12.dotrap(97, "1.0000000000000000000000000000e-131104", dfp21, dfp32);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 8 + "'", int29 == 8);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.nextAfter(dfp15);
        boolean boolean18 = dfp16.equals((java.lang.Object) (-1L));
        boolean boolean19 = dfp16.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.nextAfter(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.nextAfter(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getOne();
        boolean boolean37 = dfp27.lessThan(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp16.divide(dfp27);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp8.nextAfter(dfp27);
        int int40 = dfp39.classify();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 16);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 16L + "'", long1 == 16L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 35L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        boolean boolean9 = dfp7.equals((java.lang.Object) (-1L));
        boolean boolean10 = dfp7.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getOne();
        boolean boolean28 = dfp18.lessThan(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp7.divide(dfp18);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp7.ceil();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass36 = dfp35.getClass();
        boolean boolean37 = dfp7.equals((java.lang.Object) dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = null;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlags(35);
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 32 is smaller than, or equal to, the minimum (2)");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = null;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 2.5515520672986852E154d, (java.lang.Number) 0.36381231312127915d, true);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((byte) 3, (byte) 100);
        int int30 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField26.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField26.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField26.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable20, (java.lang.Object[]) dfpArray35);
        java.lang.Number number37 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, number37);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.negate();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = null;
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.nextAfter(dfp29);
        boolean boolean32 = dfp30.equals((java.lang.Object) (-1L));
        boolean boolean33 = dfp30.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp37.nextAfter(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp49.getOne();
        boolean boolean51 = dfp41.lessThan(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp30.divide(dfp41);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp18.dotrap((-32767), "-0.", dfp22, dfp30);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.multiply(4);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.newInstance();
        int int12 = dfp11.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField13.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.newDfp(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.nextAfter(dfp29);
        boolean boolean32 = dfp30.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp33 = dfp9.dotrap((int) (byte) 3, "hi!", dfp21, dfp30);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp21.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp6.subtract(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 3, (byte) 100);
        boolean boolean42 = dfp41.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField44.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.newInstance();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField44.newDfp(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp41.subtract(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp6.multiply(dfp53);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp6.newInstance();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 3, (byte) 100);
        boolean boolean34 = dfp33.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.newInstance();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField36.newDfp(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp28.divide(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp((byte) 3, (byte) 100);
        int int53 = dfpField49.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField49.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField49.getZero();
        boolean boolean57 = dfp47.greaterThan(dfp56);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 8 + "'", int53 == 8);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        int int8 = dfp7.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8d, (double) 97L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8d + "'", double2 == 0.8d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        int int9 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.floor(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        boolean boolean7 = dfp6.isInfinite();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-9.1237992E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0E32d, (double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999999E31d + "'", double2 == 9.999999999999999E31d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5711645232847797d + "'", double2 == 0.5711645232847797d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1), (-8.4742713141067756E18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.141592653589793d) + "'", double2 == (-3.141592653589793d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        long long2 = org.apache.commons.math.util.FastMath.max((-9123799161329637972L), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 3, (byte) 100);
        int int13 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.divide((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(0);
        boolean boolean21 = dfp7.greaterThan(dfp18);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.signum(6.38905609893065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 16L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.833213344056216d + "'", double1 == 2.833213344056216d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int[] intArray4 = new int[] { 8, 6, (byte) 3, (byte) 2 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        boolean boolean4 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6770136959079763d + "'", double1 == 0.6770136959079763d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(1.2220998133980223d);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 10, (byte) 10);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((long) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField16.newDfp(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp29.nextAfter(dfp32);
        boolean boolean35 = dfp33.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp12.dotrap((int) (byte) 3, "hi!", dfp24, dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.Dfp.copysign(dfp7, dfp24);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.newDfp((byte) 3, (byte) 100);
        boolean boolean43 = dfp42.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField45.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.newInstance();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField45.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp42.subtract(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField56 = dfp42.getField();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray68 = dfpField64.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp71.newInstance();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField64.newDfp(dfp72);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField75.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp76.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField79.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp77.nextAfter(dfp80);
        boolean boolean83 = dfp81.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp84 = dfp60.dotrap((int) (byte) 3, "hi!", dfp72, dfp81);
        org.apache.commons.math.dfp.DfpField dfpField86 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField86.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp88 = dfp87.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField90 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp91 = dfpField90.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp92 = dfp88.nextAfter(dfp91);
        org.apache.commons.math.dfp.Dfp dfp93 = dfp84.subtract(dfp91);
        int int94 = dfp84.classify();
        org.apache.commons.math.dfp.Dfp dfp95 = org.apache.commons.math.dfp.Dfp.copysign(dfp57, dfp84);
        org.apache.commons.math.dfp.Dfp dfp96 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp95);
        org.apache.commons.math.dfp.Dfp dfp97 = new org.apache.commons.math.dfp.Dfp(dfp96);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfpField56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfpArray68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertNotNull(dfp95);
        org.junit.Assert.assertNotNull(dfp96);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getTwo();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField12.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode18);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.602681965908778d + "'", double1 == 0.602681965908778d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.1129943035738381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3361462532497397d + "'", double1 == 0.3361462532497397d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.multiply((int) (byte) 100);
        int int10 = dfp9.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        mersenneTwister1.setSeed(0);
        long long6 = mersenneTwister1.nextLong();
        int[] intArray8 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray8);
        double double10 = mersenneTwister9.nextGaussian();
        int[] intArray16 = new int[] { (short) -1, (byte) -1, 32768, (short) 10, ' ' };
        mersenneTwister9.setSeed(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        int int20 = mersenneTwister18.nextInt((int) (byte) 2);
        boolean boolean21 = mersenneTwister18.nextBoolean();
        byte[] byteArray26 = new byte[] { (byte) 2, (byte) 0, (byte) -1, (byte) 2 };
        mersenneTwister18.nextBytes(byteArray26);
        mersenneTwister1.nextBytes(byteArray26);
        byte[] byteArray29 = null;
        try {
            mersenneTwister1.nextBytes(byteArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-8322921849960486353L) + "'", long6 == (-8322921849960486353L));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.22421783414369487d + "'", double10 == 0.22421783414369487d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(byteArray26);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5403023058681399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5707963267948968d + "'", double1 == 0.5707963267948968d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((long) (byte) 2);
        int int13 = dfp12.classify();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        mersenneTwister1.setSeed(0);
        long long6 = mersenneTwister1.nextLong();
        int[] intArray8 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray8);
        double double10 = mersenneTwister9.nextGaussian();
        int[] intArray16 = new int[] { (short) -1, (byte) -1, 32768, (short) 10, ' ' };
        mersenneTwister9.setSeed(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        int int20 = mersenneTwister18.nextInt((int) (byte) 2);
        boolean boolean21 = mersenneTwister18.nextBoolean();
        byte[] byteArray26 = new byte[] { (byte) 2, (byte) 0, (byte) -1, (byte) 2 };
        mersenneTwister18.nextBytes(byteArray26);
        mersenneTwister1.nextBytes(byteArray26);
        int int29 = mersenneTwister1.nextInt();
        mersenneTwister1.setSeed(10L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-8322921849960486353L) + "'", long6 == (-8322921849960486353L));
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.22421783414369487d + "'", double10 == 0.22421783414369487d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(byteArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1706118333) + "'", int29 == (-1706118333));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = null;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.446441332248135d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4464413322481353d + "'", double1 == 1.4464413322481353d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.floor();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.multiply(4);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField29.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.newInstance();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField29.newDfp(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp42.nextAfter(dfp45);
        boolean boolean48 = dfp46.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp49 = dfp25.dotrap((int) (byte) 3, "hi!", dfp37, dfp46);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp37.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField53.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp51.add(dfp56);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField59.newDfp((byte) 3, (byte) 100);
        int int63 = dfpField59.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField59.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField59.getLn10();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField59.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp51.add(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp19.remainder(dfp51);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp10.remainder(dfp51);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 8 + "'", int63 == 8);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) 4);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField13.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.newDfp(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.nextAfter(dfp29);
        boolean boolean32 = dfp30.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp33 = dfp9.dotrap((int) (byte) 3, "hi!", dfp21, dfp30);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp21.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp6.subtract(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp6.newInstance();
        double[] doubleArray38 = dfp6.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10000);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("-0.");
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        boolean boolean10 = dfp9.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField12.newDfp(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp9.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp4.add(dfp21);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((double) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getOne();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.floor();
        boolean boolean31 = dfp27.equals((java.lang.Object) 0.0787171938695459d);
        int int32 = dfp27.classify();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp27);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(0.9999999958776927d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((long) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField16.newDfp(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp29.nextAfter(dfp32);
        boolean boolean35 = dfp33.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp36 = dfp12.dotrap((int) (byte) 3, "hi!", dfp24, dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.Dfp.copysign(dfp7, dfp24);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.newDfp((byte) 3, (byte) 100);
        boolean boolean43 = dfp42.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField45.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.newInstance();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField45.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp42.subtract(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField56 = dfp42.getField();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField59.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray68 = dfpField64.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp71.newInstance();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField64.newDfp(dfp72);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField75.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp76.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField79.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp81 = dfp77.nextAfter(dfp80);
        boolean boolean83 = dfp81.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp84 = dfp60.dotrap((int) (byte) 3, "hi!", dfp72, dfp81);
        org.apache.commons.math.dfp.DfpField dfpField86 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField86.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp88 = dfp87.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField90 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp91 = dfpField90.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp92 = dfp88.nextAfter(dfp91);
        org.apache.commons.math.dfp.Dfp dfp93 = dfp84.subtract(dfp91);
        int int94 = dfp84.classify();
        org.apache.commons.math.dfp.Dfp dfp95 = org.apache.commons.math.dfp.Dfp.copysign(dfp57, dfp84);
        org.apache.commons.math.dfp.Dfp dfp96 = org.apache.commons.math.dfp.DfpField.computeExp(dfp7, dfp95);
        org.apache.commons.math.dfp.Dfp dfp98 = dfp95.power10((int) ' ');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfpField56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfpArray68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertNotNull(dfp95);
        org.junit.Assert.assertNotNull(dfp96);
        org.junit.Assert.assertNotNull(dfp98);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.multiply(4);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.negate();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getOne();
        try {
            org.apache.commons.math.dfp.Dfp dfp21 = dfp18.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = null;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        int int7 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        int int12 = dfp10.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.39720770839918d, Double.NaN);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.397207708399177d + "'", double2 == 10.397207708399177d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        mersenneTwister1.setSeed(32768);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.5403023058681399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        int int8 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 100L, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathRuntimeException10.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = mathRuntimeException10.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException10);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance((long) '4');
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.nextAfter(dfp21);
        boolean boolean24 = dfp22.equals((java.lang.Object) (-1L));
        boolean boolean25 = dfp22.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp28.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp29.nextAfter(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp37.nextAfter(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.getOne();
        boolean boolean43 = dfp33.lessThan(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp22.divide(dfp33);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.Dfp.copysign(dfp14, dfp22);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp((byte) 3, (byte) 100);
        int int52 = dfpField48.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField48.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField60.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp67.newInstance();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField60.newDfp(dfp68);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField71.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp72.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField75.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp73.nextAfter(dfp76);
        boolean boolean79 = dfp77.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp80 = dfp56.dotrap((int) (byte) 3, "hi!", dfp68, dfp77);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp68.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp53.subtract(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField1.newDfp(dfp82);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 8 + "'", int52 == 8);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn5();
        dfpField18.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((byte) 3, (byte) 100);
        boolean boolean26 = dfp25.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField18.newDfp(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.nextAfter(dfp34);
        int int36 = dfp34.log10();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp27.divide(dfp34);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double1 = org.apache.commons.math.util.FastMath.ceil(7.610125138662287d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.nextAfter(dfp15);
        boolean boolean18 = dfp16.equals((java.lang.Object) (-1L));
        boolean boolean19 = dfp16.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.nextAfter(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.nextAfter(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getOne();
        boolean boolean37 = dfp27.lessThan(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp16.divide(dfp27);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp8.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp39.newInstance((byte) 100, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((byte) 3, (byte) 100);
        int int48 = dfpField44.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField44.newDfp(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField44.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField44.getLn10();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp39.multiply(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 8 + "'", int48 == 8);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpArray51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        mersenneTwister1.setSeed(0);
        mersenneTwister1.setSeed(8474271314106775063L);
        double double8 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed((int) '#');
        try {
            int int12 = mersenneTwister1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.0715612268167676d) + "'", double8 == (-0.0715612268167676d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode8);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 32 is smaller than, or equal to, the minimum (2)");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(1.2220998133980223d);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 2, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.newInstance();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((long) '4');
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 3, (byte) 100);
        boolean boolean14 = dfp13.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField16.newDfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.subtract(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.dotrap((int) (short) 0, "1.0000000000000000000000000000e-131104", dfp8, dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp5.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((double) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getOne();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.floor();
        boolean boolean31 = dfp27.equals((java.lang.Object) 0.0787171938695459d);
        int int32 = dfp27.classify();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp27);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((byte) 3, (byte) 100);
        int int39 = dfpField35.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField35.newDfp(0);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp45.nextAfter(dfp48);
        double double50 = dfp45.toDouble();
        boolean boolean51 = dfp41.greaterThan(dfp45);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp33.newInstance(dfp45);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 8 + "'", int39 == 8);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.NEGATIVE_INFINITY + "'", double50 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        int int4 = dfp3.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.1129943035738381d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.6381276686402511d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2106069878945154d + "'", double1 == 1.2106069878945154d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance("-0.");
        boolean boolean5 = dfp2.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0E32d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8014398509481984E16d + "'", double1 == 1.8014398509481984E16d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp2.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance((long) 97);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode8);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((byte) 10, (byte) 100);
        int int15 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray11);
        java.lang.Throwable[] throwableArray14 = mathIllegalArgumentException13.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 32.0d, (java.lang.Number) (byte) 2, false);
        java.lang.Throwable[] throwableArray20 = numberIsTooSmallException19.getSuppressed();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 6.38905609893065d, (java.lang.Number) 0.8813735870195429d, false);
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooSmallException26);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException13);
        java.lang.String str29 = mathRuntimeException28.toString();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str29.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.log10((-2.0881967013605216d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-8544263343346348898L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance("1.7320508075688772935274463415");
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        boolean boolean22 = dfp20.equals((java.lang.Object) (-1L));
        boolean boolean23 = dfp20.isNaN();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp12.nextAfter(dfp20);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp20);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.7705113220733022d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.nextAfter(dfp15);
        boolean boolean18 = dfp16.equals((java.lang.Object) (-1L));
        boolean boolean19 = dfp16.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.nextAfter(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.nextAfter(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getOne();
        boolean boolean37 = dfp27.lessThan(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp16.divide(dfp27);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp8.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp39.newInstance((byte) 100, (byte) -1);
        boolean boolean43 = dfp42.isInfinite();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 16L, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 256.0d + "'", double2 == 256.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(52.0d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        dfpField1.setIEEEFlagsBits((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("1.0000000000000000000000000000e-131104");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        double double2 = mersenneTwister1.nextDouble();
        int int4 = mersenneTwister1.nextInt((int) '#');
        int[] intArray6 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        double double8 = mersenneTwister7.nextGaussian();
        int[] intArray14 = new int[] { (short) -1, (byte) -1, 32768, (short) 10, ' ' };
        mersenneTwister7.setSeed(intArray14);
        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister(intArray14);
        int int18 = mersenneTwister16.nextInt((int) (byte) 2);
        boolean boolean19 = mersenneTwister16.nextBoolean();
        byte[] byteArray24 = new byte[] { (byte) 2, (byte) 0, (byte) -1, (byte) 2 };
        mersenneTwister16.nextBytes(byteArray24);
        mersenneTwister1.nextBytes(byteArray24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1129943035738381d + "'", double2 == 0.1129943035738381d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.22421783414369487d + "'", double8 == 0.22421783414369487d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(byteArray24);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32.0d, (java.lang.Number) (byte) 2, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        java.lang.Object[] objArray6 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-9123799161329637972L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.227551850691884E20d) + "'", double1 == (-5.227551850691884E20d));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 9468.356509017014d, true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp("1.7320508075688772935274463415");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double2 = org.apache.commons.math.util.FastMath.min(7.211102550927978d, 0.6547010314013565d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6547010314013565d + "'", double2 == 0.6547010314013565d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3L, (java.lang.Number) 1.2220998133980223d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException(throwable6, localizable7, localizable8, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray15);
        java.lang.Throwable[] throwableArray18 = mathIllegalArgumentException17.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 32.0d, (java.lang.Number) (byte) 2, false);
        java.lang.Throwable[] throwableArray24 = numberIsTooSmallException23.getSuppressed();
        mathIllegalArgumentException17.addSuppressed((java.lang.Throwable) numberIsTooSmallException23);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException17);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        double double2 = mersenneTwister1.nextDouble();
        int int4 = mersenneTwister1.nextInt(3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1129943035738381d + "'", double2 == 0.1129943035738381d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        long long2 = org.apache.commons.math.util.FastMath.min((-8474271314106775063L), 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8474271314106775063L) + "'", long2 == (-8474271314106775063L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.add(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp28.divide(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0.016676307f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0168161325053868d + "'", double1 == 1.0168161325053868d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.46579480672d + "'", double1 == 22026.46579480672d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 2, (java.lang.Number) (byte) -1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.Object[] objArray6 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 2 + "'", number4.equals((byte) 2));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((long) '4');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.nextAfter(dfp12);
        boolean boolean15 = dfp13.equals((java.lang.Object) (-1L));
        boolean boolean16 = dfp13.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.nextAfter(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.nextAfter(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.getOne();
        boolean boolean34 = dfp24.lessThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp13);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp5.sqrt();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        mersenneTwister1.setSeed((long) 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 6);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        dfpField1.setIEEEFlags(0);
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(8);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.multiply((int) (byte) 100);
        int int10 = dfp3.log10();
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp3.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-4) + "'", int10 == (-4));
        org.junit.Assert.assertNotNull(dfpField11);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 22026.465794806718d, (java.lang.Number) 6, true);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47712125471966244d + "'", double1 == 0.47712125471966244d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.nextAfter(dfp9);
        boolean boolean11 = dfp10.isNaN();
        boolean boolean12 = dfp2.lessThan(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.floor();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.multiply(4);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.newInstance(dfp23);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test400");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
//        int[] intArray2 = null;
//        mersenneTwister1.setSeed(intArray2);
//        double double4 = mersenneTwister1.nextGaussian();
//        double double5 = mersenneTwister1.nextDouble();
//        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 3, (byte) 10, (byte) 2, (byte) 1, (byte) 10 };
//        mersenneTwister1.nextBytes(byteArray12);
//        boolean boolean14 = mersenneTwister1.nextBoolean();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6334327543507475d + "'", double4 == 0.6334327543507475d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8408646178652373d + "'", double5 == 0.8408646178652373d);
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((long) '4');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.nextAfter(dfp12);
        boolean boolean15 = dfp13.equals((java.lang.Object) (-1L));
        boolean boolean16 = dfp13.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp20.nextAfter(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.nextAfter(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.getOne();
        boolean boolean34 = dfp24.lessThan(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp13.divide(dfp24);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp13);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp5.power10(16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
//        int[] intArray2 = null;
//        mersenneTwister1.setSeed(intArray2);
//        double double4 = mersenneTwister1.nextGaussian();
//        double double5 = mersenneTwister1.nextDouble();
//        long long6 = mersenneTwister1.nextLong();
//        int[] intArray8 = new int[] { 'a' };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray8);
//        double double10 = mersenneTwister9.nextGaussian();
//        int[] intArray16 = new int[] { (short) -1, (byte) -1, 32768, (short) 10, ' ' };
//        mersenneTwister9.setSeed(intArray16);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister(intArray16);
//        int int20 = mersenneTwister18.nextInt((int) (byte) 2);
//        boolean boolean21 = mersenneTwister18.nextBoolean();
//        byte[] byteArray26 = new byte[] { (byte) 2, (byte) 0, (byte) -1, (byte) 2 };
//        mersenneTwister18.nextBytes(byteArray26);
//        mersenneTwister1.nextBytes(byteArray26);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.4055713422096992d + "'", double4 == 0.4055713422096992d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.40350457226825376d + "'", double5 == 0.40350457226825376d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 6669475797134556297L + "'", long6 == 6669475797134556297L);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.22421783414369487d + "'", double10 == 0.22421783414369487d);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(byteArray26);
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        mersenneTwister1.setSeed((long) (short) 100);
        double double4 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed((-32767));
        mersenneTwister1.setSeed((-1));
        float float9 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0787171938695459d + "'", double4 == 0.0787171938695459d);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.78306735f + "'", float9 == 0.78306735f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) 4);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        int int13 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        dfpField1.setIEEEFlags((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance("1.7320508075688772935274463415");
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        boolean boolean22 = dfp20.equals((java.lang.Object) (-1L));
        boolean boolean23 = dfp20.isNaN();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp12.nextAfter(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = dfp20.getField();
        boolean boolean26 = dfp20.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.nextAfter(dfp36);
        boolean boolean38 = dfp37.isNaN();
        boolean boolean39 = dfp29.lessThan(dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp37.ceil();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance((double) 35);
        boolean boolean43 = dfp20.unequal(dfp40);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 3, (byte) 100);
        boolean boolean34 = dfp33.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.newInstance();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField36.newDfp(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp28.divide(dfp45);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp28.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 32 is smaller than, or equal to, the minimum (2)");
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.2220998133980223d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.844459278766346d + "'", double1 == 1.844459278766346d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 3, (byte) 100);
        boolean boolean34 = dfp33.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.newInstance();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField36.newDfp(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp28.divide(dfp45);
        int int48 = dfp45.log10K();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray59 = dfpField55.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp62.newInstance();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField55.newDfp(dfp63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp67.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        boolean boolean74 = dfp72.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp75 = dfp51.dotrap((int) (byte) 3, "hi!", dfp63, dfp72);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp63.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField79.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp77.add(dfp82);
        org.apache.commons.math.dfp.DfpField dfpField85 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField85.newDfp((byte) 3, (byte) 100);
        int int89 = dfpField85.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp90 = dfpField85.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp91 = dfpField85.getLn10();
        org.apache.commons.math.dfp.Dfp dfp94 = dfpField85.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp95 = dfp77.add(dfp94);
        org.apache.commons.math.dfp.Dfp dfp96 = dfp45.remainder(dfp95);
        try {
            org.apache.commons.math.dfp.Dfp dfp98 = dfp95.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfpArray59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 8 + "'", int89 == 8);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertNotNull(dfp95);
        org.junit.Assert.assertNotNull(dfp96);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        mersenneTwister1.setSeed(0);
        mersenneTwister1.setSeed(8474271314106775063L);
        double double8 = mersenneTwister1.nextGaussian();
        mersenneTwister1.setSeed((int) '#');
        int[] intArray12 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray12);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray12);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister(intArray12);
        mersenneTwister1.setSeed(intArray12);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.0715612268167676d) + "'", double8 == (-0.0715612268167676d));
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        boolean boolean9 = dfp7.equals((java.lang.Object) (-1L));
        boolean boolean10 = dfp7.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getOne();
        boolean boolean28 = dfp18.lessThan(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp7.divide(dfp18);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance((-1.0d));
        java.lang.Class<?> wildcardClass32 = dfp31.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', (long) 16);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int[] intArray1 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        float float3 = mersenneTwister2.nextFloat();
        mersenneTwister2.setSeed(35L);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.19453716f + "'", float3 == 0.19453716f);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        float float2 = org.apache.commons.math.util.FastMath.min((-9.1237992E18f), (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-9.1237992E18f) + "'", float2 == (-9.1237992E18f));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 1, (long) (byte) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        long long1 = org.apache.commons.math.util.FastMath.round(0.22421783414369487d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.sin(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9589242746631385d) + "'", double1 == (-0.9589242746631385d));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray11);
        java.lang.Throwable[] throwableArray14 = mathIllegalArgumentException13.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 32.0d, (java.lang.Number) (byte) 2, false);
        java.lang.Throwable[] throwableArray20 = numberIsTooSmallException19.getSuppressed();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.String str22 = numberIsTooSmallException19.toString();
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 32 is smaller than, or equal to, the minimum (2)" + "'", str22.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 32 is smaller than, or equal to, the minimum (2)"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) ' ', (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.999999999999996d + "'", double2 == 31.999999999999996d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.08014278376996599d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.591843268448604d + "'", double1 == 4.591843268448604d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        int[] intArray1 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        mersenneTwister2.setSeed((long) 32768);
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 0.5067887767860024d, true);
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException(throwable4, localizable5, localizable6, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = mathRuntimeException14.getSpecificPattern();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathRuntimeException14);
        java.lang.Object[] objArray17 = mathRuntimeException14.getArguments();
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.floor();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.floor();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass15 = dfp14.getClass();
        boolean boolean16 = dfp8.greaterThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-8322921849960486353L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.7686829521995124E20d) + "'", double1 == (-4.7686829521995124E20d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 8.0f, (-3.141592653589793d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0014549870613941869d + "'", double2 == 0.0014549870613941869d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 7912994101175981310L, (java.lang.Number) 1.0f, true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        int int7 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        dfpField1.setIEEEFlagsBits((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 10, 0.8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.tanh(10.397207708399177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999981373549d + "'", double1 == 0.9999999981373549d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode8);
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((double) (byte) 3);
        boolean boolean20 = dfp19.isNaN();
        org.apache.commons.math.dfp.Dfp dfp21 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.nextAfter(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.newInstance((long) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField38.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.newInstance();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField38.newDfp(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp51.nextAfter(dfp54);
        boolean boolean57 = dfp55.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp58 = dfp34.dotrap((int) (byte) 3, "hi!", dfp46, dfp55);
        org.apache.commons.math.dfp.Dfp dfp59 = org.apache.commons.math.dfp.Dfp.copysign(dfp29, dfp46);
        boolean boolean60 = dfp19.greaterThan(dfp59);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.newInstance();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(dfp61);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0.0d);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField13.getESplit();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.nextAfter(dfp27);
        boolean boolean30 = dfp28.equals((java.lang.Object) (-1L));
        boolean boolean31 = dfp28.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp35.nextAfter(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp42.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp43.nextAfter(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.getOne();
        boolean boolean49 = dfp39.lessThan(dfp47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp28.divide(dfp39);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp20.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp11.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp11.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0232274785475506d + "'", double1 == 1.0232274785475506d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5707963267948968d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 32.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 32.0d, (java.lang.Number) (byte) 2, false);
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException6.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException14.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = null;
        dfpField19.setRoundingMode(roundingMode20);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField19.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField19.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, (java.lang.Object[]) dfpArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 2.5515520672986852E154d, (java.lang.Number) 0.36381231312127915d, true);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((byte) 3, (byte) 100);
        int int40 = dfpField36.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField36.getZero();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField36.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField36.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable30, (java.lang.Object[]) dfpArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable47, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooSmallException51.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField54.newDfp((byte) 3, (byte) 100);
        int int58 = dfpField54.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField54.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField54.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray61 = dfpField54.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, (java.lang.Object[]) dfpArray61);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.newDfp((byte) 3, (byte) 100);
        int int68 = dfpField64.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField64.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField64.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray71 = dfpField64.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException72 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException9, localizable30, localizable52, (java.lang.Object[]) dfpArray71);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 100L);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 8 + "'", int40 == 8);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 8 + "'", int58 == 8);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfpArray61);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 8 + "'", int68 == 8);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfpArray71);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((byte) 3, (byte) 100);
        boolean boolean16 = dfp15.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField18.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField18.newDfp(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.subtract(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp15.getField();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp10, dfp30);
        int int32 = dfp30.intValue();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((long) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.newDfp("1.0000000000000000000000000000e-131104");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        dfpField1.setIEEEFlagsBits((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        int int9 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp((byte) 3, (byte) 100);
        int int15 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.newDfp(0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField11.setRoundingMode(roundingMode18);
        dfpField1.setRoundingMode(roundingMode18);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((long) 1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((-7910618197763358337L));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number4 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10K(35);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.negate();
        int int14 = dfp13.intValue();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-2147483648) + "'", int14 == (-2147483648));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = null;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 2.5515520672986852E154d, (java.lang.Number) 0.36381231312127915d, true);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((byte) 3, (byte) 100);
        int int30 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField26.getZero();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField26.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField26.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable20, (java.lang.Object[]) dfpArray35);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        java.lang.Throwable throwable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException(throwable46, localizable47, localizable48, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Throwable throwable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.exception.MathRuntimeException(throwable59, localizable60, localizable61, objArray68);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException70 = new org.apache.commons.math.exception.MathRuntimeException(throwable46, localizable57, localizable58, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable39, objArray68);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable39, (java.lang.Number) 35.0d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 8 + "'", int30 == 8);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.4055713422096992d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '#', (float) 32768);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32768.0f + "'", float2 == 32768.0f);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = null;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.1529388524411384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4010708144165935d + "'", double1 == 1.4010708144165935d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.8559604290184278d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.6547010314013565d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248291097914389d + "'", double1 == 4.248291097914389d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) 4);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        dfpField1.setIEEEFlags((int) '4');
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.nextAfter(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp26.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.power10((int) (byte) -1);
        int int38 = dfp37.log10K();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        mersenneTwister1.setSeed(100);
        mersenneTwister1.setSeed(97L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance(0.0d);
        int int8 = dfp7.classify();
        int int9 = dfp7.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.4224317792764335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.40997967597831364d + "'", double1 == 0.40997967597831364d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = null;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.nextAfter(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.nextAfter(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.getOne();
        boolean boolean39 = dfp29.lessThan(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray50 = dfpField46.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.newInstance();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField46.newDfp(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp58.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp59.nextAfter(dfp62);
        boolean boolean65 = dfp63.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp66 = dfp42.dotrap((int) (byte) 3, "hi!", dfp54, dfp63);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp54.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp68.add(dfp73);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp19.dotrap(10, "1.7320508075688772935274463415", dfp29, dfp68);
        org.apache.commons.math.dfp.DfpField dfpField76 = dfp68.getField();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfpArray50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfpField76);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int[] intArray1 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        double double3 = mersenneTwister2.nextGaussian();
        int[] intArray9 = new int[] { (short) -1, (byte) -1, 32768, (short) 10, ' ' };
        mersenneTwister2.setSeed(intArray9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        int int13 = mersenneTwister11.nextInt((int) (byte) 2);
        boolean boolean14 = mersenneTwister11.nextBoolean();
        byte[] byteArray19 = new byte[] { (byte) 2, (byte) 0, (byte) -1, (byte) 2 };
        mersenneTwister11.nextBytes(byteArray19);
        long long21 = mersenneTwister11.nextLong();
        float float22 = mersenneTwister11.nextFloat();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.22421783414369487d + "'", double3 == 0.22421783414369487d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-8544263343346348898L) + "'", long21 == (-8544263343346348898L));
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.82503617f + "'", float22 == 0.82503617f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9999999981373549d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077182743762d + "'", double1 == 1.5574077182743762d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6020599913279624d + "'", double1 == 0.6020599913279624d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField13.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.newInstance();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.newDfp(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.nextAfter(dfp29);
        boolean boolean32 = dfp30.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp33 = dfp9.dotrap((int) (byte) 3, "hi!", dfp21, dfp30);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp21.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp6.subtract(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp6.newInstance();
        int int38 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2 + "'", int38 == 2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-571.892036000982d) + "'", double1 == (-571.892036000982d));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.4010708144165935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.835182023568388d + "'", double1 == 5.835182023568388d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 3, (byte) 100);
        boolean boolean34 = dfp33.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.newInstance();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField36.newDfp(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp28.divide(dfp45);
        int int48 = dfp45.log10K();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp51.newInstance();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.newInstance((long) '4');
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.newDfp((byte) 3, (byte) 100);
        int int60 = dfpField56.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField56.getLn5();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField56.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray63 = dfpField56.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField56.getOne();
        org.apache.commons.math.dfp.Dfp dfp65 = org.apache.commons.math.dfp.DfpField.computeLn(dfp45, dfp54, dfp64);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass71 = dfpField67.getClass();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField67.getSqr2();
        boolean boolean73 = dfp64.unequal(dfp72);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 8 + "'", int60 == 8);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfpArray63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(wildcardClass71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((byte) 3, (byte) 100);
        int int12 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField8.newDfp((byte) 0, (byte) 100);
        boolean boolean18 = dfp6.lessThan(dfp17);
        boolean boolean19 = dfp17.isInfinite();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        double double2 = mersenneTwister1.nextGaussian();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0019203836877835d + "'", double2 == 1.0019203836877835d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(35);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1967331017 + "'", int2 == 1967331017);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 1);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.37363825732108413d + "'", double3 == 0.37363825732108413d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode8);
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode12);
        int int14 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.36381231312127915d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-32767));
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn5Split();
        int int13 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 16 + "'", int13 == 16);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(1.2220998133980223d);
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0.78306735f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-2.359932348087549d), 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.3599323480875487d) + "'", double2 == (-2.3599323480875487d));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.nextAfter(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.floor();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.multiply(4);
        boolean boolean24 = dfp12.greaterThan(dfp21);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.acosh(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.043958477050381d + "'", double1 == 7.043958477050381d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double1 = org.apache.commons.math.util.FastMath.abs(458.3662361046586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 458.3662361046586d + "'", double1 == 458.3662361046586d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3L, (java.lang.Number) 1.2220998133980223d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3L + "'", number4.equals(3L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        int int8 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags((-1706118333));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) 458.3662361046586d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Object[] objArray5 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 458.3662361046586d + "'", number4.equals(458.3662361046586d));
        org.junit.Assert.assertNotNull(objArray5);
    }
}

