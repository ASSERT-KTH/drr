import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.nextAfter(dfp9);
        boolean boolean11 = dfp10.isNaN();
        boolean boolean12 = dfp2.lessThan(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 3, (byte) 100);
        boolean boolean18 = dfp17.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField20.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.newInstance();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField20.newDfp(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp17.subtract(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField31 = dfp17.getField();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp10, dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpField31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        boolean boolean9 = dfp7.equals((java.lang.Object) (-1L));
        boolean boolean10 = dfp7.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp14.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp22.nextAfter(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getOne();
        boolean boolean28 = dfp18.lessThan(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp7.divide(dfp18);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp7.ceil();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass36 = dfp35.getClass();
        boolean boolean37 = dfp7.equals((java.lang.Object) dfp35);
        int int38 = dfp35.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 100 + "'", int38 == 100);
    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test03");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
//        int[] intArray2 = null;
//        mersenneTwister1.setSeed(intArray2);
//        mersenneTwister1.setSeed(0);
//        long long6 = mersenneTwister1.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
//        int[] intArray9 = null;
//        mersenneTwister8.setSeed(intArray9);
//        double double11 = mersenneTwister8.nextGaussian();
//        double double12 = mersenneTwister8.nextDouble();
//        byte[] byteArray19 = new byte[] { (byte) 0, (byte) 3, (byte) 10, (byte) 2, (byte) 1, (byte) 10 };
//        mersenneTwister8.nextBytes(byteArray19);
//        mersenneTwister1.nextBytes(byteArray19);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-8322921849960486353L) + "'", long6 == (-8322921849960486353L));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.11510471784851932d + "'", double11 == 0.11510471784851932d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.07074100010259854d + "'", double12 == 0.07074100010259854d);
//        org.junit.Assert.assertNotNull(byteArray19);
//    }

//    @Test
//    public void test04() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test04");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
//        int[] intArray2 = null;
//        mersenneTwister1.setSeed(intArray2);
//        double double4 = mersenneTwister1.nextGaussian();
//        double double5 = mersenneTwister1.nextDouble();
//        long long6 = mersenneTwister1.nextLong();
//        double double7 = mersenneTwister1.nextDouble();
//        int int9 = mersenneTwister1.nextInt(100);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5095758900415271d + "'", double4 == 0.5095758900415271d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8463813208744928d + "'", double5 == 0.8463813208744928d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3429722238365325895L) + "'", long6 == (-3429722238365325895L));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5504220297276654d + "'", double7 == 0.5504220297276654d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 99 + "'", int9 == 99);
//    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.11510471784851932d, (java.lang.Number) 1.5574077182743762d, true);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.3006322420239034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2654408339187349d + "'", double1 == 1.2654408339187349d);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        boolean boolean18 = dfp17.isInfinite();
        double[] doubleArray19 = dfp17.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.newInstance();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        dfpField1.setIEEEFlagsBits((-32767));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.nextAfter(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.floor();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField18.getESplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField18.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10K((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp14.newInstance(dfp29);
        boolean boolean31 = dfp7.equals((java.lang.Object) dfp29);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getESplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField14.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.nextAfter(dfp28);
        boolean boolean31 = dfp29.equals((java.lang.Object) (-1L));
        boolean boolean32 = dfp29.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.nextAfter(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp44.nextAfter(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp48.getOne();
        boolean boolean50 = dfp40.lessThan(dfp48);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp29.divide(dfp40);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp21.nextAfter(dfp40);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp12.newInstance(dfp52);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.newDfp((byte) 3, (byte) 100);
        int int6 = dfpField2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField2.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.newInstance();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField14.newDfp(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp27.nextAfter(dfp30);
        boolean boolean33 = dfp31.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp34 = dfp10.dotrap((int) (byte) 3, "hi!", dfp22, dfp31);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp22.newInstance(10);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp7.subtract(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.newDfp((byte) 3, (byte) 100);
        boolean boolean43 = dfp42.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField45.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField51.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.newInstance();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField45.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp42.subtract(dfp54);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp7.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.newDfp((byte) 3, (byte) 100);
        java.lang.Class<?> wildcardClass62 = dfpField58.getClass();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp63.getOne();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp56.nextAfter(dfp63);
        try {
            org.apache.commons.math.dfp.Dfp dfp66 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 32 is smaller than, or equal to, the minimum (2)");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9913289158005998d + "'", double1 == 0.9913289158005998d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathRuntimeException10.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = mathRuntimeException10.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException17.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 2.5515520672986852E154d, (java.lang.Number) 0.36381231312127915d, true);
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException(throwable23, localizable24, localizable25, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException46 = new org.apache.commons.math.exception.MathRuntimeException(throwable36, localizable37, localizable38, objArray45);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException(throwable23, localizable34, localizable35, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable49, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.newDfp((byte) 3, (byte) 100);
        int int60 = dfpField56.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField56.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField56.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray63 = dfpField56.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, (java.lang.Object[]) dfpArray63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode67 = null;
        dfpField66.setRoundingMode(roundingMode67);
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField66.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray70 = dfpField66.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException71 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException10, localizable18, localizable54, (java.lang.Object[]) dfpArray70);
        java.lang.String str72 = mathRuntimeException71.toString();
        org.apache.commons.math.exception.util.Localizable localizable73 = mathRuntimeException71.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 8 + "'", int60 == 8);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfpArray63);
        org.junit.Assert.assertNotNull(dfpArray69);
        org.junit.Assert.assertNotNull(dfpArray70);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: 2.718281828459 is smaller than, or equal to, the minimum (4.523536028747135266249775724709e-14): 2.718281828459 is smaller than, or equal to, the minimum (4.523536028747135266249775724709e-14)" + "'", str72.equals("org.apache.commons.math.exception.MathRuntimeException: 2.718281828459 is smaller than, or equal to, the minimum (4.523536028747135266249775724709e-14): 2.718281828459 is smaller than, or equal to, the minimum (4.523536028747135266249775724709e-14)"));
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.multiply((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp3.newInstance(1.2220998133980223d);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp15.nextAfter(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp11.divide(dfp19);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 3, (byte) -1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField6.newDfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        boolean boolean25 = dfp23.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp26 = dfp2.dotrap((int) (byte) 3, "hi!", dfp14, dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp14.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp((byte) 3, (byte) 100);
        boolean boolean34 = dfp33.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray40 = dfpField36.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp43.newInstance();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField36.newDfp(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp28.divide(dfp45);
        int int48 = dfp45.log10K();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray59 = dfpField55.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp62.newInstance();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField55.newDfp(dfp63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp67.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp68.nextAfter(dfp71);
        boolean boolean74 = dfp72.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp75 = dfp51.dotrap((int) (byte) 3, "hi!", dfp63, dfp72);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp63.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField79.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp77.add(dfp82);
        org.apache.commons.math.dfp.DfpField dfpField85 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField85.newDfp((byte) 3, (byte) 100);
        int int89 = dfpField85.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp90 = dfpField85.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp91 = dfpField85.getLn10();
        org.apache.commons.math.dfp.Dfp dfp94 = dfpField85.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp95 = dfp77.add(dfp94);
        org.apache.commons.math.dfp.Dfp dfp96 = dfp45.remainder(dfp95);
        org.apache.commons.math.dfp.Dfp dfp98 = dfp95.newInstance((double) (short) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfpArray40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfpArray59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 8 + "'", int89 == 8);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertNotNull(dfp95);
        org.junit.Assert.assertNotNull(dfp96);
        org.junit.Assert.assertNotNull(dfp98);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.negate();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.newInstance((long) '4');
        org.apache.commons.math.dfp.Dfp dfp19 = null;
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp((byte) 3, (byte) 100);
        boolean boolean25 = dfp24.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray31 = dfpField27.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.newInstance();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField27.newDfp(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp24.subtract(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp16.dotrap((int) (short) 0, "1.0000000000000000000000000000e-131104", dfp19, dfp37);
        boolean boolean39 = dfp10.unequal(dfp38);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) 'a');
        int[] intArray3 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        double double5 = mersenneTwister4.nextGaussian();
        int[] intArray11 = new int[] { (short) -1, (byte) -1, 32768, (short) 10, ' ' };
        mersenneTwister4.setSeed(intArray11);
        mersenneTwister1.setSeed(intArray11);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.22421783414369487d + "'", double5 == 0.22421783414369487d);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
        mersenneTwister1.setSeed((long) (short) 100);
        mersenneTwister1.setSeed(0L);
        double double6 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.15071724896777527d + "'", double6 == 0.15071724896777527d);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-3429722238365325895L), (float) (-1706118333));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.70611827E9f) + "'", float2 == (-1.70611827E9f));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        int[] intArray1 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        double double3 = mersenneTwister2.nextGaussian();
        int[] intArray9 = new int[] { (short) -1, (byte) -1, 32768, (short) 10, ' ' };
        mersenneTwister2.setSeed(intArray9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        int int13 = mersenneTwister11.nextInt((int) (byte) 2);
        boolean boolean14 = mersenneTwister11.nextBoolean();
        byte[] byteArray19 = new byte[] { (byte) 2, (byte) 0, (byte) -1, (byte) 2 };
        mersenneTwister11.nextBytes(byteArray19);
        int int21 = mersenneTwister11.nextInt();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.22421783414369487d + "'", double3 == 0.22421783414369487d);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(byteArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1989366334) + "'", int21 == (-1989366334));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfpArray14);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10(10000);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.nextAfter(dfp9);
        boolean boolean11 = dfp10.isNaN();
        boolean boolean12 = dfp2.lessThan(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((byte) 3, (byte) 100);
        boolean boolean18 = dfp17.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField20.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.newInstance();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField20.newDfp(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp17.subtract(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField31 = dfp17.getField();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.Dfp.copysign(dfp10, dfp32);
        int int34 = dfp32.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpField31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        int[] intArray1 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        boolean boolean4 = mersenneTwister3.nextBoolean();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode8);
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((byte) 3, (byte) 100);
        int int13 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getZero();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField9.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) dfpArray18);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathIllegalArgumentException19);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        java.lang.String str9 = dfp8.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1." + "'", str9.equals("1."));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((byte) 3, (byte) 100);
        boolean boolean23 = dfp22.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray29 = dfpField25.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.newInstance();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField25.newDfp(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp22.subtract(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray41 = dfpField37.getESplit();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField37.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp47.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField50.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp48.nextAfter(dfp51);
        boolean boolean54 = dfp52.equals((java.lang.Object) (-1L));
        boolean boolean55 = dfp52.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp58.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp59.nextAfter(dfp62);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField65.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp66.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField69.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp67.nextAfter(dfp70);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp71.getOne();
        boolean boolean73 = dfp63.lessThan(dfp71);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp52.divide(dfp63);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp44.nextAfter(dfp63);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp34.divide(dfp63);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp16.subtract(dfp34);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpArray29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpArray41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 2, (java.lang.Number) (byte) 2, true);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField18.getESplit();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.getLn10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Object[] objArray6 = numberIsTooSmallException4.getArguments();
        java.lang.Object[] objArray7 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = null;
        dfpField9.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField9.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) dfpArray13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (-3.141592653589793d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField5.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.newInstance();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField5.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.multiply((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp19.newInstance(1.2220998133980223d);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.divide(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp2.subtract(dfp15);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.floor();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.multiply(4);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((byte) 3, (byte) 100);
        boolean boolean36 = dfp35.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray42 = dfpField38.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp45.newInstance();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField38.newDfp(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp35.subtract(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField50.getLn5Split();
        int int55 = dfpField50.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField50.newDfp((byte) 1, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp35.nextAfter(dfp58);
        int int60 = dfp59.classify();
        boolean boolean61 = dfp30.lessThan(dfp59);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField63.newDfp((byte) 3, (byte) 100);
        int int67 = dfpField63.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField63.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField63.getLn10();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField63.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp72.newInstance("1.7320508075688772935274463415");
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField76.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp78 = dfp77.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField80.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp82 = dfp78.nextAfter(dfp81);
        boolean boolean84 = dfp82.equals((java.lang.Object) (-1L));
        boolean boolean85 = dfp82.isNaN();
        org.apache.commons.math.dfp.Dfp dfp86 = dfp74.nextAfter(dfp82);
        int int87 = dfp86.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp88 = dfp17.dotrap((int) (byte) 10, "1.7320508075688772935274463415", dfp30, dfp86);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp17.sqrt();
        org.apache.commons.math.dfp.Dfp dfp90 = dfp17.negate();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpArray42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 8 + "'", int55 == 8);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 8 + "'", int67 == 8);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 8 + "'", int87 == 8);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 2, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(100L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.negate();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32.0d, (java.lang.Number) (byte) 2, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test42() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test42");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
//        int[] intArray2 = null;
//        mersenneTwister1.setSeed(intArray2);
//        double double4 = mersenneTwister1.nextGaussian();
//        double double5 = mersenneTwister1.nextDouble();
//        byte[] byteArray12 = new byte[] { (byte) 0, (byte) 3, (byte) 10, (byte) 2, (byte) 1, (byte) 10 };
//        mersenneTwister1.nextBytes(byteArray12);
//        mersenneTwister1.setSeed((-2147483648));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.19374902580307324d) + "'", double4 == (-0.19374902580307324d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.21220464056835042d + "'", double5 == 0.21220464056835042d);
//        org.junit.Assert.assertNotNull(byteArray12);
//    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = null;
        dfpField2.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField2.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField2.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 10L, (java.lang.Number) 10.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getGeneralPattern();
        java.lang.Throwable throwable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException(throwable14, localizable15, localizable16, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Throwable throwable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 0.36787944117144233d, (byte) 0, 1, 2.5515520672986852E154d, (byte) 0, 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException(throwable27, localizable28, localizable29, objArray36);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.exception.MathRuntimeException(throwable14, localizable25, localizable26, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray36);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.newDfp((byte) 3, (byte) 100);
        int int45 = dfpField41.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField41.newDfp(0);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode48 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField41.setRoundingMode(roundingMode48);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode50 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField41.setRoundingMode(roundingMode50);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField41.newDfp((byte) 10, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField41.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable13, (java.lang.Object[]) dfpArray55);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 8 + "'", int45 == 8);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + roundingMode48 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode48.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertTrue("'" + roundingMode50 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode50.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfpArray55);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 32 is smaller than, or equal to, the minimum (2)");
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 3, (byte) 100);
        int int14 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField10.getESplit();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        boolean boolean20 = dfp18.equals((java.lang.Object) roundingMode19);
        dfpField1.setRoundingMode(roundingMode19);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        boolean boolean5 = dfp4.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField7.newDfp(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField18 = dfp4.getField();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn5();
        dfpField18.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((byte) 3, (byte) 100);
        boolean boolean26 = dfp25.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField18.newDfp(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField29.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.newDfp(1.2220998133980223d);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField29.getOne();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp25.newInstance(dfp36);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp25.newInstance((byte) 0, (byte) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpField18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 99);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 99.0f + "'", float1 == 99.0f);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.15071724896777527d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3, (byte) 100);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.nextAfter(dfp9);
        boolean boolean11 = dfp10.isNaN();
        boolean boolean12 = dfp2.lessThan(dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((double) 35);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((long) '4');
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((byte) 3, (byte) 100);
        boolean boolean14 = dfp13.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField16.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp23.newInstance();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField16.newDfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.subtract(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.dotrap((int) (short) 0, "1.0000000000000000000000000000e-131104", dfp8, dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.ceil();
        boolean boolean29 = dfp28.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        int[] intArray1 = new int[] { 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        double double3 = mersenneTwister2.nextGaussian();
        int[] intArray9 = new int[] { (short) -1, (byte) -1, 32768, (short) 10, ' ' };
        mersenneTwister2.setSeed(intArray9);
        mersenneTwister2.setSeed(97);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.22421783414369487d + "'", double3 == 0.22421783414369487d);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        float float2 = org.apache.commons.math.util.FastMath.min(32768.0f, 99.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.0f + "'", float2 == 99.0f);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 0);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = null;
        dfpField1.setRoundingMode(roundingMode2);
        dfpField1.setIEEEFlagsBits(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfp2.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.nextAfter(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.multiply((int) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField11.newDfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField28.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.newInstance();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField28.newDfp(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp41.nextAfter(dfp44);
        boolean boolean47 = dfp45.equals((java.lang.Object) (-1L));
        org.apache.commons.math.dfp.Dfp dfp48 = dfp24.dotrap((int) (byte) 3, "hi!", dfp36, dfp45);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp36.newInstance(10);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField52.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp50.add(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.newDfp((byte) 3, (byte) 100);
        int int62 = dfpField58.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField58.getLn10();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField58.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp50.add(dfp67);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp21.nextAfter(dfp67);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField71.newDfp((byte) 3, (byte) 100);
        boolean boolean75 = dfp74.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField77.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray81 = dfpField77.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField83 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField83.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp85 = dfp84.newInstance();
        org.apache.commons.math.dfp.Dfp dfp86 = dfpField77.newDfp(dfp85);
        org.apache.commons.math.dfp.Dfp dfp87 = dfp74.subtract(dfp86);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp87.newInstance((double) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp89.getOne();
        boolean boolean91 = dfp69.greaterThan(dfp89);
        org.apache.commons.math.dfp.DfpField dfpField93 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp94 = dfpField93.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp95 = dfp94.newInstance();
        org.apache.commons.math.dfp.Dfp dfp97 = dfp95.power10((-1));
        org.apache.commons.math.dfp.Dfp dfp98 = dfp69.divide(dfp97);
        org.apache.commons.math.dfp.Dfp dfp99 = dfp3.remainder(dfp97);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 8 + "'", int62 == 8);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfpArray81);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertNotNull(dfp95);
        org.junit.Assert.assertNotNull(dfp97);
        org.junit.Assert.assertNotNull(dfp98);
        org.junit.Assert.assertNotNull(dfp99);
    }
}

