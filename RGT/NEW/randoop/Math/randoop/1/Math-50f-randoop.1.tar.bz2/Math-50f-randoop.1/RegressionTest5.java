import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test01");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 32.0f, 1.4857159644818056E138d, (-0.9976952979536658d), 3.854370717180455E247d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test02");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.apache.commons.math.exception.NotPositiveException notPositiveException3 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-126.99999f));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test03");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) (-5.7982058E11f), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.7982058496E11d + "'", double2 == 5.7982058496E11d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test04");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 720L, 21);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test05");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 78125);
        try {
            int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12, (-16));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test06");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 100);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 100);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 1);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (short) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 100);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) bigInteger19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test07");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (short) 100);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 100);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger11);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1825.0000000000002d, (java.lang.Number) bigInteger12, false);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test08");
        long long2 = org.apache.commons.math.util.FastMath.min(283500L, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test09");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1022.9999389648438d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1023.0d + "'", double1 == 1023.0d);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test10");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 350L, 0.7071067811865476d);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test11");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        int int3 = regulaFalsiSolver0.getEvaluations();
        double double4 = regulaFalsiSolver0.getFunctionValueAccuracy();
        int int5 = regulaFalsiSolver0.getEvaluations();
        int int6 = regulaFalsiSolver0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test12");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 9.390741286647697E62d, (double) (byte) 10, 0.19607161940718024d, (-143));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test13");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(100.0d, (double) 97.0f, (double) 190, (double) 3.0f);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test14");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.1368683772161603E-13d, (double) 1.5258789E-5f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.37209302325581395d + "'", double2 == 0.37209302325581395d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test15");
        double double3 = org.apache.commons.math.util.MathUtils.round(7.105427357601002E-15d, 97, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.105427357601002E-15d + "'", double3 == 7.105427357601002E-15d);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test16");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 13627L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3352447997325401d + "'", double1 == 0.3352447997325401d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test17");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 14065L, (java.lang.Number) 5.0d, 548640);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test18");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test19");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 95.85927185202274d);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test20");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(133.6804062609211d, 1.000000000000028d);
        double double3 = regulaFalsiSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test21");
        org.apache.commons.math.util.MathUtils.checkFinite(0.3352447997325401d);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test22");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (-148335), 1078067190);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test23");
        float float1 = org.apache.commons.math.util.FastMath.ulp((-17144.998f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.001953125f + "'", float1 == 0.001953125f);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test24");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.resetCount();
        int int5 = incrementor0.getMaximalCount();
        int int6 = incrementor0.getCount();
        int int7 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test25");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.340456340784037d, number2, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 100.0f, objArray17);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 572.9577951308232d, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray17);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException20 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray17);
        java.lang.Throwable[] throwableArray21 = nullArgumentException20.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 5040L, (java.lang.Object[]) throwableArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test26");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.26345500297896E58d);
        double double2 = regulaFalsiSolver1.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test27");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 145, (int) 'a');
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 100);
        java.lang.Number number10 = null;
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) (short) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (short) 100);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(number10, (java.lang.Number) (short) 100, false);
        java.lang.Throwable[] throwableArray18 = numberIsTooSmallException17.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) bigInteger7, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException20 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException33 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Number) 100.0f, objArray32);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 572.9577951308232d, (org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray32);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, (java.lang.Number) 135.00002f, (java.lang.Number) 145.0d, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException44 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, 145, (int) 'a');
        java.lang.Throwable[] throwableArray45 = dimensionMismatchException44.getSuppressed();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 135.00002f, (org.apache.commons.math.exception.util.Localizable) localizedFormats40, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats21, (org.apache.commons.math.exception.util.Localizable) localizedFormats23, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException62 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats53, (java.lang.Number) 100.0f, objArray61);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException63 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray61);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext64 = mathArithmeticException63.getContext();
        java.lang.Object obj66 = exceptionContext64.getValue("");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats67 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats68 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats69 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats73 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats75 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray83 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException84 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats75, (java.lang.Number) 100.0f, objArray83);
        java.lang.Object[] objArray86 = new java.lang.Object[] { localizedFormats72, localizedFormats73, (short) -1, localizedFormats75, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException87 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats70, (java.lang.Number) 100.0f, objArray86);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException88 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats69, objArray86);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext89 = mathArithmeticException88.getContext();
        java.lang.String str90 = mathArithmeticException88.toString();
        java.lang.Throwable[] throwableArray91 = mathArithmeticException88.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats68, (java.lang.Object[]) throwableArray91);
        exceptionContext64.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats67, (java.lang.Object[]) throwableArray91);
        org.apache.commons.math.exception.NoBracketingException noBracketingException94 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, 15930.000000000002d, (double) 5, 0.0d, (-8.600387595703641E8d), (java.lang.Object[]) throwableArray91);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException95 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray91);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException96 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray91);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats53.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(exceptionContext64);
        org.junit.Assert.assertNull(obj66);
        org.junit.Assert.assertTrue("'" + localizedFormats67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats67.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats68.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats69.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats70.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats72.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats73.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats75.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(exceptionContext89);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31" + "'", str90.equals("org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31"));
        org.junit.Assert.assertNotNull(throwableArray91);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test28");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test29");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 100.0d, (-1.0f) };
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray3);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        double[] doubleArray12 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray18 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection6, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray25 = new double[] { 100.0d, (-1.0f) };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = null;
        double[] doubleArray34 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray40 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray41 = new double[][] { doubleArray34, doubleArray40 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray27, orderDirection28, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray27);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray27);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test30");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 548640);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 548640 + "'", int1 == 548640);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test31");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 100, (long) 102300);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102300L + "'", long2 == 102300L);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test32");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-127));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test33");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(7.6426060314262897E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test34");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        double[] doubleArray25 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray31 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray31 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray18, orderDirection19, doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = null;
        double[] doubleArray42 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray48 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray49 = new double[][] { doubleArray42, doubleArray48 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray35, orderDirection36, doubleArray49);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray18, orderDirection34, doubleArray49);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, (int) (short) 100);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray53);
        double[] doubleArray56 = null;
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (byte) 1);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test35");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.2769536E10f, (java.lang.Number) 4.311231547115195E15d, (-16), orderDirection3, true);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test36");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.8573324964312685d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS));
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test37");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4E-45f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, objArray14);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) Float.NEGATIVE_INFINITY, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notStrictlyPositiveException1, localizable3, objArray14);
        java.lang.Object[] objArray18 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test38");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1023), (java.lang.Number) Double.NaN, 145);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test39");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 453842378333305L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test40");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test41");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 36L, (double) 20.999998f, (double) 21, 2005.3522829578812d);
        double double5 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2005.3522829578812d + "'", double5 == 2005.3522829578812d);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest5.test42");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number4, (int) (short) 0, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection6, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException15 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, 145, (int) 'a');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        double[] doubleArray25 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray31 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray31 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray18, orderDirection19, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = null;
        double[] doubleArray42 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray48 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray49 = new double[][] { doubleArray42, doubleArray48 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray35, orderDirection36, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray35, (int) (short) 100);
        double[] doubleArray53 = new double[] {};
        double[] doubleArray56 = new double[] { 100.0d, (-1.0f) };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray56);
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = null;
        double[] doubleArray66 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray72 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray73 = new double[][] { doubleArray66, doubleArray72 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray59, orderDirection60, doubleArray73);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray76 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = null;
        double[] doubleArray83 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray89 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray90 = new double[][] { doubleArray83, doubleArray89 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray76, orderDirection77, doubleArray90);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray59, orderDirection75, doubleArray90);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray35, doubleArray90);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray18, doubleArray90);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException95 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Object[]) doubleArray90);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException96 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) doubleArray90);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) nonMonotonousSequenceException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) doubleArray90);
        java.lang.Number number98 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + number98 + "' != '" + 135L + "'", number98.equals(135L));
    }
}

