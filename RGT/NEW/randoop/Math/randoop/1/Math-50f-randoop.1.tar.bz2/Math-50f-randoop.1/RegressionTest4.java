import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        double[] doubleArray26 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray32 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray33 = new double[][] { doubleArray26, doubleArray32 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray19, orderDirection20, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (short) 100);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray37);
        double[] doubleArray39 = new double[] {};
        double[] doubleArray42 = new double[] { 100.0d, (-1.0f) };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray42);
        double[] doubleArray44 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = null;
        double[] doubleArray51 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray57 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray58 = new double[][] { doubleArray51, doubleArray57 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray44, orderDirection45, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray44);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray63 = new double[] {};
        double[] doubleArray66 = new double[] { 100.0d, (-1.0f) };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray63);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray63, 720);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray63);
        java.lang.Number number76 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException80 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number76, (int) (short) 0, orderDirection78, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException82 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.3893909511247697d, (java.lang.Number) 10.0f, 6, orderDirection78, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = nonMonotonousSequenceException82.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = nonMonotonousSequenceException82.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection84, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection83.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = null;
        double[] doubleArray24 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray30 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray31 = new double[][] { doubleArray24, doubleArray30 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray17, orderDirection18, doubleArray31);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection16, doubleArray31);
        double[] doubleArray34 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        double[] doubleArray41 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray47 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray48 = new double[][] { doubleArray41, doubleArray47 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray34, orderDirection35, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray34);
        double[] doubleArray52 = new double[] {};
        double[] doubleArray55 = new double[] { 100.0d, (-1.0f) };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray55);
        double[] doubleArray57 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = null;
        double[] doubleArray64 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray70 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray71 = new double[][] { doubleArray64, doubleArray70 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray57, orderDirection58, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray57);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray76 = new double[] {};
        double[] doubleArray79 = new double[] { 100.0d, (-1.0f) };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray57, doubleArray76);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray57, (int) (byte) 100);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray83);
        java.lang.Number number89 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection91 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException93 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number89, (int) (short) 0, orderDirection91, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException95 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection91, false);
        try {
            boolean boolean98 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection91, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + orderDirection91 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection91.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.5563025467867841d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2005.3522829578812d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 36, (java.lang.Number) 145, true);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException10 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, 145, (int) 'a');
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = dimensionMismatchException10.getContext();
        java.lang.Object obj13 = exceptionContext11.getValue("");
        exceptionContext5.setValue("{0} is smaller than, or equal to, the minimum ({1})", obj13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        java.lang.Object[] objArray16 = null;
        exceptionContext5.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray16);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertNull(obj13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2005.3522829578812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114898.22225041104d + "'", double1 == 114898.22225041104d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int int2 = org.apache.commons.math.util.FastMath.max((-148335), 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(3.3893909511247697d, (double) (-1023L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [3.389, -1,023]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        double double1 = org.apache.commons.math.util.FastMath.abs(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(9, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(4.644483341943245d, 6.283185307179586d, (double) 'a', 3.7581226324091723d);
        java.lang.String str5 = noBracketingException4.toString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        double[] doubleArray20 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray26 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray27 = new double[][] { doubleArray20, doubleArray26 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray13, orderDirection14, doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray13);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        java.lang.Number number37 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number37, (int) (short) 0, orderDirection39, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) (short) -1, (-1023), orderDirection39, false);
        double[] doubleArray50 = new double[] { 0.9999999958776927d, 3.7581226324091723d, (short) 100, 0.8623188722876839d, (byte) 1, 6.994405055138486E-14d };
        double[] doubleArray57 = new double[] { 0.9999999958776927d, 3.7581226324091723d, (short) 100, 0.8623188722876839d, (byte) 1, 6.994405055138486E-14d };
        double[][] doubleArray58 = new double[][] { doubleArray50, doubleArray57 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray13, orderDirection39, doubleArray58);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException64 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats60, (java.lang.Number) (-1.1752011936438014d), (java.lang.Number) 10L, false);
        java.lang.Object[] objArray65 = new java.lang.Object[] { (-1.2246467991473532E-16d), (-17145), 36.0d, localizedFormats12, doubleArray58, numberIsTooLargeException64 };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException66 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, number8, objArray65);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException67 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray65);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [4.644, 6.283], values: [97, 3.758]" + "'", str5.equals("org.apache.commons.math.exception.NoBracketingException: function values at endpoints do not have different signs, endpoints: [4.644, 6.283], values: [97, 3.758]"));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(objArray65);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number4, (int) (short) 0, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 36.0f, 0, orderDirection6, true);
        org.apache.commons.math.exception.MathInternalError mathInternalError11 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.exception.MathInternalError mathInternalError12 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException10);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1078067190, 2.0794415416798357d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1079525377, 145);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29 + "'", int2 == 29);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.5258789E-5f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16) + "'", int1 == (-16));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1022.99994f), (-0.01358843711736837d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1022.9999389648436d) + "'", double2 == (-1022.9999389648436d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(35.0d, 36.0d, (-7.174648137343063E-42d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4E-45f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = notStrictlyPositiveException1.getContext();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 40500L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.275957614183426E-12d + "'", double1 == 7.275957614183426E-12d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) bigInteger2);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) bigInteger2, (java.lang.Number) 35.0d, false);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 35.0d);
        java.lang.Number number10 = maxCountExceededException9.getMax();
        java.lang.Number number11 = maxCountExceededException9.getMax();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 35.0d + "'", number10.equals(35.0d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 35.0d + "'", number11.equals(35.0d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 36.000008f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 41L, (java.lang.Number) 6.283185307179586d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-113L), (java.lang.Number) (-1.3721358231788738d), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        int int2 = org.apache.commons.math.util.MathUtils.pow(30, (long) 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 102300, 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 102299.0f + "'", float3 == 102299.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray21 = new double[] { 100.0d, (-1.0f) };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray27 = new double[] { 100.0d, (-1.0f) };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray27);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        int int2 = org.apache.commons.math.util.FastMath.max((-143), 210);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 210 + "'", int2 == 210);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1720077615), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 10, n = -1,720,077,615");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.2965278837753546E39d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3.102242897201188d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        float[] floatArray0 = null;
        float[] floatArray2 = new float[] { 0.0f };
        float[] floatArray6 = new float[] { (short) 0, 'a', 10L };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(floatArray2, floatArray6);
        float[] floatArray9 = new float[] { 0.0f };
        float[] floatArray13 = new float[] { (short) 0, 'a', 10L };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(floatArray9, floatArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray2, floatArray13);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray13);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 2147483647);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 21, (float) 20L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 21.0f + "'", float2 == 21.0f);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5430806348152437d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5430806348152435d + "'", double2 == 1.5430806348152435d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (short) 1);
        int int6 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.incrementCount();
        incrementor0.incrementCount((-48));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-135));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(547922, (-10));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 547932 + "'", int2 == 547932);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 1L, (-1.64376061222056256E17d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 20.999998f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1607139329) + "'", int1 == (-1607139329));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 97, 143L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-46L) + "'", long2 == (-46L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-1.5495411464777387d), 6.691673596021348E41d, 214322.12823951655d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        float float1 = org.apache.commons.math.util.FastMath.abs(Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + Float.POSITIVE_INFINITY + "'", float1 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (-17145));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-17144.998f) + "'", float1 == (-17144.998f));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 145L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 145.00002f + "'", float1 == 145.00002f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-46L), (float) 29, 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats3, localizedFormats4, (short) -1, localizedFormats6, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, objArray17);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray17);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.773121177104694d, (java.lang.Number) 35L, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 331563.4413511861d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException11 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 100.0f, objArray10);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-808182895));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -808,182,895");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.52587890625E-5d, (double) Float.POSITIVE_INFINITY, (double) (-166718472));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        float[] floatArray1 = new float[] { 0.0f };
        float[] floatArray5 = new float[] { (short) 0, 'a', 10L };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(floatArray1, floatArray5);
        float[] floatArray8 = new float[] { 0.0f };
        float[] floatArray12 = new float[] { (short) 0, 'a', 10L };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(floatArray8, floatArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray1, floatArray12);
        float[] floatArray16 = new float[] { 0.0f };
        float[] floatArray20 = new float[] { (short) 0, 'a', 10L };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(floatArray16, floatArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray16);
        float[] floatArray24 = new float[] { 0.0f };
        float[] floatArray28 = new float[] { (short) 0, 'a', 10L };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray28);
        float[] floatArray31 = new float[] { 0.0f };
        float[] floatArray35 = new float[] { (short) 0, 'a', 10L };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(floatArray31, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray24, floatArray35);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray12, floatArray35);
        float[] floatArray40 = new float[] { 0.0f };
        float[] floatArray44 = new float[] { (short) 0, 'a', 10L };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(floatArray40, floatArray44);
        float[] floatArray47 = new float[] { 0.0f };
        float[] floatArray51 = new float[] { (short) 0, 'a', 10L };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(floatArray47, floatArray51);
        float[] floatArray54 = new float[] { 0.0f };
        float[] floatArray58 = new float[] { (short) 0, 'a', 10L };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(floatArray54, floatArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray47, floatArray58);
        float[] floatArray62 = new float[] { 0.0f };
        float[] floatArray66 = new float[] { (short) 0, 'a', 10L };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(floatArray62, floatArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray58, floatArray62);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(floatArray44, floatArray62);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(floatArray12, floatArray44);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        double double4 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 145.00002f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(5040L, (long) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(35.0d, (double) (-135), 35.00000000000001d, 0.0d);
        double double5 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-135.0d) + "'", double5 == (-135.0d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 101L, 1.0f, 10.0f, 101L };
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray10);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException(localizable2, (java.lang.Number) (byte) 10, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray10);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9);
        int[] intArray16 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray21 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray21);
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray16);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray23, (int) (byte) 1);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray23, 0);
        try {
            double double28 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 145 + "'", int22 == 145);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(4.594700892207039d, 0.0d, 2.0794415416798357d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(90);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4857159644818056E138d + "'", double1 == 1.4857159644818056E138d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(1.505149978319906d, 190.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 95.75257498915995d + "'", double2 == 95.75257498915995d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-9193510194255822747L), 17145);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-208617464059018235L) + "'", long2 == (-208617464059018235L));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (short) 1);
        int int6 = incrementor0.getMaximalCount();
        int int7 = incrementor0.getCount();
        incrementor0.incrementCount();
        int int9 = incrementor0.getMaximalCount();
        int int10 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 1.0f, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 5L, 720);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        double double3 = regulaFalsiSolver0.getRelativeAccuracy();
        double double4 = regulaFalsiSolver0.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver14 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 4.9E-324d);
        int int15 = regulaFalsiSolver14.getEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution19 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double20 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(78125, univariateRealFunction11, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver14, (-4.503599627370496E15d), (double) 3L, (double) 36L, allowedSolution19);
        try {
            double double21 = regulaFalsiSolver0.solve((int) (short) 0, univariateRealFunction6, 0.0d, 1.3666125331663666E39d, (double) 110, allowedSolution19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution19 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution19.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-4.503599627370496E15d) + "'", double20 == (-4.503599627370496E15d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 7642606031426289665L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 6);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 97);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(5.267831587699267d, 0.0d, 0.0d, 21863.46579480672d);
        double double5 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(306.3666941127301d, (double) 36.0f, 18896.732897403363d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 21.633796709367743d + "'", double3 == 21.633796709367743d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100, 286.4788975654116d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3358423725664079d + "'", double2 == 0.3358423725664079d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-113L), (double) (-5.7982058E11f));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, 2.0f, 1102438400);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-135));
        int int2 = regulaFalsiSolver1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        long long1 = org.apache.commons.math.util.FastMath.abs(1078067199L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1078067199L + "'", long1 == 1078067199L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        float[] floatArray0 = new float[] {};
        float[] floatArray2 = new float[] { 0.0f };
        float[] floatArray6 = new float[] { (short) 0, 'a', 10L };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(floatArray2, floatArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray2);
        float[] floatArray11 = new float[] { (-0.5f), (short) 100 };
        float[] floatArray13 = new float[] { 0.0f };
        float[] floatArray17 = new float[] { (short) 0, 'a', 10L };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(floatArray13, floatArray17);
        float[] floatArray20 = new float[] { 0.0f };
        float[] floatArray24 = new float[] { (short) 0, 'a', 10L };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(floatArray20, floatArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray13, floatArray24);
        float[] floatArray28 = new float[] { 0.0f };
        float[] floatArray32 = new float[] { (short) 0, 'a', 10L };
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(floatArray28, floatArray32);
        float[] floatArray35 = new float[] { 0.0f };
        float[] floatArray39 = new float[] { (short) 0, 'a', 10L };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(floatArray35, floatArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray28, floatArray39);
        float[] floatArray43 = new float[] { 0.0f };
        float[] floatArray47 = new float[] { (short) 0, 'a', 10L };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(floatArray43, floatArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray39, floatArray43);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray24, floatArray39);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray39);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray39);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (short) 100);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 100);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger11);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (int) 'a');
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (short) 10);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException19 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) bigInteger18);
        java.lang.Throwable[] throwableArray20 = tooManyEvaluationsException19.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4.0144243921987787E-44d, (java.lang.Object[]) throwableArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(4.26345500297896E58d, (-0.941007838550008d), 28.64788975654116d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-1.5717738435900939d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 20, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 1081466880, (float) (short) -1, (-1720077615));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        int int2 = org.apache.commons.math.util.FastMath.min(145, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 110);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 110.0d + "'", double1 == 110.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 13627L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1607139329), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 0);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 100);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 100);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 3, (java.lang.Number) bigInteger15, false);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 3);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.99822295029797d, (java.lang.Number) bigInteger15, false);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 1174405120);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger25, (java.lang.Number) 286.4788975654116d, 5);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger25);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(106.0801583709225d, (double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        double double1 = org.apache.commons.math.util.FastMath.rint(41.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.0d + "'", double1 == 41.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.2414508546761014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6816381923098981d + "'", double1 == 0.6816381923098981d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getEvaluations();
        int int5 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double11 = regulaFalsiSolver2.solve(548642, univariateRealFunction7, 36.0d, 3.719933267899063E41d, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats3, localizedFormats4, (short) -1, localizedFormats6, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, objArray17);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext20 = mathArithmeticException19.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext21 = mathArithmeticException19.getContext();
        org.apache.commons.math.exception.MathInternalError mathInternalError22 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) mathArithmeticException19);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext23 = mathArithmeticException19.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext20);
        org.junit.Assert.assertNotNull(exceptionContext21);
        org.junit.Assert.assertNotNull(exceptionContext23);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) bigInteger2);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        try {
            java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats3, localizedFormats4, (short) -1, localizedFormats6, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, objArray17);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext20 = mathArithmeticException19.getContext();
        java.lang.String str21 = mathArithmeticException19.toString();
        java.lang.Throwable[] throwableArray22 = mathArithmeticException19.getSuppressed();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        double[] doubleArray31 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray37 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray38 = new double[][] { doubleArray31, doubleArray37 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, orderDirection25, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray24);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        java.lang.Number number48 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number48, (int) (short) 0, orderDirection50, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) (short) -1, (-1023), orderDirection50, false);
        double[] doubleArray61 = new double[] { 0.9999999958776927d, 3.7581226324091723d, (short) 100, 0.8623188722876839d, (byte) 1, 6.994405055138486E-14d };
        double[] doubleArray68 = new double[] { 0.9999999958776927d, 3.7581226324091723d, (short) 100, 0.8623188722876839d, (byte) 1, 6.994405055138486E-14d };
        double[][] doubleArray69 = new double[][] { doubleArray61, doubleArray68 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, orderDirection50, doubleArray69);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException71 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathArithmeticException19, (org.apache.commons.math.exception.util.Localizable) localizedFormats23, (java.lang.Object[]) doubleArray69);
        java.lang.Class<?> wildcardClass72 = localizedFormats23.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31" + "'", str21.equals("org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31"));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(wildcardClass72);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        int int2 = org.apache.commons.math.util.FastMath.max(36, 548642);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 548642 + "'", int2 == 548642);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1L), 97.0d, (double) '4', 0.0d);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getHi();
        double double7 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double5 = regulaFalsiSolver4.getAbsoluteAccuracy();
        int int6 = regulaFalsiSolver4.getMaxEvaluations();
        double double7 = regulaFalsiSolver4.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction12 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver15 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double16 = regulaFalsiSolver15.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution20 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double21 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(17145, univariateRealFunction12, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver15, 0.8623188722876839d, (double) Float.NaN, (-0.9036922050915037d), allowedSolution20);
        double double22 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, 10.0498756212d, (double) (-80L), 0.0d, allowedSolution20);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-15d + "'", double7 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution20 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution20.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.8623188722876839d + "'", double21 == 0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0498756212d + "'", double22 == 10.0498756212d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) (-135));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, 135.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 548642, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 548642.0f + "'", float2 == 548642.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        double double2 = org.apache.commons.math.util.FastMath.min(102.0d, 1.4857159644818056E138d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 102.0d + "'", double2 == 102.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 41L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 548640, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1825.0000000000002d);
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notPositiveException2);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) notPositiveException2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(143L, (-1607139329));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,607,139,329)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-46L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.43323115153831737d, 1.5556649017821482d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.43323115153831737d + "'", double2 == 0.43323115153831737d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (short) 100);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 100);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger11);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1825.0000000000002d, (java.lang.Number) bigInteger12, false);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) ' ');
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray16 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, 0);
        int[] intArray24 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray29 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray29);
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray24);
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray24);
        int[] intArray37 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray42 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray42);
        int[] intArray49 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray49);
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray49, 0);
        int[] intArray54 = org.apache.commons.math.util.MathUtils.copyOf(intArray52, (int) (byte) 0);
        int[] intArray55 = org.apache.commons.math.util.MathUtils.copyOf(intArray54);
        try {
            double double56 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 135 + "'", int17 == 135);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 145 + "'", int30 == 145);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 145 + "'", int43 == 145);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 135 + "'", int50 == 135);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.1752011936438014d), (java.lang.Number) 10L, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, objArray14);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = mathArithmeticException16.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext18 = mathArithmeticException16.getContext();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) mathArithmeticException16);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext20 = mathArithmeticException16.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertNotNull(exceptionContext18);
        org.junit.Assert.assertNotNull(exceptionContext20);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 145, (int) 'a');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 100);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (short) 100);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger16);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 3, (java.lang.Number) bigInteger19, false);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 3);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 40500L, (java.lang.Number) 3, false);
        java.lang.Class<?> wildcardClass26 = numberIsTooLargeException25.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-1023));
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        java.util.Set<java.lang.String> strSet3 = exceptionContext2.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-46L), 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3440585709080678E43d + "'", double2 == 1.3440585709080678E43d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        double double1 = org.apache.commons.math.util.FastMath.cos(95.75257498915995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06595303770555495d + "'", double1 == 0.06595303770555495d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.6777218383022342E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 256.00001212067787d + "'", double1 == 256.00001212067787d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) 'a');
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (short) 10);
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException17 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) bigInteger16);
        java.lang.Throwable[] throwableArray18 = tooManyEvaluationsException17.getSuppressed();
        java.lang.Number number19 = tooManyEvaluationsException17.getMax();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(number19);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) bigInteger2);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (byte) 10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 100);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) (short) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (short) 100);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 3, (java.lang.Number) bigInteger22, false);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1.2664126E30f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.5403023093369417d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, (-126.99999237060547d), 0.0d, 0.0d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = noBracketingException4.getContext();
        org.apache.commons.math.exception.MathInternalError mathInternalError6 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException4);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1825.0000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-46L), (float) 3628800L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 'a', (long) 1174405120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1174405120L + "'", long2 == 1174405120L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (short) 100, 548640);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 2.2579283999999997E8d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        java.lang.Number number5 = null;
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 100);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(number5, (java.lang.Number) (short) 100, false);
        java.lang.Throwable[] throwableArray13 = numberIsTooSmallException12.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (short) 100);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 100);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger11);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3, (java.lang.Number) bigInteger14, false);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 110);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction> univariateRealFunctionBracketedUnivariateRealSolver2 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double7 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(548642, univariateRealFunction1, univariateRealFunctionBracketedUnivariateRealSolver2, (double) 145539071858L, (-0.5745225696183645d), 0.013493510057371112d, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution6 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution6.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        double double1 = org.apache.commons.math.util.FastMath.sin(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(6.2919553545008196d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 270.1033726055465d + "'", double1 == 270.1033726055465d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) ' ', (-1022.9999999999999d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = null;
        double[] doubleArray24 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray30 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray31 = new double[][] { doubleArray24, doubleArray30 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray17, orderDirection18, doubleArray31);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection16, doubleArray31);
        double[] doubleArray34 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = null;
        double[] doubleArray41 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray47 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray48 = new double[][] { doubleArray41, doubleArray47 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray34, orderDirection35, doubleArray48);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray34, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray34);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection55, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-48));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (short) 1);
        int int6 = incrementor0.getMaximalCount();
        incrementor0.incrementCount();
        int int8 = incrementor0.getCount();
        incrementor0.setMaximalCount(0);
        try {
            incrementor0.incrementCount(1078067200);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-4.503599627370496E15d), (double) 9, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.7937005259840998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9258747122872905d + "'", double1 == 0.9258747122872905d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 100.00001f, 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.000008d + "'", double2 == 100.000008d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.19607161940718024d, (-1.4155594961262613E11d), 0.08835348699955041d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.1556157735575975E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.30685281944005d + "'", double1 == 35.30685281944005d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.0144243921987787E-44d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0144243921987787E-44d + "'", double1 == 4.0144243921987787E-44d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((-5348.853343181455d), (double) 145L, 97.00000000000001d, (double) 3628800L);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 145.0d + "'", double5 == 145.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.00000000000001d + "'", double6 == 97.00000000000001d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 3628800L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(10.0498756212d, 1.5574077246549023d);
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-1720077616), (float) 1, (-135));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.3893909511247697d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        double double4 = regulaFalsiSolver2.getMin();
        double double5 = regulaFalsiSolver2.getRelativeAccuracy();
        double double6 = regulaFalsiSolver2.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 35.0d + "'", double6 == 35.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 720, 14065L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14065L + "'", long2 == 14065L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 548642);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 740.7037194452314d + "'", double1 == 740.7037194452314d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.17453294184418977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9848077501218763d + "'", double1 == 0.9848077501218763d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray19 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray20 = new double[][] { doubleArray13, doubleArray19 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray6, orderDirection7, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = null;
        double[] doubleArray30 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray36 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray37 = new double[][] { doubleArray30, doubleArray36 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray23, orderDirection24, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray23, (int) (short) 100);
        double[] doubleArray41 = new double[] {};
        double[] doubleArray44 = new double[] { 100.0d, (-1.0f) };
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray44);
        double[] doubleArray47 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = null;
        double[] doubleArray54 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray60 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray61 = new double[][] { doubleArray54, doubleArray60 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray47, orderDirection48, doubleArray61);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray64 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = null;
        double[] doubleArray71 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray77 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray78 = new double[][] { doubleArray71, doubleArray77 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray64, orderDirection65, doubleArray78);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray47, orderDirection63, doubleArray78);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray23, doubleArray78);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray6, doubleArray78);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException83 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) doubleArray78);
        org.apache.commons.math.exception.NoBracketingException noBracketingException84 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 573.0d, 3.355443242632568E7d, 6.488801459162743E9d, 1.5707963098836446d, (java.lang.Object[]) doubleArray78);
        double double85 = noBracketingException84.getLo();
        double double86 = noBracketingException84.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 573.0d + "'", double85 == 573.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.5707963098836446d + "'", double86 == 1.5707963098836446d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 547932, 13627L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 561559L + "'", long2 == 561559L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        int int2 = org.apache.commons.math.util.FastMath.max(9, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 97.00000000000001d, 106.0801583709225d, 1022.9999389648438d, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection2 = null;
        double[] doubleArray8 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray14 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray1, orderDirection2, doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray1, (int) (short) 100);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(8.138849254928481E9d, 7.275957614183426E-12d, (double) 1.5258789E-5f, (double) 145539071768L, 3.0d, 4.6116860184273879E18d, (double) 5730L, (double) 0.00390625f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.3835058055284384E19d + "'", double8 == 1.3835058055284384E19d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, (-126.99999237060547d), 0.0d, 0.0d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = noBracketingException4.getContext();
        double double6 = noBracketingException4.getFHi();
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (short) 1);
        int int6 = incrementor0.getMaximalCount();
        int int7 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        java.math.BigInteger bigInteger2 = null;
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (short) 100);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 100);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger11);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3, (java.lang.Number) bigInteger14, false);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 101L);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (short) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) (short) 100);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (short) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) (short) 100);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger28);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) 6);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger31);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(283500L, 20L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 283500L + "'", long2 == 283500L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        double[] doubleArray10 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray16 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray17 = new double[][] { doubleArray10, doubleArray16 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray3, orderDirection4, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (short) 100);
        java.lang.Number number25 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number25, (int) (short) 0, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection27, false);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection27, false, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.355443242632568E7d, (java.lang.Number) 2005.3522829578812d, 10, orderDirection27, true);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver6 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 3628800L, 0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver14 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 3628800L, 0.0d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution18 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double19 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(36, univariateRealFunction11, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver14, 572.9577951308232d, 17.5d, (double) (byte) 1, allowedSolution18);
        double double20 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(135, univariateRealFunction3, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver6, (double) 41L, 133.6804062609211d, (double) 7.2769536E10f, allowedSolution18);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution24 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double25 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(5, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver6, (double) 1174405120L, 2.0d, (double) 5730L, allowedSolution24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution18 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution18.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 572.9577951308232d + "'", double19 == 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 41.0d + "'", double20 == 41.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution24 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution24.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray10 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray10);
        int[] intArray17 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray17, 0);
        int[] intArray25 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray30 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray30);
        int[] intArray37 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray37, 0);
        int[] intArray45 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray50 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray50);
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray45);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray45);
        int[] intArray58 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray63 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray63);
        int[] intArray70 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray63, intArray70);
        int[] intArray73 = org.apache.commons.math.util.MathUtils.copyOf(intArray70, 0);
        int[] intArray78 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray83 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray78, intArray83);
        int[] intArray85 = org.apache.commons.math.util.MathUtils.copyOf(intArray78);
        int int86 = org.apache.commons.math.util.MathUtils.distance1(intArray73, intArray78);
        int[] intArray87 = org.apache.commons.math.util.MathUtils.copyOf(intArray78);
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray78);
        int[] intArray90 = org.apache.commons.math.util.MathUtils.copyOf(intArray45, 97);
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray90);
        try {
            int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 145 + "'", int11 == 145);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 135 + "'", int18 == 135);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 145 + "'", int31 == 145);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 135 + "'", int38 == 135);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 145 + "'", int51 == 145);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 145 + "'", int64 == 145);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 135 + "'", int71 == 135);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 145 + "'", int84 == 145);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 173.91377173760566d + "'", double91 == 173.91377173760566d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray16 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, 0);
        int[] intArray24 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray29 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray29);
        int[] intArray36 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray36);
        int[] intArray39 = org.apache.commons.math.util.MathUtils.copyOf(intArray36, 0);
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray39, (int) (byte) 0);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray41);
        int[] intArray47 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray52 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray52);
        int[] intArray59 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray59);
        int[] intArray62 = org.apache.commons.math.util.MathUtils.copyOf(intArray59, 0);
        int[] intArray67 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray72 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray72);
        int[] intArray74 = org.apache.commons.math.util.MathUtils.copyOf(intArray67);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray67);
        int[] intArray76 = org.apache.commons.math.util.MathUtils.copyOf(intArray67);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray67);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 135 + "'", int17 == 135);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 145 + "'", int30 == 145);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 135 + "'", int37 == 135);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 145 + "'", int53 == 145);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 135 + "'", int60 == 135);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 145 + "'", int73 == 145);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (short) 1);
        int int6 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (short) 100);
        int int9 = incrementor0.getCount();
        int int10 = incrementor0.getMaximalCount();
        int int11 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        double double4 = regulaFalsiSolver2.getStartValue();
        int int5 = regulaFalsiSolver2.getMaxEvaluations();
        double double6 = regulaFalsiSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(69840L, 145539071858L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 101L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 101 + "'", int1 == 101);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        double double1 = org.apache.commons.math.util.FastMath.acos(1032.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 145);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4E-45f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException(0.0d, (-126.99999237060547d), 0.0d, 0.0d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = noBracketingException8.getContext();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) noBracketingException8);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 4.9E-324d);
        double double5 = regulaFalsiSolver4.getRelativeAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-17145), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, 1.3440585709080678E43d, 0.0d, 0.648740696524143d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.8623188722876839d);
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = notStrictlyPositiveException2.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.401298464324817E-45d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.401298464324817E-45d + "'", double1 == 1.401298464324817E-45d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(1.0f, 100, 33554432);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 33,554,432, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, Double.NEGATIVE_INFINITY, 1.4025335376029113d, 3.0325108002841175d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        double double2 = org.apache.commons.math.util.MathUtils.round((-1.5717738435900939d), 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.57d) + "'", double2 == (-1.57d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number4, (int) (short) 0, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.3893909511247697d, (java.lang.Number) 10.0f, 6, orderDirection6, true);
        int int11 = nonMonotonousSequenceException10.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10.0f + "'", number12.equals(10.0f));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(20, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 100.0d, (-1.0f) };
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray3);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        double[] doubleArray12 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray18 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection6, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray28 = new double[] { 100.0d, (-1.0f) };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray28);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = null;
        double[] doubleArray37 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray43 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray44 = new double[][] { doubleArray37, doubleArray43 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray30, orderDirection31, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray30);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray49 = new double[] {};
        double[] doubleArray52 = new double[] { 100.0d, (-1.0f) };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray49);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray49);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.9705802315631344d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) ' ', 4.76837158203125E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.2d) + "'", double2 == (-4.2d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.3822622382423977E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3822622382423977E12d + "'", double1 == 1.3822622382423977E12d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats3, localizedFormats4, (short) -1, localizedFormats6, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, objArray17);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext20 = mathArithmeticException19.getContext();
        java.lang.String str21 = mathArithmeticException19.toString();
        java.lang.Throwable[] throwableArray22 = mathArithmeticException19.getSuppressed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext23 = mathArithmeticException19.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        org.apache.commons.math.exception.NotPositiveException notPositiveException27 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Number) 7.6293945E-6f);
        exceptionContext23.setValue("org.apache.commons.math.exception.NumberIsTooLargeException: 7 is larger than the maximum (-0.5)", (java.lang.Object) localizedFormats25);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31" + "'", str21.equals("org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31"));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(exceptionContext23);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-2), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(145539071768L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 145539071868L + "'", long2 == 145539071868L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3628800L, (java.lang.Number) 1.0d, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException4.getContext();
        float[] floatArray8 = new float[] {};
        float[] floatArray10 = new float[] { 0.0f };
        float[] floatArray14 = new float[] { (short) 0, 'a', 10L };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(floatArray10, floatArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(floatArray8, floatArray10);
        exceptionContext6.setValue("", (java.lang.Object) floatArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 78125);
        int[] intArray13 = null;
        try {
            int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        incrementor0.incrementCount(0);
        incrementor0.resetCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        int int1 = org.apache.commons.math.util.FastMath.round(36.000004f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 36 + "'", int1 == 36);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, (double) 5, 5729.5779513082325d, (double) 0.0f);
        double double5 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 2);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (short) 1);
        int int6 = incrementor0.getMaximalCount();
        incrementor0.incrementCount();
        int int8 = incrementor0.getCount();
        incrementor0.setMaximalCount(0);
        incrementor0.setMaximalCount((-17145));
        int int13 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException17 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 100.0f, objArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizedFormats5, localizedFormats6, (short) -1, localizedFormats8, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 100.0f, objArray19);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray19);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext22 = mathArithmeticException21.getContext();
        java.lang.String str23 = mathArithmeticException21.toString();
        java.lang.Throwable[] throwableArray24 = mathArithmeticException21.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException25 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 100.00001f, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException31 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, 145, (int) 'a');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 101L, 1.0f, 10.0f, 101L };
        java.lang.Object[] objArray51 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray50);
        org.apache.commons.math.exception.NoBracketingException noBracketingException52 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, (-2989.6366929140413d), (double) 100.0f, 95.85927185202274d, 35.0d, objArray50);
        org.apache.commons.math.exception.NoBracketingException noBracketingException53 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, (double) 100.00001f, (double) (short) 1, 0.0d, 286.4788975654116d, objArray50);
        org.apache.commons.math.exception.NoBracketingException noBracketingException54 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, Double.POSITIVE_INFINITY, (double) 1079525377L, 5.109094217170942E19d, (double) '#', objArray50);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) mathArithmeticException26, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray50);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(exceptionContext22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31" + "'", str23.equals("org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) (short) 0, 2.4741354375614093d, 2.200956328216774E-15d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.474135437561407d + "'", double3 == 2.474135437561407d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(78125L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 78125L + "'", long2 == 78125L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.resetCount();
        int int5 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 7.52574989159953d, (java.lang.Number) (-1023), false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1023) + "'", number4.equals((-1023)));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(4.311231547115195E15d, (double) 720, 2.474135437561407d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 392.5258645624386d + "'", double3 == 392.5258645624386d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.resetCount();
        int int5 = incrementor0.getCount();
        int int6 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount(2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray11, (int) (byte) 1);
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray13, 101);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(143);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.854370717180455E247d + "'", double1 == 3.854370717180455E247d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.0780671900000002E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) 8.028848784397557E-44d, (int) (byte) 100);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.5745225696183645d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 100);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 1);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) 'a');
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (byte) 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.4741354375614093d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5554408779604834d + "'", double1 == 1.5554408779604834d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 720, 13500.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(13.215199590383916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3642382658800676d + "'", double1 == 2.3642382658800676d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 0.00390625f, (double) (-135));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 3628800L, (double) (byte) 0);
        double double3 = regulaFalsiSolver2.getMin();
        double double4 = regulaFalsiSolver2.getMin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(7.2769536E10f, (float) 145539071868L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-17145L), (double) Float.NEGATIVE_INFINITY);
        double double3 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 17145);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 299.23670025442783d + "'", double1 == 299.23670025442783d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1032.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(7.105427357601002E-15d, 0.0d, 580.0342727671309d, (double) 3805048218720998409L, 9.042354332119482d, (double) 8L, 6.0d, (double) 36);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.2070583763897011E21d + "'", double8 == 2.2070583763897011E21d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-1023));
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = maxCountExceededException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Number number10 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number10, (int) (short) 0, orderDirection12, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection12, false);
        java.lang.Number number17 = nonMonotonousSequenceException16.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException29 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 100.0f, objArray28);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException30 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray28);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext31 = mathArithmeticException30.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException36 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, 145, (int) 'a');
        java.lang.Throwable[] throwableArray37 = dimensionMismatchException36.getSuppressed();
        exceptionContext31.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats32, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException16, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) maxCountExceededException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-0.0f), (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0f + "'", number17.equals(0.0f));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(exceptionContext31);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 108816201, 7.629395E-6f, (float) 210);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.7581226324091723d, (double) 350L, 572.9577951308232d);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver3.solve((-17145), univariateRealFunction6, 0.9999999958776927d, 35.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 350.0d + "'", double4 == 350.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.5745225696183645d), (java.lang.Number) 19.999999999999996d, false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(311.9264291075885d, (double) 33554432, 0.9998151400298467d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [33,554,432, 1]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(36.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray21 = new double[] { 100.0d, (-1.0f) };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.2255938657968326d, (double) 1079525377L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0795253785856714E9d + "'", double2 == 1.0795253785856714E9d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1102438400, (-1607139329));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4.584967478670572d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        int int3 = regulaFalsiSolver0.getEvaluations();
        double double4 = regulaFalsiSolver0.getFunctionValueAccuracy();
        int int5 = regulaFalsiSolver0.getEvaluations();
        int int6 = regulaFalsiSolver0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) 100);
        java.lang.Number number5 = null;
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 100);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(number5, (java.lang.Number) (short) 100, false);
        java.lang.Throwable[] throwableArray13 = numberIsTooSmallException12.getSuppressed();
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) bigInteger2, (java.lang.Object[]) throwableArray13);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 145539071768L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-48), Double.NaN, (-1.5574077246549023d), (double) 5.9604645E-8f, 4.26345500297896E58d, 6.488801459162743E9d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        java.lang.Number number6 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number6, (int) (short) 0, orderDirection8, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection8, false);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) 100.0f, objArray24);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray24);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext27 = mathArithmeticException26.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException32 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, 145, (int) 'a');
        java.lang.Throwable[] throwableArray33 = dimensionMismatchException32.getSuppressed();
        exceptionContext27.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats28, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException12, (org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException36 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.8390387292223656d), (java.lang.Object[]) throwableArray33);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext37 = maxCountExceededException36.getContext();
        java.lang.Number number38 = maxCountExceededException36.getMax();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = null;
        double[] doubleArray47 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray53 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray54 = new double[][] { doubleArray47, doubleArray53 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, orderDirection41, doubleArray54);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, (int) (short) 100);
        double[] doubleArray58 = new double[] {};
        double[] doubleArray61 = new double[] { 100.0d, (-1.0f) };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray58, doubleArray61);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray61);
        double[] doubleArray64 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = null;
        double[] doubleArray71 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray77 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray78 = new double[][] { doubleArray71, doubleArray77 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray64, orderDirection65, doubleArray78);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray81 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection82 = null;
        double[] doubleArray88 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray94 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray95 = new double[][] { doubleArray88, doubleArray94 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray81, orderDirection82, doubleArray95);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray64, orderDirection80, doubleArray95);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray40, doubleArray95);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException99 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException36, (org.apache.commons.math.exception.util.Localizable) localizedFormats39, (java.lang.Object[]) doubleArray95);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0f + "'", number13.equals(0.0f));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(exceptionContext27);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(exceptionContext37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (-0.8390387292223656d) + "'", number38.equals((-0.8390387292223656d)));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray21 = new double[] { 100.0d, (-1.0f) };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double[] doubleArray25 = new double[] { (-4.5035996E15f) };
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean29 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection26, false, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray25);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 214322.12823951655d);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1202215227 + "'", int34 == 1202215227);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        int int2 = org.apache.commons.math.util.MathUtils.pow(97, (long) 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1098724673 + "'", int2 == 1098724673);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException1 = new org.apache.commons.math.exception.MathIllegalStateException();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 100.0f, objArray12);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathArithmeticException14.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException20 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, 145, (int) 'a');
        java.lang.Throwable[] throwableArray21 = dimensionMismatchException20.getSuppressed();
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) mathIllegalStateException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException24 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray21);
        java.lang.String str25 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "internal error, please fill a bug report at {0}" + "'", str25.equals("internal error, please fill a bug report at {0}"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        double double2 = org.apache.commons.math.util.FastMath.max(1.3877787807814457E-17d, 90.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.0d + "'", double2 == 90.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        double double1 = org.apache.commons.math.util.FastMath.atan((-7.62364218539641d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4403700558013304d) + "'", double1 == (-1.4403700558013304d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(561559L, (-808182895L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 453842378333305L + "'", long2 == 453842378333305L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray21 = new double[] { 100.0d, (-1.0f) };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = null;
        double[] doubleArray30 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray36 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray37 = new double[][] { doubleArray30, doubleArray36 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray23, orderDirection24, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray23);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray23);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1.1752011936438014d), 0.9999999999998863d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(9.042354332119482d, (double) 1.0f, (double) 30);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-1L), 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.64376061222056256E17d), (double) 7.6293945E-6f, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-80.0f), 1.3877787807814457E-17d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        int int3 = regulaFalsiSolver0.getEvaluations();
        double double4 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver0.solve(1694013537, univariateRealFunction6, (-3628800.5876005967d), (double) 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3628800L, (java.lang.Number) 1.0d, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException4.getContext();
        java.lang.Number number9 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number9, (int) (short) 0, orderDirection11, true);
        java.lang.Number number14 = nonMonotonousSequenceException13.getPrevious();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        exceptionContext6.setValue("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", (java.lang.Object) boolean15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) 100.0f, objArray29);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 572.9577951308232d, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray29);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Number) 135.00002f, (java.lang.Number) 145.0d, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException41 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, 145, (int) 'a');
        java.lang.Throwable[] throwableArray42 = dimensionMismatchException41.getSuppressed();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 135.00002f, (org.apache.commons.math.exception.util.Localizable) localizedFormats37, (java.lang.Object[]) throwableArray42);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats18, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Object[]) throwableArray42);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException59 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats50, (java.lang.Number) 100.0f, objArray58);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException60 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats49, objArray58);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext61 = mathArithmeticException60.getContext();
        java.lang.Object obj63 = exceptionContext61.getValue("");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats66 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats67 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats69 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray80 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException81 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats72, (java.lang.Number) 100.0f, objArray80);
        java.lang.Object[] objArray83 = new java.lang.Object[] { localizedFormats69, localizedFormats70, (short) -1, localizedFormats72, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException84 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats67, (java.lang.Number) 100.0f, objArray83);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException85 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats66, objArray83);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext86 = mathArithmeticException85.getContext();
        java.lang.String str87 = mathArithmeticException85.toString();
        java.lang.Throwable[] throwableArray88 = mathArithmeticException85.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats65, (java.lang.Object[]) throwableArray88);
        exceptionContext61.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats64, (java.lang.Object[]) throwableArray88);
        org.apache.commons.math.exception.NoBracketingException noBracketingException91 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, 15930.000000000002d, (double) 5, 0.0d, (-8.600387595703641E8d), (java.lang.Object[]) throwableArray88);
        exceptionContext6.addMessage(localizable17, (java.lang.Object[]) throwableArray88);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(exceptionContext61);
        org.junit.Assert.assertNull(obj63);
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats64.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats66.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats67.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats69.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats70.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats72.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(exceptionContext86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31" + "'", str87.equals("org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31"));
        org.junit.Assert.assertNotNull(throwableArray88);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(7.52574989159953d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7433100246963575d + "'", double1 == 2.7433100246963575d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray16 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, 0);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, (int) (byte) 0);
        int[] intArray26 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray31 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray31);
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, (int) (byte) 1);
        int[] intArray42 = new int[] { 7, 0, (short) 10, 'a', 10, 'a' };
        int[] intArray43 = org.apache.commons.math.util.MathUtils.copyOf(intArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray42);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray33);
        try {
            int[] intArray47 = org.apache.commons.math.util.MathUtils.copyOf(intArray33, (-135));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 135 + "'", int17 == 135);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 145 + "'", int32 == 145);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 106.0801583709225d + "'", double44 == 106.0801583709225d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-27L), (-148335));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-148,335)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 108816201, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.7581226324091723d, (double) 350L, 572.9577951308232d);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        double double5 = regulaFalsiSolver3.getMin();
        int int6 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 350.0d + "'", double4 == 350.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number7, (int) (short) 0, orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.648740696524143d, (java.lang.Number) 6, (int) (short) 100, orderDirection9, true);
        boolean boolean16 = nonMonotonousSequenceException15.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException15.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-5.7982058E11f), (java.lang.Number) 1.0329816652440604d, false);
        java.lang.Class<?> wildcardClass4 = numberIsTooLargeException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.9848077501218763d, (-1.57d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9848077501218763d) + "'", double2 == (-0.9848077501218763d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        double double2 = org.apache.commons.math.util.FastMath.copySign((-0.9033391107665127d), (-6.4708378242902675d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9033391107665127d) + "'", double2 == (-0.9033391107665127d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 30);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.4553908567243008E12d, (double) (-0.99999994f));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 90, (-617220L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray21 = new double[] { 100.0d, (-1.0f) };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        double[] doubleArray31 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray37 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray38 = new double[][] { doubleArray31, doubleArray37 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, orderDirection25, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, (int) (short) 100);
        double[] doubleArray42 = new double[] {};
        double[] doubleArray45 = new double[] { 100.0d, (-1.0f) };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray45);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.00499987500625d + "'", double48 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        int[] intArray6 = new int[] { 7, 0, (short) 10, 'a', 10, 'a' };
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray12 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray17 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray17);
        int[] intArray24 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray24, 0);
        int[] intArray32 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray37 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray37);
        int[] intArray39 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray32);
        int[] intArray45 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray50 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray50);
        int[] intArray57 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray57);
        int[] intArray60 = org.apache.commons.math.util.MathUtils.copyOf(intArray57, 0);
        int[] intArray65 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray70 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray70);
        int[] intArray72 = org.apache.commons.math.util.MathUtils.copyOf(intArray65);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray65);
        int[] intArray74 = org.apache.commons.math.util.MathUtils.copyOf(intArray65);
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray65);
        int[] intArray77 = org.apache.commons.math.util.MathUtils.copyOf(intArray32, 97);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray77);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 145 + "'", int18 == 145);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 135 + "'", int25 == 135);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 145 + "'", int38 == 145);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 145 + "'", int51 == 145);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 135 + "'", int58 == 135);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 145 + "'", int71 == 145);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 98 + "'", int78 == 98);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(1.0795253785856714E9d, (double) 350L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 78.58567142486572d + "'", double2 == 78.58567142486572d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(3.7581226324091723d, (double) 350L, 572.9577951308232d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double9 = regulaFalsiSolver3.solve((int) (byte) -1, univariateRealFunction5, (double) (short) 10, (double) 98, (double) 35L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4E-45f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(9.629649721936179E-35d, 573.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats4, localizedFormats5, 0L, (short) -1, 3, localizedFormats9 };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException11 = new org.apache.commons.math.exception.NullArgumentException(localizable3, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray10);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = mathIllegalStateException12.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(exceptionContext13);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.923458286012058E41d + "'", double1 == 4.923458286012058E41d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0000002f + "'", float1 == 2.0000002f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-17144.998f), (double) 1.5258789E-5f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-17144.998046875d) + "'", double2 == (-17144.998046875d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 4.6116860184273879E18d, (double) (-17145L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(143);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number7, (int) (short) 0, orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection9, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0f, (java.lang.Number) 104.99761904761903d, 651510, orderDirection14, true);
        boolean boolean17 = nonMonotonousSequenceException16.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 78125, (float) 1078067199L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 78125.0f + "'", float2 == 78125.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-48), (float) 5040L, (float) 6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 17145L, (float) 720);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        double double3 = regulaFalsiSolver0.getRelativeAccuracy();
        double double4 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double5 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-6d + "'", double4 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double8 = regulaFalsiSolver2.solve(17145, univariateRealFunction6, 2.5876124932152237E44d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((-1.2664126E30f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.2664125E30f) + "'", float1 == (-1.2664125E30f));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        double[] doubleArray4 = new double[] { (-4.5035996E15f) };
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean8 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection5, false, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 306.3666941127301d, (java.lang.Number) 1.570794504106066d, 548640, orderDirection5, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 306.3666941127301d + "'", number11.equals(306.3666941127301d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 306.3666941127301d + "'", number12.equals(306.3666941127301d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        double double1 = org.apache.commons.math.util.FastMath.ceil(6.691673596021443E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021443E41d + "'", double1 == 6.691673596021443E41d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((-1));
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount(1694013537);
        incrementor0.incrementCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        double double1 = org.apache.commons.math.util.FastMath.log(2.009724813202227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6979978038434983d + "'", double1 == 0.6979978038434983d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-1023), 69.99996852874756d, 804.247719318987d, 1.4210854715202004E-14d, (double) 145.0f, (double) 1081466880, 4.592018220781603E81d, (double) 145.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.658426420133325E83d + "'", double8 == 6.658426420133325E83d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        double double1 = org.apache.commons.math.util.FastMath.sin(9.184036441563206E81d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013587182768352685d + "'", double1 == 0.013587182768352685d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray21 = new double[] { 100.0d, (-1.0f) };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray21);
        double[] doubleArray26 = new double[] {};
        double[] doubleArray29 = new double[] { 100.0d, (-1.0f) };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray29);
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = null;
        double[] doubleArray38 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray44 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray45 = new double[][] { doubleArray38, doubleArray44 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray31, orderDirection32, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray31);
        try {
            double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.00499987500625d + "'", double24 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 15930.000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 15930.000000000002d + "'", double2 == 15930.000000000002d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(214322.12823951655d, (double) 145539071768L, (double) 3.552714E-14f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1607139329), (-48));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = -48, n = -1,607,139,329");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 101L, 1.0f, 10.0f, 101L };
        java.lang.Object[] objArray10 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray9);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException13 = new org.apache.commons.math.exception.MaxCountExceededException(localizable1, (java.lang.Number) (byte) 10, objArray9);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        java.lang.Object[] objArray15 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number1, (int) (short) 0, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.MathInternalError mathInternalError7 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.apache.commons.math.exception.MathInternalError mathInternalError8 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) nonMonotonousSequenceException5);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.461729143006029E41d, (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int[] intArray16 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray21 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray21);
        int[] intArray28 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray28);
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray28, 0);
        int[] intArray36 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray41 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray41);
        int[] intArray43 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray36);
        int[] intArray45 = org.apache.commons.math.util.MathUtils.copyOf(intArray36);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray36);
        int[] intArray51 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray56 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray56);
        int[] intArray63 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray63);
        int[] intArray66 = org.apache.commons.math.util.MathUtils.copyOf(intArray63, 0);
        int[] intArray68 = org.apache.commons.math.util.MathUtils.copyOf(intArray66, (int) (byte) 0);
        int[] intArray69 = org.apache.commons.math.util.MathUtils.copyOf(intArray68);
        try {
            int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray36, intArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 145 + "'", int22 == 145);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 135 + "'", int29 == 135);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 145 + "'", int42 == 145);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 145 + "'", int57 == 145);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 135 + "'", int64 == 135);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray69);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getMaxEvaluations();
        int int5 = regulaFalsiSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 145, (int) 'a');
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = dimensionMismatchException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        java.util.Set<java.lang.String> strSet6 = exceptionContext4.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 548642.0f, 0.0d, (double) (-135));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.2070583763897011E21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07288848500453873d) + "'", double1 == (-0.07288848500453873d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getEvaluations();
        int int5 = regulaFalsiSolver2.getMaxEvaluations();
        double double6 = regulaFalsiSolver2.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        try {
            double double10 = regulaFalsiSolver2.solve(0, univariateRealFunction8, 0.004931288061015948d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 101L, 1.0f, 10.0f, 101L };
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (-2989.6366929140413d), (double) 100.0f, 95.85927185202274d, 35.0d, objArray16);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray16);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 20L, objArray16);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException(throwable2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray16);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, localizable1, objArray16);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        int int2 = org.apache.commons.math.util.FastMath.max(102300, (-1607139329));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 102300 + "'", int2 == 102300);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1202215227, (-148335));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-148,335)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) -1, (double) (-1.2664126E30f), 548642);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 100);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 100);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 1);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.00001f, (java.lang.Number) bigInteger3, true);
        java.lang.Number number16 = numberIsTooSmallException15.getMin();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(number16);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 78125);
        int[] intArray17 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray22 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray22);
        int[] intArray29 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray29);
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray29, 0);
        int[] intArray37 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray42 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray42);
        int[] intArray44 = org.apache.commons.math.util.MathUtils.copyOf(intArray37);
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray37);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray37);
        int[] intArray48 = org.apache.commons.math.util.MathUtils.copyOf(intArray37, (int) '#');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 145 + "'", int23 == 145);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 135 + "'", int30 == 135);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 145 + "'", int43 == 145);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 95.85927185202274d + "'", double46 == 95.85927185202274d);
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 145, (int) 'a');
        int int4 = dimensionMismatchException3.getDimension();
        org.apache.commons.math.exception.MathInternalError mathInternalError5 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) dimensionMismatchException3);
        int int6 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 3.36999333339383E66d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 100.0f, objArray17);
        java.lang.Object[] objArray20 = new java.lang.Object[] { localizedFormats6, localizedFormats7, (short) -1, localizedFormats9, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 100.0f, objArray20);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException22 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray20);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext23 = mathArithmeticException22.getContext();
        java.lang.Object obj25 = exceptionContext23.getValue("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        double[] doubleArray27 = new double[] {};
        double[] doubleArray30 = new double[] { 100.0d, (-1.0f) };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray30);
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        double[] doubleArray39 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray45 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray46 = new double[][] { doubleArray39, doubleArray45 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray32, orderDirection33, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray32);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        java.lang.Number number56 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException60 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number56, (int) (short) 0, orderDirection58, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) (short) -1, (-1023), orderDirection58, false);
        double[] doubleArray69 = new double[] { 0.9999999958776927d, 3.7581226324091723d, (short) 100, 0.8623188722876839d, (byte) 1, 6.994405055138486E-14d };
        double[] doubleArray76 = new double[] { 0.9999999958776927d, 3.7581226324091723d, (short) 100, 0.8623188722876839d, (byte) 1, 6.994405055138486E-14d };
        double[][] doubleArray77 = new double[][] { doubleArray69, doubleArray76 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray32, orderDirection58, doubleArray77);
        double[] doubleArray79 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = null;
        double[] doubleArray86 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray92 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray93 = new double[][] { doubleArray86, doubleArray92 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray79, orderDirection80, doubleArray93);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray27, orderDirection58, doubleArray93);
        exceptionContext23.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) doubleArray93);
        java.lang.Object[] objArray97 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) doubleArray93);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats1, localizable2, (java.lang.Object[]) doubleArray93);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray93);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(exceptionContext23);
        org.junit.Assert.assertNull(obj25);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(objArray97);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 36, (java.lang.Number) 97.00001f, false);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, objArray14);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext17 = mathArithmeticException16.getContext();
        java.lang.Object obj19 = exceptionContext17.getValue("");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, (java.lang.Number) 100.0f, objArray36);
        java.lang.Object[] objArray39 = new java.lang.Object[] { localizedFormats25, localizedFormats26, (short) -1, localizedFormats28, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException40 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, (java.lang.Number) 100.0f, objArray39);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException41 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray39);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext42 = mathArithmeticException41.getContext();
        java.lang.String str43 = mathArithmeticException41.toString();
        java.lang.Throwable[] throwableArray44 = mathArithmeticException41.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) throwableArray44);
        exceptionContext17.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException47 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) throwableArray44);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertNull(obj19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(exceptionContext42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31" + "'", str43.equals("org.apache.commons.math.exception.MathArithmeticException: overflow: gcd(NAN_VALUE_CONVERSION, INVALID_BINARY_DIGIT) is 2^31"));
        org.junit.Assert.assertNotNull(throwableArray44);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray0);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray22 = new double[] { 100.0d, (-1.0f) };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray22);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        double[] doubleArray31 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray37 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray38 = new double[][] { doubleArray31, doubleArray37 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, orderDirection25, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray24);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray46 = new double[] { 100.0d, (-1.0f) };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray43);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray43);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray43);
        java.lang.Number number55 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException59 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number55, (int) (short) 0, orderDirection57, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException61 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection57, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection57, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        double double1 = org.apache.commons.math.util.FastMath.cosh(28.64788975654116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3822622382423977E12d + "'", double1 == 1.3822622382423977E12d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 13500L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9052075436677391d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8127326642860244d + "'", double1 == 0.8127326642860244d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (double) (-134.99998f), (double) 0.0f, 14.299885424508982d, 0.3796077390275217d, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        double[] doubleArray25 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray31 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray31 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray18, orderDirection19, doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = null;
        double[] doubleArray42 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray48 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray49 = new double[][] { doubleArray42, doubleArray48 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray35, orderDirection36, doubleArray49);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray18, orderDirection34, doubleArray49);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18, (int) (short) 100);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray53);
        double[] doubleArray56 = null;
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (byte) 1);
        try {
            double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (-1.4920006428759518d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.NaN);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 145L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.390741286647697E62d + "'", double1 == 9.390741286647697E62d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 145, (int) 'a');
        int int4 = dimensionMismatchException3.getDimension();
        org.apache.commons.math.exception.MathInternalError mathInternalError5 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) dimensionMismatchException3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 3628800L, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = null;
        double[] doubleArray19 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray25 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray26 = new double[][] { doubleArray19, doubleArray25 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, orderDirection13, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = null;
        double[] doubleArray36 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray42 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray43 = new double[][] { doubleArray36, doubleArray42 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray29, orderDirection30, doubleArray43);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, orderDirection28, doubleArray43);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException46 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) doubleArray43);
        java.lang.Throwable[] throwableArray47 = mathArithmeticException46.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray47);
        dimensionMismatchException3.addSuppressed((java.lang.Throwable) mathIllegalArgumentException48);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext50 = dimensionMismatchException3.getContext();
        java.util.Set<java.lang.String> strSet51 = exceptionContext50.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(exceptionContext50);
        org.junit.Assert.assertNotNull(strSet51);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 78125L, (double) (-808182895));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.08182895E8d) + "'", double2 == (-8.08182895E8d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.0d, (double) 548640);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) (short) 100);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 100);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger10);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 101L, 1.0f, 10.0f, 101L };
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) bigInteger10, objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1.1024384E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-135), 1694013537);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,694,013,537, n = -135");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (byte) 1, 98);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.1691265E29f + "'", float2 == 3.1691265E29f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int3 = regulaFalsiSolver2.getEvaluations();
        int int4 = regulaFalsiSolver2.getMaxEvaluations();
        double double5 = regulaFalsiSolver2.getMin();
        double double6 = regulaFalsiSolver2.getRelativeAccuracy();
        double double7 = regulaFalsiSolver2.getFunctionValueAccuracy();
        int int8 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution12 = null;
        try {
            double double13 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 0.0d, (double) (-808182895), (double) 135, allowedSolution12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-14d + "'", double6 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-15d + "'", double7 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        double double2 = org.apache.commons.math.util.FastMath.copySign(2.4917798526449118d, (-1.401298464324817E-45d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.4917798526449118d) + "'", double2 == (-2.4917798526449118d));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        double[] doubleArray4 = new double[] { (-4.5035996E15f) };
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        boolean boolean8 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection5, false, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9, (java.lang.Number) 0.0f, 1098724673, orderDirection5, false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (-1.401298464324817E-45d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 108816201);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 26 + "'", int1 == 26);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        double[] doubleArray26 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray32 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray33 = new double[][] { doubleArray26, doubleArray32 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray19, orderDirection20, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19, (int) (short) 100);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray19);
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, 3);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray40, 143);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 720.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.579251212010101d + "'", double1 == 6.579251212010101d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, objArray9);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = mathArithmeticException11.getContext();
        java.util.Set<java.lang.String> strSet13 = exceptionContext12.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 101L, 1.0f, 10.0f, 101L };
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray27);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (-2989.6366929140413d), (double) 100.0f, 95.85927185202274d, 35.0d, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray27);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException31 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 20L, objArray27);
        exceptionContext12.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double3 = regulaFalsiSolver2.getRelativeAccuracy();
        int int4 = regulaFalsiSolver2.getEvaluations();
        double double5 = regulaFalsiSolver2.getStartValue();
        int int6 = regulaFalsiSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.2255938657968326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(0.06595303770555495d, 0.013587182768352685d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0.066, 0.014]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(6.658426420133325E83d, 0.23144338144734428d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [665,842,642,013,332,500,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000, 0.231]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 3628800L, 0.0d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double9 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(36, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, 572.9577951308232d, 17.5d, (double) (byte) 1, allowedSolution8);
        int int10 = regulaFalsiSolver4.getMaxEvaluations();
        double double11 = regulaFalsiSolver4.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction13 = null;
        try {
            double double17 = regulaFalsiSolver4.solve((int) (byte) 100, univariateRealFunction13, (double) 1174405120, (-17144.998046875d), 106.0801583709225d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 572.9577951308232d + "'", double9 == 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.340456340784037d, 3.3893909511247697d);
        double double3 = regulaFalsiSolver2.getMax();
        double double4 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-15d + "'", double4 == 1.0E-15d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 548642);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-80.0f), 0.0d, (-135));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        double double2 = org.apache.commons.math.util.FastMath.copySign(5.267831587699267d, 392.5258645624386d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.267831587699267d + "'", double2 == 5.267831587699267d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(101);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        double double5 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double6 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double7 = regulaFalsiSolver0.getMin();
        double double8 = regulaFalsiSolver0.getStartValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-15d + "'", double5 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-15d + "'", double6 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.0d, (double) 41L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) (-4.5035996E15f), 0.8567319198553678d, (double) 2147483647);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) '#', (double) 100);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(143, univariateRealFunction5, 2.2250738585072014E-308d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 145, (int) 'a');
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) (short) 100);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) (short) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (short) 100);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger16);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 3, (java.lang.Number) bigInteger19, false);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 3);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 40500L, (java.lang.Number) 3, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext26 = numberIsTooLargeException25.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(exceptionContext26);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver14 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 3628800L, 0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction19 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver22 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 3628800L, 0.0d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution26 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double27 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(36, univariateRealFunction19, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver22, 572.9577951308232d, 17.5d, (double) (byte) 1, allowedSolution26);
        double double28 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(135, univariateRealFunction11, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver14, (double) 41L, 133.6804062609211d, (double) 7.2769536E10f, allowedSolution26);
        try {
            double double29 = regulaFalsiSolver0.solve((-48), univariateRealFunction6, 6.994405055138486E-14d, (-1787.4856780636228d), 38006.190943898575d, allowedSolution26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + allowedSolution26 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution26.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 572.9577951308232d + "'", double27 == 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 41.0d + "'", double28 == 41.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-808182895L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1079525377L, 0, (-2));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -2, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 110837787060L, (float) 41L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 41.0f + "'", float2 == 41.0f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1L), 97.0d, (double) '4', 0.0d);
        double double5 = noBracketingException4.getHi();
        double double6 = noBracketingException4.getFHi();
        double double7 = noBracketingException4.getFLo();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = noBracketingException4.getContext();
        java.util.Set<java.lang.String> strSet9 = exceptionContext8.getKeys();
        java.lang.Object obj11 = exceptionContext8.getValue("invalid exponent {0} (must be positive)");
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 97.0d + "'", double5 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number1, (int) (short) 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-1023));
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        java.lang.String str3 = maxCountExceededException1.toString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 101L, 1.0f, 10.0f, 101L };
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 3L, objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) maxCountExceededException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray12);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (-1,023) exceeded" + "'", str3.equals("org.apache.commons.math.exception.MaxCountExceededException: illegal state: maximal count (-1,023) exceeded"));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) '4', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 2.99822295029797d, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (double) 0.5f, 52.0d, (-0.9033391107665127d), 4.0d, 0.3358423725664079d, (double) 145539071858L, 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 5.746097968073778E24d + "'", double8 == 5.746097968073778E24d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        float float2 = org.apache.commons.math.util.FastMath.copySign(9.536743E-7f, (float) 101);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.536743E-7f + "'", float2 == 9.536743E-7f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        float float2 = org.apache.commons.math.util.FastMath.max(3.0f, 420.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 420.0f + "'", float2 == 420.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 100.00001f, (-0.5745225696183645d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5309572854788485d) + "'", double2 == (-0.5309572854788485d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8127326642860244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8127326642860244d + "'", double1 == 0.8127326642860244d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1.5258789E-5f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707810680058336d + "'", double1 == 1.5707810680058336d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray18);
        java.lang.Number number24 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number24, (int) (short) 0, orderDirection26, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.3893909511247697d, (java.lang.Number) 10.0f, 6, orderDirection26, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection26, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        incrementor0.setMaximalCount(1);
        incrementor0.incrementCount(0);
        incrementor0.setMaximalCount(2147483647);
        incrementor0.incrementCount();
        int int9 = incrementor0.getMaximalCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 135, (double) (-1078976735));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        double[] doubleArray15 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray21 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray22 = new double[][] { doubleArray15, doubleArray21 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray8, orderDirection9, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = null;
        double[] doubleArray32 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray38 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray39 = new double[][] { doubleArray32, doubleArray38 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, orderDirection26, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray25, (int) (short) 100);
        double[] doubleArray43 = new double[] {};
        double[] doubleArray46 = new double[] { 100.0d, (-1.0f) };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray46);
        double[] doubleArray49 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = null;
        double[] doubleArray56 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray62 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray63 = new double[][] { doubleArray56, doubleArray62 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray49, orderDirection50, doubleArray63);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = null;
        double[] doubleArray73 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray79 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray80 = new double[][] { doubleArray73, doubleArray79 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray66, orderDirection67, doubleArray80);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray49, orderDirection65, doubleArray80);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, doubleArray80);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray8, doubleArray80);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException85 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) doubleArray80);
        org.apache.commons.math.exception.NoBracketingException noBracketingException86 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 573.0d, 3.355443242632568E7d, 6.488801459162743E9d, 1.5707963098836446d, (java.lang.Object[]) doubleArray80);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) doubleArray80);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray80);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + orderDirection65 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection65.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 1.0E-14d, 2147483647);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (long) 1098724673);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1140688799) + "'", int2 == (-1140688799));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.1368683772161603E-13d, (java.lang.Number) 1.4210854715202004E-14d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        long long2 = org.apache.commons.math.util.MathUtils.pow(36L, 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 60466176L + "'", long2 == 60466176L);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-1023));
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        java.lang.Number number8 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number8, (int) (short) 0, orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection10, false);
        java.lang.Number number15 = nonMonotonousSequenceException14.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) 100.0f, objArray26);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException28 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray26);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext29 = mathArithmeticException28.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException34 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, 145, (int) 'a');
        java.lang.Throwable[] throwableArray35 = dimensionMismatchException34.getSuppressed();
        exceptionContext29.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException14, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) maxCountExceededException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext39 = maxCountExceededException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0f + "'", number15.equals(0.0f));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(exceptionContext29);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(exceptionContext39);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(6, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 100.0d, (-1.0f) };
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray3);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        double[] doubleArray12 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray18 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection6, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray27 = new double[] { 100.0d, (-1.0f) };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 720);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 100.0d, (-1.0f) };
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray3);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        double[] doubleArray12 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray18 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection6, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray27 = new double[] { 100.0d, (-1.0f) };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) (byte) 100);
        double[] doubleArray32 = new double[] {};
        double[] doubleArray35 = new double[] { 100.0d, (-1.0f) };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray35);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = null;
        double[] doubleArray44 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray50 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray51 = new double[][] { doubleArray44, doubleArray50 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray37, orderDirection38, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray37);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        try {
            double double57 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray31, doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.004931288061015948d, (double) 143, (double) 1079525377, (double) 135.00002f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5706217938714695d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 90);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 90.0f + "'", float1 == 90.0f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 3628800L, 0.0d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double9 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(36, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, 572.9577951308232d, 17.5d, (double) (byte) 1, allowedSolution8);
        int int10 = regulaFalsiSolver4.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction12 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution15 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double16 = regulaFalsiSolver4.solve(720, univariateRealFunction12, 0.0d, 2.009724813202227d, allowedSolution15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 572.9577951308232d + "'", double9 == 572.9577951308232d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution15 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution15.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 36.000008f, (int) (short) -1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 26, (long) (-1140688799));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 26L + "'", long2 == 26L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d, 6.283185307179586d);
        double double3 = regulaFalsiSolver2.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((-166718472), univariateRealFunction5, (double) 145.0f, (-1.4920006428759518d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 3628800L, (double) (byte) 0);
        double double3 = regulaFalsiSolver2.getMin();
        double double4 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        float[] floatArray1 = new float[] { 0.0f };
        float[] floatArray5 = new float[] { (short) 0, 'a', 10L };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(floatArray1, floatArray5);
        float[] floatArray7 = new float[] {};
        float[] floatArray9 = new float[] { 0.0f };
        float[] floatArray13 = new float[] { (short) 0, 'a', 10L };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(floatArray9, floatArray13);
        float[] floatArray16 = new float[] { 0.0f };
        float[] floatArray20 = new float[] { (short) 0, 'a', 10L };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(floatArray16, floatArray20);
        float[] floatArray23 = new float[] { 0.0f };
        float[] floatArray27 = new float[] { (short) 0, 'a', 10L };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(floatArray23, floatArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray16, floatArray27);
        float[] floatArray31 = new float[] { 0.0f };
        float[] floatArray35 = new float[] { (short) 0, 'a', 10L };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(floatArray31, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray27, floatArray31);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(floatArray13, floatArray31);
        float[] floatArray42 = new float[] { 10.0f, 4.7683716E-7f, (-27L) };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray31, floatArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray42);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray1, floatArray42);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 7.150985421276864E54d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        double double1 = org.apache.commons.math.util.FastMath.log((-2.5663706143591725d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1.5430806348152435d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        double double1 = org.apache.commons.math.util.FastMath.expm1(306.3666941127301d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1307450418374475E133d + "'", double1 == 1.1307450418374475E133d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(9, (-143));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 7.629395E-6f, (double) 100.0f, 1.0049949995625378E195d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.014424392198779E-42d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (-143));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-17145L), (double) Float.NEGATIVE_INFINITY);
        double double3 = regulaFalsiSolver2.getMin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(114898.22225041104d, 20.41402394624231d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) (-1140688799));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 78125);
        int[] intArray17 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray22 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray22);
        int[] intArray29 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray29);
        int[] intArray35 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray40 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray22);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 145 + "'", int23 == 145);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 135 + "'", int30 == 135);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 145 + "'", int41 == 145);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 95.85927185202274d + "'", double42 == 95.85927185202274d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-7806.609597845923d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray21 = new double[] { 100.0d, (-1.0f) };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray21);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = null;
        double[] doubleArray33 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray39 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray40 = new double[][] { doubleArray33, doubleArray39 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray26, orderDirection27, doubleArray40);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = null;
        double[] doubleArray50 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray56 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray57 = new double[][] { doubleArray50, doubleArray56 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray43, orderDirection44, doubleArray57);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray26, orderDirection42, doubleArray57);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray26, (int) (short) 100);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray61);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.00499987500625d + "'", double24 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.00499987500625d + "'", double25 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 100.00499987500625d + "'", double64 == 100.00499987500625d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 4.7683716E-7f, (double) 9.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.76837158203125E-7d + "'", double2 == 4.76837158203125E-7d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3628800L, (java.lang.Number) 1.0d, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException4.getContext();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = null;
        double[] doubleArray16 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray22 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray23 = new double[][] { doubleArray16, doubleArray22 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray9, orderDirection10, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray9, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray9);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        java.lang.Number number33 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number33, (int) (short) 0, orderDirection35, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 0, (java.lang.Number) (short) -1, (-1023), orderDirection35, false);
        double[] doubleArray46 = new double[] { 0.9999999958776927d, 3.7581226324091723d, (short) 100, 0.8623188722876839d, (byte) 1, 6.994405055138486E-14d };
        double[] doubleArray53 = new double[] { 0.9999999958776927d, 3.7581226324091723d, (short) 100, 0.8623188722876839d, (byte) 1, 6.994405055138486E-14d };
        double[][] doubleArray54 = new double[][] { doubleArray46, doubleArray53 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray9, orderDirection35, doubleArray54);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException56 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 78125, (java.lang.Object[]) doubleArray54);
        exceptionContext6.addMessage(localizable7, (java.lang.Object[]) doubleArray54);
        java.lang.Object obj59 = exceptionContext6.getValue("permutation k ({0}) must be positive");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNull(obj59);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 100.0f, objArray11);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 572.9577951308232d, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 135.00002f, (java.lang.Number) 145.0d, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException23 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, 145, (int) 'a');
        java.lang.Throwable[] throwableArray24 = dimensionMismatchException23.getSuppressed();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 135.00002f, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 7235.910447264d, (java.lang.Number) (-1.1752011936438014d), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(35.0d, (double) (-135), 35.00000000000001d, 0.0d);
        double double5 = noBracketingException4.getFHi();
        double double6 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-135.0d) + "'", double6 == (-135.0d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.8567319198553678d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 135, (float) 110837787060L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 143.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4958208303518914d + "'", double1 == 2.4958208303518914d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        float[] floatArray0 = new float[] {};
        float[] floatArray2 = new float[] { 0.0f };
        float[] floatArray6 = new float[] { (short) 0, 'a', 10L };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(floatArray2, floatArray6);
        float[] floatArray9 = new float[] { 0.0f };
        float[] floatArray13 = new float[] { (short) 0, 'a', 10L };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(floatArray9, floatArray13);
        float[] floatArray16 = new float[] { 0.0f };
        float[] floatArray20 = new float[] { (short) 0, 'a', 10L };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(floatArray16, floatArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray9, floatArray20);
        float[] floatArray24 = new float[] { 0.0f };
        float[] floatArray28 = new float[] { (short) 0, 'a', 10L };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray20, floatArray24);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(floatArray6, floatArray24);
        float[] floatArray35 = new float[] { 10.0f, 4.7683716E-7f, (-27L) };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray24, floatArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray35);
        float[] floatArray39 = new float[] { 0.0f };
        float[] floatArray43 = new float[] { (short) 0, 'a', 10L };
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(floatArray39, floatArray43);
        float[] floatArray46 = new float[] { 0.0f };
        float[] floatArray50 = new float[] { (short) 0, 'a', 10L };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(floatArray46, floatArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray39, floatArray50);
        float[] floatArray54 = new float[] { 0.0f };
        float[] floatArray58 = new float[] { (short) 0, 'a', 10L };
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(floatArray54, floatArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray50, floatArray54);
        float[] floatArray62 = new float[] { 0.0f };
        float[] floatArray66 = new float[] { (short) 0, 'a', 10L };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(floatArray62, floatArray66);
        float[] floatArray69 = new float[] { 0.0f };
        float[] floatArray73 = new float[] { (short) 0, 'a', 10L };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(floatArray69, floatArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray62, floatArray73);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray50, floatArray73);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray50);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(floatArray62);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(floatArray69);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        double double3 = regulaFalsiSolver0.getMin();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        double double5 = regulaFalsiSolver0.getFunctionValueAccuracy();
        int int6 = regulaFalsiSolver0.getMaxEvaluations();
        double double7 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-15d + "'", double5 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-6d + "'", double7 == 1.0E-6d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 98, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.2414508546761014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9257413597468074d + "'", double1 == 2.9257413597468074d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 10, (double) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, 6.5940659E8f, 0.00390625f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((-0.07288848500453873d));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(133.6804062609211d, 1.000000000000028d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(6, univariateRealFunction4, (-1.4155594961262613E11d), (-7.62364218539641d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 145539071868L, (float) 90, 1079525377);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.7071067811865476d, 21863.465794806718d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 100.0d, (-1.0f) };
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray3);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        double[] doubleArray12 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray18 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection6, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray24 = new double[] {};
        double[] doubleArray27 = new double[] { 100.0d, (-1.0f) };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray24);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray5, (int) (byte) 100);
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        double[] doubleArray39 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray45 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray46 = new double[][] { doubleArray39, doubleArray45 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray32, orderDirection33, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32, (int) (short) 100);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection52, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 100.0d, (-1.0f) };
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray3);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        double[] doubleArray12 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray18 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection6, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = null;
        double[] doubleArray31 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray37 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray38 = new double[][] { doubleArray31, doubleArray37 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray24, orderDirection25, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, (int) (short) 100);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray3 = new double[] { 100.0d, (-1.0f) };
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray3);
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = null;
        double[] doubleArray12 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray18 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray19 = new double[][] { doubleArray12, doubleArray18 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray5, orderDirection6, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray25 = new double[] {};
        double[] doubleArray28 = new double[] { 100.0d, (-1.0f) };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray28);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = null;
        double[] doubleArray37 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray43 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray44 = new double[][] { doubleArray37, doubleArray43 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray30, orderDirection31, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray30);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray49 = new double[] {};
        double[] doubleArray52 = new double[] { 100.0d, (-1.0f) };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray49);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray49);
        double[] doubleArray56 = null;
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 110837787060L, (float) 90, 29);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(78125, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.085536923187668d + "'", double1 == 20.085536923187668d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        double double2 = org.apache.commons.math.util.FastMath.min(190.0752260525949d, (-126.99999237060547d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-126.99999237060547d) + "'", double2 == (-126.99999237060547d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        double double1 = org.apache.commons.math.util.FastMath.abs(78.58567142486572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 78.58567142486572d + "'", double1 == 78.58567142486572d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.8343417564827366E82d, 4.6116860184273879E18d, (-8.08182895E8d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 21, (java.lang.Number) 10.000001f, 135);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 135 + "'", int4 == 135);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.000001f + "'", number5.equals(10.000001f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.000001f + "'", number6.equals(10.000001f));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        java.lang.Object[] objArray1 = null;
        java.lang.Object[] objArray2 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray1);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException3 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 3.670016E8f, (double) (-1.0f), 0.7071067811865476d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-148335), 311.9264291075885d, 1.291281104044386E11d, 0.0d, 4.644483341943245d, 2.8421709430404007E-14d, 2.2009563282167764E-15d, 4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-4.626960686167414E7d) + "'", double8 == (-4.626960686167414E7d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) bigInteger2);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 3);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) bigInteger2, (java.lang.Number) 35.0d, false);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 35.0d);
        java.lang.Number number10 = maxCountExceededException9.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = maxCountExceededException9.getContext();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 35.0d + "'", number10.equals(35.0d));
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-113L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 113.0f + "'", float1 == 113.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 98, (double) (-208617464059018235L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0861746405901824E17d + "'", double2 == 2.0861746405901824E17d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 100.0f, objArray11);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException13 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = mathArithmeticException13.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathArithmeticException13.getContext();
        exceptionContext15.setValue("org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (135) exceeded: evaluations", (java.lang.Object) (-0.7853981633974483d));
        exceptionContext15.setValue("", (java.lang.Object) (-1.4155594961262613E11d));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        java.lang.Number number24 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number24, (int) (short) 0, orderDirection26, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException28.getDirection();
        boolean boolean30 = nonMonotonousSequenceException28.getStrict();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        java.lang.Object[] objArray32 = null;
        java.lang.Object[] objArray33 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException34 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException28, (org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray32);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException52 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, (java.lang.Number) 100.0f, objArray51);
        java.lang.Object[] objArray54 = new java.lang.Object[] { localizedFormats40, localizedFormats41, (short) -1, localizedFormats43, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException55 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, (java.lang.Number) 100.0f, objArray54);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException56 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray54);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException57 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.9867717342662448d, objArray54);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException58 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException34, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray54);
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray54);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException60 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3, objArray54);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray54);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.552714E-14f, (float) 36, (float) 33554432L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710663101885897d + "'", double1 == 3.2710663101885897d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 453842378333305L, 145.00002f, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 2046L, (float) (-10), (float) (-80L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(453842378333305L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, objArray9);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = mathArithmeticException11.getContext();
        java.lang.Throwable[] throwableArray13 = mathArithmeticException11.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.854370717180455E247d, 286.4788975654116d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.8543707171804544E247d + "'", double2 == 3.8543707171804544E247d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(0.004931288061015948d, 2.2070583763897011E21d, (-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number4, (int) (short) 0, orderDirection6, true);
        java.lang.Number number9 = nonMonotonousSequenceException8.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.8368072883126412E82d, (java.lang.Number) 3.141592653589793d, (int) (short) 10, orderDirection10, false);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException(0.0d, 1.5430806348152437d, 0.0d, 0.0d);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) noBracketingException17);
        int int19 = nonMonotonousSequenceException12.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 145, (int) 'a');
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = dimensionMismatchException3.getContext();
        java.lang.Object obj6 = exceptionContext4.getValue("");
        java.lang.Object obj8 = exceptionContext4.getValue("org.apache.commons.math.exception.DimensionMismatchException: number of sample is not positive: 145");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1032.0d, (java.lang.Number) (-10), true);
        exceptionContext4.setValue("", (java.lang.Object) 1032.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 100.0f, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats3, localizedFormats4, (short) -1, localizedFormats6, true };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, objArray17);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext20 = mathArithmeticException19.getContext();
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException24 = new org.apache.commons.math.exception.DimensionMismatchException((-1023), 0);
        exceptionContext20.setValue("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", (java.lang.Object) 0);
        java.util.Set<java.lang.String> strSet26 = exceptionContext20.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext20);
        org.junit.Assert.assertNotNull(strSet26);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 145, (java.lang.Number) 145.00002f, false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        double double1 = org.apache.commons.math.util.FastMath.sin(7.52574989159953d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.946613855774109d + "'", double1 == 0.946613855774109d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 30, 7235.910447264d, 26);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(90, 29);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 110);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(18896.732897403363d, 803.4623211555895d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray10 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray10);
        int[] intArray17 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray17);
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray17, 0);
        int[] intArray25 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray30 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray30);
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray25);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray25);
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray25);
        int[] intArray39 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray44 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray44);
        try {
            double double47 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 145 + "'", int11 == 145);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 135 + "'", int18 == 135);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 145 + "'", int31 == 145);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 145 + "'", int45 == 145);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 90 + "'", int46 == 90);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(52.0d, 0.6218224167640864d, 1.232595164421844E-32d, (double) 10, 36.00000000000001d, (double) 145.00002f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5252.3353149881395d + "'", double6 == 5252.3353149881395d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        double[] doubleArray10 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray16 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray17 = new double[][] { doubleArray10, doubleArray16 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray3, orderDirection4, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray3, (int) (short) 100);
        java.lang.Number number25 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number25, (int) (short) 0, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 135L, 20, orderDirection27, false);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection27, false, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.275957614183426E-12d, (java.lang.Number) (-1055715.2055845829d), 1078067200, orderDirection27, true);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(2.9982230451921064d, 2.384185791015625E-7d, (double) (-1720077616), 1.0329816652440602d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.7683715820310695E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.768371582030889E-7d + "'", double1 == 4.768371582030889E-7d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-145.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 145.0d + "'", double1 == 145.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        int[] intArray4 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray9 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray16 = new int[] { 'a', (short) 100, (short) 1, 145, 0 };
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray16, 0);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, (int) (byte) 0);
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, 0);
        int[] intArray28 = new int[] { ' ', ' ', 10, (-1) };
        int[] intArray33 = new int[] { (byte) 10, 10, (short) 100, (short) 10 };
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray33);
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray33);
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray35);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 145 + "'", int10 == 145);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 135 + "'", int17 == 135);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 145 + "'", int34 == 145);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(17145L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.9982230451921064d, 4.0144243921987787E-44d, 190);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-48), 547932);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2191728 + "'", int2 == 2191728);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        double double1 = org.apache.commons.math.util.MathUtils.sign(6.833062665831833E38d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        double double3 = regulaFalsiSolver0.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double9 = regulaFalsiSolver0.solve(1202215227, univariateRealFunction5, 2.99822295029797d, 6.994405055138486E-14d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(32.63992885965673d, 0.773121177104694d, (double) (-1023));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.32952211174938384d + "'", double3 == 0.32952211174938384d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(143.0f, (float) (-166718472), 145);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 7642606031426289665L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.6426060314262897E18d + "'", double1 == 7.6426060314262897E18d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        double[] doubleArray7 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray13 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray14 = new double[][] { doubleArray7, doubleArray13 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection1, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 100);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        java.lang.Number number23 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1032.0d, number23, (int) (short) 0, orderDirection25, true);
        java.lang.Number number28 = nonMonotonousSequenceException27.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.8368072883126412E82d, (java.lang.Number) 3.141592653589793d, (int) (short) 10, orderDirection29, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection29, false);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection2 = null;
        double[] doubleArray8 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray14 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray15 = new double[][] { doubleArray8, doubleArray14 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray1, orderDirection2, doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        double[] doubleArray25 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray31 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray31 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray18, orderDirection19, doubleArray32);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray1, orderDirection17, doubleArray32);
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = null;
        double[] doubleArray42 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[] doubleArray48 = new double[] { '#', 0, Double.NaN, (-1), 0.0f };
        double[][] doubleArray49 = new double[][] { doubleArray42, doubleArray48 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray35, orderDirection36, doubleArray49);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray35, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray35);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray35);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 5L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        long long2 = org.apache.commons.math.util.FastMath.min(26L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 78125, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 78125L + "'", long2 == 78125L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.19607161940718024d, (double) 17145);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9999999958776927d);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 143.0f);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-808182895));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.8573324964312685d, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 3628800L, 0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(720, univariateRealFunction4, (-4.2d), (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 190, 3.719933267899063E41d, 1.232595164421844E-32d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        float float1 = org.apache.commons.math.util.MathUtils.sign(2.0000002f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 720, 97.0d, 6.994405055138486E-14d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 1.0d, ' ', (byte) 1, 'a', 100.0d, (byte) 100 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 100.0f, objArray9);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException14 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 7, (int) 'a');
        java.lang.String str15 = dimensionMismatchException14.toString();
        int int16 = dimensionMismatchException14.getDimension();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.DimensionMismatchException: unable to bracket optimum in line search" + "'", str15.equals("org.apache.commons.math.exception.DimensionMismatchException: unable to bracket optimum in line search"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 97 + "'", int16 == 97);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.505149978319906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }
}

