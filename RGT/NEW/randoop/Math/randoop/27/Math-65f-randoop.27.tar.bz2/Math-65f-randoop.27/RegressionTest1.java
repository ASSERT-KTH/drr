import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test1() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test1");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.multiply(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.multiply(blockRealMatrix12);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix9, 10);
        double[][] doubleArray16 = blockRealMatrix9.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix2.multiply(blockRealMatrix9);
        java.lang.Class<?> wildcardClass18 = blockRealMatrix2.getClass();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.multiply(blockRealMatrix25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix29.multiply(blockRealMatrix32);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix29, 10);
        double[][] doubleArray36 = blockRealMatrix29.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix22.multiply(blockRealMatrix29);
        double[] doubleArray39 = blockRealMatrix37.getRow(1);
        blockRealMatrix2.setColumn((int) (byte) 0, doubleArray39);
        double double41 = blockRealMatrix2.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix48 = blockRealMatrix44.multiply(blockRealMatrix47);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix55 = blockRealMatrix51.multiply(blockRealMatrix54);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix51, 10);
        double[][] doubleArray58 = blockRealMatrix51.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix59 = blockRealMatrix44.multiply(blockRealMatrix51);
        double[] doubleArray61 = blockRealMatrix59.getRow(1);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix59, (int) (byte) 0);
        double double64 = blockRealMatrix59.getDeterminant();
        blockRealMatrix59.setEntry((int) (byte) 10, (int) '#', (double) 0.0f);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix70 = blockRealMatrix59.getRowMatrix(0);
        org.apache.commons.math.linear.RealVector realVector72 = blockRealMatrix59.getColumnVector((int) ' ');
        org.apache.commons.math.linear.RealVector realVector73 = blockRealMatrix2.operate(realVector72);
        java.io.ObjectOutputStream objectOutputStream74 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector73, objectOutputStream74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix48);
        org.junit.Assert.assertNotNull(blockRealMatrix55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(blockRealMatrix59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix70);
        org.junit.Assert.assertNotNull(realVector72);
        org.junit.Assert.assertNotNull(realVector73);
    }

    @Test
    public void test2() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test2");
        org.apache.commons.math.exception.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException(throwable1);
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException6 = new org.apache.commons.math.FunctionEvaluationException(throwable1, (double) (-1), localizable4, objArray5);
        java.lang.Object[] objArray8 = null;
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException9 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("hi!", objArray8);
        functionEvaluationException6.addSuppressed((java.lang.Throwable) arrayIndexOutOfBoundsException9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) arrayIndexOutOfBoundsException9);
        org.apache.commons.math.exception.Localizable localizable12 = null;
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix18 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix15.multiply(blockRealMatrix18);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix15, 10);
        double[][] doubleArray22 = blockRealMatrix15.getData();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11, localizable12, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable0, (java.lang.Object[]) doubleArray22);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        double[][] doubleArray26 = array2DRowRealMatrix25.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix30 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix30.multiply(blockRealMatrix33);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix40 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix37.multiply(blockRealMatrix40);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix37, 10);
        double[][] doubleArray44 = blockRealMatrix37.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix30.multiply(blockRealMatrix37);
        java.lang.Class<?> wildcardClass46 = blockRealMatrix30.getClass();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix53 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix50.multiply(blockRealMatrix53);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix57.multiply(blockRealMatrix60);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix57, 10);
        double[][] doubleArray64 = blockRealMatrix57.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix65 = blockRealMatrix50.multiply(blockRealMatrix57);
        double[] doubleArray67 = blockRealMatrix65.getRow(1);
        blockRealMatrix30.setColumn((int) (byte) 0, doubleArray67);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix71 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix74 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = blockRealMatrix71.multiply(blockRealMatrix74);
        org.apache.commons.math.linear.RealVector realVector77 = blockRealMatrix74.getRowVector(0);
        org.apache.commons.math.linear.RealVector realVector78 = blockRealMatrix30.operate(realVector77);
        array2DRowRealMatrix25.setColumnVector((int) (short) 1, realVector78);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException9);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(blockRealMatrix41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(blockRealMatrix65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(blockRealMatrix75);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(realVector78);
    }

    @Test
    public void test3() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test3");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.multiply(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.multiply(blockRealMatrix12);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix9, 10);
        double[][] doubleArray16 = blockRealMatrix9.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix2.multiply(blockRealMatrix9);
        java.lang.Class<?> wildcardClass18 = blockRealMatrix2.getClass();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix22.multiply(blockRealMatrix25);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix29 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix33 = blockRealMatrix29.multiply(blockRealMatrix32);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix29, 10);
        double[][] doubleArray36 = blockRealMatrix29.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix22.multiply(blockRealMatrix29);
        double[] doubleArray39 = blockRealMatrix37.getRow(1);
        blockRealMatrix2.setColumn((int) (byte) 0, doubleArray39);
        int int41 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor42 = null;
        try {
            double double47 = blockRealMatrix2.walkInRowOrder(realMatrixPreservingVisitor42, 52, (int) 'a', (int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 52 out of allowed range [0, 51]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(blockRealMatrix33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 52 + "'", int41 == 52);
    }

    @Test
    public void test4() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test4");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.multiply(blockRealMatrix5);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix9.multiply(blockRealMatrix12);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix9, 10);
        double[][] doubleArray16 = blockRealMatrix9.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix2.multiply(blockRealMatrix9);
        java.lang.Class<?> wildcardClass18 = blockRealMatrix2.getClass();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix21.multiply(blockRealMatrix24);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix32 = blockRealMatrix28.multiply(blockRealMatrix31);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix28, 10);
        double[][] doubleArray35 = blockRealMatrix28.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix21.multiply(blockRealMatrix28);
        java.lang.Class<?> wildcardClass37 = blockRealMatrix21.getClass();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix41 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix45 = blockRealMatrix41.multiply(blockRealMatrix44);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix48 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math.linear.BlockRealMatrix((int) '4', (int) '4');
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix52 = blockRealMatrix48.multiply(blockRealMatrix51);
        org.apache.commons.math.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math.linear.AnyMatrix) blockRealMatrix48, 10);
        double[][] doubleArray55 = blockRealMatrix48.getData();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix56 = blockRealMatrix41.multiply(blockRealMatrix48);
        double[] doubleArray58 = blockRealMatrix56.getRow(1);
        blockRealMatrix21.setColumn((int) (byte) 0, doubleArray58);
        double double60 = blockRealMatrix21.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix61 = blockRealMatrix2.subtract(blockRealMatrix21);
        double[] doubleArray63 = blockRealMatrix2.getColumn(1);
        org.apache.commons.math.linear.RealVector realVector65 = blockRealMatrix2.getColumnVector(0);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(blockRealMatrix32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(blockRealMatrix45);
        org.junit.Assert.assertNotNull(blockRealMatrix52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(blockRealMatrix56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realVector65);
    }
}

