import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.log1p(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-4001699307210888657L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6043420314257906d + "'", double1 == 0.6043420314257906d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.464757906675863d + "'", double1 == 3.464757906675863d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) -1, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.09966865249116202d) + "'", double2 == (-0.09966865249116202d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 155.74607629780772d + "'", double1 == 155.74607629780772d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4505495340698077d) + "'", double1 == (-0.4505495340698077d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570765801764381d + "'", double1 == 1.570765801764381d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 32768);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.4505495340698077d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45054953406980763d) + "'", double1 == (-0.45054953406980763d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray4 = new byte[] { (byte) 3, (byte) 3, (byte) 0 };
        mersenneTwister0.nextBytes(byteArray4);
        mersenneTwister0.setSeed(0);
        org.junit.Assert.assertNotNull(byteArray4);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 100.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.396963537967006d + "'", double1 == 10.396963537967006d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        long long2 = mersenneTwister1.nextLong();
        float float3 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4001699307210888657L) + "'", long2 == (-4001699307210888657L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.71518934f + "'", float3 == 0.71518934f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.71518934f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.71518934f + "'", float1 == 0.71518934f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-4001699307210888657L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4001699307210888657L) + "'", long2 == (-4001699307210888657L));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int2 = org.apache.commons.math.util.FastMath.max(52, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int2 = org.apache.commons.math.util.FastMath.min(32760, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister0.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        try {
            int int8 = mersenneTwister6.nextInt((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) 100, Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int1 = org.apache.commons.math.util.FastMath.abs(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0.71518934f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7151893377304077d + "'", double1 == 0.7151893377304077d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.45054953406980763d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.42331082513074814d) + "'", double1 == (-0.42331082513074814d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5574077246549023d, (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5574077246549025d + "'", double2 == 1.5574077246549025d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 93740670);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1636083.334525473d + "'", double1 == 1636083.334525473d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4723742494957611d + "'", double0 == 0.4723742494957611d);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister0.setSeed(intArray3);
        try {
            int int7 = mersenneTwister0.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2246467991473532E-16d) + "'", double1 == (-1.2246467991473532E-16d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0L, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray14);
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) mathIllegalArgumentException15);
        java.lang.Object[] objArray17 = mathIllegalArgumentException15.getArguments();
        java.lang.String str18 = mathIllegalArgumentException15.toString();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str18.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.log(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfp4.subtract(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.02182568980423394d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9997618290871159d + "'", double1 == 0.9997618290871159d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8551258436102158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.351670304635608d + "'", double1 == 2.351670304635608d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.38905609893065d + "'", double1 == 7.38905609893065d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9997618290871159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.3819928008026126E-4d) + "'", double1 == (-2.3819928008026126E-4d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.0d), (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.9E-324d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-323d + "'", double2 == 1.0E-323d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.tanh(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.45054953406980763d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1032260564029732d + "'", double1 == 1.1032260564029732d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 100);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1L, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.42331082513074814d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.signum((-2.3819928008026126E-4d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister0.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int[] intArray7 = null;
        mersenneTwister6.setSeed(intArray7);
        mersenneTwister6.setSeed((-1L));
        float float11 = mersenneTwister6.nextFloat();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.021825671f + "'", float11 == 0.021825671f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.351670304635608d, 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3516703046356078d + "'", double2 == 2.3516703046356078d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister0.setSeed(intArray3);
        double double6 = mersenneTwister0.nextDouble();
        double double7 = mersenneTwister0.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.02182568980423394d + "'", double6 == 0.02182568980423394d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.9259573975574423d) + "'", double7 == (-0.9259573975574423d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(1.0d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int[] intArray3 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray9 = new int[] { '4' };
        mersenneTwister7.setSeed(intArray9);
        byte[] byteArray12 = new byte[] { (byte) 1 };
        mersenneTwister7.nextBytes(byteArray12);
        mersenneTwister5.nextBytes(byteArray12);
        mersenneTwister4.nextBytes(byteArray12);
        long long16 = mersenneTwister4.nextLong();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-421172439773005097L) + "'", long16 == (-421172439773005097L));
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int2 = mersenneTwister0.nextInt((int) (short) 100);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 93740670, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 32768, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32768.0f + "'", float2 == 32768.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4436354751788103d + "'", double1 == 1.4436354751788103d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.4436354751788103d, (-0.05805644741791105d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.44363547517881d + "'", double2 == 1.44363547517881d);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
//        int[] intArray4 = new int[] { '4' };
//        mersenneTwister2.setSeed(intArray4);
//        byte[] byteArray7 = new byte[] { (byte) 1 };
//        mersenneTwister2.nextBytes(byteArray7);
//        mersenneTwister0.nextBytes(byteArray7);
//        long long10 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(byteArray7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-323078381150436252L) + "'", long10 == (-323078381150436252L));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100L, 0.9528177801669238d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 80.47028886738161d + "'", double2 == 80.47028886738161d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.45054953406980763d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        try {
            int int3 = mersenneTwister1.nextInt((-4));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -4 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.570765801764381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.atan(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037345d + "'", double1 == 1.4711276743037345d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.141592653589793d, (double) 4589153899890174528L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926535897936d + "'", double2 == 3.1415926535897936d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0f);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-4001699307210888657L), (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.0016993072108887E18d) + "'", double2 == (-4.0016993072108887E18d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.9528177801669238d, (java.lang.Number) (-2.3819928008026126E-4d), true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray4 = new int[] { '4' };
        mersenneTwister2.setSeed(intArray4);
        byte[] byteArray7 = new byte[] { (byte) 1 };
        mersenneTwister2.nextBytes(byteArray7);
        mersenneTwister0.nextBytes(byteArray7);
        java.lang.Class<?> wildcardClass10 = byteArray7.getClass();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100, (float) (byte) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.44363547517881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.05805644741791105d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.058121807055025725d) + "'", double1 == (-0.058121807055025725d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 1, 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.newInstance(1636083.334525473d);
        org.apache.commons.math.dfp.Dfp dfp17 = new org.apache.commons.math.dfp.Dfp(dfp16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.351670304635608d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.351670304635608d + "'", double2 == 2.351670304635608d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.log(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.36651292058166435d) + "'", double1 == (-0.36651292058166435d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 4589153899890174528L, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.589154E18f + "'", float2 == 4.589154E18f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        int int3 = dfp2.intValue();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.negate();
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfp2.nextAfter(dfp5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister0.setSeed(intArray3);
        int int6 = mersenneTwister0.nextInt();
        double double7 = mersenneTwister0.nextDouble();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 93740670 + "'", int6 == 93740670);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.24877852705263082d + "'", double7 == 0.24877852705263082d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        long long5 = mersenneTwister1.nextLong();
        int int7 = mersenneTwister1.nextInt(1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-399282402319373395L) + "'", long5 == (-399282402319373395L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, (java.lang.Number) 7.930067261567154E14d, true);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.02182568980423394d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.021590919313363134d + "'", double1 == 0.021590919313363134d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp9.getOne();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp9.getZero();
        double[] doubleArray21 = dfp20.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2479614275509088d + "'", double1 == 1.2479614275509088d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.0f, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        int int19 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        float float2 = org.apache.commons.math.util.FastMath.min(1.0f, (float) 93740670);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9528177801669238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.59300589547846d + "'", double1 == 2.59300589547846d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException7.getSpecificPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException7);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)");
        int int12 = dfp11.log10();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1000 + "'", int12 == 1000);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        dfpField1.setIEEEFlagsBits(2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp9.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.newInstance(1636083.334525473d);
        double[] doubleArray17 = dfp16.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.02182568980423394d, 4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2369943016397563E-7d + "'", double2 == 1.2369943016397563E-7d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.sin(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-4.0016993072108887E18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Object[] objArray8 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, (java.lang.Number) 7.930067261567154E14d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 0);
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5488135008937807d + "'", double2 == 0.5488135008937807d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        try {
            org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.asinh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        byte[] byteArray6 = new byte[] { (byte) 1 };
        mersenneTwister1.nextBytes(byteArray6);
        double double8 = mersenneTwister1.nextGaussian();
        byte[] byteArray13 = new byte[] { (byte) 10, (byte) 100, (byte) 0, (byte) 10 };
        mersenneTwister1.nextBytes(byteArray13);
        double double15 = mersenneTwister1.nextDouble();
        int int16 = mersenneTwister1.nextInt();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.05805644741791105d) + "'", double8 == (-0.05805644741791105d));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.8551258436102158d + "'", double15 == 0.8551258436102158d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1593528082 + "'", int16 == 1593528082);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-421172439773005097L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.2117243977300512E17d) + "'", double1 == (-4.2117243977300512E17d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int[] intArray2 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        int int5 = mersenneTwister3.nextInt(32768);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 24190 + "'", int5 == 24190);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathRuntimeException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        mersenneTwister0.setSeed(intArray3);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        int[] intArray7 = null;
//        mersenneTwister6.setSeed(intArray7);
//        long long9 = mersenneTwister6.nextLong();
//        mersenneTwister6.setSeed(8);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1610700922250475512L + "'", long9 == 1610700922250475512L);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getSpecificPattern();
        java.lang.String str15 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, number17, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable24, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getSpecificPattern();
        java.lang.String str44 = numberIsTooSmallException42.toString();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException42.getGeneralPattern();
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, number46, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable53, objArray60);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray67 = numberIsTooSmallException66.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable53, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField70.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField70.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable16, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 10000, (java.lang.Number) (-0.9259573975574423d), true);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str15.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str44.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8325546111576977d + "'", double1 == 0.8325546111576977d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException4.getSuppressed();
        java.lang.Number number9 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0f + "'", number9.equals(1.0f));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((double) 10L);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.021590919313363134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.021592597163906775d + "'", double1 == 0.021592597163906775d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1593528082, (float) 24190);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.59352806E9f + "'", float2 == 1.59352806E9f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0L, 1.4711276743037345d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) 3, (byte) 3, (byte) 0 };
//        mersenneTwister0.nextBytes(byteArray4);
//        int int6 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1063681186 + "'", int6 == 1063681186);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 32760);
        int[] intArray8 = new int[] { '#', 52, 'a', 100, 100, (short) -1 };
        mersenneTwister1.setSeed(intArray8);
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        int[] intArray14 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister(intArray14);
        mersenneTwister11.setSeed(intArray14);
        mersenneTwister1.setSeed(intArray14);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        int int15 = dfp11.intValue();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField17.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp();
        int int21 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.ceil();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField24.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField24.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp20.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-4) + "'", int21 == (-4));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getSpecificPattern();
        java.lang.String str10 = numberIsTooSmallException8.toString();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getSpecificPattern();
        java.lang.Number number18 = numberIsTooSmallException16.getArgument();
        java.lang.String str19 = numberIsTooSmallException16.toString();
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooSmallException25.getSpecificPattern();
        java.lang.String str27 = numberIsTooSmallException25.toString();
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException25.getGeneralPattern();
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, number29, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable38, objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable36, objArray43);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException54.getSpecificPattern();
        java.lang.String str56 = numberIsTooSmallException54.toString();
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException54.getGeneralPattern();
        java.lang.Number number58 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, number58, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable62, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable65 = notStrictlyPositiveException64.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, localizable67, objArray72);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable65, objArray72);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException78 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray79 = numberIsTooSmallException78.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable65, (java.lang.Object[]) throwableArray79);
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField82.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField82.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray86 = dfpField82.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable28, (java.lang.Object[]) dfpArray86);
        org.apache.commons.math.exception.util.Localizable localizable88 = null;
        org.apache.commons.math.exception.util.Localizable localizable89 = null;
        java.lang.Object[] objArray94 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable88, localizable89, objArray94);
        org.apache.commons.math.exception.util.Localizable localizable96 = mathIllegalArgumentException95.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable97 = mathIllegalArgumentException95.getGeneralPattern();
        java.lang.Object[] objArray98 = mathIllegalArgumentException95.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException99 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException3, localizable11, localizable20, objArray98);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str10.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100.0d + "'", number18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str19.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str27.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNull(localizable55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str56.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(throwableArray79);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfpArray86);
        org.junit.Assert.assertNotNull(objArray94);
        org.junit.Assert.assertNull(localizable96);
        org.junit.Assert.assertNull(localizable97);
        org.junit.Assert.assertNotNull(objArray98);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.signum(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471784987917d + "'", double1 == 0.6931471784987917d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.4226923E18f + "'", float1 == 8.4226923E18f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathRuntimeException5.getSpecificPattern();
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double2 = org.apache.commons.math.util.FastMath.max(11013.232920103323d, (double) 0.71518934f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.232920103323d + "'", double2 == 11013.232920103323d);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test240");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        mersenneTwister0.setSeed(intArray3);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        int[] intArray7 = null;
//        mersenneTwister6.setSeed(intArray7);
//        long long9 = mersenneTwister6.nextLong();
//        long long10 = mersenneTwister6.nextLong();
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4979395747288800127L) + "'", long9 == (-4979395747288800127L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6728482946328567508L + "'", long10 == 6728482946328567508L);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 3, (float) (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.4226923E18f) + "'", float2 == (-8.4226923E18f));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 100, (float) (byte) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-4));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.25d + "'", double1 == 1.25d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable15, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException28.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.021592597163906775d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02159595356918104d + "'", double1 == 0.02159595356918104d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.058121807055025725d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.05808913272436415d) + "'", double1 == (-0.05808913272436415d));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlags((-1));
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray15);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1593528082, (float) 20);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.59352806E9f + "'", float2 == 1.59352806E9f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(10.396963537967006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1814612459473227d + "'", double1 == 0.1814612459473227d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double2 = org.apache.commons.math.util.FastMath.max(0.021592597163906775d, 0.6931471784987917d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6931471784987917d + "'", double2 == 0.6931471784987917d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.getZero();
        double[] doubleArray24 = dfp23.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp23, dfp27);
        try {
            org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance(1610700922250475512L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.636130838093536d + "'", double1 == 43.636130838093536d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.multiply(16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.divide((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4589153899890174528L);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 912482958 + "'", int2 == 912482958);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.9528177801669238d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.floor();
        org.apache.commons.math.dfp.Dfp dfp20 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp19, dfp20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.6043420314257906d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0064987226208176275d + "'", double2 == 0.0064987226208176275d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.570765801764381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32760.000000006385d + "'", double1 == 32760.000000006385d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.615120516841261d + "'", double1 == 4.615120516841261d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int2 = org.apache.commons.math.util.FastMath.min(1, (-4));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-4) + "'", int2 == (-4));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.2369943016397563E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2369943016397594E-7d + "'", double1 == 1.2369943016397594E-7d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        boolean boolean6 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException11.getSpecificPattern();
        java.lang.Number number13 = numberIsTooSmallException11.getArgument();
        java.lang.String str14 = numberIsTooSmallException11.toString();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 0.9528177801669238d, (java.lang.Number) (short) 1, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100.0d + "'", number13.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str14.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.negate();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (793,006,726,156,715.4)");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        int[] intArray4 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister1.setSeed(intArray4);
        boolean boolean7 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getSpecificPattern();
        java.lang.String str15 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, number17, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable24, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getSpecificPattern();
        java.lang.String str44 = numberIsTooSmallException42.toString();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException42.getGeneralPattern();
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, number46, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable53, objArray60);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray67 = numberIsTooSmallException66.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable53, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField70.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField70.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable16, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 1.0f);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str15.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str44.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.rint();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 6728482946328567508L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.classify();
        double[] doubleArray4 = dfp2.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.getZero();
        double[] doubleArray24 = dfp23.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.multiply((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getZero();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField15.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp();
        int int19 = dfp18.log10();
        int int20 = dfp18.log10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.getZero();
        double[] doubleArray26 = dfp25.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.newInstance(1.570765801764381d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp13.nextAfter(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp7.divide(dfp28);
        double[] doubleArray31 = dfp28.toSplitDouble();
        java.lang.String str32 = dfp28.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-4) + "'", int19 == (-4));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-4) + "'", int20 == (-4));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "1.570765801764" + "'", str32.equals("1.570765801764"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int[] intArray9 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        mersenneTwister5.setSeed(intArray9);
        int int12 = mersenneTwister5.nextInt();
        double double13 = mersenneTwister5.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1081843539 + "'", int12 == 1081843539);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.7451902148403322d + "'", double13 == 1.7451902148403322d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 1063681186);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1063681186 + "'", int2 == 1063681186);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.021592597163906775d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.021595953882295536d + "'", double1 == 0.021595953882295536d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32760);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField16.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp6.nextAfter(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp24 = dfp22.divide(dfp23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlags((-1));
        dfpField1.setIEEEFlagsBits((int) (short) -1);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 52, (long) 30);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30L + "'", long2 == 30L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField16.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp6.nextAfter(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp24 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47712125471966244d + "'", double1 == 0.47712125471966244d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.1415926535897936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.216245299353273E-16d + "'", double1 == 3.216245299353273E-16d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 32768, false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        boolean boolean8 = dfp7.isNaN();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        boolean boolean5 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed((int) ' ');
        java.lang.Class<?> wildcardClass5 = mersenneTwister1.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(7.38905609893065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.389056098930651d + "'", double1 == 7.389056098930651d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0f + "'", number7.equals(1.0f));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8306408778607839d + "'", double1 == 0.8306408778607839d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        double[] doubleArray11 = dfp7.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.newInstance();
        double double13 = dfp7.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.609437912434d + "'", double13 == 1.609437912434d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        float float6 = mersenneTwister5.nextFloat();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.9783548f + "'", float6 == 0.9783548f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math.util.FastMath.sin(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0.021825671f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0220655934664422d + "'", double1 == 1.0220655934664422d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.Dfp.copysign(dfp10, dfp19);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.multiply(8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        java.lang.String str8 = mathIllegalArgumentException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str8.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.1622776601683795d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.162277660168379d + "'", double2 == 3.162277660168379d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int1 = org.apache.commons.math.util.FastMath.round((-8.4226923E18f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        double[] doubleArray11 = dfp7.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.sqrt();
        double double13 = dfp7.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.609437912434d + "'", double13 == 1.609437912434d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0000000000000004d + "'", double1 == 3.0000000000000004d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)");
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getZero();
        try {
            int int13 = dfp11.intValue();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        int int15 = dfp11.intValue();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField17.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp();
        int int21 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.ceil();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField24.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField24.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(1.4436354751788103d);
        double double35 = dfp32.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-4) + "'", int21 == (-4));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + Double.NEGATIVE_INFINITY + "'", double35 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getLn2();
        double double20 = dfp19.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.69314718056d + "'", double20 == 0.69314718056d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.9259573975574423d), (-4.0016993072108887E18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9259573975574424d) + "'", double2 == (-0.9259573975574424d));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        double double6 = dfp4.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.02159595356918104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02159595356918104d + "'", double1 == 0.02159595356918104d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField9.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.subtract(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.newInstance(1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getSpecificPattern();
        java.lang.String str7 = numberIsTooSmallException5.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException5.getGeneralPattern();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException17.getSpecificPattern();
        java.lang.Number number19 = numberIsTooSmallException17.getArgument();
        java.lang.String str20 = numberIsTooSmallException17.toString();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException17.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) 0.9528177801669238d, (java.lang.Number) (short) 1, true);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException32.getSpecificPattern();
        java.lang.String str34 = numberIsTooSmallException32.toString();
        java.lang.Object[] objArray35 = numberIsTooSmallException32.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable21, objArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        boolean boolean41 = numberIsTooSmallException40.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable43, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable48 = numberIsTooSmallException47.getSpecificPattern();
        java.lang.String str49 = numberIsTooSmallException47.toString();
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooSmallException47.getGeneralPattern();
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, number51, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable55, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable58 = notStrictlyPositiveException57.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, localizable60, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable58, objArray65);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException71 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray72 = numberIsTooSmallException71.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException73 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException40, localizable42, localizable58, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable21, (java.lang.Object[]) throwableArray72);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 100.0d + "'", number19.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str20.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str34.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(localizable48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str49.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray72);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47712125471966244d + "'", double1 == 0.47712125471966244d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.newInstance(0.0d);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException7.getSpecificPattern();
        java.lang.Throwable[] throwableArray9 = mathIllegalArgumentException7.getSuppressed();
        java.lang.String str10 = mathIllegalArgumentException7.toString();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str10.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        int int11 = dfp7.classify();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.9259573975574424d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.39615196253728696d + "'", double1 == 0.39615196253728696d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.02159595356918104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02159931185343449d + "'", double1 == 0.02159931185343449d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        java.lang.String str10 = dfp9.toString();
        double[] doubleArray11 = dfp9.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0." + "'", str10.equals("0."));
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.floor(7.38905609893065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 8);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10000, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        int int1 = org.apache.commons.math.util.FastMath.abs((-2147483648));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        int[] intArray4 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister1.setSeed(intArray4);
        int int7 = mersenneTwister1.nextInt();
        float float8 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 93740670 + "'", int7 == 93740670);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.24877846f + "'", float8 == 0.24877846f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.162277660168379d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8685511210994619d + "'", double1 == 1.8685511210994619d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0.021825671f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-608192130026889042L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.0819213002688896E17d) + "'", double1 == (-6.0819213002688896E17d));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.24877852705263082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24377011666628626d + "'", double1 == 0.24377011666628626d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp11.subtract(dfp16);
        double double21 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.getTwo();
        java.lang.String str23 = dfp22.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + Double.NEGATIVE_INFINITY + "'", double21 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2." + "'", str23.equals("2."));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, (java.lang.Number) 7.930067261567154E14d, true);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (793,006,726,156,715.4)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (793,006,726,156,715.4)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.ceil(10.396963537967006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp("hi!");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0064987226208176275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.673617379884035E-19d + "'", double1 == 8.673617379884035E-19d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-4));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943292d + "'", double1 == 0.17453292519943292d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.4436354751788103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 82.71421988310894d + "'", double1 == 82.71421988310894d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        double[] doubleArray11 = dfp7.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((long) 32760);
        java.lang.String str16 = dfp15.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "32760." + "'", str16.equals("32760."));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-608192130026889042L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField10.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField10.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        boolean boolean19 = dfp8.equals((java.lang.Object) "org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp20 = dfp4.multiply(dfp8);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp4.ceil();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField23.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField23.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getE();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField30.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        int int34 = dfp33.log10();
        int int35 = dfp33.log10();
        boolean boolean36 = dfp28.lessThan(dfp33);
        int int37 = dfp33.intValue();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField39.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.newDfp();
        int int43 = dfp42.log10();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.ceil();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField46.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode50 = dfpField46.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField46.getE();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField46.getLn5();
        org.apache.commons.math.dfp.Dfp dfp53 = org.apache.commons.math.dfp.Dfp.copysign(dfp42, dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.Dfp.copysign(dfp33, dfp42);
        boolean boolean55 = dfp21.unequal(dfp42);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-4) + "'", int34 == (-4));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-4) + "'", int35 == (-4));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-4) + "'", int43 == (-4));
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + roundingMode50 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode50.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.05808913272436415d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.05812185124882447d) + "'", double1 == (-0.05812185124882447d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 20, (-323078381150436252L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        int int15 = dfp11.intValue();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField17.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp();
        int int21 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.ceil();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField24.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField24.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance((double) (-1L));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-4) + "'", int21 == (-4));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        double[] doubleArray12 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance();
        double[] doubleArray14 = dfp13.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.24877852705263082d, 0.02159931185343449d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9703981820289231d + "'", double2 == 0.9703981820289231d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9278563334139247d + "'", double1 == 0.9278563334139247d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (-4.2117243977300512E17d), true);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (-421,172,439,773,005,120)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (-421,172,439,773,005,120)"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(2.718281828459045d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8184464592320668d + "'", double1 == 1.8184464592320668d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1000, 3.464757906675863d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.464757906675863d + "'", double2 == 3.464757906675863d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister0.setSeed(intArray3);
        double double6 = mersenneTwister0.nextDouble();
        int int8 = mersenneTwister0.nextInt(2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.02182568980423394d + "'", double6 == 0.02182568980423394d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException12.getSpecificPattern();
        java.lang.Number number14 = numberIsTooSmallException12.getArgument();
        java.lang.String str15 = numberIsTooSmallException12.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooSmallException21.getSpecificPattern();
        java.lang.String str23 = numberIsTooSmallException21.toString();
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException21.getGeneralPattern();
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, number25, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException31 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable29, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable32 = notStrictlyPositiveException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable32, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooSmallException50.getSpecificPattern();
        java.lang.String str52 = numberIsTooSmallException50.toString();
        org.apache.commons.math.exception.util.Localizable localizable53 = numberIsTooSmallException50.getGeneralPattern();
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable53, number54, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable58, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable61 = notStrictlyPositiveException60.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable63, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable53, localizable61, objArray68);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray75 = numberIsTooSmallException74.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable61, (java.lang.Object[]) throwableArray75);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField78.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField78.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray82 = dfpField78.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable24, (java.lang.Object[]) dfpArray82);
        org.apache.commons.math.dfp.DfpField dfpField85 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField85.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField85.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray89 = dfpField85.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray90 = dfpField85.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable24, (java.lang.Object[]) dfpArray90);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100.0d + "'", number14.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str15.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str23.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNull(localizable51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str52.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(throwableArray75);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfpArray82);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfpArray89);
        org.junit.Assert.assertNotNull(dfpArray90);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9528177801669238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9840185471443639d + "'", double1 == 0.9840185471443639d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 82.71421988310894d, false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.newInstance((long) 1063681186);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp4.power10(97);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        int int15 = dfp11.intValue();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField17.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp();
        int int21 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.ceil();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField24.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField24.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp20.newInstance("hi!");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-4) + "'", int21 == (-4));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister0.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray10 = new int[] { '4' };
        mersenneTwister8.setSeed(intArray10);
        byte[] byteArray13 = new byte[] { (byte) 1 };
        mersenneTwister8.nextBytes(byteArray13);
        double double15 = mersenneTwister8.nextGaussian();
        byte[] byteArray20 = new byte[] { (byte) 10, (byte) 100, (byte) 0, (byte) 10 };
        mersenneTwister8.nextBytes(byteArray20);
        mersenneTwister6.nextBytes(byteArray20);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.05805644741791105d) + "'", double15 == (-0.05805644741791105d));
        org.junit.Assert.assertNotNull(byteArray20);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.expm1(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 59873.14171519782d + "'", double1 == 59873.14171519782d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (byte) 10, (java.lang.Number) (short) 0, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.609437912434d, (double) 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6094379124340001d + "'", double2 == 1.6094379124340001d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6043420314257906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5682207726504982d + "'", double1 == 0.5682207726504982d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int2 = org.apache.commons.math.util.FastMath.min(32760, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        boolean boolean13 = dfp12.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.nextAfter(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test385");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
//        int[] intArray4 = new int[] { '4' };
//        mersenneTwister2.setSeed(intArray4);
//        byte[] byteArray7 = new byte[] { (byte) 1 };
//        mersenneTwister2.nextBytes(byteArray7);
//        mersenneTwister0.nextBytes(byteArray7);
//        boolean boolean10 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed((-323078381150436252L));
//        boolean boolean13 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertNotNull(intArray4);
//        org.junit.Assert.assertNotNull(byteArray7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.log(4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5227830126997552d + "'", double1 == 1.5227830126997552d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1593528082);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 30);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.09462222433053d + "'", double1 == 4.09462222433053d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) (byte) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.00000000000001d + "'", double1 == 32.00000000000001d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09711515743188391d) + "'", double1 == (-0.09711515743188391d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        int[] intArray3 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray9 = new int[] { '4' };
        mersenneTwister7.setSeed(intArray9);
        byte[] byteArray12 = new byte[] { (byte) 1 };
        mersenneTwister7.nextBytes(byteArray12);
        mersenneTwister5.nextBytes(byteArray12);
        mersenneTwister4.nextBytes(byteArray12);
        mersenneTwister4.setSeed(100L);
        mersenneTwister4.setSeed((int) (short) 1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        int[] intArray24 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math.random.MersenneTwister(intArray24);
        mersenneTwister21.setSeed(intArray24);
        org.apache.commons.math.random.MersenneTwister mersenneTwister27 = new org.apache.commons.math.random.MersenneTwister(intArray24);
        org.apache.commons.math.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math.random.MersenneTwister(intArray24);
        mersenneTwister4.setSeed(intArray24);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.351670304635608d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 134.74078326186495d + "'", double1 == 134.74078326186495d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.classify();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.floor();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField6.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField6.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField6.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getOne();
        boolean boolean16 = dfp2.unequal(dfp14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 32768.0f, 1636083.334525473d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32768.00000000001d + "'", double2 == 32768.00000000001d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8997923511366261d + "'", double1 == 0.8997923511366261d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 52);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, (float) (-399282402319373395L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-4001699307210888657L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-4001699307210888704L) + "'", long1 == (-4001699307210888704L));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-421172439773005097L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-421172439773005120L) + "'", long1 == (-421172439773005120L));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        int[] intArray4 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister1.setSeed(intArray4);
        int int7 = mersenneTwister1.nextInt();
        long long8 = mersenneTwister1.nextLong();
        byte[] byteArray9 = null;
        try {
            mersenneTwister1.nextBytes(byteArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 93740670 + "'", int7 == 93740670);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4589153899890174528L + "'", long8 == 4589153899890174528L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable15, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (-32767), number30, false);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray36 = dfpField34.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) dfpArray36);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfpArray36);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((-0.05808913272436415d));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int2 = org.apache.commons.math.util.FastMath.min(10000, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        double[] doubleArray11 = dfp7.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField14.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField18.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField14.newDfp(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField14.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)");
        boolean boolean25 = dfp7.unequal(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp27 = dfp7.newInstance(dfp26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((double) 10L);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 100);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-4), (-4001699307210888657L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4001699307210888657L) + "'", long2 == (-4001699307210888657L));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        byte[] byteArray6 = new byte[] { (byte) 1 };
        mersenneTwister1.nextBytes(byteArray6);
        double double8 = mersenneTwister1.nextGaussian();
        byte[] byteArray13 = new byte[] { (byte) 10, (byte) 100, (byte) 0, (byte) 10 };
        mersenneTwister1.nextBytes(byteArray13);
        byte[] byteArray15 = new byte[] {};
        mersenneTwister1.nextBytes(byteArray15);
        boolean boolean17 = mersenneTwister1.nextBoolean();
        boolean boolean18 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed((long) 16);
        boolean boolean21 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.05805644741791105d) + "'", double8 == (-0.05805644741791105d));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertNotNull(byteArray15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-8799575916858517781L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int2 = org.apache.commons.math.util.FastMath.min((-4), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-4) + "'", int2 == (-4));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double2 = org.apache.commons.math.util.FastMath.pow(7.930067261567154E14d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.log(1.44363547517881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36716456759013444d + "'", double1 == 0.36716456759013444d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        dfpField1.setIEEEFlagsBits(2);
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((-608192130026889042L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 10, 1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 36.3744688295182d + "'", double2 == 36.3744688295182d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) 32768);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1610700922250475512L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.61634829414454d + "'", double1 == 42.61634829414454d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1813538343);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.813538343E9d + "'", double1 == 1.813538343E9d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int int3 = mersenneTwister1.nextInt(1081843539);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 93740670 + "'", int3 == 93740670);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 'a', 0.7151893377304077d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5634233744407626d + "'", double2 == 1.5634233744407626d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4);
        long long2 = mersenneTwister1.nextLong();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-608192130026889042L) + "'", long2 == (-608192130026889042L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.22506536563720722d) + "'", double3 == (-0.22506536563720722d));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.power10(52);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-4.0016993072108887E18d), (-0.05805644741791105d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8306408778607839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7383637324705482d + "'", double1 == 0.7383637324705482d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(7.0d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.999999999999999d + "'", double2 == 6.999999999999999d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 4L, (double) 6728482946328567508L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 32768, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        java.lang.String str8 = mathIllegalArgumentException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException7.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str8.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNull(localizable9);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        int int3 = dfp2.intValue();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.negate();
        double double5 = dfp2.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.69314718056d + "'", double5 == 0.69314718056d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance(2);
        java.lang.String str22 = dfp19.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "2." + "'", str22.equals("2."));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable15, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooSmallException33.getSpecificPattern();
        java.lang.String str35 = numberIsTooSmallException33.toString();
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooSmallException33.getGeneralPattern();
        java.lang.Number number37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, number37, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable44 = notStrictlyPositiveException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable44, objArray51);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray58 = numberIsTooSmallException57.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable44, (java.lang.Object[]) throwableArray58);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable44, (java.lang.Number) 97L, (java.lang.Number) 0.6043420314257906d, true);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNull(localizable34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str35.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray58);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((double) 10L);
        int int5 = dfp4.log10K();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.divide((int) 'a');
        int int8 = dfp7.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp9.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.cosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.45054953406980763d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 4589153899890174528L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.5891538998901745E18d + "'", double2 == 4.5891538998901745E18d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable15, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 80.47028886738161d);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooSmallException35.getSpecificPattern();
        java.lang.String str37 = numberIsTooSmallException35.toString();
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException35.getGeneralPattern();
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, number39, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable43, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException45.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable48, objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable46, objArray53);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable60, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooSmallException64.getSpecificPattern();
        java.lang.String str66 = numberIsTooSmallException64.toString();
        org.apache.commons.math.exception.util.Localizable localizable67 = numberIsTooSmallException64.getGeneralPattern();
        java.lang.Number number68 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException71 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable67, number68, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable72, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable75 = notStrictlyPositiveException74.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray82 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, localizable77, objArray82);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, localizable75, objArray82);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException88 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray89 = numberIsTooSmallException88.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable75, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, (java.lang.Object[]) throwableArray89);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNull(localizable36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str37.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNull(localizable65);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str66.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable75.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray82);
        org.junit.Assert.assertNotNull(throwableArray89);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 8.4226923E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((long) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.ceil();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int[] intArray9 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        mersenneTwister5.setSeed(intArray9);
        mersenneTwister5.setSeed((-323078381150436252L));
        mersenneTwister5.setSeed((long) 8);
        int int16 = mersenneTwister5.nextInt();
        mersenneTwister5.setSeed((long) 2);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1813538343 + "'", int16 == 1813538343);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.5891538998901745E18d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField18.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getE();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.newInstance((byte) 1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp3.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int[] intArray2 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        int[] intArray3 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray9 = new int[] { '4' };
        mersenneTwister7.setSeed(intArray9);
        byte[] byteArray12 = new byte[] { (byte) 1 };
        mersenneTwister7.nextBytes(byteArray12);
        mersenneTwister5.nextBytes(byteArray12);
        mersenneTwister4.nextBytes(byteArray12);
        mersenneTwister4.setSeed(100);
        long long18 = mersenneTwister4.nextLong();
        double double19 = mersenneTwister4.nextGaussian();
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray23 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister24 = new org.apache.commons.math.random.MersenneTwister(intArray23);
        mersenneTwister20.setSeed(intArray23);
        org.apache.commons.math.random.MersenneTwister mersenneTwister26 = new org.apache.commons.math.random.MersenneTwister(intArray23);
        mersenneTwister4.setSeed(intArray23);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-8422692239103173864L) + "'", long18 == (-8422692239103173864L));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.2321040789270661d) + "'", double19 == (-0.2321040789270661d));
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        dfpField1.setIEEEFlagsBits((int) (byte) -1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getSpecificPattern();
        java.lang.String str15 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, number17, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable24, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getSpecificPattern();
        java.lang.String str44 = numberIsTooSmallException42.toString();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException42.getGeneralPattern();
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, number46, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable53, objArray60);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray67 = numberIsTooSmallException66.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable53, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField70.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField70.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable16, (java.lang.Object[]) dfpArray74);
        java.lang.Throwable[] throwableArray76 = mathIllegalArgumentException75.getSuppressed();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str15.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str44.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertNotNull(throwableArray76);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Class<?> wildcardClass9 = localizable8.getClass();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0220655934664422d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7041195599665006d + "'", double1 == 0.7041195599665006d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField6.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField6.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        boolean boolean19 = dfp11.lessThan(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField21.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp11.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.newDfp(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField30.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField30.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField30.getE();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField37.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp();
        int int41 = dfp40.log10();
        int int42 = dfp40.log10();
        boolean boolean43 = dfp35.lessThan(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField45.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField45.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField45.getLn2();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp35.nextAfter(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp28.newInstance(dfp50);
        int int53 = dfp28.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-4) + "'", int41 == (-4));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-4) + "'", int42 == (-4));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        boolean boolean13 = dfp12.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.nextAfter(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getZero();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField20.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp();
        int int24 = dfp23.log10();
        int int25 = dfp23.log10();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp26.getZero();
        double[] doubleArray31 = dfp30.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.newInstance(1.570765801764381d);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp18.nextAfter(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField36.setIEEEFlagsBits((int) '4');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp12.nextAfter(dfp39);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-4) + "'", int24 == (-4));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-4) + "'", int25 == (-4));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.getZero();
        double[] doubleArray24 = dfp23.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp23.divide(1000);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.getZero();
        double[] doubleArray24 = dfp23.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp30 = dfp23.divide(dfp29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10000, (double) (-4979395747288800127L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9999.999999999998d + "'", double2 == 9999.999999999998d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (byte) 10, (java.lang.Number) (short) 0, false);
        java.lang.Number number6 = numberIsTooSmallException5.getMin();
        java.lang.Object[] objArray7 = numberIsTooSmallException5.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray7);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 0 + "'", number6.equals((short) 0));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        try {
            boolean boolean11 = dfp7.greaterThan(dfp10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.36651292058166435d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.38385689584400523d) + "'", double1 == (-0.38385689584400523d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-4001699307210888657L), (java.lang.Number) (-1), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-4001699307210888657L) + "'", number6.equals((-4001699307210888657L)));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.38385689584400523d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("2.");
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int[] intArray9 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        mersenneTwister5.setSeed(intArray9);
        mersenneTwister5.setSeed((-323078381150436252L));
        double double14 = mersenneTwister5.nextDouble();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.3471111598691299d + "'", double14 == 0.3471111598691299d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        int int15 = dfp11.intValue();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField17.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp();
        int int21 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.ceil();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField24.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField24.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(1.4436354751788103d);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField37.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp();
        int int41 = dfp40.log10();
        int int42 = dfp40.log10();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp43.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.ceil();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField49.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp();
        int int53 = dfp52.log10();
        int int54 = dfp52.log10();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp52.getZero();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp47.subtract(dfp52);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.floor();
        boolean boolean58 = dfp35.equals((java.lang.Object) dfp57);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField60.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField64.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.newDfp();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField60.newDfp(dfp67);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField60.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField71 = dfp70.getField();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField71.newDfp();
        boolean boolean73 = dfp72.isNaN();
        org.apache.commons.math.dfp.Dfp dfp74 = new org.apache.commons.math.dfp.Dfp(dfp72);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp35.divide(dfp74);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-4) + "'", int21 == (-4));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-4) + "'", int41 == (-4));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-4) + "'", int42 == (-4));
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-4) + "'", int53 == (-4));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-4) + "'", int54 == (-4));
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfpField71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(dfp75);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1591352365493741d + "'", double1 == 1.1591352365493741d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.abs(8.673617379884035E-19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.673617379884035E-19d + "'", double1 == 8.673617379884035E-19d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        boolean boolean13 = dfp12.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.nextAfter(dfp12);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((long) (byte) 10);
        try {
            org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp10.multiply((-2147483648));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        long long1 = org.apache.commons.math.util.FastMath.abs(1610700922250475512L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1610700922250475512L + "'", long1 == 1610700922250475512L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        int int7 = dfp6.classify();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int17 = dfp14.intValue();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp14.newInstance(0);
        double double20 = dfp14.toDouble();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.609437912434d + "'", double20 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode12);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.141592653589793d, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06034189865081758d + "'", double2 == 0.06034189865081758d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfpArray23);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        byte[] byteArray6 = new byte[] { (byte) 1 };
        mersenneTwister1.nextBytes(byteArray6);
        mersenneTwister1.setSeed(1063681186);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(byteArray6);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-7510691156635244939L) + "'", long3 == (-7510691156635244939L));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        int int15 = dfp11.intValue();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField17.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp();
        int int21 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.ceil();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField24.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField24.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(1.4436354751788103d);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField37.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp();
        int int41 = dfp40.log10();
        int int42 = dfp40.log10();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp43.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.ceil();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField49.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp();
        int int53 = dfp52.log10();
        int int54 = dfp52.log10();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp52.getZero();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp47.subtract(dfp52);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.floor();
        boolean boolean58 = dfp35.equals((java.lang.Object) dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp35.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-4) + "'", int21 == (-4));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-4) + "'", int41 == (-4));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-4) + "'", int42 == (-4));
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-4) + "'", int53 == (-4));
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-4) + "'", int54 == (-4));
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField23.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField23.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getE();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField30.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        int int34 = dfp33.log10();
        int int35 = dfp33.log10();
        boolean boolean36 = dfp28.lessThan(dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField20.newDfp(dfp28);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp28.getOne();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp28.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField1.newDfp(dfp28);
        org.apache.commons.math.dfp.Dfp dfp41 = new org.apache.commons.math.dfp.Dfp(dfp28);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-4) + "'", int34 == (-4));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-4) + "'", int35 == (-4));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        double[] doubleArray11 = dfp7.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((long) 32760);
        int int16 = dfpField13.getRadixDigits();
        try {
            org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((double) 10L);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField28.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp();
        int int32 = dfp31.log10();
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp34.getZero();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField40.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp();
        int int44 = dfp43.log10();
        int int45 = dfp43.log10();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp43.getZero();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp46.getZero();
        double[] doubleArray51 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getPi();
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.DfpField.computeLn(dfp34, dfp50, dfp54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp50.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeLn(dfp20, dfp25, dfp50);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp58.newInstance((int) (short) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-4) + "'", int32 == (-4));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-4) + "'", int33 == (-4));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-4) + "'", int44 == (-4));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-4) + "'", int45 == (-4));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp19.getZero();
        double[] doubleArray24 = dfp23.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp23, dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.sqrt();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }
}

