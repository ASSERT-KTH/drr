import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        double[] doubleArray12 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance(1.570765801764381d);
        int int15 = dfp14.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.floor();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField23.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField23.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.multiply(0);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField32.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp();
        int int36 = dfp35.log10();
        int int37 = dfp35.log10();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.getZero();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp38.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp38.getZero();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField44.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp();
        int int48 = dfp47.log10();
        int int49 = dfp47.log10();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp47.getZero();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp50.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.getZero();
        double[] doubleArray55 = dfp54.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getPi();
        org.apache.commons.math.dfp.Dfp dfp59 = org.apache.commons.math.dfp.DfpField.computeLn(dfp38, dfp54, dfp58);
        boolean boolean61 = dfp54.equals((java.lang.Object) (-608192130026889042L));
        org.apache.commons.math.dfp.Dfp dfp62 = dfp19.dotrap(1000, "1.570765801764", dfp30, dfp54);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-4) + "'", int36 == (-4));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-4) + "'", int37 == (-4));
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-4) + "'", int48 == (-4));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-4) + "'", int49 == (-4));
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dfp62);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        int int15 = dfp11.intValue();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField17.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp();
        int int21 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.ceil();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField24.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField24.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(1.4436354751788103d);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getOne();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.sqrt();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-4) + "'", int21 == (-4));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 97, (float) 20L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        int int13 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) '4');
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Throwable[] throwableArray9 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        int int8 = dfp7.log10();
        int int9 = dfp7.log10();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getLn2();
        int int13 = dfp12.intValue();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.negate();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.nextAfter(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp2.multiply(dfp7);
        boolean boolean17 = dfp16.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-4) + "'", int8 == (-4));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-4) + "'", int9 == (-4));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (-0.05808913272436415d));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 20.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.0d + "'", double1 == 20.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 3, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance("hi!");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        boolean boolean10 = dfp8.isNaN();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        int int9 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-141605766) + "'", int2 == (-141605766));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlagsBits(0);
        dfpField1.setIEEEFlags((-1));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NEGATIVE_INFINITY, (double) 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField9.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getPi();
        boolean boolean21 = dfp20.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.nextAfter(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp7.nextAfter(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField26.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = dfpField26.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.getE();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField26.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int35 = dfp32.intValue();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp32.newInstance(0);
        double double38 = dfp32.toDouble();
        boolean boolean39 = dfp7.unequal(dfp32);
        double double40 = dfp7.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.609437912434d + "'", double38 == 1.609437912434d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.71828182846d + "'", double40 == 2.71828182846d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) -1, (byte) 100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.9259573975574424d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.75435938449189d + "'", double1 == 2.75435938449189d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.02159595356918104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.021597632593812872d + "'", double1 == 0.021597632593812872d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8422692239103173864L));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        java.lang.Class<?> wildcardClass9 = dfpArray8.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        dfpField1.setIEEEFlagsBits(2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) notStrictlyPositiveException10);
        java.lang.Number number13 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.0f + "'", number13.equals(1.0f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException10.getSpecificPattern();
        java.lang.String str12 = numberIsTooSmallException10.toString();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException10.getGeneralPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, number14, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable23, objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable21, objArray28);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray35 = numberIsTooSmallException34.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable5, localizable21, (java.lang.Object[]) throwableArray35);
        boolean boolean37 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number38 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str12.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0.0f + "'", number38.equals(0.0f));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (-421,172,439,773,005,120)");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 4.589154E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.66337454814249d + "'", double1 == 43.66337454814249d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.6931471784987917d, (java.lang.Number) 1.2369943016397563E-7d, true);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        java.lang.String str10 = dfp9.toString();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField12.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField12.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getE();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField19.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp();
        int int23 = dfp22.log10();
        int int24 = dfp22.log10();
        boolean boolean25 = dfp17.lessThan(dfp22);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.newInstance(1636083.334525473d);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField29.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp();
        int int33 = dfp32.log10();
        int int34 = dfp32.log10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.getZero();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.ceil();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField41.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.newDfp();
        int int45 = dfp44.log10();
        int int46 = dfp44.log10();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.getZero();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp39.subtract(dfp44);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp17.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.subtract(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.subtract(dfp53);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0." + "'", str10.equals("0."));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-4) + "'", int23 == (-4));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-4) + "'", int24 == (-4));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-4) + "'", int33 == (-4));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-4) + "'", int34 == (-4));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-4) + "'", int45 == (-4));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-4) + "'", int46 == (-4));
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) (short) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        java.lang.Object[] objArray12 = numberIsTooSmallException11.getArguments();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-32767), (float) 4589153899890174528L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.589154E18f + "'", float2 == 4.589154E18f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getSpecificPattern();
        java.lang.Number number18 = numberIsTooSmallException16.getArgument();
        java.lang.String str19 = numberIsTooSmallException16.toString();
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 0.9528177801669238d, (java.lang.Number) (short) 1, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooSmallException31.getSpecificPattern();
        java.lang.String str33 = numberIsTooSmallException31.toString();
        java.lang.Object[] objArray34 = numberIsTooSmallException31.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable20, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = mathIllegalArgumentException43.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = mathIllegalArgumentException43.getGeneralPattern();
        mathIllegalArgumentException35.addSuppressed((java.lang.Throwable) mathIllegalArgumentException43);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100.0d + "'", number18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str19.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str33.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNull(localizable44);
        org.junit.Assert.assertNull(localizable45);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        double[] doubleArray12 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.rint();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.020683531529582487d) + "'", double1 == (-0.020683531529582487d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        double[] doubleArray12 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.sqrt();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        long long1 = org.apache.commons.math.util.FastMath.abs((-7510691156635244939L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7510691156635244939L + "'", long1 == 7510691156635244939L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.ulp(134.74078326186495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.42331082513074814d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.42331082513074814d + "'", double1 == 0.42331082513074814d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        int int3 = dfpField1.getIEEEFlags();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 30 + "'", int5 == 30);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.3516703046356078d, (-6.0819213002688896E17d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3516703046356073d + "'", double2 == 2.3516703046356073d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.newInstance(0);
        org.apache.commons.math.dfp.Dfp dfp13 = new org.apache.commons.math.dfp.Dfp(dfp12);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.8306408778607839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int2 = mersenneTwister0.nextInt((int) '4');
//        double double3 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8331828951365361d + "'", double3 == 0.8331828951365361d);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getZero();
        int int5 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        dfpField1.setIEEEFlags((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 0, (byte) -1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.ceil();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField20.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp();
        int int24 = dfp23.log10();
        int int25 = dfp23.log10();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp18.subtract(dfp23);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp6.divide(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField30.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField30.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField30.getE();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField30.getLn5();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int39 = dfp36.intValue();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp43 = dfp36.newInstance(40);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp23.newInstance(dfp36);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-4) + "'", int24 == (-4));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-4) + "'", int25 == (-4));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 10, (double) (-32767));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1412874685045082d + "'", double2 == 3.1412874685045082d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(30L);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField16.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField20.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField16.newDfp(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField16.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField27 = dfp26.getField();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.newDfp();
        boolean boolean29 = dfp28.isNaN();
        org.apache.commons.math.dfp.Dfp dfp30 = new org.apache.commons.math.dfp.Dfp(dfp28);
        boolean boolean31 = dfp12.lessThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp12.newInstance((byte) 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfpField27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getZero();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField15.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp();
        int int19 = dfp18.log10();
        int int20 = dfp18.log10();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp21.getZero();
        double[] doubleArray26 = dfp25.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.newInstance(1.570765801764381d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp13.nextAfter(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp7.divide(dfp28);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.sqrt();
        int int32 = dfp31.intValue();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField34.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode38 = dfpField34.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField34.getE();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField34.getLn5();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int43 = dfp40.intValue();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getZero();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField48.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp();
        int int52 = dfp51.log10();
        int int53 = dfp51.log10();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.getZero();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp54.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp54.getZero();
        double[] doubleArray59 = dfp58.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp58.newInstance(1.570765801764381d);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp46.nextAfter(dfp61);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp40.divide(dfp61);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp63.sqrt();
        int int65 = dfp64.intValue();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp31.divide(dfp64);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-4) + "'", int19 == (-4));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-4) + "'", int20 == (-4));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + roundingMode38 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode38.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2 + "'", int43 == 2);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-4) + "'", int52 == (-4));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-4) + "'", int53 == (-4));
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
        org.junit.Assert.assertNotNull(dfp66);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.021590919313363134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.021590919313363138d + "'", double1 == 0.021590919313363138d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        int[] intArray4 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister1.setSeed(intArray4);
        int int7 = mersenneTwister1.nextInt();
        double double8 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(7);
        double double11 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 93740670 + "'", int7 == 93740670);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.24877852705263082d + "'", double8 == 0.24877852705263082d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6255740904286167d + "'", double11 == 0.6255740904286167d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.negate();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 2.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.7451902148403322d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.776189479195884d + "'", double1 == 2.776189479195884d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-4.2117243977300512E17d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("1.570765801764");
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.464757906675863d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1032260564029732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.013873282646648d + "'", double1 == 2.013873282646648d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double2 = org.apache.commons.math.util.FastMath.atan2(7.389056098930651d, (-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6838679518167485d + "'", double2 == 1.6838679518167485d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974484d + "'", double1 == 0.7853981633974484d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int1 = org.apache.commons.math.util.FastMath.abs(32768);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32768 + "'", int1 == 32768);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int[] intArray3 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray9 = new int[] { '4' };
        mersenneTwister7.setSeed(intArray9);
        byte[] byteArray12 = new byte[] { (byte) 1 };
        mersenneTwister7.nextBytes(byteArray12);
        mersenneTwister5.nextBytes(byteArray12);
        mersenneTwister4.nextBytes(byteArray12);
        mersenneTwister4.setSeed(100);
        long long18 = mersenneTwister4.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray22 = new int[] { '4' };
        mersenneTwister20.setSeed(intArray22);
        byte[] byteArray25 = new byte[] { (byte) 1 };
        mersenneTwister20.nextBytes(byteArray25);
        double double27 = mersenneTwister20.nextGaussian();
        byte[] byteArray32 = new byte[] { (byte) 10, (byte) 100, (byte) 0, (byte) 10 };
        mersenneTwister20.nextBytes(byteArray32);
        byte[] byteArray34 = new byte[] {};
        mersenneTwister20.nextBytes(byteArray34);
        mersenneTwister4.nextBytes(byteArray34);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-8422692239103173864L) + "'", long18 == (-8422692239103173864L));
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(byteArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-0.05805644741791105d) + "'", double27 == (-0.05805644741791105d));
        org.junit.Assert.assertNotNull(byteArray32);
        org.junit.Assert.assertNotNull(byteArray34);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 93740670);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93740670 + "'", int2 == 93740670);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.216245299353273E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.851458867961321E-6d + "'", double1 == 6.851458867961321E-6d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        int int15 = dfp11.intValue();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField17.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp();
        int int21 = dfp20.log10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.ceil();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField24.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = dfpField24.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getE();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.getLn5();
        org.apache.commons.math.dfp.Dfp dfp31 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp20);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.newInstance(1.4436354751788103d);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getOne();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.newInstance(24190);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.newInstance();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-4) + "'", int21 == (-4));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 46);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException7.getSpecificPattern();
        java.lang.Throwable[] throwableArray9 = mathIllegalArgumentException7.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathIllegalArgumentException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.getOne();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4);
        long long2 = mersenneTwister1.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        int[] intArray7 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister4.setSeed(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister1.setSeed(intArray7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-608192130026889042L) + "'", long2 == (-608192130026889042L));
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray4 = new int[] { '4' };
        mersenneTwister2.setSeed(intArray4);
        byte[] byteArray7 = new byte[] { (byte) 1 };
        mersenneTwister2.nextBytes(byteArray7);
        mersenneTwister0.nextBytes(byteArray7);
        boolean boolean10 = mersenneTwister0.nextBoolean();
        mersenneTwister0.setSeed((-323078381150436252L));
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray16 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        mersenneTwister13.setSeed(intArray16);
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        byte[] byteArray24 = new byte[] { (byte) 2, (byte) 1, (byte) 1, (byte) 0 };
        mersenneTwister19.nextBytes(byteArray24);
        mersenneTwister0.nextBytes(byteArray24);
        mersenneTwister0.setSeed((int) (byte) -1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(byteArray24);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int[] intArray9 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        mersenneTwister5.setSeed(intArray9);
        mersenneTwister5.setSeed((-323078381150436252L));
        mersenneTwister5.setSeed((long) 8);
        float float16 = mersenneTwister5.nextFloat();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.4222473f + "'", float16 == 0.4222473f);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField10.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField10.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        boolean boolean19 = dfp8.equals((java.lang.Object) "org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp20 = dfp4.multiply(dfp8);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp4.sqrt();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        java.lang.String str10 = dfp9.toString();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField12.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField12.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getE();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField19.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp();
        int int23 = dfp22.log10();
        int int24 = dfp22.log10();
        boolean boolean25 = dfp17.lessThan(dfp22);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp17.newInstance(1636083.334525473d);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField29.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp();
        int int33 = dfp32.log10();
        int int34 = dfp32.log10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.getZero();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.ceil();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField41.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.newDfp();
        int int45 = dfp44.log10();
        int int46 = dfp44.log10();
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.getZero();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp39.subtract(dfp44);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp17.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp9.subtract(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField52.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField52.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode56 = dfpField52.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField52.newDfp((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp9.add(dfp58);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0." + "'", str10.equals("0."));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-4) + "'", int23 == (-4));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-4) + "'", int24 == (-4));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-4) + "'", int33 == (-4));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-4) + "'", int34 == (-4));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-4) + "'", int45 == (-4));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-4) + "'", int46 == (-4));
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + roundingMode56 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode56.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.ceil();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField8.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getLn5();
        org.apache.commons.math.dfp.Dfp dfp15 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.newInstance((long) 1063681186);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp4.newInstance((int) (byte) 10);
        boolean boolean21 = dfp4.equals((java.lang.Object) 20.0d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.389056098930651d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 423.3617290541268d + "'", double1 == 423.3617290541268d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        int int10 = dfp8.log10();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-4) + "'", int10 == (-4));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException14.getSpecificPattern();
        java.lang.String str16 = numberIsTooSmallException14.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException14.getGeneralPattern();
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, number18, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getSpecificPattern();
        java.lang.Number number28 = numberIsTooSmallException26.getArgument();
        java.lang.String str29 = numberIsTooSmallException26.toString();
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException26.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 0.9528177801669238d, (java.lang.Number) (short) 1, true);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooSmallException41.getSpecificPattern();
        java.lang.String str43 = numberIsTooSmallException41.toString();
        java.lang.Object[] objArray44 = numberIsTooSmallException41.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable30, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField48.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode52 = dfpField48.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField48.getE();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField48.getLn5();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int57 = dfp54.intValue();
        double[] doubleArray58 = dfp54.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp54.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField60 = dfp54.getField();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((long) 32760);
        int int63 = dfpField60.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField60.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException7, localizable30, localizable46, (java.lang.Object[]) dfpArray64);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str16.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable27);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 100.0d + "'", number28.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str29.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str43.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + roundingMode52 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode52.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfpField60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 4 + "'", int63 == 4);
        org.junit.Assert.assertNotNull(dfpArray64);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(1000);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance((long) 7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) '4');
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        int int3 = dfp2.intValue();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.negate();
        double[] doubleArray5 = dfp2.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        long long5 = mersenneTwister1.nextLong();
        int[] intArray6 = null;
        mersenneTwister1.setSeed(intArray6);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-399282402319373395L) + "'", long5 == (-399282402319373395L));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.7383637324705482d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0925088075373832d + "'", double1 == 1.0925088075373832d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField18.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp();
        int int22 = dfp21.log10();
        int int23 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn2();
        int int32 = dfp31.intValue();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.negate();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.divide(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField36.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode40 = dfpField36.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getE();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField43.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp();
        int int47 = dfp46.log10();
        int int48 = dfp46.log10();
        boolean boolean49 = dfp41.lessThan(dfp46);
        int int50 = dfp46.intValue();
        int int51 = dfp46.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp31, dfp46);
        int int53 = dfp46.intValue();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-4) + "'", int22 == (-4));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-4) + "'", int23 == (-4));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + roundingMode40 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode40.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-4) + "'", int47 == (-4));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-4) + "'", int48 == (-4));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9521553682590148d) + "'", double1 == (-0.9521553682590148d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.newInstance(1636083.334525473d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp6.newInstance("1.570765801764");
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField20.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getE();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getPi();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField29.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = dfpField29.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getE();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        boolean boolean38 = dfp27.equals((java.lang.Object) "org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp39 = dfp23.multiply(dfp27);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp23.ceil();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp18.subtract(dfp40);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        int[] intArray4 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister1.setSeed(intArray4);
        int int7 = mersenneTwister1.nextInt();
        long long8 = mersenneTwister1.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray13 = new byte[] { (byte) 3, (byte) 3, (byte) 0 };
        mersenneTwister9.nextBytes(byteArray13);
        mersenneTwister1.nextBytes(byteArray13);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 93740670 + "'", int7 == 93740670);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 4589153899890174528L + "'", long8 == 4589153899890174528L);
        org.junit.Assert.assertNotNull(byteArray13);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.302585092994046d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.05805644741791105d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.ceil();
        int int7 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.02159595356918104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1.59352806E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getSpecificPattern();
        java.lang.Number number18 = numberIsTooSmallException16.getArgument();
        java.lang.String str19 = numberIsTooSmallException16.toString();
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 0.9528177801669238d, (java.lang.Number) (short) 1, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooSmallException31.getSpecificPattern();
        java.lang.String str33 = numberIsTooSmallException31.toString();
        java.lang.Object[] objArray34 = numberIsTooSmallException31.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable20, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) (short) 1);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 100.0d + "'", number18.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str19.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str33.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.apache.commons.math.dfp.Dfp dfp12 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(dfp11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.44363547517881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.163085598195192d + "'", double1 == 1.163085598195192d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getPi();
        boolean boolean4 = dfp3.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 2);
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField9.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField9.newDfp(0.0d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp7.divide(dfp17);
        int int19 = dfp18.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp13);
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister((long) ' ');
        boolean boolean18 = dfp13.equals((java.lang.Object) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfp13.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp21 = new org.apache.commons.math.dfp.Dfp(dfp13);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.abs(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField14.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp12.subtract(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField22.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = dfpField22.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.getE();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField22.getLn5();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int31 = dfp28.intValue();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField33.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode37 = dfpField33.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getE();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField40.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp();
        int int44 = dfp43.log10();
        int int45 = dfp43.log10();
        boolean boolean46 = dfp38.lessThan(dfp43);
        boolean boolean47 = dfp28.lessThan(dfp38);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp28.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp50 = org.apache.commons.math.dfp.DfpField.computeExp(dfp20, dfp49);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + roundingMode37 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode37.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-4) + "'", int44 == (-4));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-4) + "'", int45 == (-4));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(20);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        double[] doubleArray11 = dfp7.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((long) 32760);
        double[] doubleArray16 = dfp15.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((double) 10L);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField28.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp();
        int int32 = dfp31.log10();
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp34.getZero();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField40.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp();
        int int44 = dfp43.log10();
        int int45 = dfp43.log10();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp43.getZero();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp46.getZero();
        double[] doubleArray51 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getPi();
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.DfpField.computeLn(dfp34, dfp50, dfp54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp50.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeLn(dfp20, dfp25, dfp50);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField60.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField60.newDfp();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp63.rint();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.floor();
        org.apache.commons.math.dfp.Dfp dfp66 = dfp20.subtract(dfp63);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp63.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-4) + "'", int32 == (-4));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-4) + "'", int33 == (-4));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-4) + "'", int44 == (-4));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-4) + "'", int45 == (-4));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5227830126997552d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.401535766928942d + "'", double1 == 2.401535766928942d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int1 = org.apache.commons.math.util.FastMath.round(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException7.getSpecificPattern();
        java.lang.Object[] objArray9 = mathIllegalArgumentException7.getArguments();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField14.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.newDfp();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp12.subtract(dfp19);
        boolean boolean21 = dfp12.isInfinite();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 20);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4258259770489514E8d + "'", double1 == 2.4258259770489514E8d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 32, (float) 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 20L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.acos(16.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.nextAfter(dfp15);
        boolean boolean17 = dfp6.isNaN();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        int int1 = org.apache.commons.math.util.FastMath.abs(93740670);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 93740670 + "'", int1 == 93740670);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((double) 10L);
        int int26 = dfp25.log10K();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField28.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp();
        int int32 = dfp31.log10();
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp34.getZero();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField40.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp();
        int int44 = dfp43.log10();
        int int45 = dfp43.log10();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp43.getZero();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp46.getZero();
        double[] doubleArray51 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getPi();
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.DfpField.computeLn(dfp34, dfp50, dfp54);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp50.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeLn(dfp20, dfp25, dfp50);
        org.apache.commons.math.dfp.DfpField dfpField59 = dfp50.getField();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (793,006,726,156,715.4)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-4) + "'", int32 == (-4));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-4) + "'", int33 == (-4));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-4) + "'", int44 == (-4));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-4) + "'", int45 == (-4));
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfpField59);
        org.junit.Assert.assertNotNull(dfp61);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        int int10 = dfp9.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 4589153899890174528L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.629391499997093E20d + "'", double1 == 2.629391499997093E20d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (short) 1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance(1000);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.floor();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        dfpField1.setIEEEFlags(912482958);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getSpecificPattern();
        java.lang.String str15 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, number17, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable24, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getSpecificPattern();
        java.lang.String str44 = numberIsTooSmallException42.toString();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException42.getGeneralPattern();
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, number46, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable53, objArray60);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray67 = numberIsTooSmallException66.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable53, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField70.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField70.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable16, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException77 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 2.4258259770489514E8d);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str15.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str44.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.newInstance((double) 1000);
        double double13 = dfp7.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.609437912434d + "'", double13 == 1.609437912434d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField12.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = dfpField12.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getE();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField19.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp();
        int int23 = dfp22.log10();
        int int24 = dfp22.log10();
        boolean boolean25 = dfp17.lessThan(dfp22);
        boolean boolean26 = dfp7.lessThan(dfp17);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp7.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField30.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField30.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField30.getE();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField30.getLn5();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int39 = dfp36.intValue();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getZero();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField44.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp();
        int int48 = dfp47.log10();
        int int49 = dfp47.log10();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp47.getZero();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp50.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp50.getZero();
        double[] doubleArray55 = dfp54.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp54.newInstance(1.570765801764381d);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp42.nextAfter(dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp36.divide(dfp57);
        boolean boolean60 = dfp7.greaterThan(dfp59);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode16 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode16.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-4) + "'", int23 == (-4));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-4) + "'", int24 == (-4));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-4) + "'", int48 == (-4));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-4) + "'", int49 == (-4));
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getSpecificPattern();
        java.lang.String str7 = numberIsTooSmallException5.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException5.getGeneralPattern();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, number9, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable18, objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable16, objArray23);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (-32767), number31, false);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable39 = numberIsTooSmallException38.getSpecificPattern();
        java.lang.String str40 = numberIsTooSmallException38.toString();
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException38.getGeneralPattern();
        java.lang.Number number42 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable41, number42, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable46, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable49 = notStrictlyPositiveException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable51, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable49, objArray56);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 11.0d);
        org.apache.commons.math.exception.util.Localizable localizable61 = notStrictlyPositiveException60.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException65 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Number number66 = numberIsTooSmallException65.getMin();
        java.lang.Object[] objArray67 = numberIsTooSmallException65.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException68 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable8, localizable61, objArray67);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNull(localizable39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str40.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + (-1.0f) + "'", number66.equals((-1.0f)));
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int[] intArray9 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        mersenneTwister5.setSeed(intArray9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((byte) 2);
        double double6 = dfp5.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-141605766), 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7615941559557649d + "'", double2 == 0.7615941559557649d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.69314718056d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6061119347328919d + "'", double1 == 0.6061119347328919d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10(30);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister0.setSeed(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int[] intArray7 = null;
        mersenneTwister6.setSeed(intArray7);
        mersenneTwister6.setSeed((-1L));
        double double11 = mersenneTwister6.nextDouble();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.02182568980423394d + "'", double11 == 0.02182568980423394d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 3779824525346770773L, 1.7451902148403322d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7451902148403322d + "'", double2 == 1.7451902148403322d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        byte[] byteArray6 = new byte[] { (byte) 1 };
        mersenneTwister1.nextBytes(byteArray6);
        double double8 = mersenneTwister1.nextGaussian();
        byte[] byteArray13 = new byte[] { (byte) 10, (byte) 100, (byte) 0, (byte) 10 };
        mersenneTwister1.nextBytes(byteArray13);
        double double15 = mersenneTwister1.nextDouble();
        boolean boolean16 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.05805644741791105d) + "'", double8 == (-0.05805644741791105d));
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.8551258436102158d + "'", double15 == 0.8551258436102158d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.5891538998901745E18d, 16.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((long) (-32767));
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.newInstance((long) 30);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K((-1));
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField12.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp();
        int int16 = dfp15.log10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.ceil();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField19.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField19.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField19.getLn5();
        org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.Dfp.copysign(dfp15, dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp15.multiply(16);
        boolean boolean29 = dfp10.lessThan(dfp28);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getPi();
        dfpField1.setIEEEFlags(32768);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlagsBits(8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.5488135008937807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-4.0016993072108887E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.0016993072108882E18d) + "'", double1 == (-4.0016993072108882E18d));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int int2 = org.apache.commons.math.util.FastMath.min((-32767), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32767) + "'", int2 == (-32767));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp11.subtract(dfp16);
        int int21 = dfp11.classify();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int2 = org.apache.commons.math.util.FastMath.max(16, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getPiSplit();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((double) 10L);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.916079783099616d + "'", double1 == 5.916079783099616d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.newDfp();
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp13);
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister((long) ' ');
        boolean boolean18 = dfp13.equals((java.lang.Object) ' ');
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField20.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField20.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField27.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode31 = dfpField27.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getE();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField27.getLn5();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int36 = dfp33.intValue();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.newInstance(0);
        double double39 = dfp33.toDouble();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField20.newDfp(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getPi();
        boolean boolean44 = dfp43.isInfinite();
        boolean boolean46 = dfp43.equals((java.lang.Object) (byte) 0);
        boolean boolean47 = dfp40.lessThan(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField49.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode53 = dfpField49.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField49.getE();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField49.getLn5();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp55.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField61.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode65 = dfpField61.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField61.getE();
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField68.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField68.newDfp();
        int int72 = dfp71.log10();
        int int73 = dfp71.log10();
        boolean boolean74 = dfp66.lessThan(dfp71);
        int int75 = dfp71.intValue();
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField77.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField77.newDfp();
        int int81 = dfp80.log10();
        org.apache.commons.math.dfp.Dfp dfp82 = dfp80.ceil();
        org.apache.commons.math.dfp.DfpField dfpField84 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField84.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField84.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode88 = dfpField84.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField84.getE();
        org.apache.commons.math.dfp.Dfp dfp90 = dfpField84.getLn5();
        org.apache.commons.math.dfp.Dfp dfp91 = org.apache.commons.math.dfp.Dfp.copysign(dfp80, dfp90);
        org.apache.commons.math.dfp.Dfp dfp92 = org.apache.commons.math.dfp.Dfp.copysign(dfp71, dfp80);
        boolean boolean93 = dfp57.unequal(dfp80);
        org.apache.commons.math.dfp.Dfp dfp95 = dfp80.newInstance(0.8997923511366261d);
        org.apache.commons.math.dfp.Dfp dfp96 = org.apache.commons.math.dfp.DfpField.computeLn(dfp13, dfp43, dfp95);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + roundingMode31 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode31.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.609437912434d + "'", double39 == 1.609437912434d);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + roundingMode53 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode53.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + roundingMode65 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode65.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-4) + "'", int72 == (-4));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-4) + "'", int73 == (-4));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-4) + "'", int81 == (-4));
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertTrue("'" + roundingMode88 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode88.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(dfp95);
        org.junit.Assert.assertNotNull(dfp96);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double2 = org.apache.commons.math.util.FastMath.pow(7.0d, 0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0459461309099596d + "'", double2 == 2.0459461309099596d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 7.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(2.718281828459045d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp21.getField();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.getTwo();
        double double18 = dfp17.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField23.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField23.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getE();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField30.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        int int34 = dfp33.log10();
        int int35 = dfp33.log10();
        boolean boolean36 = dfp28.lessThan(dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField20.newDfp(dfp28);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField20.getTwo();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField20.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp17, dfp39);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-4) + "'", int34 == (-4));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-4) + "'", int35 == (-4));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getZero();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField18.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp();
        int int22 = dfp21.log10();
        int int23 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn2();
        int int32 = dfp31.intValue();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.negate();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.divide(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField36.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode40 = dfpField36.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getE();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField43.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp();
        int int47 = dfp46.log10();
        int int48 = dfp46.log10();
        boolean boolean49 = dfp41.lessThan(dfp46);
        int int50 = dfp46.intValue();
        int int51 = dfp46.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp31, dfp46);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField54.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField54.newDfp();
        int int58 = dfp57.log10();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp57.ceil();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField61.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode65 = dfpField61.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField61.getE();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField61.getLn5();
        org.apache.commons.math.dfp.Dfp dfp68 = org.apache.commons.math.dfp.Dfp.copysign(dfp57, dfp67);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp57.newInstance((long) 1063681186);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp57.newInstance((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp57.newInstance();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp6.nextAfter(dfp57);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-4) + "'", int22 == (-4));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-4) + "'", int23 == (-4));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + roundingMode40 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode40.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-4) + "'", int47 == (-4));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-4) + "'", int48 == (-4));
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-4) + "'", int58 == (-4));
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + roundingMode65 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode65.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getSqr3Reciprocal();
        int int21 = dfp20.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1063681186);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp21.getField();
        double[] doubleArray23 = dfp21.toSplitDouble();
        int int24 = dfp21.log10K();
        org.apache.commons.math.dfp.DfpField dfpField25 = dfp21.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(dfpField25);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.classify();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.floor();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField14.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp();
        int int18 = dfp17.log10();
        int int19 = dfp17.log10();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.newInstance((byte) 10, (byte) 1);
        int int24 = dfp20.log10K();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField1.newDfp(dfp20);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-4) + "'", int19 == (-4));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (-0.22506536563720722d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField10.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField10.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        boolean boolean19 = dfp8.equals((java.lang.Object) "org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp20 = dfp4.multiply(dfp8);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp4.ceil();
        int int22 = dfp4.log10K();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.power10((int) ' ');
        java.lang.String str25 = dfp24.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1.000000000000e32" + "'", str25.equals("1.000000000000e32"));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField10.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp();
        int int14 = dfp13.log10();
        int int15 = dfp13.log10();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.ceil();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField22.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp();
        int int26 = dfp25.log10();
        int int27 = dfp25.log10();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.getZero();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp20.subtract(dfp25);
        double double30 = dfp25.toDouble();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField33.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode37 = dfpField33.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getE();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField33.getLn5();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getPi();
        boolean boolean45 = dfp44.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.nextAfter(dfp44);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.newInstance((long) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp8.multiply(dfp48);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-4) + "'", int14 == (-4));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-4) + "'", int26 == (-4));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-4) + "'", int27 == (-4));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.NEGATIVE_INFINITY + "'", double30 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + roundingMode37 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode37.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister0.setSeed(intArray3);
        java.lang.Class<?> wildcardClass6 = intArray3.getClass();
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField7.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField7.newDfp(dfp14);
        dfpField7.setIEEEFlags(4);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField7.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode18);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getSpecificPattern();
        java.lang.String str8 = numberIsTooSmallException6.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException6.getGeneralPattern();
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, number10, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable17, objArray24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 11.0d);
        org.apache.commons.math.exception.util.Localizable localizable29 = notStrictlyPositiveException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable30, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException32);
        java.lang.Number number34 = notStrictlyPositiveException32.getMin();
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException32.getGeneralPattern();
        java.lang.Object[] objArray36 = notStrictlyPositiveException32.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable29, objArray36);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str8.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 0 + "'", number34.equals(0));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = null;
        try {
            boolean boolean14 = dfp12.greaterThan(dfp13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(2.718281828459045d);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField10.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField10.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.subtract(dfp16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.asinh(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.401535766928942d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.401535766928942d + "'", double1 == 2.401535766928942d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(1.813538343E9d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.rint();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp22.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.newInstance(0);
        int int13 = dfp7.log10K();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (-421,172,439,773,005,120)");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("2.");
        int int7 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.401535766928942d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04191470623731719d + "'", double1 == 0.04191470623731719d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1063681186);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException15.getSpecificPattern();
        java.lang.Number number17 = numberIsTooSmallException15.getArgument();
        java.lang.String str18 = numberIsTooSmallException15.toString();
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) 0.9528177801669238d, (java.lang.Number) (short) 1, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 10.396963537967006d);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable28, objArray29);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooSmallException35.getSpecificPattern();
        java.lang.String str37 = numberIsTooSmallException35.toString();
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException35.getGeneralPattern();
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, number39, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable43, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException45.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable48, objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, localizable46, objArray53);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) (-399282402319373395L), (java.lang.Number) 7.38905609893065d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 155.74607629780772d, (java.lang.Number) (short) 100, false);
        java.lang.Throwable[] throwableArray68 = numberIsTooSmallException67.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException69 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException10, localizable28, localizable38, (java.lang.Object[]) throwableArray68);
        boolean boolean70 = notStrictlyPositiveException10.getBoundIsAllowed();
        java.lang.Number number71 = notStrictlyPositiveException10.getArgument();
        boolean boolean72 = notStrictlyPositiveException10.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 100.0d + "'", number17.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str18.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str37.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + number71 + "' != '" + (-4001699307210888657L) + "'", number71.equals((-4001699307210888657L)));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        boolean boolean3 = dfp2.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((byte) 2);
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp2.getField();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999161440783615d + "'", double1 == 0.999161440783615d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-7510691156635244939L));
        double double2 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3394638130366636d + "'", double2 == 1.3394638130366636d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.getZero();
        double[] doubleArray12 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance(1.570765801764381d);
        int int15 = dfp11.log10K();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.newInstance(1);
        double double18 = dfp17.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12217304763960307d + "'", double1 == 0.12217304763960307d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        dfpField1.setIEEEFlags(1);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, (java.lang.Number) 7.930067261567154E14d, true);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (793,006,726,156,715.4)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (793,006,726,156,715.4)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (793,006,726,156,715.4)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0 is smaller than the minimum (793,006,726,156,715.4)"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        dfpField1.setIEEEFlagsBits((int) (byte) -1);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp((byte) 10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) (byte) 1, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 3);
        int int7 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6218224167640864d + "'", double1 == 0.6218224167640864d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267831587699267d + "'", double1 == 5.267831587699267d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField13.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField20.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp();
        int int24 = dfp23.log10();
        int int25 = dfp23.log10();
        boolean boolean26 = dfp18.lessThan(dfp23);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField10.newDfp(dfp18);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField1.newDfp(dfp29);
        int int31 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-4) + "'", int24 == (-4));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-4) + "'", int25 == (-4));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int[] intArray3 = new int[] { (byte) -1, (short) -1 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        mersenneTwister0.setSeed(intArray3);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray3);
//        int[] intArray7 = null;
//        mersenneTwister6.setSeed(intArray7);
//        long long9 = mersenneTwister6.nextLong();
//        double double10 = mersenneTwister6.nextDouble();
//        mersenneTwister6.setSeed(1063681186);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4978630122362200518L + "'", long9 == 4978630122362200518L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2324047709614403d + "'", double10 == 0.2324047709614403d);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray14);
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) mathIllegalArgumentException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        boolean boolean22 = numberIsTooSmallException21.getBoundIsAllowed();
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable24 = mathIllegalArgumentException7.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(localizable24);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.abs(134.74078326186495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 134.74078326186495d + "'", double1 == 134.74078326186495d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 3779824525346770773L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.577471638609047d + "'", double1 == 18.577471638609047d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) -1, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException9.getSpecificPattern();
        java.lang.Number number11 = numberIsTooSmallException9.getArgument();
        java.lang.String str12 = numberIsTooSmallException9.toString();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable13, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable27, objArray32);
        mathIllegalArgumentException25.addSuppressed((java.lang.Throwable) mathIllegalArgumentException33);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray41);
        org.apache.commons.math.exception.util.Localizable localizable43 = mathIllegalArgumentException42.getSpecificPattern();
        java.lang.Object[] objArray45 = new java.lang.Object[] { mathIllegalArgumentException33, localizable43, 16 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray45);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable4, localizable13, objArray45);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable13, (java.lang.Number) 2.629391499997093E20d, (java.lang.Number) (-4.0016993072108887E18d), true);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100.0d + "'", number11.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str12.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.5707963267948966d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1.0f) + "'", number6.equals((-1.0f)));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getLn2();
        int int10 = dfp9.intValue();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.negate();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp4.nextAfter(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp11.getField();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int[] intArray0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 8.0d, (java.lang.Number) 32760, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 2.351670304635608d);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int10 = dfp7.intValue();
        double[] doubleArray11 = dfp7.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp7.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField14.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField18.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField14.newDfp(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField14.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)");
        boolean boolean25 = dfp7.unequal(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField27.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.newDfp();
        int int31 = dfp30.log10();
        int int32 = dfp30.log10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.getZero();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.ceil();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField39.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField39.newDfp();
        int int43 = dfp42.log10();
        int int44 = dfp42.log10();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp42.getZero();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp37.subtract(dfp42);
        double double47 = dfp42.toDouble();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp42.getTwo();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp48.ceil();
        boolean boolean50 = dfp24.equals((java.lang.Object) dfp48);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-4) + "'", int31 == (-4));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-4) + "'", int32 == (-4));
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-4) + "'", int43 == (-4));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-4) + "'", int44 == (-4));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.NEGATIVE_INFINITY + "'", double47 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        int int6 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((long) (-32767));
        boolean boolean9 = dfp4.isNaN();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        long long1 = org.apache.commons.math.util.FastMath.abs(4978630122362200518L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4978630122362200518L + "'", long1 == 4978630122362200518L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((byte) -1);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.8551258436102158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField8.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp();
        int int12 = dfp11.log10();
        int int13 = dfp11.log10();
        boolean boolean14 = dfp6.lessThan(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField16.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField16.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp6.nextAfter(dfp21);
        org.apache.commons.math.dfp.Dfp dfp23 = null;
        try {
            boolean boolean24 = dfp6.greaterThan(dfp23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-4) + "'", int12 == (-4));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-4) + "'", int13 == (-4));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.newDfp(0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-2147483648), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable15, objArray22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (-399282402319373395L), (java.lang.Number) 7.38905609893065d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1063681186, (java.lang.Number) (-4001699307210888704L), false);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray14);
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) mathIllegalArgumentException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        boolean boolean22 = numberIsTooSmallException21.getBoundIsAllowed();
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Object[] objArray24 = numberIsTooSmallException21.getArguments();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        float float2 = org.apache.commons.math.util.FastMath.min(97.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getPiSplit();
        java.lang.Class<?> wildcardClass11 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathRuntimeException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10000);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException4.getSuppressed();
        boolean boolean9 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlags(3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number8, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable15, objArray22);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 11.0d);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooSmallException31.getSpecificPattern();
        java.lang.Number number33 = numberIsTooSmallException31.getArgument();
        java.lang.String str34 = numberIsTooSmallException31.toString();
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) (-4001699307210888657L));
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 0.9528177801669238d, (java.lang.Number) (short) 1, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) 10.396963537967006d);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable44, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable47, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooSmallException51.getSpecificPattern();
        java.lang.String str53 = numberIsTooSmallException51.toString();
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException51.getGeneralPattern();
        java.lang.Number number55 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable54, number55, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable59, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable62 = notStrictlyPositiveException61.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable62, objArray69);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable54, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable54, (java.lang.Number) (-399282402319373395L), (java.lang.Number) 7.38905609893065d, true);
        org.apache.commons.math.dfp.DfpField dfpField81 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField81.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField81.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray85 = dfpField81.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray86 = dfpField81.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray87 = dfpField81.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray88 = dfpField81.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField81.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray90 = dfpField81.getPiSplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException91 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException26, localizable44, localizable54, (java.lang.Object[]) dfpArray90);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 100.0d + "'", number33.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str34.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str53.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfpArray85);
        org.junit.Assert.assertNotNull(dfpArray86);
        org.junit.Assert.assertNotNull(dfpArray87);
        org.junit.Assert.assertNotNull(dfpArray88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfpArray90);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 3, (byte) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField23.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = dfpField23.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getE();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField30.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        int int34 = dfp33.log10();
        int int35 = dfp33.log10();
        boolean boolean36 = dfp28.lessThan(dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField20.newDfp(dfp28);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp28.getOne();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp28.getZero();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField1.newDfp(dfp28);
        int int41 = dfp40.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-4) + "'", int34 == (-4));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-4) + "'", int35 == (-4));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 3 + "'", int41 == 3);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-4));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance("2.");
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.ceil();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        int int8 = dfp7.log10();
        int int9 = dfp7.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.getZero();
        double[] doubleArray15 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance(1.570765801764381d);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp2.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-4) + "'", int8 == (-4));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-4) + "'", int9 == (-4));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooSmallException13.getSpecificPattern();
        java.lang.String str15 = numberIsTooSmallException13.toString();
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException13.getGeneralPattern();
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, number17, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable24 = notStrictlyPositiveException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable24, objArray31);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) 16, (java.lang.Number) (-1.0f), true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 100.0d, (java.lang.Number) 1.0f, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooSmallException42.getSpecificPattern();
        java.lang.String str44 = numberIsTooSmallException42.toString();
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException42.getGeneralPattern();
        java.lang.Number number46 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, number46, (java.lang.Number) (short) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException52 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 100.0d);
        org.apache.commons.math.exception.util.Localizable localizable53 = notStrictlyPositiveException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable55, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable53, objArray60);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException66 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) (-1.0f), false);
        java.lang.Throwable[] throwableArray67 = numberIsTooSmallException66.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable53, (java.lang.Object[]) throwableArray67);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField70.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField70.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField70.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable16, (java.lang.Object[]) dfpArray74);
        org.apache.commons.math.exception.util.Localizable localizable76 = mathIllegalArgumentException75.getGeneralPattern();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str15.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str44.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfpArray74);
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1425465430742778d) + "'", double1 == (-0.1425465430742778d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.rint();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.ceil();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField15.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField15.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.getE();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField22.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp();
        int int26 = dfp25.log10();
        int int27 = dfp25.log10();
        boolean boolean28 = dfp20.lessThan(dfp25);
        int int29 = dfp25.intValue();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField31.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp();
        int int35 = dfp34.log10();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.ceil();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField38.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode42 = dfpField38.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField38.getE();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField38.getLn5();
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.Dfp.copysign(dfp34, dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.Dfp.copysign(dfp25, dfp34);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField48.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.newDfp();
        int int52 = dfp51.log10();
        int int53 = dfp51.log10();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.getZero();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp54.newInstance((double) (byte) 1);
        int int59 = dfp58.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.DfpField.computeLn(dfp13, dfp25, dfp58);
        org.apache.commons.math.dfp.Dfp dfp61 = org.apache.commons.math.dfp.DfpField.computeExp(dfp6, dfp60);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-4) + "'", int26 == (-4));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-4) + "'", int27 == (-4));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-4) + "'", int35 == (-4));
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + roundingMode42 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode42.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-4) + "'", int52 == (-4));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-4) + "'", int53 == (-4));
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        int int7 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 30 + "'", int7 == 30);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray3 = new int[] { '4' };
        mersenneTwister1.setSeed(intArray3);
        long long5 = mersenneTwister1.nextLong();
        double double6 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-399282402319373395L) + "'", long5 == (-399282402319373395L));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7543039670382905d + "'", double6 == 0.7543039670382905d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.615120516841261d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000011d + "'", double1 == 100.00000000000011d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        int int2 = org.apache.commons.math.util.FastMath.max(7, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 0);
        mersenneTwister1.setSeed((-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 97, (java.lang.Number) (-4.9E-324d), true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9259573975574423d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3296237801745263d) + "'", double1 == (-1.3296237801745263d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits(7);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField6.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField6.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        int int17 = dfp16.log10();
        int int18 = dfp16.log10();
        boolean boolean19 = dfp11.lessThan(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField21.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp11.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.newDfp(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField30.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode34 = dfpField30.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField30.getE();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField37.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp();
        int int41 = dfp40.log10();
        int int42 = dfp40.log10();
        boolean boolean43 = dfp35.lessThan(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField45.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField45.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField45.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField45.getLn2();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp35.nextAfter(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp28.newInstance(dfp50);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp50.ceil();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getTwo();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.newDfp((int) (byte) 10);
        java.lang.Throwable throwable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, localizable65, objArray70);
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, localizable73, objArray78);
        mathIllegalArgumentException71.addSuppressed((java.lang.Throwable) mathIllegalArgumentException79);
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Object[] objArray87 = new java.lang.Object[] { (byte) 1, 10, 1L, 10.0d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable81, localizable82, objArray87);
        org.apache.commons.math.exception.util.Localizable localizable89 = mathIllegalArgumentException88.getSpecificPattern();
        java.lang.Object[] objArray91 = new java.lang.Object[] { mathIllegalArgumentException79, localizable89, 16 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable63, objArray91);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException93 = new org.apache.commons.math.exception.MathRuntimeException(throwable59, localizable60, localizable61, objArray91);
        boolean boolean94 = dfp58.equals((java.lang.Object) localizable60);
        int int95 = dfp58.classify();
        boolean boolean96 = dfp50.greaterThan(dfp58);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-4) + "'", int17 == (-4));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + roundingMode34 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode34.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-4) + "'", int41 == (-4));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-4) + "'", int42 == (-4));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNull(localizable89);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5227830126997552d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField4.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField11.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.newDfp();
        int int15 = dfp14.log10();
        int int16 = dfp14.log10();
        boolean boolean17 = dfp9.lessThan(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getTwo();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4) + "'", int15 == (-4));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NaN, 1.6838679518167485d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
        int int2 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        int[] intArray6 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister3.setSeed(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister1.setSeed(intArray6);
        long long11 = mersenneTwister1.nextLong();
        long long12 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 402613113023623976L + "'", long11 == 402613113023623976L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 6236757884745972499L + "'", long12 == 6236757884745972499L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) '4');
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp(2.3978952727983707d);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 20 + "'", int4 == 20);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.log10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.sqrt();
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfp4.multiply(dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-4) + "'", int5 == (-4));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000003d + "'", double1 == 100.00000000000003d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (short) -1, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 0 + "'", number4.equals((short) 0));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((long) '#');
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField13.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField13.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField20.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp();
        int int24 = dfp23.log10();
        int int25 = dfp23.log10();
        boolean boolean26 = dfp18.lessThan(dfp23);
        int int27 = dfp23.intValue();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField29.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp();
        int int33 = dfp32.log10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.ceil();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField36.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode40 = dfpField36.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getE();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField36.getLn5();
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.Dfp.copysign(dfp32, dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.Dfp.copysign(dfp23, dfp32);
        boolean boolean45 = dfp9.unequal(dfp32);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp32.newInstance(0.8997923511366261d);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField49.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.rint();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp52.floor();
        org.apache.commons.math.dfp.Dfp dfp55 = org.apache.commons.math.dfp.Dfp.copysign(dfp47, dfp52);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField57.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField61.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.newDfp();
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField57.newDfp(dfp64);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField57.newDfp((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField68 = dfp67.getField();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField68.newDfp();
        boolean boolean70 = dfp69.isNaN();
        org.apache.commons.math.dfp.Dfp dfp71 = dfp52.subtract(dfp69);
        org.apache.commons.math.dfp.DfpField dfpField73 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField73.getPi();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField73.getLn2();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp75.getTwo();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp52.subtract(dfp76);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-4) + "'", int24 == (-4));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-4) + "'", int25 == (-4));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-4) + "'", int33 == (-4));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + roundingMode40 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode40.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfpField68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 1063681186);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1063681186L + "'", long2 == 1063681186L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp();
        try {
            org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(4978630122362200518L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField5.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10((int) (short) 100);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
        dfpField1.setIEEEFlags(93740670);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        int int8 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 30 + "'", int8 == 30);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9403184054350179d + "'", double1 == 0.9403184054350179d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray4 = new int[] { (byte) -1, (short) -1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray4);
        mersenneTwister1.setSeed(intArray4);
        java.lang.Class<?> wildcardClass7 = intArray4.getClass();
        mersenneTwister0.setSeed(intArray4);
        double double9 = mersenneTwister0.nextGaussian();
        int int11 = mersenneTwister0.nextInt(912482958);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister((long) (byte) -1);
        int[] intArray15 = new int[] { '4' };
        mersenneTwister13.setSeed(intArray15);
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray15);
        int[] intArray21 = new int[] { 100, (short) 10, (short) 100 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister(intArray21);
        mersenneTwister17.setSeed(intArray21);
        mersenneTwister17.setSeed((-323078381150436252L));
        mersenneTwister17.setSeed((long) 8);
        byte[] byteArray28 = new byte[] {};
        mersenneTwister17.nextBytes(byteArray28);
        mersenneTwister0.nextBytes(byteArray28);
        mersenneTwister0.setSeed((long) 910393425);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4588770968736724d + "'", double9 == 1.4588770968736724d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 910393425 + "'", int11 == 910393425);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(byteArray28);
    }
}

