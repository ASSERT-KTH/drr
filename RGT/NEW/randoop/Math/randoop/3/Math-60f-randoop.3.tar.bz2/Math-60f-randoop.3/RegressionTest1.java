import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (short) -1, number20, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable23 = outOfRangeException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Throwable throwable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, localizable26, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException17, localizable23, objArray27);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, localizable37, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("hi!", objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(throwable15, localizable23, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable7, objArray38);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 10.0d, (java.lang.Number) 77, true);
        java.lang.Number number47 = numberIsTooLargeException46.getMax();
        java.lang.Throwable[] throwableArray48 = numberIsTooLargeException46.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 77 + "'", number47.equals(77));
        org.junit.Assert.assertNotNull(throwableArray48);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextBeta(0.10050340356651512d, 2.7512950036679866E-5d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9999999982463432d + "'", double6 == 0.9999999982463432d);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        double double9 = randomDataImpl0.nextBeta(1.6704649792860586d, (double) 10);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
//        long long12 = randomDataImpl10.nextPoisson((double) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl13.getStandardDeviation();
//        double double15 = normalDistributionImpl13.getMean();
//        double double17 = normalDistributionImpl13.density(0.0d);
//        double double18 = randomDataImpl10.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double19 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double22 = randomDataImpl0.nextBeta(0.9061879047873144d, 12.801827480081469d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution23 = null;
//        try {
//            int int24 = randomDataImpl0.nextInversionDeviate(integerDistribution23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 15L + "'", long6 == 15L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.15749570706959562d + "'", double9 == 0.15749570706959562d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.3989422804014327d + "'", double17 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-0.03908467117098427d) + "'", double18 == (-0.03908467117098427d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.5447640507733381d) + "'", double19 == (-0.5447640507733381d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.1668125902320197d + "'", double22 == 0.1668125902320197d);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double2 = org.apache.commons.math.util.FastMath.min(2.038327316204626d, (double) 25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.038327316204626d + "'", double2 == 2.038327316204626d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 7L, 0.12568883201658335d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.808978076818956E-11d + "'", double2 == 8.808978076818956E-11d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1531713279938371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9140547957692365d + "'", double1 == 0.9140547957692365d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 10, (java.lang.Number) (byte) 1, number2);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 10 + "'", number4.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        double double4 = randomDataImpl0.nextChiSquare(1.5707963267948966d);
//        double double7 = randomDataImpl0.nextF(1.0000000000005154d, 145.43177371950645d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.438939466091658d + "'", double4 == 3.438939466091658d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.4315007549717104E-4d + "'", double7 == 2.4315007549717104E-4d);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        int int10 = randomDataImpl7.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double12 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        normalDistributionImpl11.reseedRandomGenerator((long) (short) 0);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        normalDistributionImpl11.reseedRandomGenerator(5L);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1308472440325117E-4d + "'", double6 == 1.1308472440325117E-4d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.8331759204700901d) + "'", double12 == (-0.8331759204700901d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.26399325260676d) + "'", double15 == (-0.26399325260676d));
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        long long8 = randomDataImpl0.nextSecureLong((long) 0, 52L);
//        try {
//            double double11 = randomDataImpl0.nextBeta(1.0000000000005154d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.196");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.689150618558509d + "'", double5 == 1.689150618558509d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.5667583460678747d, (java.lang.Number) 2.1556157735575975E15d, (java.lang.Number) (-1.4880270450331359d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 72L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.26241737750193517d) + "'", double1 == (-0.26241737750193517d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        double double8 = randomDataImpl0.nextChiSquare((double) 19L);
//        try {
//            int int11 = randomDataImpl0.nextZipf(21, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 23.115762530117518d + "'", double8 == 23.115762530117518d);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.density(0.0d);
//        double double7 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        int int10 = randomDataImpl1.nextZipf(42, 1.1579869585617917d);
//        try {
//            int int13 = randomDataImpl1.nextInt(58, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 58 is larger than, or equal to, the maximum (10): lower bound (58) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3989422804014327d + "'", double6 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.19206562286621795d + "'", double7 == 0.19206562286621795d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double2 = normalDistributionImpl0.getMean();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        double double5 = normalDistributionImpl0.sample();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8025330637390305d + "'", double5 == 0.8025330637390305d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.special.Erf.erf(0.9074467814501962d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8006212530493106d + "'", double1 == 0.8006212530493106d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable1, objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        java.lang.String str5 = maxIterationsExceededException3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str5.equals("org.apache.commons.math.MaxIterationsExceededException: "));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable8, objArray12);
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 100L, number17, (java.lang.Number) 57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 16L);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, (java.lang.Number) (short) -1, number28, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable31 = outOfRangeException30.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Throwable throwable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, localizable34, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException25, localizable31, objArray35);
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 100L, number40, (java.lang.Number) 57);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable43, localizable44, objArray45);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException(29, localizable31, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Throwable throwable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(throwable50, localizable51, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray52);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException(4, localizable31, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable8, objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Number number63 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException(localizable61, (java.lang.Number) (short) -1, number63, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable66 = outOfRangeException65.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Throwable throwable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(throwable68, localizable69, objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray70);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException60, localizable66, objArray70);
        java.lang.Number number75 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException77 = new org.apache.commons.math.exception.OutOfRangeException(localizable66, (java.lang.Number) 100L, number75, (java.lang.Number) 57);
        java.lang.Throwable throwable78 = null;
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        java.lang.Object[] objArray80 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(throwable78, localizable79, objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(29, localizable66, objArray80);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException(localizable8, objArray80);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException("4f5b758", objArray80);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray80);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 14, (long) 178);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.density(0.0d);
//        double double7 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        double double9 = normalDistributionImpl2.cumulativeProbability(0.13313701469396125d);
//        double[] doubleArray11 = normalDistributionImpl2.sample(10);
//        double double12 = normalDistributionImpl2.sample();
//        double double15 = normalDistributionImpl2.cumulativeProbability((-53.912573722555265d), (double) (short) -1);
//        try {
//            double[] doubleArray17 = normalDistributionImpl2.sample(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3989422804014327d + "'", double6 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.032314183102358014d) + "'", double7 == (-0.032314183102358014d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.552957488893538d + "'", double9 == 0.552957488893538d);
//        org.junit.Assert.assertNotNull(doubleArray11);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.3407149365254844d) + "'", double12 == (-0.3407149365254844d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.15865525393145702d + "'", double15 == 0.15865525393145702d);
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        double double8 = randomDataImpl0.nextChiSquare((double) 19L);
//        int[] intArray11 = randomDataImpl0.nextPermutation(68, 48);
//        double double14 = randomDataImpl0.nextGaussian((double) 47, 1.233403117511217d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 37 + "'", int6 == 37);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 23.75280727114798d + "'", double8 == 23.75280727114798d);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 46.570030839615605d + "'", double14 == 46.570030839615605d);
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8438669798515654d + "'", double1 == 2.8438669798515654d);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        try {
//            long long8 = randomDataImpl0.nextSecureLong((long) 86, (long) 78);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 86 is larger than, or equal to, the maximum (78): lower bound (86) must be strictly less than upper bound (78)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 38, 0.7886151878278062d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 17.61332455496356d + "'", double2 == 17.61332455496356d);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.density(0.0d);
//        double double7 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        normalDistributionImpl2.reseedRandomGenerator((long) '4');
//        try {
//            double double11 = normalDistributionImpl2.inverseCumulativeProbability((double) 25);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 25 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3989422804014327d + "'", double6 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5315012770045401d + "'", double7 == 0.5315012770045401d);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int int2 = org.apache.commons.math.util.FastMath.min(67, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.7535193459130228d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 100L, number16, (java.lang.Number) 57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 16L);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(throwable23, localizable24, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable28 = mathIllegalArgumentException27.getSpecificPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (short) -1, number34, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Throwable throwable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(throwable39, localizable40, objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException31, localizable37, objArray41);
        java.lang.Throwable throwable45 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Number number50 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) (short) -1, number50, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable53 = outOfRangeException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Throwable throwable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(throwable55, localizable56, objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException47, localizable53, objArray57);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException(localizable53, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(throwable66, localizable67, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException("hi!", objArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(throwable45, localizable53, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable37, objArray68);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException27, "3", objArray68);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException20, "", objArray68);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNull(localizable28);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.sin(218.41579693359327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9971807567237755d) + "'", double1 == (-0.9971807567237755d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.special.Erf.erf((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (short) -1, number20, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable23 = outOfRangeException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Throwable throwable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, localizable26, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException17, localizable23, objArray27);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, localizable37, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("hi!", objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(throwable15, localizable23, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable7, objArray38);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 10.0d, (java.lang.Number) 77, true);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooLargeException46.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int int1 = org.apache.commons.math.util.FastMath.abs(23);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23 + "'", int1 == 23);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.3355204343494705d), number1, (java.lang.Number) 2.7512950036679866E-5d);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Number number9 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) (short) -1, number9, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException11.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Throwable throwable14 = null;
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        java.lang.Object[] objArray16 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, localizable15, objArray16);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray16);
//        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, localizable12, objArray16);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl();
//        long long28 = randomDataImpl26.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl26, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray30);
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable12, objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        java.lang.Throwable throwable35 = null;
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        java.lang.Object[] objArray37 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(throwable35, localizable36, objArray37);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray37);
//        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray37);
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable12, objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        java.lang.Number number44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable42, (java.lang.Number) (short) -1, number44, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable47 = outOfRangeException46.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable48 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable48, (java.lang.Number) (short) 1);
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException50);
//        java.lang.Number number52 = notStrictlyPositiveException50.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        java.lang.Throwable throwable57 = null;
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        java.lang.Object[] objArray59 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException(throwable57, localizable58, objArray59);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, objArray59);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable55, objArray59);
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException50, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray59);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable47, objArray59);
//        org.apache.commons.math.exception.util.Localizable localizable67 = null;
//        java.lang.Throwable throwable68 = null;
//        org.apache.commons.math.exception.util.Localizable localizable69 = null;
//        java.lang.Object[] objArray70 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(throwable68, localizable69, objArray70);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable67, objArray70);
//        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("", objArray70);
//        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray70);
//        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException41, localizable47, objArray70);
//        org.apache.commons.math.exception.util.Localizable localizable76 = null;
//        org.apache.commons.math.exception.util.Localizable localizable77 = null;
//        org.apache.commons.math.exception.util.Localizable localizable78 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl79 = new org.apache.commons.math.random.RandomDataImpl();
//        long long81 = randomDataImpl79.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray83 = new java.lang.Object[] { randomDataImpl79, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable77, localizable78, objArray83);
//        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException(localizable76, objArray83);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException86 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, objArray83);
//        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException(localizable0, objArray83);
//        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 5L + "'", long28 == 5L);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (short) 1 + "'", number52.equals((short) 1));
//        org.junit.Assert.assertNotNull(objArray59);
//        org.junit.Assert.assertNotNull(objArray70);
//        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 6L + "'", long81 == 6L);
//        org.junit.Assert.assertNotNull(objArray83);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.67416883827634d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 92);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.214965293162436d + "'", double1 == 5.214965293162436d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.1531713279938371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9971807567237755d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017404087442358464d) + "'", double1 == (-0.017404087442358464d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.3970841047274319d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06981317007977318d + "'", double1 == 0.06981317007977318d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.812074794858537d, 0.05166500343733741d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0715827316170445d + "'", double2 == 1.0715827316170445d);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        java.lang.Number number4 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        java.lang.Throwable throwable9 = null;
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
//        long long23 = randomDataImpl21.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { randomDataImpl21, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray25);
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable7, objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable28 = mathException27.getSpecificPattern();
//        java.lang.Object[] objArray29 = mathException27.getArguments();
//        java.lang.String str30 = mathException27.toString();
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 7L + "'", long23 == 7L);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertNull(localizable28);
//        org.junit.Assert.assertNotNull(objArray29);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1, (java.lang.Number) 0.8504636186597091d, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (short) -1, number7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = outOfRangeException9.getLo();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.Throwable[] throwableArray12 = outOfRangeException9.getSuppressed();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Object[] objArray14 = outOfRangeException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 18L, false);
        java.lang.Number number20 = numberIsTooLargeException19.getMax();
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 18L + "'", number20.equals(18L));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 6.0f, 61.34806127363477d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 61.34806127363477d + "'", double2 == 61.34806127363477d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.44375573982337235d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41675272499058313d + "'", double1 == 0.41675272499058313d);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        try {
//            double double11 = randomDataImpl0.nextCauchy(11013.214150898206d, (-1.557939555426501d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.558 is smaller than, or equal to, the minimum (0): scale (-1.558)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 33 + "'", int6 == 33);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.4260624389053682d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Number number5 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        java.lang.Throwable throwable10 = null;
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        java.lang.Object[] objArray12 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable8, objArray12);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.exception.util.Localizable localizable21 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl22 = new org.apache.commons.math.random.RandomDataImpl();
//        long long24 = randomDataImpl22.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray26 = new java.lang.Object[] { randomDataImpl22, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable21, objArray26);
//        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable8, objArray26);
//        org.apache.commons.math.exception.util.Localizable localizable29 = null;
//        java.lang.Throwable throwable30 = null;
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        java.lang.Object[] objArray32 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(throwable30, localizable31, objArray32);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray32);
//        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable8, objArray32);
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) (short) 1);
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException38);
//        java.lang.Number number40 = notStrictlyPositiveException38.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        java.lang.Throwable throwable45 = null;
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        java.lang.Object[] objArray47 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(throwable45, localizable46, objArray47);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, objArray47);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable43, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException38, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray47);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray47);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 154.44177134794404d, (java.lang.Number) 1.0f, true);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable59 = null;
//        java.lang.Number number61 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException63 = new org.apache.commons.math.exception.OutOfRangeException(localizable59, (java.lang.Number) (short) -1, number61, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable64 = outOfRangeException63.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable65 = null;
//        java.lang.Throwable throwable66 = null;
//        org.apache.commons.math.exception.util.Localizable localizable67 = null;
//        java.lang.Object[] objArray68 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(throwable66, localizable67, objArray68);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException58, localizable64, objArray68);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable8, objArray68);
//        org.apache.commons.math.exception.util.Localizable localizable74 = null;
//        java.lang.Throwable throwable75 = null;
//        org.apache.commons.math.exception.util.Localizable localizable76 = null;
//        java.lang.Object[] objArray77 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(throwable75, localizable76, objArray77);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable74, objArray77);
//        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("", objArray77);
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(localizable8, objArray77);
//        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray12);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 15L + "'", long24 == 15L);
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertNotNull(objArray32);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (short) 1 + "'", number40.equals((short) 1));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + localizable64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable64.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertNotNull(objArray77);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(46.0d, (double) 59L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.6560647379324626d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.3140345999234646d), (java.lang.Number) (-0.017404087442358464d), (java.lang.Number) (-53.91257372255526d));
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double1 = normalDistributionImpl0.getStandardDeviation();
//        double double2 = normalDistributionImpl0.getMean();
//        double double4 = normalDistributionImpl0.density(0.0d);
//        double double6 = normalDistributionImpl0.inverseCumulativeProbability(1.0d);
//        double double8 = normalDistributionImpl0.cumulativeProbability(0.38086344735250344d);
//        double double10 = normalDistributionImpl0.cumulativeProbability(4.644298430695373d);
//        double double11 = normalDistributionImpl0.sample();
//        double double12 = normalDistributionImpl0.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3989422804014327d + "'", double4 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6483477116495999d + "'", double8 == 0.6483477116495999d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.999998293829917d + "'", double10 == 0.999998293829917d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.03242939688877998d) + "'", double11 == (-0.03242939688877998d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.009999500037496774d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        randomDataImpl0.reSeed((long) (byte) 0);
//        try {
//            randomDataImpl0.setSecureAlgorithm("{0} out of [{1}, {2}] range", "{0} out of [{1}, {2}] range");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: {0} out of [{1}, {2}] range");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.26241737750193517d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7691899141354063d + "'", double1 == 0.7691899141354063d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 100L, number16, (java.lang.Number) 57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) (short) -1, number23, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable26 = outOfRangeException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Throwable throwable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(throwable28, localizable29, objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException20, localizable26, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) (short) -1, number38, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable41 = outOfRangeException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable43, localizable44, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException35, localizable41, objArray45);
        java.lang.Number number50 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) 100L, number50, (java.lang.Number) 57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 16L);
        java.lang.Object[] objArray56 = new java.lang.Object[] { 16L, "hi!" };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable26, objArray56);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Throwable throwable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(throwable59, localizable60, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray61);
        java.lang.Throwable[] throwableArray64 = mathIllegalArgumentException63.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable26, (java.lang.Object[]) throwableArray64);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(throwableArray64);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.log(4.116563569575848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4150187302645454d + "'", double1 == 1.4150187302645454d);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        java.lang.Number number4 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        java.lang.Throwable throwable9 = null;
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
//        long long23 = randomDataImpl21.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { randomDataImpl21, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray25);
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable7, objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Throwable throwable29 = null;
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        java.lang.Object[] objArray31 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(throwable29, localizable30, objArray31);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray31);
//        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable7, objArray31);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Number number41 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) (short) -1, number41, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable44 = outOfRangeException43.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Throwable throwable46 = null;
//        org.apache.commons.math.exception.util.Localizable localizable47 = null;
//        java.lang.Object[] objArray48 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(throwable46, localizable47, objArray48);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray48);
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException38, localizable44, objArray48);
//        java.lang.Number number53 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable44, (java.lang.Number) 100L, number53, (java.lang.Number) 57);
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable56, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
//        org.apache.commons.math.exception.util.Localizable localizable61 = null;
//        java.lang.Object[] objArray62 = null;
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException60, localizable61, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable65 = null;
//        java.lang.Throwable throwable66 = null;
//        org.apache.commons.math.exception.util.Localizable localizable67 = null;
//        java.lang.Object[] objArray68 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(throwable66, localizable67, objArray68);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, objArray68);
//        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException63, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable44, objArray68);
//        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("maximal number of iterations ({0}) exceeded", objArray68);
//        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException34, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray68);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 9L + "'", long23 == 9L);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(objArray68);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 54L, (java.lang.Number) 62, false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (short) -1, number20, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable23 = outOfRangeException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Throwable throwable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, localizable26, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException17, localizable23, objArray27);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, localizable37, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("hi!", objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(throwable15, localizable23, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable7, objArray38);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 10.0d, (java.lang.Number) 77, true);
        java.lang.Number number47 = numberIsTooLargeException46.getMax();
        java.lang.Number number48 = numberIsTooLargeException46.getMax();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 77 + "'", number47.equals(77));
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 77 + "'", number48.equals(77));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 63, 0.5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.342965876290454E-107d + "'", double2 == 3.342965876290454E-107d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException(throwable3, localizable4, objArray5);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "maximal number of iterations ({0}) exceeded", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray5);
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1, (java.lang.Number) 0.8504636186597091d, (java.lang.Number) 100L);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        java.lang.Number number7 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (short) -1, number7, (java.lang.Number) 100.0f);
//        java.lang.Number number10 = outOfRangeException9.getLo();
//        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Number number16 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (short) -1, number16, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable19 = outOfRangeException18.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        java.lang.Throwable throwable21 = null;
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        java.lang.Object[] objArray23 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, localizable22, objArray23);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray23);
//        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException13, localizable19, objArray23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl33 = new org.apache.commons.math.random.RandomDataImpl();
//        long long35 = randomDataImpl33.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { randomDataImpl33, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, objArray37);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable19, objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable40 = null;
//        java.lang.Throwable throwable41 = null;
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        java.lang.Object[] objArray43 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(throwable41, localizable42, objArray43);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray43);
//        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable19, objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable47 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) (short) 1);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException49);
//        java.lang.Number number51 = notStrictlyPositiveException49.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable54 = null;
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        java.lang.Throwable throwable56 = null;
//        org.apache.commons.math.exception.util.Localizable localizable57 = null;
//        java.lang.Object[] objArray58 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(throwable56, localizable57, objArray58);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray58);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable54, objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException49, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray58);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, objArray58);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 154.44177134794404d, (java.lang.Number) 1.0f, true);
//        org.apache.commons.math.exception.util.Localizable localizable69 = null;
//        java.lang.Number number71 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math.exception.OutOfRangeException(localizable69, (java.lang.Number) (short) -1, number71, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable74 = outOfRangeException73.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable75 = null;
//        org.apache.commons.math.exception.util.Localizable localizable76 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException80 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable76, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
//        org.apache.commons.math.exception.util.Localizable localizable81 = null;
//        java.lang.Object[] objArray82 = null;
//        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException80, localizable81, objArray82);
//        org.apache.commons.math.exception.util.Localizable localizable85 = null;
//        java.lang.Throwable throwable86 = null;
//        org.apache.commons.math.exception.util.Localizable localizable87 = null;
//        java.lang.Object[] objArray88 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException(throwable86, localizable87, objArray88);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable85, objArray88);
//        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException83, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray88);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable75, objArray88);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException93 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable74, objArray88);
//        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable19, objArray88);
//        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
//        org.junit.Assert.assertNull(number10);
//        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray23);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 13L + "'", long35 == 13L);
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (short) 1 + "'", number51.equals((short) 1));
//        org.junit.Assert.assertNotNull(objArray58);
//        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray88);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 100L, number16, (java.lang.Number) 57);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 0.0d, (java.lang.Number) 1.5860134523134308E15d, true);
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, localizable25, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray26);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray26);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeed(5L);
//        int int16 = randomDataImpl0.nextHypergeometric((int) (byte) 100, 0, 68);
//        try {
//            int int19 = randomDataImpl0.nextSecureInt(0, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 56 + "'", int6 == 56);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(77);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int1 = org.apache.commons.math.util.FastMath.round(70.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 70 + "'", int1 == 70);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextGaussian((double) (byte) 0, 1.8690199572373172d);
//        try {
//            int int9 = randomDataImpl0.nextInt(39, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 39 is larger than, or equal to, the maximum (0): lower bound (39) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-3.612410691432347d) + "'", double6 == (-3.612410691432347d));
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, number2, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.08828834728448533d, (java.lang.Number) 2.4315007549717104E-4d, true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9224869535749408E-5d + "'", double1 == 1.9224869535749408E-5d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 221206.6960055904d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) -1, number8, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Throwable throwable13 = null;
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, localizable14, objArray15);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable11, objArray15);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
//        long long27 = randomDataImpl25.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { randomDataImpl25, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray29);
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable11, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Throwable throwable34 = null;
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Object[] objArray36 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, localizable35, objArray36);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray36);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray36);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        java.lang.Number number43 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) (short) -1, number43, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable46 = outOfRangeException45.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable47 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) (short) 1);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException49);
//        java.lang.Number number51 = notStrictlyPositiveException49.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable54 = null;
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        java.lang.Throwable throwable56 = null;
//        org.apache.commons.math.exception.util.Localizable localizable57 = null;
//        java.lang.Object[] objArray58 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(throwable56, localizable57, objArray58);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray58);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable54, objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException49, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable46, objArray58);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        java.lang.Throwable throwable67 = null;
//        org.apache.commons.math.exception.util.Localizable localizable68 = null;
//        java.lang.Object[] objArray69 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(throwable67, localizable68, objArray69);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, objArray69);
//        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("", objArray69);
//        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray69);
//        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException40, localizable46, objArray69);
//        org.apache.commons.math.exception.util.Localizable localizable75 = null;
//        org.apache.commons.math.exception.util.Localizable localizable76 = null;
//        org.apache.commons.math.exception.util.Localizable localizable77 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl78 = new org.apache.commons.math.random.RandomDataImpl();
//        long long80 = randomDataImpl78.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray82 = new java.lang.Object[] { randomDataImpl78, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, localizable77, objArray82);
//        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException(localizable75, objArray82);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException85 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray82);
//        java.lang.Object[] objArray86 = mathIllegalArgumentException85.getArguments();
//        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 10L + "'", long27 == 10L);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (short) 1 + "'", number51.equals((short) 1));
//        org.junit.Assert.assertNotNull(objArray58);
//        org.junit.Assert.assertNotNull(objArray69);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 13L + "'", long80 == 13L);
//        org.junit.Assert.assertNotNull(objArray82);
//        org.junit.Assert.assertNotNull(objArray86);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int int2 = org.apache.commons.math.util.FastMath.max(52, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, number2, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (short) 1);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException8);
        java.lang.Number number10 = notStrictlyPositiveException8.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, localizable16, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable13, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException8, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable5, objArray17);
        java.lang.Throwable throwable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(throwable23, localizable24, objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26);
        java.lang.Object[] objArray28 = mathException27.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable5, objArray28);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 1 + "'", number10.equals((short) 1));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        try {
//            java.lang.String str10 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 36L + "'", long6 == 36L);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', 0.41305704294326967d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 71);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 71L + "'", long1 == 71L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 100L, number16, (java.lang.Number) 57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 16L);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable25, (java.lang.Number) (short) -1, number27, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable30 = outOfRangeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Throwable throwable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(throwable32, localizable33, objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException24, localizable30, objArray34);
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 100L, number39, (java.lang.Number) 57);
        java.lang.Throwable throwable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(throwable42, localizable43, objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(29, localizable30, objArray44);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Throwable throwable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(throwable49, localizable50, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray51);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException("", objArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException(4, localizable30, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(localizable7, objArray51);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 6.0d);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-1L), (java.lang.Number) 1.5707963267948966d, true);
        java.lang.Object[] objArray5 = numberIsTooSmallException4.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.String str8 = numberIsTooSmallException4.toString();
        boolean boolean9 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (1.571)" + "'", str8.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (1.571)"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.385751988502056d, 0.34170741954613765d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.329033153951135d + "'", double2 == 1.329033153951135d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        long long2 = org.apache.commons.math.util.FastMath.min(70L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.7691899141354063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6464581529722262d + "'", double1 == 0.6464581529722262d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.cos(145.43177371950645d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6070036153979338d + "'", double1 == 0.6070036153979338d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.0139577778453165E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0139577778668735E-6d + "'", double1 == 4.0139577778668735E-6d);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double[] doubleArray7 = normalDistributionImpl4.sample((int) '#');
//        double double9 = normalDistributionImpl4.density(0.19783611111821534d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 23 + "'", int3 == 23);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.457728291001428d + "'", double5 == 1.457728291001428d);
//        org.junit.Assert.assertNotNull(doubleArray7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.39121104928144995d + "'", double9 == 0.39121104928144995d);
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        randomDataImpl0.reSeed((long) (byte) 0);
//        randomDataImpl0.reSeed();
//        double double13 = randomDataImpl0.nextT(0.9999999982463432d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 31L + "'", long6 == 31L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.116963700636854d) + "'", double13 == (-1.116963700636854d));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) 1, (java.lang.Number) 0.8504636186597091d, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) -1, number8, (java.lang.Number) 100.0f);
        java.lang.Number number11 = outOfRangeException10.getLo();
        outOfRangeException5.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Throwable[] throwableArray13 = outOfRangeException10.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("74d3d7d0499f3df1843d0e0d2d974ce1d30a74b", (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        java.lang.String str12 = randomDataImpl0.nextSecureHexString(1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 22 + "'", int6 == 22);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9" + "'", str12.equals("9"));
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(throwable2, localizable3, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathIllegalArgumentException6.getSpecificPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (short) -1, number13, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Throwable throwable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, localizable19, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException10, localizable16, objArray20);
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, (java.lang.Number) (short) -1, number29, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable32 = outOfRangeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Throwable throwable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, localizable35, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException26, localizable32, objArray36);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(throwable45, localizable46, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("hi!", objArray47);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(throwable24, localizable32, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable16, objArray47);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException6, "3", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("f3c305485b5ef34c832287c18843a186a1de901407eaf93b953cdf41bc5cbebf1ff83269478d35d06576d00313224d69d7ca", objArray47);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray47);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        double double7 = randomDataImpl0.nextT(1.0000000000005154d);
//        int int10 = randomDataImpl0.nextInt(36, 45);
//        randomDataImpl0.reSeed((long) (short) -1);
//        java.lang.String str14 = randomDataImpl0.nextSecureHexString(7);
//        randomDataImpl0.reSeed();
//        try {
//            int int19 = randomDataImpl0.nextHypergeometric(42, 71, 77);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 71 is larger than the maximum (42): number of successes (71) must be less than or equal to population size (42)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-3.279468160453441d) + "'", double7 == (-3.279468160453441d));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 43 + "'", int10 == 43);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "26752fb" + "'", str14.equals("26752fb"));
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) -1, number8, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Throwable throwable13 = null;
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, localizable14, objArray15);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable11, objArray15);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
//        long long27 = randomDataImpl25.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { randomDataImpl25, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray29);
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable11, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Throwable throwable34 = null;
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Object[] objArray36 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, localizable35, objArray36);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray36);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray36);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        java.lang.Number number43 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) (short) -1, number43, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable46 = outOfRangeException45.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable47 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) (short) 1);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException49);
//        java.lang.Number number51 = notStrictlyPositiveException49.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable54 = null;
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        java.lang.Throwable throwable56 = null;
//        org.apache.commons.math.exception.util.Localizable localizable57 = null;
//        java.lang.Object[] objArray58 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(throwable56, localizable57, objArray58);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray58);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable54, objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException49, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable46, objArray58);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        java.lang.Throwable throwable67 = null;
//        org.apache.commons.math.exception.util.Localizable localizable68 = null;
//        java.lang.Object[] objArray69 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(throwable67, localizable68, objArray69);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, objArray69);
//        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("", objArray69);
//        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray69);
//        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException40, localizable46, objArray69);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException78 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) 61L, (java.lang.Number) 0.8871428437982151d, true);
//        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 9L + "'", long27 == 9L);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (short) 1 + "'", number51.equals((short) 1));
//        org.junit.Assert.assertNotNull(objArray58);
//        org.junit.Assert.assertNotNull(objArray69);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 0, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.8379560409386598d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0767787638023264d) + "'", double1 == (-0.0767787638023264d));
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        java.lang.String str7 = randomDataImpl0.nextSecureHexString(39);
//        try {
//            int int10 = randomDataImpl0.nextInt(77, 69);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 77 is larger than, or equal to, the maximum (69): lower bound (77) must be strictly less than upper bound (69)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ef21946fdaaf79c339c0d46a838a5b8a3f3c8dd" + "'", str7.equals("ef21946fdaaf79c339c0d46a838a5b8a3f3c8dd"));
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 71, (double) (byte) -1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) (short) -1, number6, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(throwable11, localizable12, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, localizable9, objArray13);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 100L, number18, (java.lang.Number) 57);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, localizable22, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(29, localizable9, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Throwable throwable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(throwable28, localizable29, objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray30);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("", objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException(4, localizable9, objArray30);
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 3.812074794858537d, number36, true);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("org.apache.commons.math.ConvergenceException: org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray1);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test104");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong(70L, (long) 91);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "54b4e8f");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 54b4e8f");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 90L + "'", long3 == 90L);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 45L, (double) 96);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3054673447634242E-9d + "'", double2 == 2.3054673447634242E-9d);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) -1, number8, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Throwable throwable13 = null;
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, localizable14, objArray15);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable11, objArray15);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
//        long long27 = randomDataImpl25.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { randomDataImpl25, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray29);
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable11, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Throwable throwable34 = null;
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Object[] objArray36 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, localizable35, objArray36);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray36);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray36);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) (-1L), (java.lang.Number) 1.5707963267948966d, true);
//        java.lang.Object[] objArray47 = numberIsTooSmallException46.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable48 = numberIsTooSmallException46.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException46.getGeneralPattern();
//        java.lang.Number number50 = numberIsTooSmallException46.getArgument();
//        java.lang.Throwable[] throwableArray51 = numberIsTooSmallException46.getSuppressed();
//        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "maximal number of iterations ({0}) exceeded", (java.lang.Object[]) throwableArray51);
//        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 14L + "'", long27 == 14L);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
//        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
//        org.junit.Assert.assertTrue("'" + number50 + "' != '" + (-1L) + "'", number50.equals((-1L)));
//        org.junit.Assert.assertNotNull(throwableArray51);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-1L), (java.lang.Number) 1.5707963267948966d, true);
        java.lang.Object[] objArray5 = numberIsTooSmallException4.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        java.lang.Number number8 = numberIsTooSmallException4.getArgument();
        java.lang.Number number9 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1L) + "'", number8.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.5707963267948966d + "'", number9.equals(1.5707963267948966d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray1 = mathException0.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
        java.lang.Number number7 = numberIsTooSmallException6.getMin();
        mathException0.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        boolean boolean9 = numberIsTooSmallException6.getBoundIsAllowed();
        java.lang.Object[] objArray10 = numberIsTooSmallException6.getArguments();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 0 + "'", number7.equals((short) 0));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2111326.1189428633d, number1, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.String str4 = convergenceException3.getPattern();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long1 = org.apache.commons.math.util.FastMath.abs(7L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7L + "'", long1 == 7L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable1, objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException3.getGeneralPattern();
        int int6 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        long long8 = randomDataImpl0.nextSecureLong((long) (short) -1, (long) 23);
//        double double11 = randomDataImpl0.nextGaussian(0.0d, (double) (short) 100);
//        java.lang.String str13 = randomDataImpl0.nextHexString(36);
//        randomDataImpl0.reSeed((long) 90);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 94 + "'", int3 == 94);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.9604712468905262d + "'", double5 == 0.9604712468905262d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 45.196337639631125d + "'", double11 == 45.196337639631125d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "91091c93f705d9660f72276860d5dbbeedbe" + "'", str13.equals("91091c93f705d9660f72276860d5dbbeedbe"));
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        java.lang.Number number4 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = null;
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13, localizable14, objArray15);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        java.lang.Throwable throwable19 = null;
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        java.lang.Object[] objArray21 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable19, localizable20, objArray21);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray21);
//        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray21);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray21);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable7, objArray21);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl27 = new org.apache.commons.math.random.RandomDataImpl();
//        int int30 = randomDataImpl27.nextInt((int) (short) 0, (int) 'a');
//        int int34 = randomDataImpl27.nextHypergeometric(100, 0, 29);
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) 1, (java.lang.Number) 0.8504636186597091d, (java.lang.Number) 100L);
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        java.lang.Number number43 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) (short) -1, number43, (java.lang.Number) 100.0f);
//        java.lang.Number number46 = outOfRangeException45.getLo();
//        outOfRangeException40.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Throwable[] throwableArray48 = outOfRangeException45.getSuppressed();
//        java.lang.Number number49 = outOfRangeException45.getLo();
//        java.lang.Object[] objArray50 = outOfRangeException45.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable51 = outOfRangeException45.getGeneralPattern();
//        java.lang.Object[] objArray53 = new java.lang.Object[] { int34, Double.POSITIVE_INFINITY, outOfRangeException45, (-0.860531353171073d) };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable7, objArray53);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray21);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 94 + "'", int30 == 94);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNull(number46);
//        org.junit.Assert.assertNotNull(throwableArray48);
//        org.junit.Assert.assertNull(number49);
//        org.junit.Assert.assertNotNull(objArray50);
//        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray53);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Number number5 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        java.lang.Throwable throwable10 = null;
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        java.lang.Object[] objArray12 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable8, objArray12);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        java.lang.Throwable throwable21 = null;
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        java.lang.Object[] objArray23 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, localizable22, objArray23);
//        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("hi!", objArray23);
//        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(throwable0, localizable8, objArray23);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable29 = null;
//        java.lang.Number number31 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) (short) -1, number31, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable34 = outOfRangeException33.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Throwable throwable36 = null;
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        java.lang.Object[] objArray38 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, localizable37, objArray38);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray38);
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException28, localizable34, objArray38);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.exception.util.Localizable localizable47 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl48 = new org.apache.commons.math.random.RandomDataImpl();
//        long long50 = randomDataImpl48.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray52 = new java.lang.Object[] { randomDataImpl48, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable47, objArray52);
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable34, objArray52);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
//        boolean boolean59 = numberIsTooLargeException58.getBoundIsAllowed();
//        boolean boolean60 = numberIsTooLargeException58.getBoundIsAllowed();
//        java.lang.Throwable[] throwableArray61 = numberIsTooLargeException58.getSuppressed();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable34, (java.lang.Object[]) throwableArray61);
//        java.lang.Object[] objArray63 = null;
//        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException(localizable8, objArray63);
//        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray12);
//        org.junit.Assert.assertNotNull(objArray23);
//        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray38);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 8L + "'", long50 == 8L);
//        org.junit.Assert.assertNotNull(objArray52);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(throwableArray61);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.0d + "'", double1 == 14.0d);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextChiSquare(0.9686884421436269d);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
//        double double13 = randomDataImpl10.nextBeta((double) 28L, (double) '#');
//        org.apache.commons.math.random.RandomGenerator randomGenerator14 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator14);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl16 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double17 = normalDistributionImpl16.getStandardDeviation();
//        double double18 = normalDistributionImpl16.getMean();
//        double double20 = normalDistributionImpl16.density(0.0d);
//        double double21 = randomDataImpl15.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        double double22 = randomDataImpl10.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        double double23 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl16);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 63 + "'", int6 == 63);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.08657956208615027d + "'", double9 == 0.08657956208615027d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.4004824528590755d + "'", double13 == 0.4004824528590755d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.3989422804014327d + "'", double20 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.6952379854347842d) + "'", double21 == (-0.6952379854347842d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9773748734443357d + "'", double22 == 0.9773748734443357d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.4296195831928754d + "'", double23 == 0.4296195831928754d);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.8021798724125822d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.289853441995488d + "'", double1 == 2.289853441995488d);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        long long11 = randomDataImpl0.nextSecureLong((long) 47, (long) 68);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 63L + "'", long11 == 63L);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double2 = normalDistributionImpl0.getMean();
        double double4 = normalDistributionImpl0.density(0.0d);
        java.lang.Class<?> wildcardClass5 = normalDistributionImpl0.getClass();
        double double6 = normalDistributionImpl0.getStandardDeviation();
        double[] doubleArray8 = normalDistributionImpl0.sample(77);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3989422804014327d + "'", double4 == 0.3989422804014327d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 63L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 63.00000000000001d + "'", double1 == 63.00000000000001d);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        java.lang.Number number4 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        java.lang.Throwable throwable9 = null;
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
//        long long23 = randomDataImpl21.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { randomDataImpl21, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray25);
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable7, objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Throwable throwable29 = null;
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        java.lang.Object[] objArray31 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(throwable29, localizable30, objArray31);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray31);
//        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable7, objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable35, (java.lang.Number) (short) 1);
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException37);
//        java.lang.Number number39 = notStrictlyPositiveException37.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        java.lang.Throwable throwable44 = null;
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        java.lang.Object[] objArray46 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(throwable44, localizable45, objArray46);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, objArray46);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable42, objArray46);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException37, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray46);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray46);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException55 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 154.44177134794404d, (java.lang.Number) 1.0f, true);
//        boolean boolean56 = numberIsTooLargeException55.getBoundIsAllowed();
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 5L + "'", long23 == 5L);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (short) 1 + "'", number39.equals((short) 1));
//        org.junit.Assert.assertNotNull(objArray46);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.acos(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 77, (double) 95);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure(0L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-33.04436691401311d) + "'", double3 == (-33.04436691401311d));
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getSpecificPattern();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertNull(localizable2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        int int6 = randomDataImpl0.nextSecureInt(86, (int) 'a');
//        try {
//            double double9 = randomDataImpl0.nextWeibull((-3.2921242664354406d), 154.44177134794404d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.292 is smaller than, or equal to, the minimum (0): shape (-3.292)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        long long8 = randomDataImpl0.nextPoisson((double) (short) 1);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (10)");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (10)");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1593590018270535E-4d + "'", double6 == 1.1593590018270535E-4d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.05166500343733741d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-19.850758323664657d) + "'", double1 == (-19.850758323664657d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(69);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        int int5 = randomDataImpl0.nextInt((int) (short) 1, (int) (short) 100);
//        try {
//            long long8 = randomDataImpl0.nextLong((long) 62, (long) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 62 is larger than, or equal to, the maximum (1): lower bound (62) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 93 + "'", int5 == 93);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 7.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9129311827723892d + "'", double1 == 1.9129311827723892d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.2406599168205174d, (java.lang.Number) (-6.053272382792838d), true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 25);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25L + "'", long1 == 25L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.342965876290454E-107d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3429658762904546E-107d + "'", double1 == 3.3429658762904546E-107d);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        double double7 = randomDataImpl0.nextExponential(3.812074794858537d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 7.15484195759749d + "'", double7 == 7.15484195759749d);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.08747615372308178d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08747615372308178d + "'", double1 == 0.08747615372308178d);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        java.lang.Number number6 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) (short) -1, number6, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException8.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Throwable throwable11 = null;
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Object[] objArray13 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(throwable11, localizable12, objArray13);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, localizable9, objArray13);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable21 = null;
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math.random.RandomDataImpl();
//        long long25 = randomDataImpl23.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray27 = new java.lang.Object[] { randomDataImpl23, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable22, objArray27);
//        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable9, objArray27);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(1, "960bc72", objArray27);
//        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
//        org.junit.Assert.assertNotNull(objArray27);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        java.lang.Object[] objArray2 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, localizable1, objArray2);
//        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
//        mathException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
//        java.lang.Throwable throwable11 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Number number16 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) (short) -1, number16, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable19 = outOfRangeException18.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        java.lang.Throwable throwable21 = null;
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        java.lang.Object[] objArray23 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, localizable22, objArray23);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray23);
//        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException13, localizable19, objArray23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable19, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        java.lang.Throwable throwable32 = null;
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Object[] objArray34 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(throwable32, localizable33, objArray34);
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("hi!", objArray34);
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(throwable11, localizable19, objArray34);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable40 = null;
//        java.lang.Number number42 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) (short) -1, number42, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable45 = outOfRangeException44.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        java.lang.Throwable throwable47 = null;
//        org.apache.commons.math.exception.util.Localizable localizable48 = null;
//        java.lang.Object[] objArray49 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(throwable47, localizable48, objArray49);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray49);
//        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException39, localizable45, objArray49);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable57 = null;
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl59 = new org.apache.commons.math.random.RandomDataImpl();
//        long long61 = randomDataImpl59.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray63 = new java.lang.Object[] { randomDataImpl59, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray63);
//        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable45, objArray63);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
//        boolean boolean70 = numberIsTooLargeException69.getBoundIsAllowed();
//        boolean boolean71 = numberIsTooLargeException69.getBoundIsAllowed();
//        java.lang.Throwable[] throwableArray72 = numberIsTooLargeException69.getSuppressed();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable45, (java.lang.Object[]) throwableArray72);
//        java.lang.Throwable throwable75 = null;
//        org.apache.commons.math.exception.util.Localizable localizable76 = null;
//        java.lang.Object[] objArray77 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(throwable75, localizable76, objArray77);
//        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException78);
//        java.lang.Object[] objArray80 = mathException79.getArguments();
//        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("maximal number of iterations ({0}) exceeded", objArray80);
//        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4, localizable45, objArray80);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException86 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) 38L, (java.lang.Number) 36L, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException90 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) 0.6157425868972846d, (java.lang.Number) 8L, (java.lang.Number) 0.06981317007977318d);
//        org.junit.Assert.assertNotNull(objArray2);
//        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray23);
//        org.junit.Assert.assertNotNull(objArray34);
//        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray49);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 6L + "'", long61 == 6L);
//        org.junit.Assert.assertNotNull(objArray63);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertNotNull(throwableArray72);
//        org.junit.Assert.assertNotNull(objArray77);
//        org.junit.Assert.assertNotNull(objArray80);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        randomDataImpl0.reSeedSecure((long) 77);
//        java.lang.String str10 = randomDataImpl0.nextHexString(86);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36 + "'", int3 == 36);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 544.1045816373166d + "'", double6 == 544.1045816373166d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ab0af9de6a98d345e031ded1e96f474f2c33e11f5127336da161928d2305e4a044b369435b84a8cdd7dcb0" + "'", str10.equals("ab0af9de6a98d345e031ded1e96f474f2c33e11f5127336da161928d2305e4a044b369435b84a8cdd7dcb0"));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1, (java.lang.Number) 0.8504636186597091d, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (short) -1, number7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = outOfRangeException9.getLo();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.Throwable[] throwableArray12 = outOfRangeException9.getSuppressed();
        java.lang.Throwable throwable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(throwable16, localizable17, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "maximal number of iterations ({0}) exceeded", objArray18);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray18);
        java.lang.Number number22 = outOfRangeException9.getHi();
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 100.0f + "'", number22.equals(100.0f));
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        int int10 = randomDataImpl7.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double12 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        normalDistributionImpl11.reseedRandomGenerator((long) (short) 0);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double16 = normalDistributionImpl11.getStandardDeviation();
//        double double18 = normalDistributionImpl11.density(0.9729339806495481d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 38 + "'", int3 == 38);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.303317702190892E-7d + "'", double6 == 5.303317702190892E-7d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 38 + "'", int10 == 38);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2434911360094818d + "'", double12 == 0.2434911360094818d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.519690377613997d) + "'", double15 == (-0.519690377613997d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.24851829894375121d + "'", double18 == 0.24851829894375121d);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 1, 0.3788032778768237d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double2 = normalDistributionImpl0.getMean();
        double double4 = normalDistributionImpl0.density(0.0d);
        java.lang.Class<?> wildcardClass5 = normalDistributionImpl0.getClass();
        double double7 = normalDistributionImpl0.density(1.457728291001428d);
        try {
            double double10 = normalDistributionImpl0.cumulativeProbability((double) 60L, 0.13694604834661991d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3989422804014327d + "'", double4 == 0.3989422804014327d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.13787270895165282d + "'", double7 == 0.13787270895165282d);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) -1, number8, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Throwable throwable13 = null;
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, localizable14, objArray15);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable11, objArray15);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
//        long long27 = randomDataImpl25.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { randomDataImpl25, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray29);
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable11, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Throwable throwable34 = null;
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Object[] objArray36 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, localizable35, objArray36);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray36);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray36);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable11, objArray36);
//        java.lang.Number number41 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, number41);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 72L, (java.lang.Number) 0.5805798121089214d, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 2.1556157735575975E15d, (java.lang.Number) 14L, false);
//        java.lang.Number number51 = numberIsTooSmallException50.getMin();
//        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 15L + "'", long27 == 15L);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 14L + "'", number51.equals(14L));
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 45, 94L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.3429658762904546E-107d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.342965876290455E-107d + "'", double1 == 3.342965876290455E-107d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        double double8 = randomDataImpl0.nextExponential(100.0d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "efa92eb976eac8370979170b628cf2c97e624b355c05b9550f9f154ee");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: efa92eb976eac8370979170b628cf2c97e624b355c05b9550f9f154ee");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33 + "'", int3 == 33);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.006762328500846781d + "'", double6 == 0.006762328500846781d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 26.240383201296503d + "'", double8 == 26.240383201296503d);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.density(0.0d);
//        double double7 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        normalDistributionImpl2.reseedRandomGenerator((long) '4');
//        double double12 = normalDistributionImpl2.cumulativeProbability(0.18301335352733294d, 0.3788032778768237d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3989422804014327d + "'", double6 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.4317959993127792d) + "'", double7 == (-0.4317959993127792d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.07497679395120371d + "'", double12 == 0.07497679395120371d);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.3790830623353236d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 79.01563906979106d + "'", double1 == 79.01563906979106d);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        try {
//            double double13 = randomDataImpl0.nextBeta(0.0d, 2.7547663794053667E-6d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.329");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 40 + "'", int6 == 40);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 100L, number16, (java.lang.Number) 57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException(localizable21, (java.lang.Number) (short) -1, number23, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable26 = outOfRangeException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Throwable throwable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(throwable28, localizable29, objArray30);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException20, localizable26, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) (short) -1, number38, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable41 = outOfRangeException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable43, localizable44, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException35, localizable41, objArray45);
        java.lang.Number number50 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) 100L, number50, (java.lang.Number) 57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable41, (java.lang.Number) 16L);
        java.lang.Object[] objArray56 = new java.lang.Object[] { 16L, "hi!" };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable26, objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException57);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 48);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 48.0f + "'", float1 == 48.0f);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int1 = org.apache.commons.math.util.FastMath.abs(17);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 17 + "'", int1 == 17);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 1);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number8 = notStrictlyPositiveException6.getArgument();
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 1 + "'", number8.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.0f) + "'", number10.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 70L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test165() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test165");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray2);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) -1, number8, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Throwable throwable13 = null;
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, localizable14, objArray15);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable11, objArray15);
//        java.lang.Number number20 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 100L, number20, (java.lang.Number) 57);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Object[] objArray29 = null;
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException27, localizable28, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        java.lang.Throwable throwable33 = null;
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        java.lang.Object[] objArray35 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, localizable34, objArray35);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray35);
//        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray35);
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable11, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable40 = null;
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        org.apache.commons.math.exception.util.Localizable localizable42 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl43 = new org.apache.commons.math.random.RandomDataImpl();
//        long long45 = randomDataImpl43.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { randomDataImpl43, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable42, objArray47);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray47);
//        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, localizable11, objArray47);
//        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 14L + "'", long45 == 14L);
//        org.junit.Assert.assertNotNull(objArray47);
//    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1.8690199572373172d, (java.lang.Number) 100);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 34L, (float) 91);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        double double8 = randomDataImpl0.nextChiSquare((double) 19L);
//        int[] intArray11 = randomDataImpl0.nextPermutation(68, 48);
//        double double13 = randomDataImpl0.nextExponential((double) (byte) 1);
//        try {
//            long long16 = randomDataImpl0.nextLong((long) 69, 61L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 69 is larger than, or equal to, the maximum (61): lower bound (69) must be strictly less than upper bound (61)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 50 + "'", int6 == 50);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 16.262959063439666d + "'", double8 == 16.262959063439666d);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.2698610401282042d + "'", double13 == 1.2698610401282042d);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) (short) 1);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5);
        java.lang.Number number7 = notStrictlyPositiveException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(throwable12, localizable13, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable10, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray14);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(22, "", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MaxIterationsExceededException: {0} out of [{1}, {2}] range", objArray14);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 1 + "'", number7.equals((short) 1));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14L, number1, (java.lang.Number) Double.NaN);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable8, objArray12);
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 100L, number17, (java.lang.Number) 57);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 0.0d, (java.lang.Number) 1.5860134523134308E15d, true);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Number number28 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException(localizable26, (java.lang.Number) (short) -1, number28, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable31 = outOfRangeException30.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Throwable throwable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable33, localizable34, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException25, localizable31, objArray35);
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 100L, number40, (java.lang.Number) 57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) (short) -1, number47, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable50 = outOfRangeException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Throwable throwable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(throwable52, localizable53, objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException44, localizable50, objArray54);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException(localizable60, (java.lang.Number) (short) -1, number62, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable65 = outOfRangeException64.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Throwable throwable67 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(throwable67, localizable68, objArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, objArray69);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException59, localizable65, objArray69);
        java.lang.Number number74 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException(localizable65, (java.lang.Number) 100L, number74, (java.lang.Number) 57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable65, (java.lang.Number) 16L);
        java.lang.Object[] objArray80 = new java.lang.Object[] { 16L, "hi!" };
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException42, localizable50, objArray80);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException((-1), localizable8, objArray80);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(objArray80);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double2 = normalDistributionImpl0.getMean();
        double double4 = normalDistributionImpl0.cumulativeProbability((double) (short) -1);
        double[] doubleArray6 = normalDistributionImpl0.sample(63);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.15865525393145702d + "'", double4 == 0.15865525393145702d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test173");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        double double9 = randomDataImpl0.nextBeta(1.6704649792860586d, (double) 10);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
//        long long12 = randomDataImpl10.nextPoisson((double) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl13.getStandardDeviation();
//        double double15 = normalDistributionImpl13.getMean();
//        double double17 = normalDistributionImpl13.density(0.0d);
//        double double18 = randomDataImpl10.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double19 = normalDistributionImpl13.getMean();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        long long22 = randomDataImpl0.nextPoisson(0.4312533994964107d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 42L + "'", long6 == 42L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.31383645605887645d + "'", double9 == 0.31383645605887645d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 12L + "'", long12 == 12L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.3989422804014327d + "'", double17 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.1141162855775086d) + "'", double18 == (-1.1141162855775086d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.2297967792481474d) + "'", double20 == (-0.2297967792481474d));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        float float2 = org.apache.commons.math.util.FastMath.min(48.0f, (float) 28);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 28.0f + "'", float2 == 28.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 95, (float) 48);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 48.0f + "'", float2 == 48.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 1);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number8 = notStrictlyPositiveException6.getArgument();
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number10 = numberIsTooLargeException3.getMax();
        java.lang.Number number11 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 1 + "'", number8.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-1.0f) + "'", number10.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0f) + "'", number11.equals((-1.0f)));
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        double double8 = randomDataImpl0.nextExponential(100.0d);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString(61);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36 + "'", int3 == 36);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.816761657407298E-6d + "'", double6 == 2.816761657407298E-6d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 12.743831607907815d + "'", double8 == 12.743831607907815d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "48cfcbadc0de8c5fe8a3a9733c6d4698232d1510f8e9a250f642c355b2849" + "'", str10.equals("48cfcbadc0de8c5fe8a3a9733c6d4698232d1510f8e9a250f642c355b2849"));
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double4 = normalDistributionImpl0.density(1.3257298093365137d);
        double double6 = normalDistributionImpl0.density(1.1579869585617917d);
        double double8 = normalDistributionImpl0.density(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5d + "'", double2 == 0.5d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.16567648182394956d + "'", double4 == 0.16567648182394956d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2040468955714223d + "'", double6 == 0.2040468955714223d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.3989422804014327d + "'", double8 == 0.3989422804014327d);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        long long8 = randomDataImpl0.nextSecureLong((long) (short) -1, (long) 23);
//        int int11 = randomDataImpl0.nextSecureInt(45, 68);
//        double double14 = randomDataImpl0.nextGaussian(0.7886151878278062d, 0.44375573982337235d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36 + "'", int3 == 36);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2618017590183962d + "'", double5 == 0.2618017590183962d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3L + "'", long8 == 3L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 50 + "'", int11 == 50);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.5943126399447486d + "'", double14 == 0.5943126399447486d);
//    }

//    @Test
//    public void test180() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test180");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double8 = randomDataImpl0.nextCauchy((double) 0L, 1.1579869585617917d);
//        double double10 = randomDataImpl0.nextExponential(2807.493196141034d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 36 + "'", int3 == 36);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5951473585228907d + "'", double5 == 0.5951473585228907d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8422310073074554d + "'", double8 == 0.8422310073074554d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 442.1611214404537d + "'", double10 == 442.1611214404537d);
//    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable1, objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException3.getGeneralPattern();
        java.lang.Object[] objArray6 = maxIterationsExceededException3.getArguments();
        try {
            java.lang.String str7 = maxIterationsExceededException3.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(objArray6);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        double double8 = randomDataImpl0.nextExponential(100.0d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("54b4e8f", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.009880909012216032d + "'", double6 == 0.009880909012216032d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 6.000261711476602d + "'", double8 == 6.000261711476602d);
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double2 = org.apache.commons.math.util.FastMath.max(4.875087565267782d, 785989.6090064636d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 785989.6090064636d + "'", double2 == 785989.6090064636d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) -1, (java.lang.Number) (-0.519690377613997d), (java.lang.Number) 7);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.6483477116495999d, (java.lang.Number) 0.024095219843600375d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.024095219843600375d + "'", number4.equals(0.024095219843600375d));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (short) -1, number20, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable23 = outOfRangeException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Throwable throwable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, localizable26, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException17, localizable23, objArray27);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, localizable37, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("hi!", objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(throwable15, localizable23, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable7, objArray38);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1.4605356877990312d, (java.lang.Number) 95, false);
        boolean boolean47 = numberIsTooSmallException46.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 0 + "'", number5.equals((short) 0));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable2, objArray3);
        int int5 = maxIterationsExceededException4.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException4.getGeneralPattern();
        java.lang.Object[] objArray7 = maxIterationsExceededException4.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("{0}", objArray7);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        long long2 = org.apache.commons.math.util.FastMath.max(17L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17L + "'", long2 == 17L);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        double double9 = randomDataImpl0.nextBeta(1.6704649792860586d, (double) 10);
//        try {
//            double double12 = randomDataImpl0.nextGaussian((-1.2772987298365368d), (-0.0364532675563058d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.036 is smaller than, or equal to, the minimum (0): standard deviation (-0.036)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 37L + "'", long6 == 37L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.19133567070124882d + "'", double9 == 0.19133567070124882d);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.233403117511217d, 1.4150187302645454d, 3.831008000716577E22d, 41);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6678929688262193d + "'", double4 == 0.6678929688262193d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 52.0f, 5.15470108579623E-13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000020368d + "'", double2 == 1.0000000000020368d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9921115518944043d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 57);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Number number5 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        long long13 = randomDataImpl11.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray15 = new java.lang.Object[] { randomDataImpl11, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray15);
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray15);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(7, localizable2, objArray15);
//        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("1a62c549edec288491f43d0d3cf1ca0893ac74d218295b697f708ed3eae1af5d8c9a7832c45fe1f7bb252e39e15084a13bf5", objArray15);
//        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 18L + "'", long13 == 18L);
//        org.junit.Assert.assertNotNull(objArray15);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 40L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2291.831180523293d + "'", double1 == 2291.831180523293d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6483477116495999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.831008000716577E22d, (java.lang.Number) 3.342965876290455E-107d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.342965876290455E-107d + "'", number4.equals(3.342965876290455E-107d));
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.getMean();
//        double double7 = normalDistributionImpl3.density(0.0d);
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double10 = randomDataImpl0.nextChiSquare(0.2272993696369117d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3989422804014327d + "'", double7 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.8330239603741334d + "'", double8 == 1.8330239603741334d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3977915723854242d + "'", double10 == 0.3977915723854242d);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.37220941211025227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3559227494306728d + "'", double1 == 0.3559227494306728d);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        randomDataImpl0.reSeedSecure((long) 77);
//        try {
//            int int11 = randomDataImpl0.nextZipf((int) '#', (double) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): exponent (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 31 + "'", int3 == 31);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.01933348819746745d + "'", double6 == 0.01933348819746745d);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 18L, 5.214965293162436d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2887969316181147d + "'", double2 == 1.2887969316181147d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 3.3429658762904546E-107d, false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 46L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8501476017100584d + "'", double1 == 3.8501476017100584d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(13.683692642761619d, (-33.04436691401311d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) 28L, (double) '#');
//        try {
//            java.lang.String str5 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4143616584503401d + "'", double3 == 0.4143616584503401d);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.116963700636854d), 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1169637006368538d) + "'", double2 == (-1.1169637006368538d));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(throwable2, localizable3, objArray4);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "maximal number of iterations ({0}) exceeded", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = maxIterationsExceededException6.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 11L);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, localizable1, objArray2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3);
        java.lang.Throwable[] throwableArray5 = convergenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Number number5 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        java.lang.Throwable throwable10 = null;
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        java.lang.Object[] objArray12 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable8, objArray12);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        java.lang.Number number24 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) (short) -1, number24, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable27 = outOfRangeException26.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Throwable throwable29 = null;
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        java.lang.Object[] objArray31 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(throwable29, localizable30, objArray31);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray31);
//        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException21, localizable27, objArray31);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        org.apache.commons.math.exception.util.Localizable localizable40 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl41 = new org.apache.commons.math.random.RandomDataImpl();
//        long long43 = randomDataImpl41.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray45 = new java.lang.Object[] { randomDataImpl41, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable40, objArray45);
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable27, objArray45);
//        org.apache.commons.math.exception.util.Localizable localizable48 = null;
//        java.lang.Throwable throwable49 = null;
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        java.lang.Object[] objArray51 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(throwable49, localizable50, objArray51);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray51);
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable27, objArray51);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable8, objArray51);
//        java.lang.Throwable throwable56 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable59 = null;
//        java.lang.Number number61 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException63 = new org.apache.commons.math.exception.OutOfRangeException(localizable59, (java.lang.Number) (short) -1, number61, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable64 = outOfRangeException63.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable65 = null;
//        java.lang.Throwable throwable66 = null;
//        org.apache.commons.math.exception.util.Localizable localizable67 = null;
//        java.lang.Object[] objArray68 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(throwable66, localizable67, objArray68);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException58, localizable64, objArray68);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException75 = new org.apache.commons.math.exception.OutOfRangeException(localizable64, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        java.lang.Throwable throwable77 = null;
//        org.apache.commons.math.exception.util.Localizable localizable78 = null;
//        java.lang.Object[] objArray79 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(throwable77, localizable78, objArray79);
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("hi!", objArray79);
//        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException(throwable56, localizable64, objArray79);
//        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException(localizable8, objArray79);
//        java.lang.Class<?> wildcardClass84 = localizable8.getClass();
//        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray12);
//        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 8L + "'", long43 == 8L);
//        org.junit.Assert.assertNotNull(objArray45);
//        org.junit.Assert.assertNotNull(objArray51);
//        org.junit.Assert.assertTrue("'" + localizable64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable64.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertNotNull(objArray79);
//        org.junit.Assert.assertNotNull(wildcardClass84);
//    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) -1, number8, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Throwable throwable13 = null;
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, localizable14, objArray15);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable11, objArray15);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
//        long long27 = randomDataImpl25.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { randomDataImpl25, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray29);
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable11, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Throwable throwable34 = null;
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Object[] objArray36 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, localizable35, objArray36);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray36);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray36);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable11, objArray36);
//        java.lang.Number number41 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, number41);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) (-2.08468628512923d), (java.lang.Number) 0.4004824528590755d, false);
//        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 13L + "'", long27 == 13L);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray36);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-1L), (java.lang.Number) 1.5707963267948966d, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.5707963267948966d + "'", number5.equals(1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (1.571)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than the minimum (1.571)"));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.5393840659682915d), 0.0d, 0.999998293829917d, 42);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        randomDataImpl0.reSeed(5L);
//        int int16 = randomDataImpl0.nextHypergeometric((int) (byte) 100, 0, 68);
//        try {
//            int int19 = randomDataImpl0.nextBinomial(86, 785989.6090064636d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 785,989.609 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.8710880370642585d), (double) 14L, 2.289853441995488d, (int) (byte) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(218.41579693359327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.812074794858537d + "'", double1 == 3.812074794858537d);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.getMean();
//        double double7 = normalDistributionImpl3.density(0.0d);
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        normalDistributionImpl3.reseedRandomGenerator(46L);
//        double[] doubleArray12 = normalDistributionImpl3.sample(28);
//        double double14 = normalDistributionImpl3.cumulativeProbability(1.5707963267948966d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3989422804014327d + "'", double7 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.06135705292951484d) + "'", double8 == (-0.06135705292951484d));
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9418850172165905d + "'", double14 == 0.9418850172165905d);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.28059433662334016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0396255577673172d + "'", double1 == 1.0396255577673172d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.13313701469396125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.9074467814501962d, (double) 23);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0394337550609684d + "'", double2 == 0.0394337550609684d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100.0d, number1, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int int2 = org.apache.commons.math.util.FastMath.max(97, 21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 40L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 40.0d + "'", double1 == 40.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.24851829894375121d, 0.010050166663333094d, (-0.7081614540719358d), 42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (42) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.tanh(442.1611214404537d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4758800785707605E27d + "'", double1 == 2.4758800785707605E27d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-1.3140345999234646d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 23);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable8, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, localizable22, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("hi!", objArray23);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(throwable0, localizable8, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) (short) -1, number31, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable34 = outOfRangeException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, localizable37, objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException28, localizable34, objArray38);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl48 = new org.apache.commons.math.random.RandomDataImpl();
        long long50 = randomDataImpl48.nextPoisson((double) (byte) 10);
        java.lang.Object[] objArray52 = new java.lang.Object[] { randomDataImpl48, 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable47, objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable34, objArray52);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
        boolean boolean59 = numberIsTooLargeException58.getBoundIsAllowed();
        boolean boolean60 = numberIsTooLargeException58.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray61 = numberIsTooLargeException58.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable34, (java.lang.Object[]) throwableArray61);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 28.0f, (java.lang.Number) 0.6483477116495999d, (java.lang.Number) 1.4150187302645454d);
        java.lang.Number number67 = outOfRangeException66.getLo();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 10L + "'", long50 == 10L);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 0.6483477116495999d + "'", number67.equals(0.6483477116495999d));
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        double double9 = randomDataImpl0.nextBeta(1.6704649792860586d, (double) 10);
//        double double12 = randomDataImpl0.nextBeta(0.19267381485027782d, 356.27680236040976d);
//        try {
//            long long15 = randomDataImpl0.nextLong((long) 58, (long) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 58 is larger than, or equal to, the maximum (-1): lower bound (58) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 60L + "'", long6 == 60L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0946488719874096d + "'", double9 == 0.0946488719874096d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.909372929771644E-4d + "'", double12 == 1.909372929771644E-4d);
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        randomDataImpl0.reSeed((long) (byte) 0);
//        double double12 = randomDataImpl0.nextChiSquare(21.44917489924856d);
//        java.lang.String str14 = randomDataImpl0.nextHexString(38);
//        int int17 = randomDataImpl0.nextInt(0, 1);
//        randomDataImpl0.reSeed(9L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15L + "'", long2 == 15L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 25.001800390015585d + "'", double12 == 25.001800390015585d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "fa4b13bd3ef0b91b7649ad23ba709dcf37f069" + "'", str14.equals("fa4b13bd3ef0b91b7649ad23ba709dcf37f069"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 72L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 72.0f + "'", float1 == 72.0f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        int int2 = org.apache.commons.math.util.FastMath.max(95, 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 95 + "'", int2 == 95);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable8, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, localizable22, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("hi!", objArray23);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(throwable0, localizable8, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(throwable30, localizable31, objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("", objArray32);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray32);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable8, objArray32);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1, (java.lang.Number) 0.8504636186597091d, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (short) -1, number7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = outOfRangeException9.getLo();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.Throwable[] throwableArray12 = outOfRangeException9.getSuppressed();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Object[] objArray14 = outOfRangeException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 18L, false);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException19);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution1 = null;
        try {
            double double2 = randomDataImpl0.nextInversionDeviate(continuousDistribution1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5951473585228907d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8132981302076892d + "'", double1 == 1.8132981302076892d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6678929688262193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        double double4 = randomDataImpl0.nextChiSquare(1.5707963267948966d);
//        java.lang.String str6 = randomDataImpl0.nextHexString((int) (short) 1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.04203884788658d + "'", double4 == 4.04203884788658d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3" + "'", str6.equals("3"));
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 1);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number8 = notStrictlyPositiveException6.getArgument();
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "54b4e8f", objArray11);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 1 + "'", number8.equals((short) 1));
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        randomDataImpl0.reSeed((long) (byte) 0);
//        randomDataImpl0.reSeed();
//        double double13 = randomDataImpl0.nextChiSquare(2.251752586176186d);
//        try {
//            long long15 = randomDataImpl0.nextPoisson((-0.6560647379324626d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.656 is smaller than, or equal to, the minimum (0): mean (-0.656)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 82L + "'", long6 == 82L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.5741250398330395d + "'", double13 == 3.5741250398330395d);
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.asin(356.27680236040976d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        int int7 = randomDataImpl0.nextHypergeometric(100, 0, 29);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl0.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 78 + "'", int3 == 78);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        double double13 = randomDataImpl0.nextBeta((double) 96L, (double) 45);
//        double double15 = randomDataImpl0.nextChiSquare(1.3257298093365137d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 93 + "'", int6 == 93);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.7135933824633635d + "'", double13 == 0.7135933824633635d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.4118853603903676d + "'", double15 == 2.4118853603903676d);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.4004824528590755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.259830175354933d + "'", double1 == 7.259830175354933d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 10, (java.lang.Number) (byte) 1, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) (short) 1);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException11);
        java.lang.Number number13 = notStrictlyPositiveException11.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Throwable throwable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, localizable19, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable16, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException11, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray20);
        java.lang.Throwable[] throwableArray25 = notStrictlyPositiveException11.getSuppressed();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(25, "4f5b758", (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "fa4b13bd3ef0b91b7649ad23ba709dcf37f069", (java.lang.Object[]) throwableArray25);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 1 + "'", number13.equals((short) 1));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.tan(221206.6960055904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1951874708143058d + "'", double1 == 1.1951874708143058d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 57);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9948376736367679d + "'", double1 == 0.9948376736367679d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 0 + "'", number5.equals((short) 0));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.9686884421436269d, (java.lang.Number) 18L, false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        java.lang.String str4 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str4.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.038327316204626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 18L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.0d + "'", double1 == 18.0d);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta((double) 28L, (double) '#');
//        org.apache.commons.math.random.RandomGenerator randomGenerator4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator4);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.getStandardDeviation();
//        double double8 = normalDistributionImpl6.getMean();
//        double double10 = normalDistributionImpl6.density(0.0d);
//        double double11 = randomDataImpl5.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double14 = randomDataImpl0.nextT(2807.493196141034d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4779289651271826d + "'", double3 == 0.4779289651271826d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3989422804014327d + "'", double10 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5320494989774719d + "'", double11 == 0.5320494989774719d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.7227566654270449d) + "'", double12 == (-0.7227566654270449d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.24338555741268003d + "'", double14 == 0.24338555741268003d);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.6560647379324626d), (double) 10L, 1.4260624389053682d, 2147483647);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double4 = normalDistributionImpl3.getStandardDeviation();
//        double double5 = normalDistributionImpl3.getMean();
//        double double7 = normalDistributionImpl3.density(0.0d);
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl3);
//        double double11 = randomDataImpl0.nextCauchy((-0.24529595847479463d), 0.13694604834661991d);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3989422804014327d + "'", double7 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.30029491924834384d) + "'", double8 == (-0.30029491924834384d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.571205946852319d) + "'", double11 == (-0.571205946852319d));
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) 10.0d, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0d + "'", number6.equals(10.0d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 9L, 0.9074467814501962d);
        double double4 = normalDistributionImpl2.cumulativeProbability(3.342965876290455E-107d);
        try {
            double double7 = normalDistributionImpl2.cumulativeProbability(0.19267381485027785d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 44, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        long long8 = randomDataImpl0.nextPoisson((double) (short) 1);
//        double double11 = randomDataImpl0.nextUniform((-0.15865543311406305d), 0.9525862986355818d);
//        long long13 = randomDataImpl0.nextPoisson(0.7691899141354063d);
//        java.lang.String str15 = randomDataImpl0.nextHexString((int) (short) 10);
//        double double17 = randomDataImpl0.nextT(0.06251112383312837d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 70 + "'", int3 == 70);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 49.06429573948039d + "'", double6 == 49.06429573948039d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.11612525995665056d) + "'", double11 == (-0.11612525995665056d));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3L + "'", long13 == 3L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "acc3d9687c" + "'", str15.equals("acc3d9687c"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.03794460372310511d + "'", double17 == 0.03794460372310511d);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 29);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 29.0f + "'", float1 == 29.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.6157425868972846d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        long long8 = randomDataImpl0.nextSecureLong((long) (short) -1, (long) 23);
//        double double11 = randomDataImpl0.nextGaussian(0.0d, (double) (short) 100);
//        double double13 = randomDataImpl0.nextExponential(11013.232920103323d);
//        long long15 = randomDataImpl0.nextPoisson(0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.038731495036332234d) + "'", double5 == (-0.038731495036332234d));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 6L + "'", long8 == 6L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.93703091392034d + "'", double11 == 32.93703091392034d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4579.529530255936d + "'", double13 == 4579.529530255936d);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.13694604834661991d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12834576276008997d + "'", double1 == 0.12834576276008997d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.8601984309376552d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.06540135396483743d) + "'", double1 == (-0.06540135396483743d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.4260624389053682d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.density(0.0d);
//        double double7 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        normalDistributionImpl2.reseedRandomGenerator((long) '4');
//        double double10 = normalDistributionImpl2.getMean();
//        double double11 = normalDistributionImpl2.sample();
//        normalDistributionImpl2.reseedRandomGenerator((long) 1);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3989422804014327d + "'", double6 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5539076712080367d + "'", double7 == 0.5539076712080367d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.385751988502056d + "'", double11 == 1.385751988502056d);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.8099022057174124d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6268109545484124d + "'", double1 == 0.6268109545484124d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.special.Erf.erf(9.875840647350373E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1143692807796247E-4d + "'", double1 == 1.1143692807796247E-4d);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        try {
//            java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 76L + "'", long6 == 76L);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl();
//        long long5 = randomDataImpl3.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray7 = new java.lang.Object[] { randomDataImpl3, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray7);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray7);
//        org.apache.commons.math.exception.util.Localizable localizable10 = mathIllegalArgumentException9.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 14L + "'", long5 == 14L);
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNull(localizable10);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.08828834728448533d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.1143692807796247E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000062090946d + "'", double1 == 1.0000000062090946d);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
//        java.lang.Throwable throwable4 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Number number9 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) (short) -1, number9, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException11.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Throwable throwable14 = null;
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        java.lang.Object[] objArray16 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, localizable15, objArray16);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray16);
//        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, localizable12, objArray16);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        java.lang.Throwable throwable25 = null;
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        java.lang.Object[] objArray27 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, localizable26, objArray27);
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("hi!", objArray27);
//        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(throwable4, localizable12, objArray27);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Number number35 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (short) -1, number35, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Throwable throwable40 = null;
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        java.lang.Object[] objArray42 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable40, localizable41, objArray42);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray42);
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException32, localizable38, objArray42);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        org.apache.commons.math.exception.util.Localizable localizable51 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl52 = new org.apache.commons.math.random.RandomDataImpl();
//        long long54 = randomDataImpl52.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray56 = new java.lang.Object[] { randomDataImpl52, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable51, objArray56);
//        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable38, objArray56);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
//        boolean boolean63 = numberIsTooLargeException62.getBoundIsAllowed();
//        boolean boolean64 = numberIsTooLargeException62.getBoundIsAllowed();
//        java.lang.Throwable[] throwableArray65 = numberIsTooLargeException62.getSuppressed();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable38, (java.lang.Object[]) throwableArray65);
//        java.lang.Object[] objArray67 = null;
//        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable38, objArray67);
//        java.lang.Object[] objArray69 = numberIsTooLargeException3.getArguments();
//        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray42);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 12L + "'", long54 == 12L);
//        org.junit.Assert.assertNotNull(objArray56);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(throwableArray65);
//        org.junit.Assert.assertNotNull(objArray69);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 49L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        double double7 = randomDataImpl0.nextT(1.0000000000005154d);
//        int int10 = randomDataImpl0.nextInt(36, 45);
//        randomDataImpl0.reSeed((long) (short) -1);
//        java.lang.String str14 = randomDataImpl0.nextSecureHexString(7);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(57);
//        try {
//            int int19 = randomDataImpl0.nextPascal((int) ' ', 221206.6960055904d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 221,206.696 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6216245244038707d + "'", double7 == 0.6216245244038707d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 45 + "'", int10 == 45);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1d379aa" + "'", str14.equals("1d379aa"));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "abffa91dffb9086de62396e3639af9ac65ecf11358c7e97de2cf886b7" + "'", str16.equals("abffa91dffb9086de62396e3639af9ac65ecf11358c7e97de2cf886b7"));
//    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        long long8 = randomDataImpl0.nextSecureLong((long) (short) -1, (long) 23);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 100);
//        double double14 = randomDataImpl0.nextGaussian(103.08165616241465d, 2.220446049250313E-16d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 67 + "'", int3 == 67);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.09414500636669978d) + "'", double5 == (-0.09414500636669978d));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 21L + "'", long8 == 21L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 49 + "'", int11 == 49);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 103.08165616241465d + "'", double14 == 103.08165616241465d);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.04229861514908033d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.4235321272904304d) + "'", double1 == (-2.4235321272904304d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.19267381485027785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1761976898467493d + "'", double1 == 0.1761976898467493d);
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Number number9 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) (short) -1, number9, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException11.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Throwable throwable14 = null;
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        java.lang.Object[] objArray16 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, localizable15, objArray16);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray16);
//        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, localizable12, objArray16);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl26 = new org.apache.commons.math.random.RandomDataImpl();
//        long long28 = randomDataImpl26.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { randomDataImpl26, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray30);
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable12, objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        java.lang.Throwable throwable35 = null;
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        java.lang.Object[] objArray37 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(throwable35, localizable36, objArray37);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray37);
//        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray37);
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable12, objArray37);
//        java.lang.Number number42 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, number42);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 72L, (java.lang.Number) 0.5805798121089214d, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 22.787396757304858d, (java.lang.Number) 47, false);
//        java.lang.Number number53 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14L, number53, (java.lang.Number) Double.NaN);
//        java.lang.Object[] objArray56 = outOfRangeException55.getArguments();
//        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable12, objArray56);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        java.lang.Number number60 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException(localizable58, (java.lang.Number) (short) -1, number60, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable63 = outOfRangeException62.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable64 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable64, (java.lang.Number) (short) 1);
//        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException66);
//        java.lang.Number number68 = notStrictlyPositiveException66.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable71 = null;
//        org.apache.commons.math.exception.util.Localizable localizable72 = null;
//        java.lang.Throwable throwable73 = null;
//        org.apache.commons.math.exception.util.Localizable localizable74 = null;
//        java.lang.Object[] objArray75 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(throwable73, localizable74, objArray75);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, objArray75);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable71, objArray75);
//        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException66, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray75);
//        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable63, objArray75);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(97, localizable12, objArray75);
//        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 7L + "'", long28 == 7L);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertNotNull(objArray56);
//        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + number68 + "' != '" + (short) 1 + "'", number68.equals((short) 1));
//        org.junit.Assert.assertNotNull(objArray75);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.22998785417893894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2070042946843023d + "'", double1 == 0.2070042946843023d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable8, objArray12);
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 100L, number17, (java.lang.Number) 57);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24, localizable25, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Throwable throwable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(throwable30, localizable31, objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException27, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable8, objArray32);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("maximal number of iterations ({0}) exceeded", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException37.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(localizable38);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.24262085532106012d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.319694584012438d + "'", double1 == 1.319694584012438d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-1L), (java.lang.Number) 1.5707963267948966d, true);
        java.lang.Object[] objArray9 = numberIsTooSmallException8.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(45, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(86, "org.apache.commons.math.MaxIterationsExceededException: {0} out of [{1}, {2}] range", objArray9);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5667583460678747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5156184004079982d + "'", double1 == 0.5156184004079982d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.08828834728448533d, 3.438939466091658d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.880477177856917E-4d + "'", double2 == 7.880477177856917E-4d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.2040468955714223d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1, (java.lang.Number) 0.8504636186597091d, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (short) -1, number7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = outOfRangeException9.getLo();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.Throwable[] throwableArray12 = outOfRangeException9.getSuppressed();
        java.lang.Number number13 = outOfRangeException9.getLo();
        java.lang.Object[] objArray14 = outOfRangeException9.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException9.getGeneralPattern();
        java.lang.Number number16 = outOfRangeException9.getArgument();
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) -1 + "'", number16.equals((short) -1));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray1 = mathException0.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
        java.lang.Number number7 = numberIsTooSmallException6.getMin();
        mathException0.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        boolean boolean9 = numberIsTooSmallException6.getBoundIsAllowed();
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        boolean boolean11 = numberIsTooSmallException6.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 0 + "'", number7.equals((short) 0));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4579.529530255936d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 100L, number16, (java.lang.Number) 57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 16L);
        java.lang.Number number21 = notStrictlyPositiveException20.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException20.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) (-0.07356685700469068d));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 16L + "'", number21.equals(16L));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 100L, number16, (java.lang.Number) 57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 16L);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 0.9999832982992097d, (java.lang.Number) 0.5805798121089214d, (java.lang.Number) 70L);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 2.7547663794053667E-6d, (java.lang.Number) 12.743831607907815d, true);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.5091784786580567d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        java.lang.Number number2 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, number2, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
//        long long10 = randomDataImpl8.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray12 = new java.lang.Object[] { randomDataImpl8, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray12);
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable5, objArray12);
//        java.lang.Number number16 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-53.912573722555265d), number16, false);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 9L + "'", long10 == 9L);
//        org.junit.Assert.assertNotNull(objArray12);
//    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.random.RandomGenerator randomGenerator4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator4);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = normalDistributionImpl6.getStandardDeviation();
//        double double8 = normalDistributionImpl6.getMean();
//        double double10 = normalDistributionImpl6.density(0.0d);
//        double double11 = randomDataImpl5.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3989422804014327d + "'", double10 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.9414978972774334d) + "'", double11 == (-0.9414978972774334d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.9394012385242317d) + "'", double12 == (-0.9394012385242317d));
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.acos(28.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, (float) 17L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 17.0f + "'", float2 == 17.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.26399325260676d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        try {
//            int int6 = randomDataImpl0.nextSecureInt(78, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 78 is larger than, or equal to, the maximum (0): lower bound (78) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 47);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 47.0f + "'", float1 == 47.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        java.lang.Throwable throwable15 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable18, (java.lang.Number) (short) -1, number20, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable23 = outOfRangeException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Throwable throwable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, localizable26, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException17, localizable23, objArray27);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, localizable37, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("hi!", objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(throwable15, localizable23, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable7, objArray38);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 10.0d, (java.lang.Number) 77, true);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) 11L);
        java.lang.Object[] objArray50 = notStrictlyPositiveException49.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable7, objArray50);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Throwable throwable54 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Number number59 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException(localizable57, (java.lang.Number) (short) -1, number59, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable62 = outOfRangeException61.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Throwable throwable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(throwable64, localizable65, objArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException56, localizable62, objArray66);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math.exception.OutOfRangeException(localizable62, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Throwable throwable75 = null;
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(throwable75, localizable76, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("hi!", objArray77);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(throwable54, localizable62, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("maximal number of iterations ({0}) exceeded", objArray77);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException51, localizable52, objArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException84 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable85 = maxIterationsExceededException84.getSpecificPattern();
        java.lang.Class<?> wildcardClass86 = maxIterationsExceededException84.getClass();
        convergenceException82.addSuppressed((java.lang.Throwable) maxIterationsExceededException84);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNull(localizable85);
        org.junit.Assert.assertNotNull(wildcardClass86);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
        long long23 = randomDataImpl21.nextPoisson((double) (byte) 10);
        java.lang.Object[] objArray25 = new java.lang.Object[] { randomDataImpl21, 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable7, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException27.getSpecificPattern();
        java.lang.Object[] objArray29 = mathException27.getArguments();
        java.lang.String str30 = mathException27.getPattern();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNull(localizable28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{0} out of [{1}, {2}] range" + "'", str30.equals("{0} out of [{1}, {2}] range"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray1 = mathException0.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
        java.lang.Number number7 = numberIsTooSmallException6.getMin();
        mathException0.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Number number9 = numberIsTooSmallException6.getArgument();
        java.lang.Number number10 = numberIsTooSmallException6.getMin();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 0 + "'", number7.equals((short) 0));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.6704649792860586d + "'", number9.equals(1.6704649792860586d));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 0 + "'", number10.equals((short) 0));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int int1 = org.apache.commons.math.util.FastMath.abs(94);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.4515827052894548d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3452626990348955d) + "'", double1 == (-0.3452626990348955d));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.6981961587081884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.193060914248062d + "'", double1 == 1.193060914248062d);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        java.lang.Number number4 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        java.lang.Throwable throwable9 = null;
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
//        long long23 = randomDataImpl21.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { randomDataImpl21, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray25);
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable7, objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Throwable throwable29 = null;
//        org.apache.commons.math.exception.util.Localizable localizable30 = null;
//        java.lang.Object[] objArray31 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(throwable29, localizable30, objArray31);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray31);
//        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable7, objArray31);
//        java.lang.Number number35 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, number35, (java.lang.Number) 0.6157425868972846d, true);
//        org.apache.commons.math.exception.util.Localizable localizable39 = numberIsTooSmallException38.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 10L + "'", long23 == 10L);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        java.lang.Number number10 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (short) -1, number10, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable13 = outOfRangeException12.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Throwable throwable15 = null;
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, localizable16, objArray17);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray17);
//        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException7, localizable13, objArray17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl27 = new org.apache.commons.math.random.RandomDataImpl();
//        long long29 = randomDataImpl27.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray31 = new java.lang.Object[] { randomDataImpl27, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable26, objArray31);
//        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable13, objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Throwable throwable36 = null;
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        java.lang.Object[] objArray38 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(throwable36, localizable37, objArray38);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray38);
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray38);
//        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable13, objArray38);
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        java.lang.Number number45 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) (short) -1, number45, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable48 = outOfRangeException47.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable49, (java.lang.Number) (short) 1);
//        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException51);
//        java.lang.Number number53 = notStrictlyPositiveException51.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        org.apache.commons.math.exception.util.Localizable localizable57 = null;
//        java.lang.Throwable throwable58 = null;
//        org.apache.commons.math.exception.util.Localizable localizable59 = null;
//        java.lang.Object[] objArray60 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(throwable58, localizable59, objArray60);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray60);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable56, objArray60);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException51, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray60);
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable48, objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable68 = null;
//        java.lang.Throwable throwable69 = null;
//        org.apache.commons.math.exception.util.Localizable localizable70 = null;
//        java.lang.Object[] objArray71 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(throwable69, localizable70, objArray71);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable68, objArray71);
//        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("", objArray71);
//        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray71);
//        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException42, localizable48, objArray71);
//        org.apache.commons.math.exception.util.Localizable localizable77 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable77, (java.lang.Number) (short) 100, (java.lang.Number) 10.0d, true);
//        java.lang.String str82 = numberIsTooSmallException81.toString();
//        java.lang.Object[] objArray83 = numberIsTooSmallException81.getArguments();
//        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException(localizable48, objArray83);
//        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException(throwable0, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray83);
//        java.lang.String str86 = convergenceException85.toString();
//        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException85);
//        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 5L + "'", long29 == 5L);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(objArray38);
//        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (short) 1 + "'", number53.equals((short) 1));
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertNotNull(objArray71);
//        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (10)" + "'", str82.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than the minimum (10)"));
//        org.junit.Assert.assertNotNull(objArray83);
//        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "org.apache.commons.math.ConvergenceException: org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded" + "'", str86.equals("org.apache.commons.math.ConvergenceException: org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded"));
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        double double7 = randomDataImpl0.nextT(1.0000000000005154d);
//        int int10 = randomDataImpl0.nextInt(36, 45);
//        randomDataImpl0.reSeed((long) (short) -1);
//        try {
//            double double15 = randomDataImpl0.nextF((-53.91257372255526d), 2.251752586176186d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -53.913 is smaller than, or equal to, the minimum (0): degrees of freedom (-53.913)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.7447995429726162d + "'", double7 == 1.7447995429726162d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 44 + "'", int10 == 44);
//    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        int int10 = randomDataImpl7.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double12 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        normalDistributionImpl11.reseedRandomGenerator((long) (short) 0);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double18 = randomDataImpl0.nextUniform(0.8504636186597091d, (double) 10);
//        int int21 = randomDataImpl0.nextPascal(61, 0.0d);
//        randomDataImpl0.reSeed((long) 38);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 81 + "'", int3 == 81);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.36436402379091E-5d + "'", double6 == 7.36436402379091E-5d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 81 + "'", int10 == 81);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.9103384150680479d + "'", double12 == 0.9103384150680479d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.2115734095869588d) + "'", double15 == (-1.2115734095869588d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.1208735758296746d + "'", double18 == 3.1208735758296746d);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (-0.882014470307824d), (double) 25L, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6449340668481562d + "'", double1 == 0.6449340668481562d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) -1, number8, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, localizable14, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable11, objArray15);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
        long long27 = randomDataImpl25.nextPoisson((double) (byte) 10);
        java.lang.Object[] objArray29 = new java.lang.Object[] { randomDataImpl25, 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable11, objArray29);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Throwable throwable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, localizable35, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray36);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable11, objArray36);
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, number41);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 72L, (java.lang.Number) 0.5805798121089214d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 22.787396757304858d, (java.lang.Number) 47, false);
        java.lang.Number number52 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 0.6483477116495999d, number52, true);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 12L + "'", long27 == 12L);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.31682694491851604d, (java.lang.Number) 7.259830175354933d, false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9604712468905262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.853144528746779d + "'", double1 == 0.853144528746779d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextZipf(100, (double) 52.0f);
//        int int6 = randomDataImpl0.nextInt((int) (byte) -1, 95);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) (short) 1);
//        try {
//            int int13 = randomDataImpl0.nextSecureInt(97, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (97): lower bound (97) must be strictly less than upper bound (97)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 43 + "'", int6 == 43);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(throwable4, localizable5, objArray6);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable2, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException(localizable0, objArray6);
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, "1a62c549edec288491f43d0d3cf1ca0893ac74d218295b697f708ed3eae1af5d8c9a7832c45fe1f7bb252e39e15084a13bf5", objArray12);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1), (-0.06135705292951484d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.06135705292951484d) + "'", double2 == (-0.06135705292951484d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.1645431933192647d), (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.454786341070473E-8d + "'", double2 == 1.454786341070473E-8d);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        long long8 = randomDataImpl0.nextSecureLong((long) (short) -1, (long) 23);
//        double double11 = randomDataImpl0.nextGaussian(0.0d, (double) (short) 100);
//        double double14 = randomDataImpl0.nextF(0.7691899141354063d, (double) 22);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 84 + "'", int3 == 84);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.1418315879263838d) + "'", double5 == (-0.1418315879263838d));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 32.96270366027029d + "'", double11 == 32.96270366027029d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0374151485207408d + "'", double14 == 1.0374151485207408d);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 39);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.1308472440325117E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1308472416222701E-4d + "'", double1 == 1.1308472416222701E-4d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 96L, (float) 78);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 78.0f + "'", float2 == 78.0f);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
//        java.lang.Throwable throwable4 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        java.lang.Number number9 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) (short) -1, number9, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException11.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Throwable throwable14 = null;
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        java.lang.Object[] objArray16 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(throwable14, localizable15, objArray16);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray16);
//        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException6, localizable12, objArray16);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        java.lang.Throwable throwable25 = null;
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        java.lang.Object[] objArray27 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(throwable25, localizable26, objArray27);
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("hi!", objArray27);
//        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(throwable4, localizable12, objArray27);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Number number35 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (short) -1, number35, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Throwable throwable40 = null;
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        java.lang.Object[] objArray42 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable40, localizable41, objArray42);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray42);
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException32, localizable38, objArray42);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        org.apache.commons.math.exception.util.Localizable localizable51 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl52 = new org.apache.commons.math.random.RandomDataImpl();
//        long long54 = randomDataImpl52.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray56 = new java.lang.Object[] { randomDataImpl52, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable51, objArray56);
//        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable38, objArray56);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
//        boolean boolean63 = numberIsTooLargeException62.getBoundIsAllowed();
//        boolean boolean64 = numberIsTooLargeException62.getBoundIsAllowed();
//        java.lang.Throwable[] throwableArray65 = numberIsTooLargeException62.getSuppressed();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable38, (java.lang.Object[]) throwableArray65);
//        java.lang.Object[] objArray67 = null;
//        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable38, objArray67);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException72 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) 21, (java.lang.Number) 38L, (java.lang.Number) 1.31989260666896d);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable38, (java.lang.Number) (-3.2921242664354406d));
//        boolean boolean75 = notStrictlyPositiveException74.getBoundIsAllowed();
//        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray16);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray42);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 7L + "'", long54 == 7L);
//        org.junit.Assert.assertNotNull(objArray56);
//        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(throwableArray65);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.4796795729111557d, 12.743831607907815d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03762237657955095d + "'", double2 == 0.03762237657955095d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(32);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        long long8 = randomDataImpl0.nextPoisson((double) (short) 1);
//        double double11 = randomDataImpl0.nextUniform((-0.15865543311406305d), 0.9525862986355818d);
//        long long13 = randomDataImpl0.nextPoisson(0.7691899141354063d);
//        java.lang.String str15 = randomDataImpl0.nextHexString((int) (short) 10);
//        int int18 = randomDataImpl0.nextBinomial(81, 5.303317702190892E-7d);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 80 + "'", int3 == 80);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.630272658486873E-14d + "'", double6 == 2.630272658486873E-14d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.947650738680081d + "'", double11 == 0.947650738680081d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6e50818aaa" + "'", str15.equals("6e50818aaa"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        randomDataImpl0.reSeed((long) (byte) 0);
//        double double12 = randomDataImpl0.nextChiSquare(21.44917489924856d);
//        java.lang.String str14 = randomDataImpl0.nextHexString(38);
//        int int17 = randomDataImpl0.nextInt(0, 1);
//        try {
//            int int20 = randomDataImpl0.nextPascal((int) (byte) 0, 0.06668481045921397d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 14L + "'", long2 == 14L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 84L + "'", long6 == 84L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 25.001800390015585d + "'", double12 == 25.001800390015585d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "fa4b13bd3ef0b91b7649ad23ba709dcf37f069" + "'", str14.equals("fa4b13bd3ef0b91b7649ad23ba709dcf37f069"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 6.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7781512503836436d + "'", double1 == 0.7781512503836436d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double2 = normalDistributionImpl0.getMean();
        double double4 = normalDistributionImpl0.density(0.0d);
        double double6 = normalDistributionImpl0.inverseCumulativeProbability(1.0d);
        double double8 = normalDistributionImpl0.cumulativeProbability(0.38086344735250344d);
        double[] doubleArray10 = normalDistributionImpl0.sample(40);
        double double12 = normalDistributionImpl0.inverseCumulativeProbability(0.19267381485027785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.3989422804014327d + "'", double4 == 0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6483477116495999d + "'", double8 == 0.6483477116495999d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.8680853147675449d) + "'", double12 == (-0.8680853147675449d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) (short) -1, number6, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable9 = outOfRangeException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(throwable11, localizable12, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException3, localizable9, objArray13);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 100L, number18, (java.lang.Number) 57);
        java.lang.Throwable throwable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(throwable21, localizable22, objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(29, localizable9, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl29 = new org.apache.commons.math.random.RandomDataImpl();
        long long31 = randomDataImpl29.nextPoisson((double) (byte) 10);
        java.lang.Object[] objArray33 = new java.lang.Object[] { randomDataImpl29, 0 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable0, localizable9, objArray33);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray1 = mathException0.getArguments();
        java.lang.String str2 = mathException0.getPattern();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.4296195831928754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3574083831414442d + "'", double1 == 0.3574083831414442d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 68);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 68L + "'", long1 == 68L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.8438669798515654d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        try {
//            double double9 = randomDataImpl0.nextGamma(0.0d, 0.9773748734443357d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 11L + "'", long6 == 11L);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 48, (java.lang.Number) 0.31682694491851604d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.31682694491851604d + "'", number4.equals(0.31682694491851604d));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        java.lang.Number number3 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) -1, number3, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        java.lang.Object[] objArray14 = null;
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12, localizable13, objArray14);
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        java.lang.Throwable throwable18 = null;
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        java.lang.Object[] objArray20 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, localizable19, objArray20);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
//        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray20);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray20);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable6, objArray20);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Number number30 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable28, (java.lang.Number) (short) -1, number30, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable33 = outOfRangeException32.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        java.lang.Throwable throwable35 = null;
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        java.lang.Object[] objArray37 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(throwable35, localizable36, objArray37);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray37);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException27, localizable33, objArray37);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl();
//        long long49 = randomDataImpl47.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray51 = new java.lang.Object[] { randomDataImpl47, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray51);
//        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(localizable33, objArray51);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray51);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 21.44917489924856d, (java.lang.Number) 40, false);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray20);
//        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 3L + "'", long49 == 3L);
//        org.junit.Assert.assertNotNull(objArray51);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8021798724125822d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException(throwable3, localizable4, objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray5);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable1, objArray5);
        int int9 = maxIterationsExceededException8.getMaxIterations();
        int int10 = maxIterationsExceededException8.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        long long10 = randomDataImpl0.nextPoisson(0.024095219843600375d);
//        long long13 = randomDataImpl0.nextSecureLong(16L, (long) ' ');
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 14L + "'", long6 == 14L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 27L + "'", long13 == 27L);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.2406599168205174d, false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.37220941211025227d, (-0.5393840659682915d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5375664622971166d + "'", double2 == 2.5375664622971166d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.16567648182394956d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test360");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.density(0.0d);
//        double double7 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        normalDistributionImpl2.reseedRandomGenerator((long) '4');
//        try {
//            double double11 = normalDistributionImpl2.inverseCumulativeProbability(1.5860134523134308E15d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1,586,013,452,313,430.8 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3989422804014327d + "'", double6 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.9551314916686544d + "'", double7 == 1.9551314916686544d);
//    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 63L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015999658697231856d + "'", double1 == 0.015999658697231856d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-1L), (java.lang.Number) 1.5707963267948966d, true);
        java.lang.Object[] objArray5 = numberIsTooSmallException4.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        boolean boolean8 = numberIsTooSmallException4.getBoundIsAllowed();
        boolean boolean9 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test363");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian((double) 77, (double) 95);
//        long long5 = randomDataImpl0.nextPoisson((double) 52);
//        int int8 = randomDataImpl0.nextZipf(62, 0.6470705702762445d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 278.5869260102844d + "'", double3 == 278.5869260102844d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 59L + "'", long5 == 59L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
//    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        java.lang.Number number4 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        java.lang.Throwable throwable9 = null;
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        java.lang.Object[] objArray11 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
//        long long23 = randomDataImpl21.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { randomDataImpl21, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable20, objArray25);
//        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable7, objArray25);
//        java.lang.String str28 = mathException27.getPattern();
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 7L + "'", long23 == 7L);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0} out of [{1}, {2}] range" + "'", str28.equals("{0} out of [{1}, {2}] range"));
//    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 44);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.0d + "'", double1 == 44.0d);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test366");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        randomDataImpl0.reSeed((long) (byte) 0);
//        try {
//            int int13 = randomDataImpl0.nextPascal(6, (-0.5564096356857139d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.556 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18L + "'", long2 == 18L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 99L + "'", long6 == 99L);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        double double7 = randomDataImpl0.nextT(1.0000000000005154d);
//        int int10 = randomDataImpl0.nextInt(36, 45);
//        double double13 = randomDataImpl0.nextGaussian(1.2863830609917772d, (double) 9L);
//        randomDataImpl0.reSeedSecure(18L);
//        try {
//            long long18 = randomDataImpl0.nextSecureLong((long) 90, 27L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 90 is larger than, or equal to, the maximum (27): lower bound (90) must be strictly less than upper bound (27)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.03093311449215d + "'", double7 == 20.03093311449215d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 40 + "'", int10 == 40);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.695822032967624d + "'", double13 == 2.695822032967624d);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) 100, 79.01563906979106d);
    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test369");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 68, (java.lang.Number) 61.34806127363477d, (java.lang.Number) 23.0f);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        java.lang.Number number8 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (short) -1, number8, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        java.lang.Throwable throwable13 = null;
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Object[] objArray15 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(throwable13, localizable14, objArray15);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray15);
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5, localizable11, objArray15);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        org.apache.commons.math.exception.util.Localizable localizable24 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl25 = new org.apache.commons.math.random.RandomDataImpl();
//        long long27 = randomDataImpl25.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { randomDataImpl25, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray29);
//        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable11, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Throwable throwable34 = null;
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        java.lang.Object[] objArray36 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(throwable34, localizable35, objArray36);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray36);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray36);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable11, objArray36);
//        java.lang.Number number41 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, number41);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 72L, (java.lang.Number) 0.5805798121089214d, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 2.1556157735575975E15d, (java.lang.Number) 14L, false);
//        boolean boolean51 = numberIsTooSmallException50.getBoundIsAllowed();
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        java.lang.Number number57 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) (short) -1, number57, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable60 = outOfRangeException59.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable61 = null;
//        java.lang.Throwable throwable62 = null;
//        org.apache.commons.math.exception.util.Localizable localizable63 = null;
//        java.lang.Object[] objArray64 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(throwable62, localizable63, objArray64);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable61, objArray64);
//        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException54, localizable60, objArray64);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable60, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        java.lang.Object[] objArray72 = outOfRangeException71.getArguments();
//        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException50, "org.apache.commons.math.MaxIterationsExceededException: ", objArray72);
//        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray15);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 14L + "'", long27 == 14L);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray64);
//        org.junit.Assert.assertNotNull(objArray72);
//    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        java.lang.Number number2 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, number2, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (short) 1);
//        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException8);
//        java.lang.Number number10 = notStrictlyPositiveException8.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable13 = null;
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        java.lang.Throwable throwable15 = null;
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        java.lang.Object[] objArray17 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(throwable15, localizable16, objArray17);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray17);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable13, objArray17);
//        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException8, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray17);
//        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable5, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        java.lang.Number number25 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable23, (java.lang.Number) (short) -1, number25, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable28 = outOfRangeException27.getGeneralPattern();
//        java.lang.Throwable throwable29 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        java.lang.Number number34 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) (short) -1, number34, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable37 = outOfRangeException36.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        java.lang.Throwable throwable39 = null;
//        org.apache.commons.math.exception.util.Localizable localizable40 = null;
//        java.lang.Object[] objArray41 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(throwable39, localizable40, objArray41);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray41);
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException31, localizable37, objArray41);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        java.lang.Throwable throwable50 = null;
//        org.apache.commons.math.exception.util.Localizable localizable51 = null;
//        java.lang.Object[] objArray52 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(throwable50, localizable51, objArray52);
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("hi!", objArray52);
//        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(throwable29, localizable37, objArray52);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        java.lang.Number number60 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException(localizable58, (java.lang.Number) (short) -1, number60, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable63 = outOfRangeException62.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable64 = null;
//        java.lang.Throwable throwable65 = null;
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        java.lang.Object[] objArray67 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException(throwable65, localizable66, objArray67);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, objArray67);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException57, localizable63, objArray67);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable63, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable75 = null;
//        org.apache.commons.math.exception.util.Localizable localizable76 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl77 = new org.apache.commons.math.random.RandomDataImpl();
//        long long79 = randomDataImpl77.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray81 = new java.lang.Object[] { randomDataImpl77, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable75, localizable76, objArray81);
//        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException(localizable63, objArray81);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException87 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 4.876699866193449E-5d, (java.lang.Number) (-1.0f), false);
//        boolean boolean88 = numberIsTooLargeException87.getBoundIsAllowed();
//        boolean boolean89 = numberIsTooLargeException87.getBoundIsAllowed();
//        java.lang.Throwable[] throwableArray90 = numberIsTooLargeException87.getSuppressed();
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable63, (java.lang.Object[]) throwableArray90);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable28, (java.lang.Object[]) throwableArray90);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException96 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.8504636186597091d, (java.lang.Number) 0.12568883201658335d, true);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 1 + "'", number10.equals((short) 1));
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray41);
//        org.junit.Assert.assertNotNull(objArray52);
//        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray67);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 7L + "'", long79 == 7L);
//        org.junit.Assert.assertNotNull(objArray81);
//        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
//        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
//        org.junit.Assert.assertNotNull(throwableArray90);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (short) -1, number3, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12, localizable13, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Throwable throwable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, localizable19, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable6, objArray20);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 38.0d, (java.lang.Number) 0.05166500343733741d, (java.lang.Number) 44.0d);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.25752249766017d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-5.369072799443803d), 0.0d, (double) 2147483647, 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1, (java.lang.Number) 0.8504636186597091d, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (short) -1, number7, (java.lang.Number) 100.0f);
        java.lang.Number number10 = outOfRangeException9.getLo();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException4.getArgument();
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1 + "'", number12.equals(1));
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test377");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        double double8 = randomDataImpl0.nextCauchy(11013.232920103323d, 0.7539022543433046d);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11011.742223675215d + "'", double8 == 11011.742223675215d);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.10050340356651512d, (java.lang.Number) 18.667927720004286d, (java.lang.Number) 89);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.017404087442358464d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017403208832762824d) + "'", double1 == (-0.017403208832762824d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.6704649792860586d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, localizable5, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7, "org.apache.commons.math.MaxIterationsExceededException: maximal number of iterations (97) exceeded", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7);
        org.junit.Assert.assertNotNull(objArray12);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextInt((int) (short) 0, (int) 'a');
//        double double6 = randomDataImpl0.nextWeibull(0.13313701469396125d, (double) 8L);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        int int10 = randomDataImpl7.nextInt((int) (short) 0, (int) 'a');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double12 = randomDataImpl7.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        normalDistributionImpl11.reseedRandomGenerator((long) (short) 0);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double16 = normalDistributionImpl11.getStandardDeviation();
//        double double17 = normalDistributionImpl11.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 19679.027768021402d + "'", double6 == 19679.027768021402d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 16 + "'", int10 == 16);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.2243801210332215d) + "'", double12 == (-1.2243801210332215d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.24192078471519757d) + "'", double15 == (-0.24192078471519757d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test383");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        java.lang.Number number4 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl10 = new org.apache.commons.math.random.RandomDataImpl();
//        long long12 = randomDataImpl10.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray14 = new java.lang.Object[] { randomDataImpl10, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray14);
//        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable7, objArray14);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(7, localizable1, objArray14);
//        int int18 = maxIterationsExceededException17.getMaxIterations();
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(objArray14);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 7 + "'", int18 == 7);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.8690199572373172d, (java.lang.Number) 100.0d, false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 52, false);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test386");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.getMean();
//        double double6 = normalDistributionImpl2.density(0.0d);
//        double double7 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl2);
//        int int10 = randomDataImpl1.nextZipf(42, 1.1579869585617917d);
//        try {
//            long long13 = randomDataImpl1.nextSecureLong(98L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 98 is larger than, or equal to, the maximum (0): lower bound (98) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3989422804014327d + "'", double6 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.9945794634228278d) + "'", double7 == (-0.9945794634228278d));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        int int4 = maxIterationsExceededException1.getMaxIterations();
        java.lang.String str5 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 97 + "'", int4 == 97);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str5.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 47.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5813128861900675E20d + "'", double1 == 2.5813128861900675E20d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
        java.lang.Number number19 = outOfRangeException18.getLo();
        java.lang.String str20 = outOfRangeException18.toString();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 13L + "'", number19.equals(13L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 1 out of [13, 68] range: 1 out of [13, 68] range" + "'", str20.equals("org.apache.commons.math.exception.OutOfRangeException: 1 out of [13, 68] range: 1 out of [13, 68] range"));
    }

//    @Test
//    public void test390() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test390");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        java.lang.Number number2 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) -1, number2, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl();
//        long long10 = randomDataImpl8.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray12 = new java.lang.Object[] { randomDataImpl8, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray12);
//        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable5, objArray12);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        java.lang.Number number19 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) (short) -1, number19, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable22 = outOfRangeException21.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable23 = null;
//        java.lang.Throwable throwable24 = null;
//        org.apache.commons.math.exception.util.Localizable localizable25 = null;
//        java.lang.Object[] objArray26 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(throwable24, localizable25, objArray26);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray26);
//        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException16, localizable22, objArray26);
//        java.lang.Throwable throwable30 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        java.lang.Number number35 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) (short) -1, number35, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable38 = outOfRangeException37.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        java.lang.Throwable throwable40 = null;
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        java.lang.Object[] objArray42 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable40, localizable41, objArray42);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray42);
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException32, localizable38, objArray42);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        java.lang.Throwable throwable51 = null;
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        java.lang.Object[] objArray53 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(throwable51, localizable52, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("hi!", objArray53);
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(throwable30, localizable38, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable22, objArray53);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        java.lang.Throwable throwable59 = null;
//        org.apache.commons.math.exception.util.Localizable localizable60 = null;
//        java.lang.Object[] objArray61 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(throwable59, localizable60, objArray61);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray61);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray61);
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable5, objArray61);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 12L + "'", long10 == 12L);
//        org.junit.Assert.assertNotNull(objArray12);
//        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray26);
//        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray42);
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertNotNull(objArray61);
//    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        double double8 = randomDataImpl0.nextCauchy(11013.232920103323d, 0.7539022543433046d);
//        randomDataImpl0.reSeedSecure((long) 17);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17L + "'", long2 == 17L);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 11013.073214023623d + "'", double8 == 11013.073214023623d);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) (short) -1, number4, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = outOfRangeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(throwable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray11);
        int int15 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100.0d, number1, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        java.lang.Class<?> wildcardClass2 = maxIterationsExceededException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test395");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        double double7 = randomDataImpl0.nextT(1.0000000000005154d);
//        int int10 = randomDataImpl0.nextInt(36, 45);
//        double double13 = randomDataImpl0.nextGaussian(1.2863830609917772d, (double) 9L);
//        double double16 = randomDataImpl0.nextGamma((double) 97, 3.438939466091658d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("4f5b758", "f3c305485b5ef34c832287c18843a186a1de901407eaf93b953cdf41bc5cbebf1ff83269478d35d06576d00313224d69d7ca");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: f3c305485b5ef34c832287c18843a186a1de901407eaf93b953cdf41bc5cbebf1ff83269478d35d06576d00313224d69d7ca");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.24649830642467138d) + "'", double7 == (-0.24649830642467138d));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 42 + "'", int10 == 42);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-4.293030333734862d) + "'", double13 == (-4.293030333734862d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 354.3987674173764d + "'", double16 == 354.3987674173764d);
//    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable3 = null;
//        java.lang.Number number5 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) (short) -1, number5, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable8 = outOfRangeException7.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        java.lang.Throwable throwable10 = null;
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        java.lang.Object[] objArray12 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException(throwable10, localizable11, objArray12);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray12);
//        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2, localizable8, objArray12);
//        java.lang.Number number17 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 100L, number17, (java.lang.Number) 57);
//        java.lang.Throwable throwable20 = null;
//        org.apache.commons.math.exception.util.Localizable localizable21 = null;
//        java.lang.Object[] objArray22 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(throwable20, localizable21, objArray22);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException(29, localizable8, objArray22);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        java.lang.Number number30 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException(localizable28, (java.lang.Number) (short) -1, number30, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable33 = outOfRangeException32.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable34 = null;
//        java.lang.Throwable throwable35 = null;
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        java.lang.Object[] objArray37 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(throwable35, localizable36, objArray37);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray37);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException27, localizable33, objArray37);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl47 = new org.apache.commons.math.random.RandomDataImpl();
//        long long49 = randomDataImpl47.nextPoisson((double) (byte) 10);
//        java.lang.Object[] objArray51 = new java.lang.Object[] { randomDataImpl47, 0 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray51);
//        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException(localizable33, objArray51);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable56 = null;
//        java.lang.Number number58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException(localizable56, (java.lang.Number) (short) -1, number58, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable61 = outOfRangeException60.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable62 = null;
//        java.lang.Throwable throwable63 = null;
//        org.apache.commons.math.exception.util.Localizable localizable64 = null;
//        java.lang.Object[] objArray65 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(throwable63, localizable64, objArray65);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, objArray65);
//        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException55, localizable61, objArray65);
//        java.lang.Throwable throwable69 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
//        org.apache.commons.math.exception.util.Localizable localizable72 = null;
//        java.lang.Number number74 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException(localizable72, (java.lang.Number) (short) -1, number74, (java.lang.Number) 100.0f);
//        org.apache.commons.math.exception.util.Localizable localizable77 = outOfRangeException76.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable78 = null;
//        java.lang.Throwable throwable79 = null;
//        org.apache.commons.math.exception.util.Localizable localizable80 = null;
//        java.lang.Object[] objArray81 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException(throwable79, localizable80, objArray81);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable78, objArray81);
//        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException71, localizable77, objArray81);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException88 = new org.apache.commons.math.exception.OutOfRangeException(localizable77, (java.lang.Number) 1.0f, (java.lang.Number) 13L, (java.lang.Number) 68);
//        java.lang.Throwable throwable90 = null;
//        org.apache.commons.math.exception.util.Localizable localizable91 = null;
//        java.lang.Object[] objArray92 = new java.lang.Object[] {};
//        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(throwable90, localizable91, objArray92);
//        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException("hi!", objArray92);
//        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException(throwable69, localizable77, objArray92);
//        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException(localizable61, objArray92);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException97 = new org.apache.commons.math.MaxIterationsExceededException(18, localizable33, objArray92);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException98 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray92);
//        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray12);
//        org.junit.Assert.assertNotNull(objArray22);
//        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 11L + "'", long49 == 11L);
//        org.junit.Assert.assertNotNull(objArray51);
//        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray65);
//        org.junit.Assert.assertTrue("'" + localizable77 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable77.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//        org.junit.Assert.assertNotNull(objArray81);
//        org.junit.Assert.assertNotNull(objArray92);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test397");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long2 = randomDataImpl0.nextPoisson((double) (byte) 10);
//        randomDataImpl0.reSeed();
//        long long6 = randomDataImpl0.nextLong((long) 10, (long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        long long10 = randomDataImpl0.nextPoisson((double) 23.0f);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 37L + "'", long6 == 37L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 24L + "'", long10 == 24L);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException(throwable2, localizable3, objArray4);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "maximal number of iterations ({0}) exceeded", objArray4);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) 'a');
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) (short) -1, number13, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Throwable throwable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(throwable18, localizable19, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException10, localizable16, objArray20);
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException(localizable16, (java.lang.Number) 100L, number25, (java.lang.Number) 57);
        java.lang.Throwable throwable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(throwable28, localizable29, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(29, localizable16, objArray30);
        java.lang.String str33 = maxIterationsExceededException32.toString();
        java.lang.Throwable[] throwableArray34 = maxIterationsExceededException32.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException6, "fa4b13bd3ef0b91b7649ad23ba709dcf37f069", (java.lang.Object[]) throwableArray34);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: {0} out of [{1}, {2}] range" + "'", str33.equals("org.apache.commons.math.MaxIterationsExceededException: {0} out of [{1}, {2}] range"));
        org.junit.Assert.assertNotNull(throwableArray34);
    }
}

