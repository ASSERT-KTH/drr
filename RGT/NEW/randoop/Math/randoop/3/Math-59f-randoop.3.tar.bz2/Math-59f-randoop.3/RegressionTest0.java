import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test002");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.1815027478891328d + "'", double0 == 0.1815027478891328d);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.log10(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test008");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.32096922f + "'", float1 == 0.32096922f);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int[] intArray2 = new int[] { 0, 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        long long4 = mersenneTwister3.nextLong();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2084377003539008444L + "'", long4 == 2084377003539008444L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.newInstance(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.DfpField.computeExp(dfp16, dfp24);
        try {
            org.apache.commons.math.dfp.Dfp dfp27 = org.apache.commons.math.dfp.DfpField.computeLn(dfp6, dfp7, dfp24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2084377003539008444L, (float) (-32767));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.08437704E18f + "'", float2 == 2.08437704E18f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 2084377003539008444L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.newInstance(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.newInstance(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = org.apache.commons.math.dfp.DfpField.computeExp(dfp9, dfp17);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp17.power10K(0);
        try {
            org.apache.commons.math.dfp.Dfp dfp22 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        int int2 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        int int19 = dfp8.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.047442967903742035d + "'", double1 == 0.047442967903742035d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        boolean boolean1 = mersenneTwister0.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0L, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp22.newInstance(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp18, dfp26);
        boolean boolean29 = dfp28.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        double double2 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1719812657575726472L) + "'", long1 == (-1719812657575726472L));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9847576174279353d + "'", double2 == 0.9847576174279353d);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0.9744649f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.011233802419004782d) + "'", double1 == (-0.011233802419004782d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1719812657575726472L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.1815027478891328d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.183536191403702d + "'", double1 == 0.183536191403702d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.power10K((int) '#');
        java.lang.String str11 = dfp10.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "1.000000000000e140" + "'", str11.equals("1.000000000000e140"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.141592653589793d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926535897927d + "'", double2 == 3.1415926535897927d);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        double double2 = mersenneTwister0.nextGaussian();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-5532369917677424186L) + "'", long1 == (-5532369917677424186L));
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0097557384509994d + "'", double2 == 1.0097557384509994d);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.newInstance(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp10.newInstance(dfp22);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.newInstance(dfp52);
        double[] doubleArray54 = dfp53.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.newInstance(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.newInstance(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp74, dfp82);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp65.remainder(dfp82);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp53.newInstance(dfp65);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField1.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.011233802419004782d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.22396264802231142d) + "'", double1 == (-0.22396264802231142d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.newInstance(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.DfpField.computeExp(dfp41, dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp32.remainder(dfp49);
        java.lang.Class<?> wildcardClass53 = dfp32.getClass();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp19.multiply(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        boolean boolean64 = dfp19.unequal(dfp63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField70.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp68.newInstance(dfp72);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField75.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField79.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp77.newInstance(dfp81);
        org.apache.commons.math.dfp.Dfp dfp83 = org.apache.commons.math.dfp.DfpField.computeExp(dfp73, dfp81);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp81.power10((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp19.add(dfp85);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 0);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.15071714f + "'", float2 == 0.15071714f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.power10((int) (byte) 100);
        int int21 = dfp20.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int[] intArray2 = new int[] { 0, 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((int) (short) -1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int[] intArray2 = new int[] { 0, 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 0.9744649f);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.newInstance(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.DfpField.computeExp(dfp41, dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp32.remainder(dfp49);
        java.lang.Class<?> wildcardClass53 = dfp32.getClass();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp19.multiply(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        boolean boolean64 = dfp19.unequal(dfp63);
        double double65 = dfp63.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 10.0d + "'", double65 == 10.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1.0f, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int[] intArray0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
        mersenneTwister1.setSeed((int) (byte) 10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int[] intArray2 = new int[] { 0, 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        int int5 = mersenneTwister3.nextInt((int) (byte) 10);
        double double6 = mersenneTwister3.nextGaussian();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.21841921301152d) + "'", double6 == (-0.21841921301152d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.011233802419004782d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.011233329892464691d) + "'", double1 == (-0.011233329892464691d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        double double19 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance((double) 1);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp27.newInstance(dfp31);
        double[] doubleArray33 = dfp32.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp37.newInstance(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp41.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.newInstance(dfp52);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp57.newInstance(dfp61);
        org.apache.commons.math.dfp.Dfp dfp63 = org.apache.commons.math.dfp.DfpField.computeExp(dfp53, dfp61);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp44.remainder(dfp61);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp32.newInstance(dfp44);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField23.newDfp(dfp65);
        boolean boolean67 = dfp21.lessThan(dfp66);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.newInstance(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.DfpField.computeExp(dfp41, dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp32.remainder(dfp49);
        java.lang.Class<?> wildcardClass53 = dfp32.getClass();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp19.multiply(dfp32);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp19.negate();
        org.apache.commons.math.dfp.Dfp dfp56 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp57 = dfp55.divide(dfp56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32768);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.89400457879299d + "'", double1 == 17.89400457879299d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        double double19 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance((double) 1);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp34.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp30, dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.newInstance();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp47.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField65.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField69.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp67.newInstance(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = org.apache.commons.math.dfp.DfpField.computeExp(dfp63, dfp71);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp54.remainder(dfp71);
        java.lang.Class<?> wildcardClass75 = dfp54.getClass();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp41.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField78.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField82.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp80.newInstance(dfp84);
        boolean boolean86 = dfp41.unequal(dfp85);
        boolean boolean87 = dfp16.unequal(dfp85);
        int int88 = dfp85.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.newInstance(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp32.newInstance(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeExp(dfp28, dfp36);
        double double39 = dfp36.toDouble();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.newInstance((double) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp18.subtract(dfp36);
        boolean boolean43 = dfp36.isNaN();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 10.0d + "'", double39 == 10.0d);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int[] intArray0 = new int[] {};
        try {
            org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int[] intArray2 = new int[] { 0, 1 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        int[] intArray9 = new int[] { 'a', (byte) 100, (short) 0, (short) -1, (short) 10 };
        mersenneTwister3.setSeed(intArray9);
        java.lang.Class<?> wildcardClass11 = mersenneTwister3.getClass();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
//        float float5 = mersenneTwister4.nextFloat();
//        java.lang.Object[] objArray7 = new java.lang.Object[] { 100.0d, 1.0f, 10.0f, mersenneTwister4, 100.0f };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray7);
//        java.lang.Object[] objArray9 = mathIllegalArgumentException8.getArguments();
//        java.lang.Throwable[] throwableArray10 = mathIllegalArgumentException8.getSuppressed();
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.59776187f + "'", float5 == 0.59776187f);
//        org.junit.Assert.assertNotNull(objArray7);
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNotNull(throwableArray10);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 2.718281828459045d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.newInstance(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp10.newInstance(dfp22);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.newInstance(dfp52);
        double[] doubleArray54 = dfp53.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.newInstance(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.newInstance(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp74, dfp82);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp65.remainder(dfp82);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp53.newInstance(dfp65);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField1.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField1.newDfp((double) 2.08437704E18f);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp89);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 2.718281828459045d, true);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((int) (short) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp16.power10((int) (byte) 100);
        int int21 = dfp16.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        dfpField11.setIEEEFlagsBits(100);
        dfpField11.setIEEEFlags((int) (short) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        double[] doubleArray18 = dfp17.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp22.newInstance(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.newInstance(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp42.newInstance(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeExp(dfp38, dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp29.remainder(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp17.newInstance(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp54.newInstance(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField65.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp63.newInstance(dfp67);
        org.apache.commons.math.dfp.Dfp dfp69 = org.apache.commons.math.dfp.DfpField.computeExp(dfp59, dfp67);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField75.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp73.newInstance(dfp77);
        org.apache.commons.math.dfp.Dfp dfp79 = org.apache.commons.math.dfp.DfpField.computeExp(dfp69, dfp77);
        org.apache.commons.math.dfp.Dfp dfp80 = dfp29.subtract(dfp79);
        boolean boolean81 = dfp8.unequal(dfp80);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        double[] doubleArray9 = dfp8.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.newInstance(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.newInstance(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.newInstance(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.DfpField.computeExp(dfp29, dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.remainder(dfp37);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp8.newInstance(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.newInstance(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp54.newInstance(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.DfpField.computeExp(dfp50, dfp58);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp64.newInstance(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = org.apache.commons.math.dfp.DfpField.computeExp(dfp60, dfp68);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp20.subtract(dfp70);
        java.lang.Class<?> wildcardClass72 = dfp70.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(wildcardClass72);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        double[] doubleArray9 = dfp8.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.newInstance(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.newInstance(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.newInstance(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.DfpField.computeExp(dfp29, dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.remainder(dfp37);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp8.newInstance(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.newInstance(dfp49);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp54.newInstance(dfp58);
        org.apache.commons.math.dfp.Dfp dfp60 = org.apache.commons.math.dfp.DfpField.computeExp(dfp50, dfp58);
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField62.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp64.newInstance(dfp68);
        org.apache.commons.math.dfp.Dfp dfp70 = org.apache.commons.math.dfp.DfpField.computeExp(dfp60, dfp68);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp20.subtract(dfp70);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp71.newInstance();
        boolean boolean73 = dfp72.isNaN();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister();
//        float float7 = mersenneTwister6.nextFloat();
//        java.lang.Object[] objArray9 = new java.lang.Object[] { 100.0d, 1.0f, 10.0f, mersenneTwister6, 100.0f };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray9);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray9);
//        org.apache.commons.math.exception.util.Localizable localizable12 = mathIllegalArgumentException11.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.08484554f + "'", float7 == 0.08484554f);
//        org.junit.Assert.assertNotNull(objArray9);
//        org.junit.Assert.assertNull(localizable12);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        double double19 = dfp16.toDouble();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp16.newInstance((double) 1);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp34.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp30, dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp40.newInstance();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp47.newInstance(dfp51);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.DfpField dfpField65 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField65.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField69.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp67.newInstance(dfp71);
        org.apache.commons.math.dfp.Dfp dfp73 = org.apache.commons.math.dfp.DfpField.computeExp(dfp63, dfp71);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp54.remainder(dfp71);
        java.lang.Class<?> wildcardClass75 = dfp54.getClass();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp41.multiply(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField78.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField82.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp80.newInstance(dfp84);
        boolean boolean86 = dfp41.unequal(dfp85);
        boolean boolean87 = dfp16.unequal(dfp85);
        org.apache.commons.math.dfp.Dfp dfp88 = new org.apache.commons.math.dfp.Dfp(dfp85);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test096");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
//        float float5 = mersenneTwister4.nextFloat();
//        java.lang.Object[] objArray7 = new java.lang.Object[] { 100.0d, 1.0f, 10.0f, mersenneTwister4, 100.0f };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray7);
//        java.lang.Throwable throwable9 = null;
//        try {
//            mathIllegalArgumentException8.addSuppressed(throwable9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.7409246f + "'", float5 == 0.7409246f);
//        org.junit.Assert.assertNotNull(objArray7);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.abs(17.89400457879299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.89400457879299d + "'", double1 == 17.89400457879299d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.newInstance(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp10.newInstance(dfp22);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.newInstance(dfp52);
        double[] doubleArray54 = dfp53.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.newInstance(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.newInstance(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp74, dfp82);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp65.remainder(dfp82);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp53.newInstance(dfp65);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField1.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5729.5779513082325d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        double[] doubleArray9 = dfp8.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.newInstance(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.newInstance(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp33.newInstance(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = org.apache.commons.math.dfp.DfpField.computeExp(dfp29, dfp37);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp20.remainder(dfp37);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp8.newInstance(dfp20);
        org.apache.commons.math.dfp.Dfp dfp42 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp43 = dfp8.divide(dfp42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.762747174039086d + "'", double1 == 1.762747174039086d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.newInstance(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.DfpField.computeExp(dfp41, dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp32.remainder(dfp49);
        java.lang.Class<?> wildcardClass53 = dfp32.getClass();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp19.multiply(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp58.newInstance((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.newInstance(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.newInstance(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp74, dfp82);
        boolean boolean85 = dfp58.lessThan(dfp82);
        boolean boolean86 = dfp54.unequal(dfp58);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.newInstance(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp10.newInstance(dfp22);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.newInstance(dfp52);
        double[] doubleArray54 = dfp53.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.newInstance(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.newInstance(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp74, dfp82);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp65.remainder(dfp82);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp53.newInstance(dfp65);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField1.newDfp(dfp53);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode88 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertTrue("'" + roundingMode88 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode88.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 2, (java.lang.Number) 2, true);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(10000);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance(dfp13);
        double[] doubleArray15 = dfp14.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp19.newInstance(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp30.newInstance(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.newInstance(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.DfpField.computeExp(dfp35, dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp26.remainder(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp14.newInstance(dfp26);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField5.newDfp(dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp57 = dfp52.newInstance(dfp56);
        double[] doubleArray58 = dfp57.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField64.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp62.newInstance(dfp66);
        org.apache.commons.math.dfp.Dfp dfp69 = dfp66.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField75.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp73.newInstance(dfp77);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField84 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp86 = dfpField84.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp87 = dfp82.newInstance(dfp86);
        org.apache.commons.math.dfp.Dfp dfp88 = org.apache.commons.math.dfp.DfpField.computeExp(dfp78, dfp86);
        org.apache.commons.math.dfp.Dfp dfp89 = dfp69.remainder(dfp86);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp57.newInstance(dfp69);
        org.apache.commons.math.dfp.Dfp dfp91 = dfpField5.newDfp(dfp57);
        org.apache.commons.math.dfp.Dfp[] dfpArray92 = dfpField5.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray93 = dfpField5.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray94 = dfpField5.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, (java.lang.Object[]) dfpArray94);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfpArray92);
        org.junit.Assert.assertNotNull(dfpArray93);
        org.junit.Assert.assertNotNull(dfpArray94);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        double[] doubleArray9 = dfp8.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp14.newInstance(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp34.newInstance(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp30, dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp21.remainder(dfp38);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp10.multiply(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp41.newInstance(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 0, (byte) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.21841921301152d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp11.newInstance(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.newInstance(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = org.apache.commons.math.dfp.DfpField.computeExp(dfp16, dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.power10((int) (byte) 100);
        boolean boolean29 = dfp7.greaterThan(dfp28);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double2 = org.apache.commons.math.util.FastMath.max(3.1415926535897927d, (double) (-3399311318112552828L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926535897927d + "'", double2 == 3.1415926535897927d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32760.0d + "'", double1 == 32760.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.newInstance(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp10.newInstance(dfp22);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.newInstance(dfp52);
        double[] doubleArray54 = dfp53.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.newInstance(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.newInstance(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp74, dfp82);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp65.remainder(dfp82);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp53.newInstance(dfp65);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField1.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp[] dfpArray88 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp90 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfpArray88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 2, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.newInstance(dfp17);
        double[] doubleArray19 = dfp18.toSplitDouble();
        int int20 = dfp18.intValue();
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp9, dfp18);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.rint();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.newInstance(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp10.newInstance(dfp22);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.newInstance(dfp52);
        double[] doubleArray54 = dfp53.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.newInstance(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.newInstance(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp74, dfp82);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp65.remainder(dfp82);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp53.newInstance(dfp65);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField1.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp[] dfpArray88 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray89 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray90 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp92 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfpArray88);
        org.junit.Assert.assertNotNull(dfpArray89);
        org.junit.Assert.assertNotNull(dfpArray90);
        org.junit.Assert.assertNotNull(dfp92);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.newInstance(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.DfpField.computeExp(dfp41, dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp32.remainder(dfp49);
        java.lang.Class<?> wildcardClass53 = dfp32.getClass();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp19.multiply(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField66 = dfp62.getField();
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getLn10();
        org.apache.commons.math.dfp.Dfp dfp68 = org.apache.commons.math.dfp.Dfp.copysign(dfp32, dfp67);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField70.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField74.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp72.newInstance(dfp76);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp76.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField80 = dfp76.getField();
        org.apache.commons.math.dfp.Dfp dfp81 = org.apache.commons.math.dfp.DfpField.computeExp(dfp68, dfp76);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfpField66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfpField80);
        org.junit.Assert.assertNotNull(dfp81);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((double) 2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 100, (byte) -1);
        dfpField1.setIEEEFlags((-1));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        dfpField11.setIEEEFlagsBits(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField11.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.newDfp((long) (-32767));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Throwable throwable4 = null;
        try {
            notStrictlyPositiveException2.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.newInstance(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp10.newInstance(dfp22);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.newInstance(dfp52);
        double[] doubleArray54 = dfp53.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.newInstance(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.newInstance(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp74, dfp82);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp65.remainder(dfp82);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp53.newInstance(dfp65);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField1.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp[] dfpArray88 = dfpField1.getESplit();
        dfpField1.setIEEEFlags((int) (byte) 2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfpArray88);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        java.lang.Class<?> wildcardClass9 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp7.getField();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2();
        dfpField11.setIEEEFlagsBits(100);
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField11.getPiSplit();
        dfpField11.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp8, dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.newInstance();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(dfp29);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp29.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp36.newInstance(dfp40);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp45.newInstance(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.DfpField.computeExp(dfp41, dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp32.remainder(dfp49);
        java.lang.Class<?> wildcardClass53 = dfp32.getClass();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp19.multiply(dfp32);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp19.negate();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp59.newInstance(dfp63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField70.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp73 = dfp68.newInstance(dfp72);
        org.apache.commons.math.dfp.Dfp dfp74 = org.apache.commons.math.dfp.DfpField.computeExp(dfp64, dfp72);
        double double75 = dfp72.toDouble();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp72.newInstance((double) 1);
        boolean boolean78 = dfp55.greaterThan(dfp77);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 10.0d + "'", double75 == 10.0d);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, number5);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.newInstance(dfp17);
        double[] doubleArray19 = dfp18.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.newInstance(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp34.newInstance(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp43.newInstance(dfp47);
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.DfpField.computeExp(dfp39, dfp47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp30.remainder(dfp47);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp18.newInstance(dfp30);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField9.newDfp(dfp51);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField9.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable7, (java.lang.Object[]) dfpArray53);
        java.lang.Number number55 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, number55, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 2.718281828459045d, true);
        java.lang.Object[] objArray64 = numberIsTooSmallException63.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable59, objArray64);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(objArray64);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance(dfp9);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp15.newInstance(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp19.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.newInstance(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp35.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.remainder(dfp39);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp10.newInstance(dfp22);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField1.newDfp(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp48.newInstance(dfp52);
        double[] doubleArray54 = dfp53.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField60 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField60.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance(dfp62);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp62.power10K((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField71.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp69.newInstance(dfp73);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField76.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.DfpField dfpField80 = new org.apache.commons.math.dfp.DfpField(1);
        org.apache.commons.math.dfp.Dfp dfp82 = dfpField80.newDfp((double) 10.0f);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp78.newInstance(dfp82);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeExp(dfp74, dfp82);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp65.remainder(dfp82);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp53.newInstance(dfp65);
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField1.newDfp(dfp53);
        org.apache.commons.math.dfp.Dfp[] dfpArray88 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray89 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlagsBits(7);
        org.apache.commons.math.dfp.Dfp dfp92 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp93 = dfp92.floor();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp82);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfpArray88);
        org.junit.Assert.assertNotNull(dfpArray89);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
    }
}

