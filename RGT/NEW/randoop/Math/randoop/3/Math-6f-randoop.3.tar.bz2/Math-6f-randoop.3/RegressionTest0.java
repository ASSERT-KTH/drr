import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "hi!", "", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((int) ' ');
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double[] doubleArray5 = new double[] { (byte) -1, (short) 10, 100L, 1.0d, 0 };
        try {
            org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int1 = org.apache.commons.math3.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((-1.0d), (double) (-1.0f), (double) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double[] doubleArray3 = new double[] { 'a', (short) -1, 0.0d };
        double[][] doubleArray4 = new double[][] { doubleArray3 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray4, (double) 0.0f, 1.0d, (double) (short) 10, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray2 = new double[] {};
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition3 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double[] doubleArray4 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray5);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess9 = new org.apache.commons.math3.optim.InitialGuess(doubleArray8);
        try {
            double double10 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double[] doubleArray4 = new double[] { (-1), (-1), 1.0f, (byte) 10 };
        double[] doubleArray9 = new double[] { (-1), (-1), 1.0f, (byte) 10 };
        double[] doubleArray14 = new double[] { (-1), (-1), 1.0f, (byte) 10 };
        double[] doubleArray19 = new double[] { (-1), (-1), 1.0f, (byte) 10 };
        double[] doubleArray24 = new double[] { (-1), (-1), 1.0f, (byte) 10 };
        double[][] doubleArray25 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: equal vertices 1 and 0 in simplex configuration");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.lang.String[] strArray4 = new java.lang.String[] { "", "hi!", "hi!", "" };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        try {
            boolean boolean7 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray4, orderDirection5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) (byte) 10);
        java.io.ObjectInputStream objectInputStream3 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) tooManyEvaluationsException1, "", objectInputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        try {
            double[] doubleArray5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 0.0d, (double) 100L, (double) (short) 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = null;
        try {
            boolean boolean6 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray3, orderDirection4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        float float3 = org.apache.commons.math3.util.Precision.round((float) 10L, (int) (byte) 100, 6);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double[] doubleArray4 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray5);
        double[] doubleArray8 = new double[] {};
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray4, doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) (byte) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        java.io.ObjectInputStream objectInputStream5 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) doubleArray0, "hi!", objectInputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        try {
            arrayRealVector9.setEntry((int) '#', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 52, 100.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.000004f + "'", float2 == 52.000004f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) 10, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray6 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray6);
        try {
            double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-0.5063656411097588d), 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.05059335214678515d) + "'", double2 == (-0.05059335214678515d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[][] doubleArray3 = new double[][] { doubleArray0, doubleArray1, doubleArray2 };
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.0d, 10.0d, 2.718281828459045d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 17.38905609893065d + "'", double4 == 17.38905609893065d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifySequence(10.0d, (double) (-1.0f), (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray0, 0.0d, (double) 10, (double) 1L, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(2.718281828459045d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4458315914355974E30d + "'", double2 == 3.4458315914355974E30d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix42 = arrayRealVector20.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round(0.0f, 1791095845, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method -1, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        try {
            arrayRealVector9.addToEntry((int) (short) 10, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double[][] doubleArray0 = null;
        try {
            double[][] doubleArray1 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) 1, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) ' ', 17.38905609893065d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (short) 0);
        org.junit.Assert.assertNotNull(simpleBounds1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (-1L), (double) 1.0f, 0.0d, (-0.05059335214678515d), (double) 10L, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        long long1 = org.apache.commons.math3.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        try {
            arrayRealVector9.addToEntry((int) (short) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(0L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isSequence((double) 0, (double) (-1.0f), 10.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double22 = arrayRealVector19.walkInDefaultOrder(realVectorPreservingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) -1);
        try {
            incrementor1.incrementCount(1791095845);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0f, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, 1, 6, (int) (byte) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 0, (double) (short) 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 10);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator3 = null;
        try {
            multiDirectionalSimplex1.evaluate(multivariateFunction2, pointValuePairComparator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        java.io.ObjectOutputStream objectOutputStream11 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, objectOutputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) (-0.7615941559557649d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 52.000004f, (double) 100.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-1.0d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient objectiveFunctionGradient1 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient(multivariateVectorFunction0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double3 = org.apache.commons.math3.util.Precision.round((double) 6, (-1), 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        double[] doubleArray4 = sigma3.getSigma();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math3.util.FastMath.log10(17.38905609893065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.240276008560994d + "'", double1 == 1.240276008560994d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("", (int) (short) 100);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 10, pointVectorValuePairConvergenceChecker1, 0.0d, (double) (short) 100, (double) 1.0f, (double) (short) 10);
        double[] doubleArray9 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma10 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray9);
        try {
            double[][] doubleArray12 = levenbergMarquardtOptimizer6.computeCovariances(doubleArray9, 3.4458315914355974E30d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-1), 100.0f, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        long[] longArray3 = new long[] { 100L, 10L, 6 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray3);
        org.junit.Assert.assertNotNull(longArray3);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, 1, 0);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector32, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector19.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        double[] doubleArray46 = null;
        try {
            arrayRealVector44.setSubVector((int) '#', doubleArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayRealVector44);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        try {
            arrayRealVector19.addToEntry(6, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, 1, 0);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector32, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector19.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        try {
            arrayRealVector32.setEntry(10, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayRealVector44);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, 1, 0);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector32, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector19.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.RealVector realVector45 = null;
        try {
            double double46 = arrayRealVector44.getL1Distance(realVector45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayRealVector44);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = mathInternalError1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker2 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(0.0d, 0.0d, pointValuePairConvergenceChecker2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapAdd(2.718281828459045d);
        java.io.ObjectOutputStream objectOutputStream23 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector22, objectOutputStream23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray2 = initialGuess1.getInitialGuess();
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, (int) 'a');
        try {
            double double7 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray2, doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(100, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number0, (java.lang.Number) 0L, (int) (byte) -1);
        java.lang.Number number4 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(1.240276008560994d, (-1.5707963267948966d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1.571 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) -1, (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(2.718281828459045d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            boolean boolean2 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric(realMatrix0, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (byte) 1, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("hi!", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(1);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double[] doubleArray6 = new double[] { (-1.5707963267948966d), (short) 10, 1.0d, 100L, 7692698082559361259L, (-1.0f) };
        double[][] doubleArray7 = new double[][] { doubleArray6 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1791095845, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 57,315,067,040 is larger than, or equal to, the maximum (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(true);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure2 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure3 = sinc1.value(derivativeStructure2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess2 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) 'a');
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1.0f), (double) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 7692698082559361259L, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.69269808255936E18d + "'", double2 == 7.69269808255936E18d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(100.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574528 + "'", int1 == 1079574528);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double[] doubleArray2 = new double[] { 0.8414709848078965d, 0.0d };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray2, orderDirection3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        java.lang.Double[] doubleArray55 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, 1, 0);
        java.lang.Double[] doubleArray65 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector58, arrayRealVector68);
        double double70 = arrayRealVector48.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        try {
            org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double double4 = simpleVectorValueChecker3.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 14 + "'", int1 == 14);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 10);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction2 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator3 = null;
        try {
            multiDirectionalSimplex1.iterate(multivariateFunction2, pointValuePairComparator3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math3.exception.ConvergenceException convergenceException0 = new org.apache.commons.math3.exception.ConvergenceException();
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math3.util.FastMath.floor(7.69269808255936E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.69269808255936E18d + "'", double1 == 7.69269808255936E18d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) (byte) 10, 6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 640.0d + "'", double2 == 640.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition2 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix0, (double) 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-0.7853981633974483d), (java.lang.Number) (short) 10, true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            org.apache.commons.math3.optim.univariate.SearchInterval searchInterval2 = new org.apache.commons.math3.optim.univariate.SearchInterval((double) 10L, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 52, number2, true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex(anyMatrix0, (int) (short) 0, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int1 = brentSolver0.getEvaluations();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        try {
            double double7 = brentSolver0.solve((int) (byte) 100, univariateFunction3, (double) (byte) 10, (double) (short) -1, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        try {
            double double11 = arrayRealVector9.getEntry((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(1.240276008560994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0415040453759297d + "'", double1 == 1.0415040453759297d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = org.apache.commons.math3.util.FastMath.max((-1), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        try {
            org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector48.getSubVector(0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor49 = null;
        try {
            double double50 = arrayRealVector20.walkInOptimizedOrder(realVectorPreservingVisitor49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double[][] doubleArray2 = new double[][] {};
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = new org.apache.commons.math3.linear.BlockRealMatrix(100, (int) (short) -1, doubleArray2, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, (int) (byte) -1, (int) '#', (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, 1, 0);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector32, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector19.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        try {
            double double46 = arrayRealVector32.getEntry((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayRealVector44);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double[] doubleArray5 = new double[] { (short) 10, (short) -1, 52, ' ', (-0.5063656411097588d) };
        double[] doubleArray11 = new double[] { (short) 10, (short) -1, 52, ' ', (-0.5063656411097588d) };
        double[] doubleArray17 = new double[] { (short) 10, (short) -1, 52, ' ', (-0.5063656411097588d) };
        double[][] doubleArray18 = new double[][] { doubleArray5, doubleArray11, doubleArray17 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray18, (double) (-1L), 0.0d, (double) 0L, (double) 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        double double2 = sinc0.value((double) 1);
        try {
            double[] doubleArray7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 0.0d, (double) 1.0f, (double) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8414709848078965d + "'", double2 == 0.8414709848078965d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray2);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess7 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray8 = initialGuess7.getInitialGuess();
        try {
            double double9 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray2, doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int1 = org.apache.commons.math3.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) -1);
        int int2 = incrementor1.getCount();
        incrementor1.incrementCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 100, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        int[] intArray27 = new int[] { (short) 0, 14, 52 };
        int[] intArray33 = new int[] { 0, '4', '4', 0, 100 };
        double[] doubleArray38 = new double[] { 1791095845, (short) 0, (byte) -1, 100L };
        double[] doubleArray43 = new double[] { 1791095845, (short) 0, (byte) -1, 100L };
        double[] doubleArray48 = new double[] { 1791095845, (short) 0, (byte) -1, 100L };
        double[] doubleArray53 = new double[] { 1791095845, (short) 0, (byte) -1, 100L };
        double[] doubleArray58 = new double[] { 1791095845, (short) 0, (byte) -1, 100L };
        double[][] doubleArray59 = new double[][] { doubleArray38, doubleArray43, doubleArray48, doubleArray53, doubleArray58 };
        try {
            diagonalMatrix23.copySubMatrix(intArray27, intArray33, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        try {
            org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector9.getSubVector((int) (short) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 1, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(32.0d, (double) (byte) -1);
        double[] doubleArray5 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray5);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) '4', (-1.0d));
        double[] doubleArray12 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray12);
        double[] doubleArray14 = sigma13.getSigma();
        double[] doubleArray17 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray17);
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma20 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray17);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex22 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 10);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray23);
        double[] doubleArray25 = initialGuess24.getInitialGuess();
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray26 = new org.apache.commons.math3.optim.OptimizationData[] { sigma6, multiDirectionalSimplex9, sigma13, sigma20, multiDirectionalSimplex22, initialGuess24 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair27 = simplexOptimizer2.optimize(optimizationDataArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(optimizationDataArray26);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.5707963267948966d), 0.0d, 0.0d, (double) '#', 32.0d, (double) 10L, (double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 320.0d + "'", double8 == 320.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray3);
        double[] doubleArray5 = sigma4.getSigma();
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess7 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, (int) 'a');
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray6);
        try {
            double double11 = org.apache.commons.math3.util.MathArrays.distance(doubleArray0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math3.util.FastMath.log10(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(Float.NaN);
        org.junit.Assert.assertEquals((float) float1, Float.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix26 = diagonalMatrix23.getRowMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) (byte) 0, (float) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 52);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray27 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma28 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray27);
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray27);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma30 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray27);
        try {
            double[] doubleArray31 = diagonalMatrix23.operate(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval((double) (short) -1, (double) Float.NaN);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 10L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, 1, 0);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector32, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector19.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor45 = null;
        try {
            double double48 = arrayRealVector32.walkInDefaultOrder(realVectorChangingVisitor45, 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayRealVector44);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double[] doubleArray4 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray5);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        java.lang.Double double6 = pointValuePair5.getValue();
        java.io.ObjectInputStream objectInputStream8 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) pointValuePair5, "hi!", objectInputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6.equals(1.0d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 52.000004f, (double) 10.0f);
        double double3 = simpleValueChecker2.getRelativeThreshold();
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 1);
        java.lang.Double double11 = pointValuePair10.getValue();
        java.lang.Double double12 = pointValuePair10.getSecond();
        org.apache.commons.math3.optim.PointValuePair pointValuePair13 = null;
        try {
            boolean boolean14 = simpleValueChecker2.converged((int) (byte) 100, pointValuePair10, pointValuePair13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.000003814697266d + "'", double3 == 52.000003814697266d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12.equals(1.0d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        try {
            org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(0.0d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        try {
            arrayRealVector9.setEntry((int) (short) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, 1, 0);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector32, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector19.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor45 = null;
        try {
            double double48 = arrayRealVector19.walkInDefaultOrder(realVectorPreservingVisitor45, (-1), 1791095845);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayRealVector44);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor25 = null;
        try {
            double double26 = diagonalMatrix23.walkInColumnOrder(realMatrixPreservingVisitor25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        double[] doubleArray15 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray16);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equals(doubleArray15, doubleArray16);
        java.lang.Object[] objArray19 = new java.lang.Object[] { doubleArray15 };
        org.apache.commons.math3.exception.NoBracketingException noBracketingException20 = new org.apache.commons.math3.exception.NoBracketingException(localizable6, (double) (byte) 1, (double) '4', (double) 100L, (double) 'a', objArray19);
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException24 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) (byte) 10);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 100L, 52, Float.NaN, (byte) 10 };
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math3.exception.MathArithmeticException(localizable5, objArray25);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException27 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) '#', (double) 1079574528, (double) 100.0f, (double) 52, objArray25);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double[] doubleArray0 = new double[] {};
        double[][] doubleArray1 = new double[][] { doubleArray0 };
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 14, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.0d + "'", double2 == 14.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(1);
        mersenneTwister1.clear();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7692698082559361259L + "'", long3 == 7692698082559361259L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE + "'", goalType0.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MAXIMIZE));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix27 = null;
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = diagonalMatrix23.subtract(diagonalMatrix27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1);
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType3 = nonLinearConjugateGradientOptimizer2.getGoalType();
        org.junit.Assert.assertNull(goalType3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, (int) (short) 0, (int) (short) -1, (int) 'a');
        int int5 = matrixDimensionMismatchException4.getWrongRowDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) 0L, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        boolean boolean11 = simpleUnivariateValueChecker3.converged(0, univariatePointValuePair7, univariatePointValuePair10);
        double double12 = simpleUnivariateValueChecker3.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[][] doubleArray28 = null;
        try {
            diagonalMatrix23.setSubMatrix(doubleArray28, (int) (byte) 100, 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        java.lang.Double[] doubleArray48 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray48, 1, 0);
        java.lang.Double[] doubleArray58 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector61 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray58, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector51, arrayRealVector61);
        double[] doubleArray63 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess64 = new org.apache.commons.math3.optim.InitialGuess(doubleArray63);
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray63, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray63);
        double double68 = arrayRealVector62.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector41.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector62);
        java.lang.Double[] doubleArray76 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray76, 1, 0);
        boolean boolean80 = arrayRealVector79.isNaN();
        double[] doubleArray81 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess82 = new org.apache.commons.math3.optim.InitialGuess(doubleArray81);
        double[] doubleArray84 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray81, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray81);
        double double86 = arrayRealVector79.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector85);
        double double87 = arrayRealVector79.getMinValue();
        double double88 = arrayRealVector69.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector79);
        double double89 = arrayRealVector19.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector79);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertEquals((double) double87, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker6 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair13 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        boolean boolean14 = simpleUnivariateValueChecker6.converged(0, univariatePointValuePair10, univariatePointValuePair13);
        java.lang.Double[] doubleArray21 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, 1, 0);
        java.lang.Double[] doubleArray31 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector24, arrayRealVector34);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math3.exception.MathIllegalStateException();
        java.lang.Double[] doubleArray44 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44, 1, 0);
        double[] doubleArray48 = arrayRealVector47.getDataRef();
        java.lang.Object[] objArray49 = new java.lang.Object[] { "", univariatePointValuePair13, arrayRealVector35, 0.0d, mathIllegalStateException37, arrayRealVector47 };
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException50 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, objArray49);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException51 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray49);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext52 = mathArithmeticException51.getContext();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(exceptionContext52);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double[] doubleArray3 = new double[] { 10.0d, 320.0d, 2.718281828459045d };
        double[] doubleArray7 = new double[] { 10.0d, 320.0d, 2.718281828459045d };
        double[] doubleArray11 = new double[] { 10.0d, 320.0d, 2.718281828459045d };
        double[] doubleArray15 = new double[] { 10.0d, 320.0d, 2.718281828459045d };
        double[] doubleArray19 = new double[] { 10.0d, 320.0d, 2.718281828459045d };
        double[][] doubleArray20 = new double[][] { doubleArray3, doubleArray7, doubleArray11, doubleArray15, doubleArray19 };
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray20, (double) 2147483647, 14.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 4");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) (byte) 10, 2.2250738585072014E-308d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.NEGATIVE_INFINITY + "'", double3 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        double double6 = arrayRealVector4.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) (-1.0f), (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector20.mapMultiply((double) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector50);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix23, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray23);
        try {
            double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray18, doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess2 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) '#', doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(Double.NEGATIVE_INFINITY, (double) 10.0f, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int1 = brentSolver0.getEvaluations();
        double double2 = brentSolver0.getRelativeAccuracy();
        org.apache.commons.math3.analysis.function.Sinc sinc4 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean7 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc4, 1.0d, 0.0d);
        try {
            double double10 = brentSolver0.solve((-1), (org.apache.commons.math3.analysis.UnivariateFunction) sinc4, (double) ' ', (double) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (-1) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex25 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 96");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker(2.2250738585072014E-308d, (double) (short) 100);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (byte) 100, 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        try {
            org.apache.commons.math3.linear.RealVector realVector25 = diagonalMatrix23.getRowVector(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = diagonalMatrix23.preMultiply(doubleArray28);
        try {
            diagonalMatrix23.addToEntry((int) (short) 100, (-1), 1.0415040453759297d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1.042 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("hi!", "", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor49 = null;
        try {
            double double52 = arrayRealVector41.walkInOptimizedOrder(realVectorPreservingVisitor49, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 0, (double) 14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double2 = org.apache.commons.math3.util.FastMath.pow(3.141592653589793d, (double) 1791095845);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction0);
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction2 = modelFunction1.getModelFunction();
        org.junit.Assert.assertNull(multivariateVectorFunction2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray25);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector29.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, (org.apache.commons.math3.linear.RealVector) arrayRealVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(arrayRealVector36);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor27 = null;
        try {
            double double28 = diagonalMatrix23.walkInColumnOrder(realMatrixChangingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math3.linear.SingularMatrixException singularMatrixException0 = new org.apache.commons.math3.linear.SingularMatrixException();
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException3 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) singularMatrixException0, localizable1, objArray2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        double[] doubleArray4 = sigma3.getSigma();
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray5);
        double[] doubleArray10 = null;
        try {
            double double11 = org.apache.commons.math3.util.MathArrays.distance(doubleArray4, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        int int1 = bracketFinder0.getEvaluations();
        double double2 = bracketFinder0.getLo();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.0d, 1.0d, (int) (short) 100);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        org.apache.commons.math3.linear.RealVector realVector53 = null;
        try {
            diagonalMatrix49.setRowVector((int) (short) -1, realVector53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10, (java.lang.Number) 52.0d, true);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(Float.NaN, (float) (byte) -1, (float) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 100, (int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 97, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        long long1 = org.apache.commons.math3.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) (short) 0, (double) 1079574528);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor7 = null;
        try {
            double double10 = arrayRealVector5.walkInDefaultOrder(realVectorPreservingVisitor7, 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        double[] doubleArray54 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma55 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray54);
        double[] doubleArray56 = sigma55.getSigma();
        try {
            double[] doubleArray57 = diagonalMatrix49.operate(doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int1 = org.apache.commons.math3.util.FastMath.round((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 7692698082559361259L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1252352413 + "'", int1 == 1252352413);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray2);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        java.lang.Double[] doubleArray13 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, 1, 0);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) doubleArray13);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, 2147483647, (int) 'a');
        try {
            double double21 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 0, (java.lang.Number) 100, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100 + "'", number5.equals(100));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 10, 7.69269808255936E18d, (double) 7692698082559361259L, (double) (-1.0f), 2.718281828459045d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess2 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) 'a');
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray4, doubleArray8);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) 'a');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) (byte) 1);
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray19);
        double double23 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray19);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix24 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray4);
        double[][] doubleArray25 = diagonalMatrix24.getData();
        double double28 = diagonalMatrix24.getEntry(6, (int) (short) 1);
        java.lang.StringBuffer stringBuffer29 = null;
        java.text.FieldPosition fieldPosition30 = null;
        try {
            java.lang.StringBuffer stringBuffer31 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix24, stringBuffer29, fieldPosition30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        long[] longArray3 = new long[] { (byte) 100, 100L, (short) 0 };
        long[] longArray7 = new long[] { (byte) 100, 100L, (short) 0 };
        long[][] longArray8 = new long[][] { longArray3, longArray7 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray8);
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray8);
        org.junit.Assert.assertNotNull(longArray3);
        org.junit.Assert.assertNotNull(longArray7);
        org.junit.Assert.assertNotNull(longArray8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray3);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = null;
        double[] doubleArray11 = new double[] { 320.0d, Double.NaN };
        double[][] doubleArray12 = new double[][] { doubleArray11 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray3, orderDirection8, doubleArray12);
        try {
            array2DRowRealMatrix2.setSubMatrix(doubleArray12, 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        try {
            array2DRowRealMatrix2.setEntry(0, 0, (-0.05059335214678515d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray32);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) 'a');
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair45 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 1);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray43);
        double double47 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray28, doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix48);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition51 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix48, 0.0d);
        int[] intArray52 = lUDecomposition51.getPivot();
        int[] intArray56 = new int[] { (byte) 100, (byte) 100, (short) 0 };
        int[] intArray57 = org.apache.commons.math3.util.MathArrays.copyOf(intArray56);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix23, intArray52, intArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        boolean boolean11 = simpleUnivariateValueChecker3.converged(0, univariatePointValuePair7, univariatePointValuePair10);
        double double12 = univariatePointValuePair7.getPoint();
        double double13 = univariatePointValuePair7.getPoint();
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 52.0d + "'", double12 == 52.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        try {
            array2DRowRealMatrix2.addToEntry(10, 1791095845, 320.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int2 = org.apache.commons.math3.util.FastMath.min(10, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.7561505025936777d + "'", double0 == 0.7561505025936777d);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray24, (double) (byte) 1, (double) (byte) -1, (double) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 96");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math3.optim.MaxIter maxIter0 = org.apache.commons.math3.optim.MaxIter.unlimited();
        org.junit.Assert.assertNotNull(maxIter0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(1.0415040453759297d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5931994782236123d + "'", double1 == 1.5931994782236123d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double[] doubleArray25 = diagonalMatrix23.getDataRef();
        double[] doubleArray28 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray28);
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        try {
            double[] doubleArray32 = diagonalMatrix23.operate(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getFLo();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getMin();
        double double2 = brentSolver0.getMin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) -1);
        int int2 = incrementor1.getCount();
        boolean boolean3 = incrementor1.canIncrement();
        incrementor1.incrementCount(0);
        try {
            incrementor1.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        java.lang.Double[] doubleArray55 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, 1, 0);
        java.lang.Double[] doubleArray65 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector58, arrayRealVector68);
        java.lang.Double[] doubleArray78 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray78, 1, 0);
        java.lang.Double[] doubleArray88 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray88, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector81, arrayRealVector91);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = arrayRealVector68.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector81);
        org.apache.commons.math3.linear.RealVector realVector94 = arrayRealVector20.append((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor95 = null;
        try {
            double double98 = arrayRealVector20.walkInOptimizedOrder(realVectorPreservingVisitor95, (int) ' ', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(arrayRealVector93);
        org.junit.Assert.assertNotNull(realVector94);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (byte) 100);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) (-1), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 2.718281828459045d);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, 1, 0);
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector15.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, 2.718281828459045d);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41, 1, 0);
        java.lang.Double[] doubleArray51 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector44.append(arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector28.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        org.apache.commons.math3.linear.RealVector realVector58 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector59 = arrayRealVector57.append(realVector58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(arrayRealVector57);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        double[] doubleArray16 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equals(doubleArray16, doubleArray17);
        java.lang.Object[] objArray20 = new java.lang.Object[] { doubleArray16 };
        org.apache.commons.math3.exception.NoBracketingException noBracketingException21 = new org.apache.commons.math3.exception.NoBracketingException(localizable7, (double) (byte) 1, (double) '4', (double) 100L, (double) 'a', objArray20);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException22 = new org.apache.commons.math3.exception.NoBracketingException(localizable2, 0.0d, (double) (byte) 100, (double) (-1.0f), 17.38905609893065d, objArray20);
        org.apache.commons.math3.exception.ConvergenceException convergenceException23 = new org.apache.commons.math3.exception.ConvergenceException(localizable1, objArray20);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray20);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType0.equals(org.apache.commons.math3.optim.nonlinear.scalar.GoalType.MINIMIZE));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double double27 = diagonalMatrix23.getEntry(6, (int) (short) 1);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor28 = null;
        try {
            double double33 = diagonalMatrix23.walkInRowOrder(realMatrixPreservingVisitor28, (-289663928), (int) (byte) 0, 1079574528, 50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-289,663,928)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math3.util.MathUtils.checkFinite((-0.7615941559557649d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(32.0d, (double) (byte) -1);
        double[] doubleArray3 = simplexOptimizer2.getUpperBound();
        int int4 = simplexOptimizer2.getMaxIterations();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = simplexOptimizer2.getGoalType();
        org.junit.Assert.assertNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertNull(goalType5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(1);
        int int2 = mersenneTwister1.nextInt();
        long long4 = mersenneTwister1.nextLong((long) 52);
        int int5 = mersenneTwister1.nextInt();
        double double6 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1791095845 + "'", int2 == 1791095845);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-289663928) + "'", int5 == (-289663928));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1436832136579866E-4d + "'", double6 == 1.1436832136579866E-4d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double double26 = eigenDecomposition25.getDeterminant();
        double double28 = eigenDecomposition25.getImagEigenvalue((int) ' ');
        try {
            double double30 = eigenDecomposition25.getRealEigenvalue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int1 = org.apache.commons.math3.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(1.5931994782236123d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5931994782236123d) + "'", double2 == (-1.5931994782236123d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) (byte) 10, (double) (short) 10);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray4 = null;
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair5 = levenbergMarquardtOptimizer3.optimize(optimizationDataArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector9.append(arrayRealVector19);
        try {
            double double22 = arrayRealVector20.getEntry(1791095845);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,791,095,845)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        double[] doubleArray4 = sigma3.getSigma();
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray5);
        org.apache.commons.math3.util.MathArrays.checkPositive(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(1.1102230246251565E-16d, (-289663928));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInRowOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 6, 10 };
        java.lang.Integer[] intArray10 = new java.lang.Integer[] { 52, 1791095845, 100, 6, 1, 100 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException11 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray3, intArray10);
        try {
            int int13 = multiDimensionMismatchException11.getWrongDimension((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException(1252352413, (int) '4');
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition50 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        double[] doubleArray51 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess52 = new org.apache.commons.math3.optim.InitialGuess(doubleArray51);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray51, (int) 'a');
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair60 = new org.apache.commons.math3.optim.PointValuePair(doubleArray58, (double) (byte) 1);
        boolean boolean61 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray54, doubleArray58);
        double[] doubleArray62 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess63 = new org.apache.commons.math3.optim.InitialGuess(doubleArray62);
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray62, (int) 'a');
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess67 = new org.apache.commons.math3.optim.InitialGuess(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair71 = new org.apache.commons.math3.optim.PointValuePair(doubleArray69, (double) (byte) 1);
        boolean boolean72 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray65, doubleArray69);
        double double73 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray54, doubleArray69);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix74 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray54);
        double[][] doubleArray75 = diagonalMatrix74.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix76 = diagonalMatrix49.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix74);
        org.apache.commons.math3.linear.RealMatrix realMatrix77 = diagonalMatrix23.multiply(realMatrix76);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realMatrix76);
        org.junit.Assert.assertNotNull(realMatrix77);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 1.0d, 0.0d);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, (double) (short) 1, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1, -1]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (byte) 100, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray1);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(17.38905609893065d, 640.0d, (-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.959852425725543d + "'", double3 == 18.959852425725543d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 0, (java.lang.Number) 100, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-0.5063656411097588d), (java.lang.Number) 100, (int) (byte) -1, orderDirection8, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = nonMonotonicSequenceException10.getDirection();
        int int12 = nonMonotonicSequenceException10.getIndex();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) nonMonotonicSequenceException10);
        java.lang.Number number14 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100 + "'", number14.equals(100));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.String str2 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix1.walkInColumnOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{}" + "'", str2.equals("{}"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        double double5 = levenbergMarquardtOptimizer4.getChiSquare();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) (-289663928), (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.89663936E8f + "'", float2 == 2.89663936E8f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double29 = diagonalMatrix23.walkInOptimizedOrder(realMatrixChangingVisitor24, 0, 0, (int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 1, 0);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 2147483647, (int) 'a');
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (6)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double2 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.midpoint((double) Float.NaN, (double) 2.89663936E8f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        double[] doubleArray6 = pointValuePair5.getFirst();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) -1);
        int int2 = incrementor1.getCount();
        boolean boolean3 = incrementor1.canIncrement();
        incrementor1.incrementCount(0);
        incrementor1.incrementCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.multiplyEntry((int) (short) 1, 1079574528, (double) 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 2147483647, 1.5931994782236123d);
        double double3 = brentOptimizer2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker4 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray9 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray12 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray12);
        org.apache.commons.math3.optim.InitialGuess initialGuess14 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair16 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray9, doubleArray12, true);
        double[] doubleArray20 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray23 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma24 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray23);
        org.apache.commons.math3.optim.InitialGuess initialGuess25 = new org.apache.commons.math3.optim.InitialGuess(doubleArray23);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair27 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray20, doubleArray23, true);
        boolean boolean28 = simpleVectorValueChecker4.converged(0, pointVectorValuePair16, pointVectorValuePair27);
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker33 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray38 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray41 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma42 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray41);
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray41, true);
        double[] doubleArray49 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray52 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma53 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray52);
        org.apache.commons.math3.optim.InitialGuess initialGuess54 = new org.apache.commons.math3.optim.InitialGuess(doubleArray52);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair56 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray49, doubleArray52, true);
        boolean boolean57 = simpleVectorValueChecker33.converged(0, pointVectorValuePair45, pointVectorValuePair56);
        double[] doubleArray61 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray64 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma65 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray64);
        org.apache.commons.math3.optim.InitialGuess initialGuess66 = new org.apache.commons.math3.optim.InitialGuess(doubleArray64);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair68 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray61, doubleArray64, true);
        boolean boolean69 = simpleVectorValueChecker4.converged((-1), pointVectorValuePair56, pointVectorValuePair68);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer74 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(1.240276008560994d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker4, 32.0d, 320.0d, (-1.5931994782236123d), (double) (byte) -1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double double16 = arrayRealVector9.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double double17 = arrayRealVector9.getMinValue();
        double double18 = arrayRealVector9.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        int[] intArray27 = lUDecomposition26.getPivot();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver28 = lUDecomposition26.getSolver();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(decompositionSolver28);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double double16 = arrayRealVector9.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector9.append(arrayRealVector21);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor23 = null;
        try {
            double double24 = arrayRealVector22.walkInOptimizedOrder(realVectorPreservingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.String str2 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix1.walkInRowOrder(realMatrixPreservingVisitor3, (int) (byte) 0, 1791095845, (int) (short) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{}" + "'", str2.equals("{}"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.String str2 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix1.walkInRowOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{}" + "'", str2.equals("{}"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double double27 = diagonalMatrix23.getEntry(6, (int) (short) 1);
        try {
            diagonalMatrix23.addToEntry((int) (short) -1, 1, (double) 2.89663936E8f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 289,663,936 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double[][] doubleArray0 = new double[][] {};
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        double double27 = lUDecomposition26.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 6, 7.69269808255936E18d);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker3 = brentOptimizer2.getConvergenceChecker();
        double double4 = brentOptimizer2.getMax();
        int int5 = brentOptimizer2.getMaxEvaluations();
        org.junit.Assert.assertNull(univariatePointValuePairConvergenceChecker3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 1.0f, 0.0d, (-0.05059335214678515d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray2);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = null;
        try {
            boolean boolean8 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray2, orderDirection6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray32);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) 'a');
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair45 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 1);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray43);
        double double47 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray28, doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        double[][] doubleArray49 = diagonalMatrix48.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix48);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor51 = null;
        try {
            double double52 = diagonalMatrix48.walkInColumnOrder(realMatrixPreservingVisitor51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math3.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        double double2 = sinc0.value((double) 1);
        double double5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, (-0.05059335214678515d), 7.69269808255936E18d);
        double double7 = sinc0.value((double) 14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8414709848078965d + "'", double2 == 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.84634904127968E18d + "'", double5 == 3.84634904127968E18d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.07075766826391931d + "'", double7 == 0.07075766826391931d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = diagonalMatrix23.preMultiply(doubleArray28);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        java.lang.Double[] doubleArray47 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray47, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector40, arrayRealVector50);
        java.lang.Double[] doubleArray60 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray60, 1, 0);
        java.lang.Double[] doubleArray70 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray70, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector63, arrayRealVector73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector75 = arrayRealVector50.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector63);
        try {
            diagonalMatrix23.setColumnVector(0, (org.apache.commons.math3.linear.RealVector) arrayRealVector50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 97x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(arrayRealVector75);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) (-289663928), 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.89663928E8d) + "'", double2 == (-2.89663928E8d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        double[] doubleArray8 = new double[] { 320.0d, Double.NaN };
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, orderDirection5, doubleArray9);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex11 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(1);
        long long2 = mersenneTwister1.nextLong();
        try {
            int int4 = mersenneTwister1.nextInt((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7692698082559361259L + "'", long2 == 7692698082559361259L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) -1);
        try {
            incrementor1.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector9.append(arrayRealVector19);
        int int21 = arrayRealVector19.getMaxIndex();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor22 = null;
        try {
            double double25 = arrayRealVector19.walkInDefaultOrder(realVectorPreservingVisitor22, (int) (byte) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double2 = org.apache.commons.math3.util.FastMath.pow(7.69269808255936E18d, 50);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded(52);
        double[] doubleArray2 = simpleBounds1.getUpper();
        org.junit.Assert.assertNotNull(simpleBounds1);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double[] doubleArray0 = null;
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 1, 0);
        boolean boolean11 = arrayRealVector10.isNaN();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor(6, maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = array2DRowRealMatrix0.createMatrix(0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.apache.commons.math3.optim.MaxEval maxEval1 = new org.apache.commons.math3.optim.MaxEval((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray2 = initialGuess1.getInitialGuess();
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2, 0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        try {
            boolean boolean7 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray4, orderDirection5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) (byte) 10, (double) (short) 10);
        int int4 = levenbergMarquardtOptimizer3.getEvaluations();
        double[] doubleArray5 = levenbergMarquardtOptimizer3.getUpperBound();
        int int6 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        int int7 = levenbergMarquardtOptimizer3.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double[][] doubleArray25 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor6 = null;
        try {
            double double9 = arrayRealVector5.walkInOptimizedOrder(realVectorPreservingVisitor6, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.RealVector realVector50 = arrayRealVector41.mapDivideToSelf((double) (byte) 1);
        int int51 = arrayRealVector41.getMaxIndex();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor52 = null;
        try {
            double double53 = arrayRealVector41.walkInDefaultOrder(realVectorChangingVisitor52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        float[] floatArray2 = new float[] { (-1.0f), (-1.0f) };
        float[] floatArray6 = new float[] { 7692698082559361259L, (short) 10, (byte) 0 };
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray6);
        float[] floatArray8 = null;
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray2, floatArray8);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.text.NumberFormat numberFormat2 = realMatrixFormat0.getFormat();
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, (int) 'a');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess8 = new org.apache.commons.math3.optim.InitialGuess(doubleArray7);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair12 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, (double) (byte) 1);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess15 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) 'a');
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) 1);
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray17, doubleArray21);
        double double25 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray6, doubleArray21);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix26 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray6);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition27 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26);
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess33 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair37 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) (byte) 1);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray31, doubleArray35);
        double[] doubleArray39 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess40 = new org.apache.commons.math3.optim.InitialGuess(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) 'a');
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess44 = new org.apache.commons.math3.optim.InitialGuess(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray43, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray46, (double) (byte) 1);
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray42, doubleArray46);
        double double50 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray31, doubleArray46);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix51 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31);
        double[][] doubleArray52 = diagonalMatrix51.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = diagonalMatrix26.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix51);
        java.lang.StringBuffer stringBuffer54 = null;
        java.text.FieldPosition fieldPosition55 = null;
        try {
            java.lang.StringBuffer stringBuffer56 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix26, stringBuffer54, fieldPosition55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getColumnSeparator();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 640.0d, (java.lang.Number) 320.0d, false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(52.000003814697266d, (double) (byte) 1, 17.38905609893065d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        int[] intArray27 = lUDecomposition26.getPivot();
        double double28 = lUDecomposition26.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.String str2 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = array2DRowRealMatrix1.add(array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{}" + "'", str2.equals("{}"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getMin();
        int int2 = brentSolver0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(1);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed(0L);
        int int6 = mersenneTwister1.nextInt(14);
        double double7 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.3358343618944353d) + "'", double7 == (-1.3358343618944353d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double double16 = arrayRealVector9.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector9.append(arrayRealVector21);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor23 = null;
        try {
            double double26 = arrayRealVector9.walkInOptimizedOrder(realVectorPreservingVisitor23, 0, 1252352413);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(17.38905609893065d, (double) (-1L));
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer8 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100.0f, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3, (double) '#', 0.0d, (double) 50, (double) (short) -1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize populationSize1 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.PopulationSize((int) (byte) 10);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-0.5063656411097588d), (java.lang.Number) 100, (int) (byte) -1, orderDirection3, true);
        boolean boolean6 = nonMonotonicSequenceException5.getStrict();
        int int7 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula1 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 10, (double) (short) 100, (int) (byte) 1);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver7 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver7);
        org.apache.commons.math3.analysis.function.Sinc sinc10 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean13 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc10, 1.0d, 0.0d);
        try {
            double double16 = brentSolver7.solve((int) (byte) 1, (org.apache.commons.math3.analysis.UnivariateFunction) sinc10, (double) 6, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.TooManyEvaluationsException; message: illegal state: maximal count (1) exceeded: evaluations");
        } catch (org.apache.commons.math3.exception.TooManyEvaluationsException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + formula1 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula1.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.text.NumberFormat numberFormat0 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 1079574528, 2.2250738585072014E-308d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) (byte) 10, (double) (short) 10);
        int int4 = levenbergMarquardtOptimizer3.getEvaluations();
        double[] doubleArray5 = levenbergMarquardtOptimizer3.getLowerBound();
        double double6 = levenbergMarquardtOptimizer3.getChiSquare();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.setEntry(1791095845, (-289663928), (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,791,095,845)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) 52, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        try {
            org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer(0.0d, (double) 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex(anyMatrix0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) (byte) 10, (double) (short) 10);
        int int4 = levenbergMarquardtOptimizer3.getEvaluations();
        double[] doubleArray5 = levenbergMarquardtOptimizer3.getLowerBound();
        int int6 = levenbergMarquardtOptimizer3.getMaxIterations();
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction7 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian modelFunctionJacobian8 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian(multivariateMatrixFunction7);
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction9 = modelFunctionJacobian8.getModelFunctionJacobian();
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction10 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient objectiveFunctionGradient11 = new org.apache.commons.math3.optim.nonlinear.scalar.ObjectiveFunctionGradient(multivariateVectorFunction10);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray12 = new org.apache.commons.math3.optim.OptimizationData[] { modelFunctionJacobian8, objectiveFunctionGradient11 };
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair13 = levenbergMarquardtOptimizer3.optimize(optimizationDataArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertNull(multivariateMatrixFunction9);
        org.junit.Assert.assertNotNull(optimizationDataArray12);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 10, pointVectorValuePairConvergenceChecker1, 0.0d, (double) (short) 100, (double) 1.0f, (double) (short) 10);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker7 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        org.apache.commons.math3.analysis.MultivariateVectorFunction multivariateVectorFunction8 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunction modelFunction9 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunction(multivariateVectorFunction8);
        double[] doubleArray12 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray12);
        org.apache.commons.math3.optim.InitialGuess initialGuess14 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray17 = new org.apache.commons.math3.optim.OptimizationData[] { modelFunction9, initialGuess14, initialGuess16 };
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair18 = levenbergMarquardtOptimizer6.optimize(optimizationDataArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(optimizationDataArray17);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray3 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray6 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray6);
        org.apache.commons.math3.optim.InitialGuess initialGuess8 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair10 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray3, doubleArray6, true);
        double[] doubleArray11 = pointVectorValuePair10.getPointRef();
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) 1);
        double[] doubleArray20 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray20);
        double[] doubleArray22 = sigma21.getSigma();
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23, (int) 'a');
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray22, doubleArray23);
        boolean boolean28 = pointValuePair17.equals((java.lang.Object) doubleArray23);
        try {
            double double29 = org.apache.commons.math3.util.MathArrays.distance(doubleArray11, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 7692698082559361259L, (float) 14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        boolean boolean25 = diagonalMatrix23.isTransposable();
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        double double53 = diagonalMatrix49.getEntry(6, (int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix23.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor55 = null;
        try {
            double double60 = diagonalMatrix23.walkInColumnOrder(realMatrixPreservingVisitor55, (int) (short) 100, (int) ' ', 10, 1791095845);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 1.0d, 0.0d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction4 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc0);
        try {
            double[] doubleArray8 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.bracket((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 1.1436832136579866E-4d, (double) 10L, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [10, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 6, 7.69269808255936E18d);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker3 = brentOptimizer2.getConvergenceChecker();
        double double4 = brentOptimizer2.getStartValue();
        org.apache.commons.math3.optim.nonlinear.scalar.GoalType goalType5 = brentOptimizer2.getGoalType();
        org.junit.Assert.assertNull(univariatePointValuePairConvergenceChecker3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(goalType5);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        double double2 = sinc0.value((double) 1);
        double double5 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.solve((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, (-0.05059335214678515d), 7.69269808255936E18d);
        try {
            org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, (double) (byte) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 0]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8414709848078965d + "'", double2 == 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.84634904127968E18d + "'", double5 == 3.84634904127968E18d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray14 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray17 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma18 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray17);
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair21 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray14, doubleArray17, true);
        try {
            double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray7, doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 2");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 0.7561505025936777d);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.7561505025936777d + "'", number2.equals(0.7561505025936777d));
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test347");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-5662804428925872054L) + "'", long1 == (-5662804428925872054L));
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix28 = diagonalMatrix23.getColumnMatrix((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(32.0d, (double) (byte) -1);
        double[] doubleArray3 = simplexOptimizer2.getUpperBound();
        int int4 = simplexOptimizer2.getIterations();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker5 = simplexOptimizer2.getConvergenceChecker();
        org.junit.Assert.assertNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker5);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        java.lang.String str49 = arrayRealVector48.toString();
        java.io.ObjectInputStream objectInputStream51 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) arrayRealVector48, "{}", objectInputStream51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{}" + "'", str49.equals("{}"));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray32);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) 'a');
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair45 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 1);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray43);
        double double47 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray28, doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        double[][] doubleArray49 = diagonalMatrix48.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix48);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix55 = diagonalMatrix48.getSubMatrix((int) (short) 10, 97, 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 0, (java.lang.Number) 100, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException10 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-0.5063656411097588d), (java.lang.Number) 100, (int) (byte) -1, orderDirection8, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = nonMonotonicSequenceException10.getDirection();
        int int12 = nonMonotonicSequenceException10.getIndex();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) nonMonotonicSequenceException10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection14 = nonMonotonicSequenceException10.getDirection();
        java.lang.Number number15 = nonMonotonicSequenceException10.getPrevious();
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100 + "'", number15.equals(100));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double[][] doubleArray25 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        try {
            double[][] doubleArray26 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2,704 != 2,340");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[] doubleArray26 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray26);
        org.apache.commons.math3.optim.InitialGuess initialGuess28 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray26);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        double[] doubleArray34 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess35 = new org.apache.commons.math3.optim.InitialGuess(doubleArray34);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair39 = new org.apache.commons.math3.optim.PointValuePair(doubleArray37, (double) (byte) 1);
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray33, doubleArray37);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        double[] doubleArray45 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess46 = new org.apache.commons.math3.optim.InitialGuess(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray45, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair50 = new org.apache.commons.math3.optim.PointValuePair(doubleArray48, (double) (byte) 1);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray48);
        double double52 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray33, doubleArray48);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix53);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        double[] doubleArray59 = diagonalMatrix53.preMultiply(doubleArray58);
        double double60 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray58);
        double[] doubleArray61 = diagonalMatrix23.operate(doubleArray58);
        org.apache.commons.math3.linear.RealVector realVector62 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector63 = diagonalMatrix23.operate(realVector62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getHi();
        int int2 = bracketFinder0.getMaxEvaluations();
        double double3 = bracketFinder0.getMid();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        try {
            org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 10.0f, 1.5931994782236123d, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((double) ' ');
        double double2 = bracketingStep1.getBracketingStep();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.String str2 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix1.walkInRowOrder(realMatrixPreservingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{}" + "'", str2.equals("{}"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 97, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2296210822213825E32d + "'", double2 == 1.2296210822213825E32d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.812644285236262E-103d + "'", double1 == 2.812644285236262E-103d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 3.84634904127968E18d, false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess2 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) 'a');
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray4, doubleArray8);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) 'a');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) (byte) 1);
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray19);
        double double23 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray19);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess25 = new org.apache.commons.math3.optim.InitialGuess(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) 'a');
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair33 = new org.apache.commons.math3.optim.PointValuePair(doubleArray31, (double) (byte) 1);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray27, doubleArray31);
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray35);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray35, (int) 'a');
        double[] doubleArray39 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess40 = new org.apache.commons.math3.optim.InitialGuess(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair44 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, (double) (byte) 1);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray38, doubleArray42);
        double double46 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray27, doubleArray42);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix47 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27);
        double[] doubleArray50 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma51 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray50);
        org.apache.commons.math3.optim.InitialGuess initialGuess52 = new org.apache.commons.math3.optim.InitialGuess(doubleArray50);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma53 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray50);
        double[] doubleArray54 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess55 = new org.apache.commons.math3.optim.InitialGuess(doubleArray54);
        double[] doubleArray57 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray54, (int) 'a');
        double[] doubleArray58 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess59 = new org.apache.commons.math3.optim.InitialGuess(doubleArray58);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray58, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair63 = new org.apache.commons.math3.optim.PointValuePair(doubleArray61, (double) (byte) 1);
        boolean boolean64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray57, doubleArray61);
        double[] doubleArray65 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess66 = new org.apache.commons.math3.optim.InitialGuess(doubleArray65);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray65, (int) 'a');
        double[] doubleArray69 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess70 = new org.apache.commons.math3.optim.InitialGuess(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair74 = new org.apache.commons.math3.optim.PointValuePair(doubleArray72, (double) (byte) 1);
        boolean boolean75 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray68, doubleArray72);
        double double76 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray57, doubleArray72);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix77 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray57);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix77);
        double[] doubleArray79 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess80 = new org.apache.commons.math3.optim.InitialGuess(doubleArray79);
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray79, (int) 'a');
        double[] doubleArray83 = diagonalMatrix77.preMultiply(doubleArray82);
        double double84 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray50, doubleArray82);
        double[] doubleArray85 = diagonalMatrix47.operate(doubleArray82);
        boolean boolean86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray4, doubleArray85);
        org.apache.commons.math3.linear.RealMatrix realMatrix87 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray85);
        try {
            org.apache.commons.math3.optim.SimpleBounds simpleBounds88 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray0, doubleArray85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(realMatrix87);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) ' ', 0.0d, (double) 0);
        double double5 = noBracketingException4.getFLo();
        double double6 = noBracketingException4.getFHi();
        double double7 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray8 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray11 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray11, true);
        double[] doubleArray19 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray22 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray22);
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray22, true);
        boolean boolean27 = simpleVectorValueChecker3.converged(0, pointVectorValuePair15, pointVectorValuePair26);
        double[] doubleArray28 = pointVectorValuePair26.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex(anyMatrix0, (int) (short) 0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(52.000003814697266d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.0d + "'", double1 == 53.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder(Double.POSITIVE_INFINITY, (int) '4');
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 52.000004f, (double) 10.0f);
        double double4 = simpleValueChecker3.getRelativeThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver5 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int6 = brentSolver5.getEvaluations();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver5, (org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner) identityPreconditioner7);
        org.apache.commons.math3.analysis.function.Sinc sinc10 = new org.apache.commons.math3.analysis.function.Sinc();
        try {
            double double13 = brentSolver5.solve((int) (byte) -1, (org.apache.commons.math3.analysis.UnivariateFunction) sinc10, 22025.465794806718d, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [22,025.466, 11,013.233]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.000003814697266d + "'", double4 == 52.000003814697266d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker3 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 52.000004f, (double) 10.0f);
        double double4 = simpleValueChecker3.getRelativeThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver5 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int6 = brentSolver5.getEvaluations();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner7 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker3, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver5, (org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner) identityPreconditioner7);
        int int9 = brentSolver5.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 52.000003814697266d + "'", double4 == 52.000003814697266d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray8 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray11 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray11, true);
        double[] doubleArray19 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray22 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray22);
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray22, true);
        boolean boolean27 = simpleVectorValueChecker3.converged(0, pointVectorValuePair15, pointVectorValuePair26);
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker32 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray37 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray40 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma41 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray40);
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair44 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray40, true);
        double[] doubleArray48 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray51 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray51);
        org.apache.commons.math3.optim.InitialGuess initialGuess53 = new org.apache.commons.math3.optim.InitialGuess(doubleArray51);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair55 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray48, doubleArray51, true);
        boolean boolean56 = simpleVectorValueChecker32.converged(0, pointVectorValuePair44, pointVectorValuePair55);
        double[] doubleArray60 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray63 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma64 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray63);
        org.apache.commons.math3.optim.InitialGuess initialGuess65 = new org.apache.commons.math3.optim.InitialGuess(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair67 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray60, doubleArray63, true);
        boolean boolean68 = simpleVectorValueChecker3.converged((-1), pointVectorValuePair55, pointVectorValuePair67);
        double[] doubleArray69 = pointVectorValuePair67.getKey();
        double[] doubleArray70 = pointVectorValuePair67.getValueRef();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double2 = org.apache.commons.math3.util.FastMath.max((-1.3358343618944353d), (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker8 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair12 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair15 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        boolean boolean16 = simpleUnivariateValueChecker8.converged(0, univariatePointValuePair12, univariatePointValuePair15);
        java.lang.Double[] doubleArray23 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23, 1, 0);
        java.lang.Double[] doubleArray33 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector26, arrayRealVector36);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException39 = new org.apache.commons.math3.exception.MathIllegalStateException();
        java.lang.Double[] doubleArray46 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46, 1, 0);
        double[] doubleArray50 = arrayRealVector49.getDataRef();
        java.lang.Object[] objArray51 = new java.lang.Object[] { "", univariatePointValuePair15, arrayRealVector37, 0.0d, mathIllegalStateException39, arrayRealVector49 };
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException52 = new org.apache.commons.math3.exception.MathArithmeticException(localizable3, objArray51);
        org.apache.commons.math3.exception.ZeroException zeroException53 = new org.apache.commons.math3.exception.ZeroException(localizable2, objArray51);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) Float.NaN, localizable1, objArray51);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math3.util.FastMath.atan(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) 2.89663936E8f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) (byte) -1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "hi!", "hi!");
        org.apache.commons.math3.linear.RealVector realVector4 = null;
        java.lang.StringBuffer stringBuffer5 = null;
        java.text.FieldPosition fieldPosition6 = null;
        try {
            java.lang.StringBuffer stringBuffer7 = realVectorFormat3.format(realVector4, stringBuffer5, fieldPosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess3 = new org.apache.commons.math3.optim.InitialGuess(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = null;
        double[] doubleArray10 = new double[] { 320.0d, Double.NaN };
        double[][] doubleArray11 = new double[][] { doubleArray10 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray2, orderDirection7, doubleArray11);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(0, (int) (short) 1, doubleArray11, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection5 = null;
        double[] doubleArray8 = new double[] { 320.0d, Double.NaN };
        double[][] doubleArray9 = new double[][] { doubleArray8 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, orderDirection5, doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double[] doubleArray4 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight8 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray8 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray11 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray11, true);
        double[] doubleArray19 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray22 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray22);
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray22, true);
        boolean boolean27 = simpleVectorValueChecker3.converged(0, pointVectorValuePair15, pointVectorValuePair26);
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker32 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray37 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray40 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma41 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray40);
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair44 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray40, true);
        double[] doubleArray48 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray51 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray51);
        org.apache.commons.math3.optim.InitialGuess initialGuess53 = new org.apache.commons.math3.optim.InitialGuess(doubleArray51);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair55 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray48, doubleArray51, true);
        boolean boolean56 = simpleVectorValueChecker32.converged(0, pointVectorValuePair44, pointVectorValuePair55);
        double[] doubleArray60 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray63 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma64 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray63);
        org.apache.commons.math3.optim.InitialGuess initialGuess65 = new org.apache.commons.math3.optim.InitialGuess(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair67 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray60, doubleArray63, true);
        boolean boolean68 = simpleVectorValueChecker3.converged((-1), pointVectorValuePair55, pointVectorValuePair67);
        double double69 = simpleVectorValueChecker3.getAbsoluteThreshold();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 10.0d + "'", double69 == 10.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((-0.7615941559557649d), (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7615941559557649d + "'", double2 == 0.7615941559557649d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray2);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2);
        double double6 = arrayRealVector5.getLInfNorm();
        double double7 = arrayRealVector5.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double2 = org.apache.commons.math3.util.FastMath.min((-0.7615941559557649d), (double) 7692698082559361259L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7615941559557649d) + "'", double2 == (-0.7615941559557649d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 1.0d);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.0d + "'", number2.equals(1.0d));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess2 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) 'a');
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray4, doubleArray8);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) 'a');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) (byte) 1);
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray19);
        double double23 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray19);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.scale((double) 52, doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray8 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray11 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray11, true);
        double[] doubleArray19 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray22 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray22);
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray22, true);
        boolean boolean27 = simpleVectorValueChecker3.converged(0, pointVectorValuePair15, pointVectorValuePair26);
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker32 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray37 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray40 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma41 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray40);
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair44 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray40, true);
        double[] doubleArray48 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray51 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray51);
        org.apache.commons.math3.optim.InitialGuess initialGuess53 = new org.apache.commons.math3.optim.InitialGuess(doubleArray51);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair55 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray48, doubleArray51, true);
        boolean boolean56 = simpleVectorValueChecker32.converged(0, pointVectorValuePair44, pointVectorValuePair55);
        double[] doubleArray60 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray63 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma64 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray63);
        org.apache.commons.math3.optim.InitialGuess initialGuess65 = new org.apache.commons.math3.optim.InitialGuess(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair67 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray60, doubleArray63, true);
        boolean boolean68 = simpleVectorValueChecker3.converged((-1), pointVectorValuePair55, pointVectorValuePair67);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer69 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double[] doubleArray25 = diagonalMatrix23.getDataRef();
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair28 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray25, doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor52 = null;
        try {
            double double53 = diagonalMatrix49.walkInOptimizedOrder(realMatrixChangingVisitor52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) 100L, (int) (short) 10);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.String str3 = realMatrixFormat1.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix2);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = array2DRowRealMatrix0.subtract(array2DRowRealMatrix2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{}" + "'", str3.equals("{}"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[] doubleArray26 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray26);
        org.apache.commons.math3.optim.InitialGuess initialGuess28 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray26);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        double[] doubleArray34 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess35 = new org.apache.commons.math3.optim.InitialGuess(doubleArray34);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair39 = new org.apache.commons.math3.optim.PointValuePair(doubleArray37, (double) (byte) 1);
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray33, doubleArray37);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        double[] doubleArray45 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess46 = new org.apache.commons.math3.optim.InitialGuess(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray45, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair50 = new org.apache.commons.math3.optim.PointValuePair(doubleArray48, (double) (byte) 1);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray48);
        double double52 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray33, doubleArray48);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix53);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        double[] doubleArray59 = diagonalMatrix53.preMultiply(doubleArray58);
        double double60 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray58);
        double[] doubleArray61 = diagonalMatrix23.operate(doubleArray58);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix64 = diagonalMatrix23.createMatrix((int) 'a', 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double double27 = diagonalMatrix23.getEntry(6, (int) (short) 1);
        int int28 = diagonalMatrix23.getRowDimension();
        try {
            double[] doubleArray30 = diagonalMatrix23.getColumn(2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (2,147,483,647)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 97 + "'", int28 == 97);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 2.718281828459045d);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, 1, 0);
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector15.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, 2.718281828459045d);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41, 1, 0);
        java.lang.Double[] doubleArray51 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector44.append(arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector28.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64, 1, 0);
        boolean boolean68 = arrayRealVector67.isNaN();
        double double69 = arrayRealVector57.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor70 = null;
        try {
            double double73 = arrayRealVector57.walkInDefaultOrder(realVectorPreservingVisitor70, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals(100.0f, (float) '#');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval(Double.NEGATIVE_INFINITY, (double) 100L, (double) 0L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor49 = null;
        try {
            double double50 = arrayRealVector48.walkInDefaultOrder(realVectorChangingVisitor49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException(",", (-289663928));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 2.718281828459045d);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, 1, 0);
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector15.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector15);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34, 1, 0);
        java.lang.Double[] doubleArray44 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector37, arrayRealVector47);
        int int49 = arrayRealVector48.getDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector15.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector48);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor51 = null;
        try {
            double double54 = arrayRealVector15.walkInOptimizedOrder(realVectorPreservingVisitor51, 97, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(arrayRealVector50);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 1.0d, 0.0d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction4 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = sinc0.derivative();
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure6 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure7 = sinc0.value(derivativeStructure6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(univariateFunction5);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double2 = org.apache.commons.math3.util.FastMath.log(18.959852425725543d, (double) (byte) -1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair5 = null;
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair6 = null;
        boolean boolean7 = simpleVectorValueChecker3.converged(1079574528, pointVectorValuePair5, pointVectorValuePair6);
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker12 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray17 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray20 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma21 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray20);
        org.apache.commons.math3.optim.InitialGuess initialGuess22 = new org.apache.commons.math3.optim.InitialGuess(doubleArray20);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair24 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray17, doubleArray20, true);
        double[] doubleArray28 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray31 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma32 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray31);
        org.apache.commons.math3.optim.InitialGuess initialGuess33 = new org.apache.commons.math3.optim.InitialGuess(doubleArray31);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair35 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray28, doubleArray31, true);
        boolean boolean36 = simpleVectorValueChecker12.converged(0, pointVectorValuePair24, pointVectorValuePair35);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair37 = null;
        boolean boolean38 = simpleVectorValueChecker3.converged(97, pointVectorValuePair35, pointVectorValuePair37);
        double[] doubleArray39 = pointVectorValuePair35.getPointRef();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) (byte) 10, (double) (short) 10);
        int int4 = levenbergMarquardtOptimizer3.getEvaluations();
        double[] doubleArray5 = levenbergMarquardtOptimizer3.getUpperBound();
        double[] doubleArray6 = null;
        try {
            double[] doubleArray8 = levenbergMarquardtOptimizer3.computeSigma(doubleArray6, 7.69269808255936E18d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(doubleArray5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess2 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) 'a');
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray4, doubleArray8);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) 'a');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) (byte) 1);
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray19);
        double double23 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray19);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.scale((double) 52, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair2 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair(0.0d, 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(1);
        long long2 = mersenneTwister1.nextLong();
        try {
            int int4 = mersenneTwister1.nextInt((-289663928));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -289,663,928 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7692698082559361259L + "'", long2 == 7692698082559361259L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double24 = arrayRealVector20.walkInDefaultOrder(realVectorPreservingVisitor21, 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double[][] doubleArray25 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2,704 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 14, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getColumnSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "," + "'", str2.equals(","));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess33 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair37 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) (byte) 1);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray31, doubleArray35);
        double[] doubleArray39 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess40 = new org.apache.commons.math3.optim.InitialGuess(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) 'a');
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess44 = new org.apache.commons.math3.optim.InitialGuess(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray43, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray46, (double) (byte) 1);
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray42, doubleArray46);
        double double50 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray31, doubleArray46);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix51 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition52 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix51);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition54 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix51, 0.0d);
        int[] intArray55 = lUDecomposition54.getPivot();
        double[] doubleArray56 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess57 = new org.apache.commons.math3.optim.InitialGuess(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray56, (int) 'a');
        double[] doubleArray60 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess61 = new org.apache.commons.math3.optim.InitialGuess(doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair65 = new org.apache.commons.math3.optim.PointValuePair(doubleArray63, (double) (byte) 1);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray59, doubleArray63);
        double[] doubleArray67 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess68 = new org.apache.commons.math3.optim.InitialGuess(doubleArray67);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray67, (int) 'a');
        double[] doubleArray71 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess72 = new org.apache.commons.math3.optim.InitialGuess(doubleArray71);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray71, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair76 = new org.apache.commons.math3.optim.PointValuePair(doubleArray74, (double) (byte) 1);
        boolean boolean77 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray70, doubleArray74);
        double double78 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray59, doubleArray74);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix79 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray59);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition80 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix79);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition82 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix79, 0.0d);
        int[] intArray83 = lUDecomposition82.getPivot();
        org.apache.commons.math3.linear.RealMatrix realMatrix84 = diagonalMatrix23.getSubMatrix(intArray55, intArray83);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(realMatrix84);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.RealVector realVector27 = eigenDecomposition25.getEigenvector((int) (byte) 0);
        org.apache.commons.math3.linear.RealVector realVector29 = realVector27.mapDivide((double) (byte) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (-0.5063656411097588d), (java.lang.Number) 100, (int) (byte) -1, orderDirection3, true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = nonMonotonicSequenceException5.getDirection();
        int int7 = nonMonotonicSequenceException5.getIndex();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = nonMonotonicSequenceException5.getDirection();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNull(orderDirection8);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math3.util.FastMath.rint(14.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.0d + "'", double1 == 14.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = weight27.getWeight();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(53.0d, (double) '#', (double) 0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        java.lang.Double double6 = pointValuePair5.getValue();
        java.lang.Double double7 = pointValuePair5.getSecond();
        java.lang.Double double8 = pointValuePair5.getSecond();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8.equals(1.0d));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray32);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) 'a');
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair45 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 1);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray43);
        double double47 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray28, doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        double[] doubleArray51 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray51);
        org.apache.commons.math3.optim.InitialGuess initialGuess53 = new org.apache.commons.math3.optim.InitialGuess(doubleArray51);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma54 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray51);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess60 = new org.apache.commons.math3.optim.InitialGuess(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair64 = new org.apache.commons.math3.optim.PointValuePair(doubleArray62, (double) (byte) 1);
        boolean boolean65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray58, doubleArray62);
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess67 = new org.apache.commons.math3.optim.InitialGuess(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66, (int) 'a');
        double[] doubleArray70 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess71 = new org.apache.commons.math3.optim.InitialGuess(doubleArray70);
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray70, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair75 = new org.apache.commons.math3.optim.PointValuePair(doubleArray73, (double) (byte) 1);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray69, doubleArray73);
        double double77 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray58, doubleArray73);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix78 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition79 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix78);
        double[] doubleArray80 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess81 = new org.apache.commons.math3.optim.InitialGuess(doubleArray80);
        double[] doubleArray83 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray80, (int) 'a');
        double[] doubleArray84 = diagonalMatrix78.preMultiply(doubleArray83);
        double double85 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray51, doubleArray83);
        double[] doubleArray86 = diagonalMatrix48.operate(doubleArray83);
        double[] doubleArray87 = diagonalMatrix23.operate(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 2.718281828459045d);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, 1, 0);
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector15.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector15);
        int int28 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        java.lang.Double double35 = pointValuePair34.getValue();
        java.lang.Double double36 = pointValuePair34.getSecond();
        double[] doubleArray37 = pointValuePair34.getKey();
        double[] doubleArray38 = pointValuePair34.getKey();
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess2 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) 'a');
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray4, doubleArray8);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) 'a');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) (byte) 1);
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray19);
        double double23 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray19);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.scale((double) 52, doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval((-0.05059335214678515d), (double) (short) 0, 0.0d);
        double double4 = searchInterval3.getMax();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker6 = new org.apache.commons.math3.optim.SimpleValueChecker(14.0d, 1.1102230246251565E-16d);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((-0.7853981633974483d), 3.4458315914355974E30d, 0.0d, 0.0d, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: -0.785 is smaller than the minimum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(2.812644285236262E-103d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.812644285236262E-103d + "'", double1 == 2.812644285236262E-103d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess3 = new org.apache.commons.math3.optim.InitialGuess(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2, (int) 'a');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess7 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair11 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, (double) (byte) 1);
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray5, doubleArray9);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess14 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13, (int) 'a');
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) (byte) 1);
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray16, doubleArray20);
        double double24 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray5, doubleArray20);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        double[][] doubleArray26 = diagonalMatrix25.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) -1, 1791095845, doubleArray26, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 6, 10 };
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 52, 1791095845, 100, 6, 1, 100 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException12 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray4, intArray11);
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { 6, 10 };
        java.lang.Integer[] intArray23 = new java.lang.Integer[] { 52, 1791095845, 100, 6, 1, 100 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException24 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable13, intArray16, intArray23);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException25 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray11, intArray16);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int1 = brentSolver0.getEvaluations();
        double double2 = brentSolver0.getStartValue();
        int int3 = brentSolver0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getMid();
        int int2 = bracketFinder0.getMaxEvaluations();
        int int3 = bracketFinder0.getMaxEvaluations();
        double double4 = bracketFinder0.getMid();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 50 + "'", int3 == 50);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray4 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray7 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray7);
        org.apache.commons.math3.optim.InitialGuess initialGuess9 = new org.apache.commons.math3.optim.InitialGuess(doubleArray7);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair11 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray4, doubleArray7, true);
        double[] doubleArray12 = pointVectorValuePair11.getValue();
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess14 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13, (int) 'a');
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) (byte) 1);
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray16, doubleArray20);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess25 = new org.apache.commons.math3.optim.InitialGuess(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) 'a');
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair33 = new org.apache.commons.math3.optim.PointValuePair(doubleArray31, (double) (byte) 1);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray27, doubleArray31);
        double double35 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray16, doubleArray31);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        double[] doubleArray37 = identityPreconditioner0.precondition(doubleArray12, doubleArray16);
        double[] doubleArray38 = null;
        try {
            double double39 = org.apache.commons.math3.util.MathArrays.distance(doubleArray12, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(1);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 10, (double) (short) 100, (int) (byte) 1);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '4', (double) (byte) 1, true, 97, 1252352413, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        java.util.List<java.lang.Double> doubleList13 = cMAESOptimizer12.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList14 = cMAESOptimizer12.getStatisticsSigmaHistory();
        org.junit.Assert.assertNotNull(doubleList13);
        org.junit.Assert.assertNotNull(doubleList14);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray9 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray10 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess11 = new org.apache.commons.math3.optim.InitialGuess(doubleArray10);
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equals(doubleArray9, doubleArray10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { doubleArray9 };
        org.apache.commons.math3.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) (byte) 1, (double) '4', (double) 100L, (double) 'a', objArray13);
        double double15 = noBracketingException14.getHi();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 52.0d + "'", double15 == 52.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = eigenDecomposition25.getD();
        double[] doubleArray27 = eigenDecomposition25.getImagEigenvalues();
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition32 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray27, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula1 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker4 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 52.000004f, (double) 10.0f);
        double double5 = simpleValueChecker4.getRelativeThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver6 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int7 = brentSolver6.getEvaluations();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer9 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver6, (org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner) identityPreconditioner8);
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        org.apache.commons.math3.exception.util.Localizable localizable11 = null;
        long[] longArray16 = new long[] { (byte) 100, 100L, (short) 0 };
        long[] longArray20 = new long[] { (byte) 100, 100L, (short) 0 };
        long[][] longArray21 = new long[][] { longArray16, longArray20 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray21);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable11, (java.lang.Number) 1.4E-45f, (java.lang.Object[]) longArray21);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) nonLinearConjugateGradientOptimizer9, localizable10, (java.lang.Object[]) longArray21);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) longArray21);
        org.junit.Assert.assertTrue("'" + formula1 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula1.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.000003814697266d + "'", double5 == 52.000003814697266d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(longArray16);
        org.junit.Assert.assertNotNull(longArray20);
        org.junit.Assert.assertNotNull(longArray21);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker((-0.5063656411097588d), 18.959852425725543d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 6, 7.69269808255936E18d);
        int int3 = brentOptimizer2.getMaxIterations();
        int int4 = brentOptimizer2.getIterations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder0 = new org.apache.commons.math3.optim.univariate.BracketFinder();
        double double1 = bracketFinder0.getMid();
        int int2 = bracketFinder0.getMaxEvaluations();
        int int3 = bracketFinder0.getEvaluations();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a', 0.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess34 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) (byte) 1);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray32, doubleArray36);
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        double[] doubleArray44 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess45 = new org.apache.commons.math3.optim.InitialGuess(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair49 = new org.apache.commons.math3.optim.PointValuePair(doubleArray47, (double) (byte) 1);
        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray43, doubleArray47);
        double double51 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray32, doubleArray47);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition53 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess60 = new org.apache.commons.math3.optim.InitialGuess(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair64 = new org.apache.commons.math3.optim.PointValuePair(doubleArray62, (double) (byte) 1);
        boolean boolean65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray58, doubleArray62);
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess67 = new org.apache.commons.math3.optim.InitialGuess(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66, (int) 'a');
        double[] doubleArray70 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess71 = new org.apache.commons.math3.optim.InitialGuess(doubleArray70);
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray70, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair75 = new org.apache.commons.math3.optim.PointValuePair(doubleArray73, (double) (byte) 1);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray69, doubleArray73);
        double double77 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray58, doubleArray73);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix78 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58);
        double[][] doubleArray79 = diagonalMatrix78.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = diagonalMatrix52.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix78);
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        org.apache.commons.math3.linear.RealMatrix realMatrix82 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix83 = diagonalMatrix52.subtract(realMatrix82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(realMatrix80);
        org.junit.Assert.assertNotNull(realMatrix81);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(32.0d, (double) (byte) -1);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker3 = simplexOptimizer2.getConvergenceChecker();
        double[] doubleArray8 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess10 = new org.apache.commons.math3.optim.InitialGuess(doubleArray9);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray9);
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray9);
        org.apache.commons.math3.optim.OptimizationData[] optimizationDataArray13 = new org.apache.commons.math3.optim.OptimizationData[] { initialGuess12 };
        try {
            org.apache.commons.math3.optim.PointValuePair pointValuePair14 = simplexOptimizer2.optimize(optimizationDataArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(optimizationDataArray13);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor52 = null;
        try {
            double double57 = diagonalMatrix23.walkInOptimizedOrder(realMatrixChangingVisitor52, 97, 97, (int) (short) 0, 1252352413);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(1079574528, (int) (short) -1, 100, 1);
        try {
            int int6 = matrixDimensionMismatchException4.getWrongDimension((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray0, 0.0d, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 10, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double double16 = arrayRealVector9.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector9.append(arrayRealVector21);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, 1, 0);
        boolean boolean33 = arrayRealVector32.isNaN();
        double[] doubleArray34 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess35 = new org.apache.commons.math3.optim.InitialGuess(doubleArray34);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34);
        double double39 = arrayRealVector32.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        double double40 = arrayRealVector32.getMinValue();
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess44 = new org.apache.commons.math3.optim.InitialGuess(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray43, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, 2.718281828459045d);
        java.lang.Double[] doubleArray55 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, 1, 0);
        java.lang.Double[] doubleArray65 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector58.append(arrayRealVector68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43, arrayRealVector58);
        double double71 = arrayRealVector58.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector32.combineToSelf((double) (byte) 100, (double) 52L, (org.apache.commons.math3.linear.RealVector) arrayRealVector58);
        try {
            double double73 = arrayRealVector22.cosine((org.apache.commons.math3.linear.RealVector) arrayRealVector58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector72);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = diagonalMatrix23.getColumn((int) (byte) 0);
        diagonalMatrix23.multiplyEntry(0, (int) (byte) 1, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        java.lang.Double[] doubleArray57 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray57, 1, 0);
        java.lang.Double[] doubleArray67 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray67, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector60, arrayRealVector70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector20.combineToSelf((double) (-1.0f), (double) (byte) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        org.apache.commons.math3.linear.RealVector realVector74 = arrayRealVector70.mapAddToSelf((double) 1.0f);
        double[] doubleArray75 = arrayRealVector70.toArray();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (short) 10, (int) '4', (double) 100.0f);
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        int int25 = diagonalMatrix23.getColumnDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix23, 1791095845);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,791,095,845)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(14.0d, 32.0d, 1.0415040453759297d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor6 = null;
        try {
            double double9 = arrayRealVector5.walkInOptimizedOrder(realVectorChangingVisitor6, (-1), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        java.lang.Double double6 = pointValuePair5.getValue();
        java.lang.Double double7 = pointValuePair5.getSecond();
        double[] doubleArray8 = pointValuePair5.getKey();
        double[] doubleArray9 = pointValuePair5.getKey();
        java.lang.Double double10 = pointValuePair5.getValue();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10.equals(1.0d));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) (byte) 1, (double) 0, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        double[] doubleArray27 = diagonalMatrix23.getDataRef();
        double[] doubleArray28 = diagonalMatrix23.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 10.0f, (double) (short) 1, 1.1102230246251565E-16d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        try {
            org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double[] doubleArray25 = diagonalMatrix23.getDataRef();
        double[] doubleArray28 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray28);
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray28);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix33 = diagonalMatrix23.add(realMatrix32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x97 but expected 2x2");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix32);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray3);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 52.00000000000001d, (java.lang.Number) 1252352413, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1252352413 + "'", number4.equals(1252352413));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        double[] doubleArray49 = arrayRealVector48.toArray();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.exception.TooManyIterationsException tooManyIterationsException1 = new org.apache.commons.math3.exception.TooManyIterationsException((java.lang.Number) 0L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 97, 2147483647);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.getColumnMatrix(1252352413);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.optim.univariate.BracketFinder bracketFinder2 = new org.apache.commons.math3.optim.univariate.BracketFinder((double) (byte) 1, 1079574528);
        double double3 = bracketFinder2.getFMid();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(14);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 6, 0);
        int int4 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) '4', (-1.0d));
        int int3 = multiDirectionalSimplex2.getDimension();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator5 = null;
        try {
            multiDirectionalSimplex2.evaluate(multivariateFunction4, pointValuePairComparator5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 52 + "'", int3 == 52);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        double[][] doubleArray1 = array2DRowRealMatrix0.getDataRef();
        org.junit.Assert.assertNull(doubleArray1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        int int25 = diagonalMatrix23.getColumnDimension();
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess28 = new org.apache.commons.math3.optim.InitialGuess(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair32 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, 2.718281828459045d);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, 1, 0);
        java.lang.Double[] doubleArray49 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray49, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = arrayRealVector42.append(arrayRealVector52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42);
        try {
            diagonalMatrix23.setColumnVector((int) '#', (org.apache.commons.math3.linear.RealVector) arrayRealVector42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 97x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 97 + "'", int25 == 97);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(arrayRealVector53);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double double16 = arrayRealVector9.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double[] doubleArray17 = arrayRealVector15.toArray();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[] doubleArray26 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray26);
        org.apache.commons.math3.optim.InitialGuess initialGuess28 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma29 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray26);
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        double[] doubleArray34 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess35 = new org.apache.commons.math3.optim.InitialGuess(doubleArray34);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair39 = new org.apache.commons.math3.optim.PointValuePair(doubleArray37, (double) (byte) 1);
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray33, doubleArray37);
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        double[] doubleArray45 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess46 = new org.apache.commons.math3.optim.InitialGuess(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray45, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair50 = new org.apache.commons.math3.optim.PointValuePair(doubleArray48, (double) (byte) 1);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray48);
        double double52 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray33, doubleArray48);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix53 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray33);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix53);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        double[] doubleArray59 = diagonalMatrix53.preMultiply(doubleArray58);
        double double60 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray26, doubleArray58);
        double[] doubleArray61 = diagonalMatrix23.operate(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix62 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix63 = diagonalMatrix23.subtract(realMatrix62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer2 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer(false, pointVectorValuePairConvergenceChecker1);
        try {
            org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair3 = gaussNewtonOptimizer2.doOptimize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double double16 = arrayRealVector9.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector9.append(arrayRealVector21);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor23 = null;
        try {
            double double24 = arrayRealVector22.walkInDefaultOrder(realVectorChangingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(arrayRealVector22);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        boolean boolean26 = eigenDecomposition25.hasComplexEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        boolean boolean25 = diagonalMatrix23.isTransposable();
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        double double53 = diagonalMatrix49.getEntry(6, (int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix23.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair60 = new org.apache.commons.math3.optim.PointValuePair(doubleArray58, (double) (byte) 1);
        java.lang.Double double61 = pointValuePair60.getValue();
        java.lang.Double double62 = pointValuePair60.getSecond();
        java.lang.Double double63 = pointValuePair60.getValue();
        double[] doubleArray64 = pointValuePair60.getPointRef();
        double[] doubleArray65 = diagonalMatrix49.preMultiply(doubleArray64);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65, 1, (int) (short) 10);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double double26 = eigenDecomposition25.getDeterminant();
        double double28 = eigenDecomposition25.getImagEigenvalue((int) ' ');
        double[] doubleArray29 = eigenDecomposition25.getImagEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (short) -1);
        int int2 = incrementor1.getCount();
        boolean boolean3 = incrementor1.canIncrement();
        int int4 = incrementor1.getCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.0415040453759297d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(0.0d, (double) 6, (double) 100.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double double27 = diagonalMatrix23.getEntry(6, (int) (short) 1);
        int int28 = diagonalMatrix23.getRowDimension();
        double[] doubleArray29 = diagonalMatrix23.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 97 + "'", int28 == 97);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = null;
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, pointValuePairConvergenceChecker1);
        int int3 = nonLinearConjugateGradientOptimizer2.getIterations();
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> pointValuePairConvergenceChecker4 = nonLinearConjugateGradientOptimizer2.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNull(pointValuePairConvergenceChecker4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        double[] doubleArray27 = diagonalMatrix23.getDataRef();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor28 = null;
        try {
            double double29 = diagonalMatrix23.walkInRowOrder(realMatrixPreservingVisitor28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) ' ', 0.0d, (double) 0);
        double double5 = noBracketingException4.getFLo();
        java.lang.Throwable[] throwableArray6 = noBracketingException4.getSuppressed();
        double double7 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        java.lang.Double double6 = pointValuePair5.getValue();
        java.lang.Double double7 = pointValuePair5.getSecond();
        double[] doubleArray8 = pointValuePair5.getKey();
        java.lang.Double double9 = pointValuePair5.getSecond();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9.equals(1.0d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance((double) (short) 10, (double) (short) 100, 1.1436832136579866E-4d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = realMatrixFormat0.format(realMatrix1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        long long2 = org.apache.commons.math3.util.FastMath.max((long) (byte) -1, (long) 1252352413);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1252352413L + "'", long2 == 1252352413L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 2147483647, 1.5931994782236123d);
        int int3 = brentOptimizer2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }
}

