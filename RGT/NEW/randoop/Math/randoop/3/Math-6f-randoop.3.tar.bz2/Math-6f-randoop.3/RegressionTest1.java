import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (byte) 1, (java.lang.Number) 0.0f, 0, orderDirection3, false);
        int int6 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray32);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) 'a');
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair45 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 1);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray43);
        double double47 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray28, doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        double[][] doubleArray49 = diagonalMatrix48.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix48);
        diagonalMatrix48.setEntry((int) '4', (int) '#', (double) 0L);
        double[] doubleArray57 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray57);
        double[] doubleArray59 = sigma58.getSigma();
        boolean boolean60 = diagonalMatrix48.equals((java.lang.Object) doubleArray59);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix62 = diagonalMatrix48.getColumnMatrix((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 6, 7.69269808255936E18d);
        int int3 = brentOptimizer2.getMaxIterations();
        int int4 = brentOptimizer2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double double27 = diagonalMatrix23.getEntry(6, (int) (short) 1);
        int int28 = diagonalMatrix23.getRowDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix31 = diagonalMatrix23.createMatrix((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: -1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 97 + "'", int28 == 97);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 6, (int) (short) 0);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, (org.apache.commons.math3.linear.RealVector) arrayRealVector13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a', 0.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double34 = diagonalMatrix23.walkInOptimizedOrder(realMatrixPreservingVisitor29, (int) (byte) 0, 1252352413, (int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,252,352,413)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, (int) 'a');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess8 = new org.apache.commons.math3.optim.InitialGuess(doubleArray7);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair12 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, (double) (byte) 1);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess15 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) 'a');
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) 1);
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray17, doubleArray21);
        double double25 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray6, doubleArray21);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, (double) (byte) 1);
        java.lang.Double double32 = pointValuePair31.getValue();
        java.lang.Double double33 = pointValuePair31.getSecond();
        java.lang.Double double34 = pointValuePair31.getValue();
        double[] doubleArray35 = pointValuePair31.getPointRef();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds36 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray21, doubleArray35);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection37 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray35, orderDirection37, false, true);
        try {
            boolean boolean42 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray0, orderDirection37, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) -1, (short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = eigenDecomposition24.getV();
        double[] doubleArray26 = eigenDecomposition24.getImagEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = eigenDecomposition24.getVT();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        try {
            org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 'a', (double) 'a');
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor24 = null;
        try {
            double double25 = diagonalMatrix23.walkInRowOrder(realMatrixPreservingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a', 0.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess34 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) (byte) 1);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray32, doubleArray36);
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        double[] doubleArray44 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess45 = new org.apache.commons.math3.optim.InitialGuess(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair49 = new org.apache.commons.math3.optim.PointValuePair(doubleArray47, (double) (byte) 1);
        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray43, doubleArray47);
        double double51 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray32, doubleArray47);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition53 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess60 = new org.apache.commons.math3.optim.InitialGuess(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair64 = new org.apache.commons.math3.optim.PointValuePair(doubleArray62, (double) (byte) 1);
        boolean boolean65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray58, doubleArray62);
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess67 = new org.apache.commons.math3.optim.InitialGuess(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66, (int) 'a');
        double[] doubleArray70 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess71 = new org.apache.commons.math3.optim.InitialGuess(doubleArray70);
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray70, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair75 = new org.apache.commons.math3.optim.PointValuePair(doubleArray73, (double) (byte) 1);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray69, doubleArray73);
        double double77 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray58, doubleArray73);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix78 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58);
        double[][] doubleArray79 = diagonalMatrix78.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = diagonalMatrix52.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix78);
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor82 = null;
        try {
            double double87 = diagonalMatrix23.walkInRowOrder(realMatrixChangingVisitor82, (int) (short) 10, (int) (byte) -1, (-289663928), (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(realMatrix80);
        org.junit.Assert.assertNotNull(realMatrix81);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor52 = null;
        try {
            double double53 = diagonalMatrix23.walkInRowOrder(realMatrixChangingVisitor52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double double27 = diagonalMatrix23.getEntry(6, (int) (short) 1);
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32);
        try {
            org.apache.commons.math3.linear.RealVector realVector34 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 53.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray29 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, 1, 0);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector32, arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector19.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor45 = null;
        try {
            double double46 = arrayRealVector44.walkInOptimizedOrder(realVectorChangingVisitor45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(arrayRealVector44);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(1.0415040453759297d, 3.4458315914355974E30d, 100);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a', 0.0d);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor3 = null;
        try {
            double double6 = arrayRealVector2.walkInDefaultOrder(realVectorChangingVisitor3, (int) (short) 100, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double29 = diagonalMatrix23.walkInColumnOrder(realMatrixChangingVisitor24, (-1), (int) (short) -1, (-289663928), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a', 0.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.analysis.function.Sinc sinc29 = new org.apache.commons.math3.analysis.function.Sinc();
        double double31 = sinc29.value((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector27.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc29);
        try {
            org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector27.getSubVector(52, 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (148)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.8414709848078965d + "'", double31 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        double double6 = arrayRealVector5.getMinValue();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0d, (double) 1252352413);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        double[] doubleArray27 = diagonalMatrix23.getDataRef();
        java.lang.String str28 = diagonalMatrix23.toString();
        double[] doubleArray32 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma33 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray32);
        double[] doubleArray34 = sigma33.getSigma();
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray35);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray35, (int) 'a');
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray34, doubleArray35);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight40 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray35);
        try {
            diagonalMatrix23.setColumn((int) (short) 100, doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (short) 0, (int) 'a', 1079574528, 50);
        try {
            int int6 = matrixDimensionMismatchException4.getWrongDimension(36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 36");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        boolean boolean28 = diagonalMatrix23.isSquare();
        double[][] doubleArray29 = diagonalMatrix23.getData();
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex30 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 96");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 1, 0);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 2147483647, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math3.exception.MathArithmeticException();
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 2.718281828459045d);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, 1, 0);
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector15.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector15);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(arrayRealVector26);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        org.apache.commons.math3.linear.RealMatrix realMatrix53 = diagonalMatrix23.scalarMultiply((double) 10.0f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realMatrix53);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-0.99999994f) + "'", float1 == (-0.99999994f));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray32);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) 'a');
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair45 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 1);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray43);
        double double47 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray28, doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        double[][] doubleArray49 = diagonalMatrix48.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix48);
        int int51 = diagonalMatrix23.getColumnDimension();
        double[] doubleArray52 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess53 = new org.apache.commons.math3.optim.InitialGuess(doubleArray52);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray52, (int) 'a');
        double[] doubleArray56 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess57 = new org.apache.commons.math3.optim.InitialGuess(doubleArray56);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray56, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair61 = new org.apache.commons.math3.optim.PointValuePair(doubleArray59, (double) (byte) 1);
        boolean boolean62 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray55, doubleArray59);
        double[] doubleArray63 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess64 = new org.apache.commons.math3.optim.InitialGuess(doubleArray63);
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray63, (int) 'a');
        double[] doubleArray67 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess68 = new org.apache.commons.math3.optim.InitialGuess(doubleArray67);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray67, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair72 = new org.apache.commons.math3.optim.PointValuePair(doubleArray70, (double) (byte) 1);
        boolean boolean73 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray66, doubleArray70);
        double double74 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray55, doubleArray70);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix75 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray55);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition76 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix75);
        org.apache.commons.math3.linear.RealMatrix realMatrix78 = diagonalMatrix75.power((int) '4');
        org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix23, (org.apache.commons.math3.linear.AnyMatrix) diagonalMatrix75);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 97 + "'", int51 == 97);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix78);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double double27 = diagonalMatrix23.getEntry(6, (int) (short) 1);
        int int28 = diagonalMatrix23.getRowDimension();
        java.lang.Double[] doubleArray36 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36, 1, 0);
        boolean boolean40 = arrayRealVector39.isNaN();
        int int41 = arrayRealVector39.getDimension();
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair47 = new org.apache.commons.math3.optim.PointValuePair(doubleArray42, 2.718281828459045d);
        java.lang.Double[] doubleArray54 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray54, 1, 0);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = arrayRealVector57.append(arrayRealVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42, arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector57);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector39.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        try {
            diagonalMatrix23.setRowVector((int) (short) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x97");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 97 + "'", int28 == 97);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(arrayRealVector68);
        org.junit.Assert.assertNotNull(arrayRealVector71);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = diagonalMatrix23.power((int) '4');
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess28 = new org.apache.commons.math3.optim.InitialGuess(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair32 = new org.apache.commons.math3.optim.PointValuePair(doubleArray30, (double) (byte) 1);
        java.lang.Double double33 = pointValuePair32.getValue();
        java.lang.Double double34 = pointValuePair32.getSecond();
        double[] doubleArray35 = pointValuePair32.getKey();
        double[] doubleArray36 = pointValuePair32.getKey();
        double[] doubleArray37 = diagonalMatrix23.operate(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray32);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) 'a');
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair45 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 1);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray43);
        double double47 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray28, doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        double[][] doubleArray49 = diagonalMatrix48.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix48);
        diagonalMatrix48.setEntry((int) '4', (int) '#', (double) 0L);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess60 = new org.apache.commons.math3.optim.InitialGuess(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair64 = new org.apache.commons.math3.optim.PointValuePair(doubleArray62, (double) (byte) 1);
        boolean boolean65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray58, doubleArray62);
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess67 = new org.apache.commons.math3.optim.InitialGuess(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66, (int) 'a');
        double[] doubleArray70 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess71 = new org.apache.commons.math3.optim.InitialGuess(doubleArray70);
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray70, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair75 = new org.apache.commons.math3.optim.PointValuePair(doubleArray73, (double) (byte) 1);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray69, doubleArray73);
        double double77 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray58, doubleArray73);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix78 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58);
        double[][] doubleArray79 = diagonalMatrix78.getData();
        double double82 = diagonalMatrix78.getEntry(6, (int) (short) 1);
        int int83 = diagonalMatrix78.getRowDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix84 = diagonalMatrix48.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix78);
        double[] doubleArray86 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess87 = new org.apache.commons.math3.optim.InitialGuess(doubleArray86);
        double[] doubleArray89 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray86, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair91 = new org.apache.commons.math3.optim.PointValuePair(doubleArray86, 2.718281828459045d);
        try {
            diagonalMatrix78.setColumn((-289663928), doubleArray86);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-289,663,928)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 97 + "'", int83 == 97);
        org.junit.Assert.assertNotNull(realMatrix84);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, (float) 10L, 2.89663936E8f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix51 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix53 = org.apache.commons.math3.linear.MatrixUtils.blockInverse(realMatrix51, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 11 != 86");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realMatrix51);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor27 = null;
        try {
            double double28 = diagonalMatrix23.walkInRowOrder(realMatrixPreservingVisitor27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker4 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 52.000004f, (double) 10.0f);
        double double5 = simpleValueChecker4.getRelativeThreshold();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer(3.141592653589793d, (double) '#', (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker4);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula8 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) 52.000004f, (double) 10.0f);
        double double12 = simpleValueChecker11.getRelativeThreshold();
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver13 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int14 = brentSolver13.getEvaluations();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner15 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer16 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula8, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver13, (org.apache.commons.math3.optim.nonlinear.scalar.gradient.Preconditioner) identityPreconditioner15);
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) 1);
        double[] doubleArray26 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray26);
        double[] doubleArray28 = sigma27.getSigma();
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equals(doubleArray28, doubleArray29);
        boolean boolean34 = pointValuePair23.equals((java.lang.Object) doubleArray29);
        double[] doubleArray35 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess36 = new org.apache.commons.math3.optim.InitialGuess(doubleArray35);
        double[] doubleArray38 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray35, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair40 = new org.apache.commons.math3.optim.PointValuePair(doubleArray38, (double) (byte) 1);
        double[] doubleArray43 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma44 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray43);
        double[] doubleArray45 = sigma44.getSigma();
        double[] doubleArray46 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess47 = new org.apache.commons.math3.optim.InitialGuess(doubleArray46);
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46, (int) 'a');
        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equals(doubleArray45, doubleArray46);
        boolean boolean51 = pointValuePair40.equals((java.lang.Object) doubleArray46);
        boolean boolean52 = simpleValueChecker11.converged((-289663928), pointValuePair23, pointValuePair40);
        double[] doubleArray53 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess54 = new org.apache.commons.math3.optim.InitialGuess(doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair58 = new org.apache.commons.math3.optim.PointValuePair(doubleArray56, (double) (byte) 1);
        java.lang.Double double59 = pointValuePair58.getValue();
        java.lang.Double double60 = pointValuePair58.getSecond();
        java.lang.Double double61 = pointValuePair58.getValue();
        double[] doubleArray62 = pointValuePair58.getPointRef();
        boolean boolean63 = simpleValueChecker4.converged(14, pointValuePair40, pointValuePair58);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.000003814697266d + "'", double5 == 52.000003814697266d);
        org.junit.Assert.assertTrue("'" + formula8 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES + "'", formula8.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.FLETCHER_REEVES));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 52.000003814697266d + "'", double12 == 52.000003814697266d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.0d + "'", double60.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc(false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(18.959852425725543d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1086.3195241849498d + "'", double1 == 1086.3195241849498d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess7 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray6);
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess10 = new org.apache.commons.math3.optim.InitialGuess(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) 'a');
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess14 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair18 = new org.apache.commons.math3.optim.PointValuePair(doubleArray16, (double) (byte) 1);
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray12, doubleArray16);
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess21 = new org.apache.commons.math3.optim.InitialGuess(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20, (int) 'a');
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess25 = new org.apache.commons.math3.optim.InitialGuess(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair29 = new org.apache.commons.math3.optim.PointValuePair(doubleArray27, (double) (byte) 1);
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray23, doubleArray27);
        double double31 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray12, doubleArray27);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix32 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray12);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix32);
        double[] doubleArray34 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess35 = new org.apache.commons.math3.optim.InitialGuess(doubleArray34);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray34, (int) 'a');
        double[] doubleArray38 = diagonalMatrix32.preMultiply(doubleArray37);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair39 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray6, doubleArray37);
        try {
            double double40 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray0, doubleArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 2147483647, 1.5931994782236123d);
        int int3 = brentOptimizer2.getIterations();
        int int4 = brentOptimizer2.getMaxEvaluations();
        int int5 = brentOptimizer2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Double[] doubleArray10 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, 1, 0);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable3, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray10, 2147483647, (int) 'a');
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Object[]) doubleArray10);
        org.apache.commons.math3.exception.MathInternalError mathInternalError19 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer4 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer5 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker10 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray15 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray18 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma19 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray18);
        org.apache.commons.math3.optim.InitialGuess initialGuess20 = new org.apache.commons.math3.optim.InitialGuess(doubleArray18);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair22 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray15, doubleArray18, true);
        double[] doubleArray26 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray29 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma30 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray29);
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair33 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray26, doubleArray29, true);
        boolean boolean34 = simpleVectorValueChecker10.converged(0, pointVectorValuePair22, pointVectorValuePair33);
        double[] doubleArray38 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray41 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma42 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray41);
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair45 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray38, doubleArray41, true);
        double[] doubleArray46 = pointVectorValuePair45.getPointRef();
        boolean boolean47 = simpleVectorValueChecker3.converged((int) (short) 100, pointVectorValuePair22, pointVectorValuePair45);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) (byte) 10, 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        double[] doubleArray4 = sigma3.getSigma();
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray5);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight10 = new org.apache.commons.math3.optim.nonlinear.vector.Weight(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = null;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 3.4458315914355974E30d, (java.lang.Number) 3.84634904127968E18d, (int) (short) 1, orderDirection3, true);
        int int6 = nonMonotonicSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonicSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 3.84634904127968E18d + "'", number7.equals(3.84634904127968E18d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.lang.String[] strArray3 = new java.lang.String[] { ",", "{}", "hi!" };
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess9 = new org.apache.commons.math3.optim.InitialGuess(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair13 = new org.apache.commons.math3.optim.PointValuePair(doubleArray11, (double) (byte) 1);
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray7, doubleArray11);
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess20 = new org.apache.commons.math3.optim.InitialGuess(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair24 = new org.apache.commons.math3.optim.PointValuePair(doubleArray22, (double) (byte) 1);
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray18, doubleArray22);
        double double26 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray7, doubleArray22);
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess28 = new org.apache.commons.math3.optim.InitialGuess(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair32 = new org.apache.commons.math3.optim.PointValuePair(doubleArray30, (double) (byte) 1);
        java.lang.Double double33 = pointValuePair32.getValue();
        java.lang.Double double34 = pointValuePair32.getSecond();
        java.lang.Double double35 = pointValuePair32.getValue();
        double[] doubleArray36 = pointValuePair32.getPointRef();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds37 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray22, doubleArray36);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection38 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray36, orderDirection38, false, true);
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray3, orderDirection38, false);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        double double1 = brentSolver0.getMin();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean6 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 1.0d, 0.0d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction7 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction8 = univariateObjectiveFunction7.getObjectiveFunction();
        boolean boolean11 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing(univariateFunction8, 3.141592653589793d, 53.0d);
        try {
            double double14 = brentSolver0.solve((int) (byte) 1, univariateFunction8, (double) 2.89663936E8f, (double) (-289663928));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [289,663,936, 4]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(univariateFunction8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(1);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 10, (double) (short) 100, (int) (byte) 1);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '4', (double) (byte) 1, true, 97, 1252352413, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        java.util.List<java.lang.Double> doubleList13 = cMAESOptimizer12.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList14 = cMAESOptimizer12.getStatisticsDHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList15 = cMAESOptimizer12.getStatisticsDHistory();
        org.junit.Assert.assertNotNull(doubleList13);
        org.junit.Assert.assertNotNull(realMatrixList14);
        org.junit.Assert.assertNotNull(realMatrixList15);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.optim.univariate.SearchInterval searchInterval3 = new org.apache.commons.math3.optim.univariate.SearchInterval(52.000003814697266d, (double) (short) 100, 100.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double double4 = simpleVectorValueChecker3.getAbsoluteThreshold();
        double double5 = simpleVectorValueChecker3.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister(1);
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker11 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 10, (double) (short) 100, (int) (byte) 1);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer cMAESOptimizer12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer((int) '4', (double) (byte) 1, true, 97, 1252352413, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister6, false, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer13 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = array2DRowRealMatrix2.add(array2DRowRealMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = diagonalMatrix23.getColumn((int) (byte) 0);
        int int27 = diagonalMatrix23.getColumnDimension();
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair33 = new org.apache.commons.math3.optim.PointValuePair(doubleArray28, 2.718281828459045d);
        java.lang.Double[] doubleArray40 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray40, 1, 0);
        java.lang.Double[] doubleArray50 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray50, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = arrayRealVector43.append(arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28, arrayRealVector43);
        int int56 = org.apache.commons.math3.util.MathUtils.hash(doubleArray28);
        double[] doubleArray57 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess58 = new org.apache.commons.math3.optim.InitialGuess(doubleArray57);
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray57, (int) 'a');
        double[] doubleArray61 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess62 = new org.apache.commons.math3.optim.InitialGuess(doubleArray61);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray61, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair66 = new org.apache.commons.math3.optim.PointValuePair(doubleArray64, (double) (byte) 1);
        boolean boolean67 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray60, doubleArray64);
        double[] doubleArray68 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess69 = new org.apache.commons.math3.optim.InitialGuess(doubleArray68);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray68, (int) 'a');
        double[] doubleArray72 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess73 = new org.apache.commons.math3.optim.InitialGuess(doubleArray72);
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray72, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair77 = new org.apache.commons.math3.optim.PointValuePair(doubleArray75, (double) (byte) 1);
        boolean boolean78 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray71, doubleArray75);
        double double79 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray60, doubleArray75);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix80 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray60);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition81 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix80);
        int int82 = diagonalMatrix80.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix84 = diagonalMatrix80.scalarMultiply(53.0d);
        double[] doubleArray85 = diagonalMatrix80.getDataRef();
        double double86 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray28, doubleArray85);
        try {
            double[] doubleArray87 = diagonalMatrix23.operate(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(arrayRealVector54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 97 + "'", int82 == 97);
        org.junit.Assert.assertNotNull(realMatrix84);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) (short) 10, 6);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 6, 10 };
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 52, 1791095845, 100, 6, 1, 100 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException13 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable2, intArray5, intArray12);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) (byte) 1, (java.lang.Object[]) intArray5);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) intArray5);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray2 = initialGuess1.getInitialGuess();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, false);
        int int5 = org.apache.commons.math3.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray32);
        double[] doubleArray36 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess37 = new org.apache.commons.math3.optim.InitialGuess(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) 'a');
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair45 = new org.apache.commons.math3.optim.PointValuePair(doubleArray43, (double) (byte) 1);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray39, doubleArray43);
        double double47 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray28, doubleArray43);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix48 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray28);
        double[][] doubleArray49 = diagonalMatrix48.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = diagonalMatrix23.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix48);
        diagonalMatrix48.setEntry((int) '4', (int) '#', (double) 0L);
        double[] doubleArray57 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma58 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray57);
        double[] doubleArray59 = sigma58.getSigma();
        boolean boolean60 = diagonalMatrix48.equals((java.lang.Object) doubleArray59);
        java.io.ObjectOutputStream objectOutputStream61 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix48, objectOutputStream61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix1 = new org.apache.commons.math3.linear.DiagonalMatrix(97);
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess7 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection11 = null;
        double[] doubleArray14 = new double[] { 320.0d, Double.NaN };
        double[][] doubleArray15 = new double[][] { doubleArray14 };
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray6, orderDirection11, doubleArray15);
        try {
            diagonalMatrix1.copySubMatrix(0, (int) (short) 100, (int) '#', (int) (short) -1, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess2 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray3 = initialGuess2.getInitialGuess();
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, 0);
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess7 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair11 = new org.apache.commons.math3.optim.PointValuePair(doubleArray6, 2.718281828459045d);
        java.lang.Double[] doubleArray18 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, 1, 0);
        java.lang.Double[] doubleArray28 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray28, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector21.append(arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, arrayRealVector21);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray6);
        double[] doubleArray35 = identityPreconditioner0.precondition(doubleArray3, doubleArray6);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection36 = null;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray6, orderDirection36, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int1 = brentSolver0.getEvaluations();
        org.apache.commons.math3.analysis.function.Sinc sinc3 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean6 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc3, 1.0d, 0.0d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction7 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc3);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction8 = sinc3.derivative();
        try {
            double double12 = brentSolver0.solve(0, univariateFunction8, (double) 100, 10.0d, 7.69269808255936E18d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [7,692,698,082,559,360,000, 10]");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(univariateFunction8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) 100L, (double) (byte) 10, (double) (short) 10);
        int int4 = levenbergMarquardtOptimizer3.getEvaluations();
        double[] doubleArray5 = levenbergMarquardtOptimizer3.getUpperBound();
        double double6 = levenbergMarquardtOptimizer3.getChiSquare();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double[][] doubleArray25 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray24);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex26 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 96");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray5 = new double[] { (-1.5707963267948966d), 18.959852425725543d, 1.0d, 1.0E-14d, (-1L) };
        double[] doubleArray6 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition7 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat3 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str4 = realMatrixFormat3.getRowSeparator();
        java.text.NumberFormat numberFormat5 = realMatrixFormat3.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat("{}", "}", "{", numberFormat5);
        org.junit.Assert.assertNotNull(realMatrixFormat3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "," + "'", str4.equals(","));
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 100.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        java.lang.String str2 = realVectorFormat0.getPrefix();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double double16 = arrayRealVector9.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double double17 = arrayRealVector9.getMinValue();
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess21 = new org.apache.commons.math3.optim.InitialGuess(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair25 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, 2.718281828459045d);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, 1, 0);
        java.lang.Double[] doubleArray42 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector35.append(arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, arrayRealVector35);
        double double48 = arrayRealVector35.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector9.combineToSelf((double) (byte) 100, (double) 52L, (org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector49);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(52.00000000000001d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex(anyMatrix0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optim.SimpleValueChecker(32.0d, (double) 100);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker2);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 1, 0);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 2147483647, (int) 'a');
        double[] doubleArray15 = arrayRealVector14.toArray();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver0 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        int int1 = brentSolver0.getEvaluations();
        double double2 = brentSolver0.getStartValue();
        double double3 = brentSolver0.getAbsoluteAccuracy();
        int int4 = brentSolver0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-6d + "'", double3 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        org.apache.commons.math3.optim.nonlinear.vector.Weight weight27 = new org.apache.commons.math3.optim.nonlinear.vector.Weight((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor28 = null;
        try {
            double double33 = diagonalMatrix23.walkInColumnOrder(realMatrixPreservingVisitor28, (int) (byte) 10, 1791095845, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,791,095,845)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        double[] doubleArray8 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma9 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray8);
        double[] doubleArray10 = sigma9.getSigma();
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray11);
        boolean boolean16 = pointValuePair5.equals((java.lang.Object) doubleArray11);
        double[] doubleArray17 = pointValuePair5.getKey();
        double[] doubleArray18 = pointValuePair5.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        boolean boolean25 = diagonalMatrix23.isTransposable();
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        double double53 = diagonalMatrix49.getEntry(6, (int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix23.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair60 = new org.apache.commons.math3.optim.PointValuePair(doubleArray58, (double) (byte) 1);
        java.lang.Double double61 = pointValuePair60.getValue();
        java.lang.Double double62 = pointValuePair60.getSecond();
        java.lang.Double double63 = pointValuePair60.getValue();
        double[] doubleArray64 = pointValuePair60.getPointRef();
        double[] doubleArray65 = diagonalMatrix49.preMultiply(doubleArray64);
        double[][] doubleArray66 = diagonalMatrix49.getData();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0d + "'", double62.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0d + "'", double63.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str7 = realMatrixFormat6.getRowSeparator();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat("{}", "hi!", "", ",", "", "{}", numberFormat8);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat10 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = null;
        try {
            java.lang.String str12 = realMatrixFormat10.format(realMatrix11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "," + "'", str7.equals(","));
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        java.lang.String str2 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix1);
        double[][] doubleArray3 = array2DRowRealMatrix1.getData();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{}" + "'", str2.equals("{}"));
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = diagonalMatrix23.preMultiply(doubleArray28);
        int int30 = diagonalMatrix23.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 97 + "'", int30 == 97);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 100, (double) 36, (double) 100.0f, (double) 1791095845, 640.0d);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction6 = null;
        java.util.Comparator<org.apache.commons.math3.optim.PointValuePair> pointValuePairComparator7 = null;
        try {
            nelderMeadSimplex5.evaluate(multivariateFunction6, pointValuePairComparator7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapAdd(2.718281828459045d);
        double double23 = arrayRealVector20.getNorm();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        float float2 = org.apache.commons.math3.util.FastMath.scalb((float) (-289663928), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-5.7932787E8f) + "'", float2 == (-5.7932787E8f));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker6 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair13 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        boolean boolean14 = simpleUnivariateValueChecker6.converged(0, univariatePointValuePair10, univariatePointValuePair13);
        double double15 = simpleUnivariateValueChecker6.getAbsoluteThreshold();
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess22 = new org.apache.commons.math3.optim.InitialGuess(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair26 = new org.apache.commons.math3.optim.PointValuePair(doubleArray24, (double) (byte) 1);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray20, doubleArray24);
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess33 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair37 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) (byte) 1);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray31, doubleArray35);
        double double39 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray20, doubleArray35);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray20);
        double[][] doubleArray41 = diagonalMatrix40.getData();
        double[][] doubleArray42 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) simpleUnivariateValueChecker6, localizable16, (java.lang.Object[]) doubleArray42);
        try {
            array2DRowRealMatrix2.setSubMatrix(doubleArray42, 14, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2,704 != 2,340");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(1.4E-45f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double2 = org.apache.commons.math3.util.FastMath.pow((-0.7853981633974483d), 3.141592653589793d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula0 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula formula1 = org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE;
        org.apache.commons.math3.optim.SimpleValueChecker simpleValueChecker5 = new org.apache.commons.math3.optim.SimpleValueChecker((double) (short) 10, (double) (short) 100, (int) (byte) 1);
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer6 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula1, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5);
        org.apache.commons.math3.analysis.solvers.BrentSolver brentSolver7 = new org.apache.commons.math3.analysis.solvers.BrentSolver();
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer nonLinearConjugateGradientOptimizer8 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer(formula0, (org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair>) simpleValueChecker5, (org.apache.commons.math3.analysis.solvers.UnivariateSolver) brentSolver7);
        double double9 = brentSolver7.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + formula0 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula0.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + formula1 + "' != '" + org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE + "'", formula1.equals(org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.Formula.POLAK_RIBIERE));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-6d + "'", double9 == 1.0E-6d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        boolean boolean25 = diagonalMatrix23.isTransposable();
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        double double53 = diagonalMatrix49.getEntry(6, (int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix23.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix59 = diagonalMatrix49.getSubMatrix(0, (int) (short) 0, (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial column 52 after final column 10");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapAdd(2.718281828459045d);
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector20.add((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor30 = null;
        try {
            double double33 = arrayRealVector20.walkInDefaultOrder(realVectorChangingVisitor30, 36, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(arrayRealVector29);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, 1, 0);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) doubleArray12);
        org.apache.commons.math3.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math3.exception.NoBracketingException(localizable0, (double) 1791095845, (-0.7853981633974483d), 0.0d, 1.0415040453759297d, (java.lang.Object[]) doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999877116507956d + "'", double1 == 0.9999877116507956d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowPrefix();
        double[] doubleArray2 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess3 = new org.apache.commons.math3.optim.InitialGuess(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2, (int) 'a');
        double[] doubleArray6 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess7 = new org.apache.commons.math3.optim.InitialGuess(doubleArray6);
        double[] doubleArray9 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray6, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair11 = new org.apache.commons.math3.optim.PointValuePair(doubleArray9, (double) (byte) 1);
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray5, doubleArray9);
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess14 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13, (int) 'a');
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) (byte) 1);
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray16, doubleArray20);
        double double24 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray5, doubleArray20);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix25 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition26 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix25);
        double[] doubleArray28 = diagonalMatrix25.getColumn((int) (byte) 0);
        java.lang.String str29 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix25);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        float[] floatArray4 = new float[] { 100, (short) 10, (short) -1, 10L };
        float[] floatArray7 = new float[] { (-1.0f), (-1.0f) };
        float[] floatArray11 = new float[] { 7692698082559361259L, (short) 10, (byte) 0 };
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray7, floatArray11);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray4, floatArray7);
        float[] floatArray16 = new float[] { (-1.0f), (-1.0f) };
        float[] floatArray20 = new float[] { 7692698082559361259L, (short) 10, (byte) 0 };
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray16, floatArray20);
        float[] floatArray24 = new float[] { (-1.0f), (-1.0f) };
        float[] floatArray28 = new float[] { 7692698082559361259L, (short) 10, (byte) 0 };
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray24, floatArray28);
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equals(floatArray16, floatArray24);
        float[] floatArray35 = new float[] { 100, (short) 10, (short) -1, 10L };
        float[] floatArray38 = new float[] { (-1.0f), (-1.0f) };
        float[] floatArray42 = new float[] { 7692698082559361259L, (short) 10, (byte) 0 };
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray38, floatArray42);
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray35, floatArray38);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equals(floatArray16, floatArray38);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray4, floatArray38);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray8 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray11 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray11, true);
        double[] doubleArray19 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray22 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray22);
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray22, true);
        boolean boolean27 = simpleVectorValueChecker3.converged(0, pointVectorValuePair15, pointVectorValuePair26);
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker32 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray37 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray40 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma41 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray40);
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair44 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray37, doubleArray40, true);
        double[] doubleArray48 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray51 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma52 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray51);
        org.apache.commons.math3.optim.InitialGuess initialGuess53 = new org.apache.commons.math3.optim.InitialGuess(doubleArray51);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair55 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray48, doubleArray51, true);
        boolean boolean56 = simpleVectorValueChecker32.converged(0, pointVectorValuePair44, pointVectorValuePair55);
        double[] doubleArray60 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray63 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma64 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray63);
        org.apache.commons.math3.optim.InitialGuess initialGuess65 = new org.apache.commons.math3.optim.InitialGuess(doubleArray63);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair67 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray60, doubleArray63, true);
        boolean boolean68 = simpleVectorValueChecker3.converged((-1), pointVectorValuePair55, pointVectorValuePair67);
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer gaussNewtonOptimizer69 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.GaussNewtonOptimizer((org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair>) simpleVectorValueChecker3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double[] doubleArray1 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess2 = new org.apache.commons.math3.optim.InitialGuess(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray1, (int) 'a');
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        double[] doubleArray8 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray5, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair10 = new org.apache.commons.math3.optim.PointValuePair(doubleArray8, (double) (byte) 1);
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray4, doubleArray8);
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) 'a');
        double[] doubleArray16 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess17 = new org.apache.commons.math3.optim.InitialGuess(doubleArray16);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray16, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair21 = new org.apache.commons.math3.optim.PointValuePair(doubleArray19, (double) (byte) 1);
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray15, doubleArray19);
        double double23 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray4, doubleArray19);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.scale((double) 52, doubleArray19);
        org.apache.commons.math3.optim.nonlinear.vector.Target target25 = new org.apache.commons.math3.optim.nonlinear.vector.Target(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (byte) 100, 52);
        org.junit.Assert.assertNotNull(realMatrix2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.analysis.function.Sinc sinc1 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean4 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc1, 1.0d, 0.0d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction5 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc1);
        org.apache.commons.math3.analysis.solvers.BracketedUnivariateSolver<org.apache.commons.math3.analysis.UnivariateFunction> univariateFunctionBracketedUnivariateSolver6 = null;
        org.apache.commons.math3.analysis.solvers.AllowedSolution allowedSolution10 = null;
        try {
            double double11 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.forceSide((int) ' ', (org.apache.commons.math3.analysis.UnivariateFunction) sinc1, univariateFunctionBracketedUnivariateSolver6, 0.0d, (double) (byte) 1, (double) (short) 1, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded(52);
        double[] doubleArray2 = simpleBounds1.getLower();
        double[] doubleArray3 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess4 = new org.apache.commons.math3.optim.InitialGuess(doubleArray3);
        double[] doubleArray6 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray3, (int) 'a');
        double[] doubleArray7 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess8 = new org.apache.commons.math3.optim.InitialGuess(doubleArray7);
        double[] doubleArray10 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray7, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair12 = new org.apache.commons.math3.optim.PointValuePair(doubleArray10, (double) (byte) 1);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray6, doubleArray10);
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess15 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) 'a');
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) 1);
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray17, doubleArray21);
        double double25 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray6, doubleArray21);
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair31 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, (double) (byte) 1);
        java.lang.Double double32 = pointValuePair31.getValue();
        java.lang.Double double33 = pointValuePair31.getSecond();
        java.lang.Double double34 = pointValuePair31.getValue();
        double[] doubleArray35 = pointValuePair31.getPointRef();
        org.apache.commons.math3.optim.SimpleBounds simpleBounds36 = new org.apache.commons.math3.optim.SimpleBounds(doubleArray21, doubleArray35);
        try {
            double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray2, doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 97");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(simpleBounds1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double[] doubleArray4 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray5);
        double[] doubleArray8 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess9 = new org.apache.commons.math3.optim.InitialGuess(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) 'a');
        double[] doubleArray12 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray12);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray12, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair17 = new org.apache.commons.math3.optim.PointValuePair(doubleArray15, (double) (byte) 1);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray11, doubleArray15);
        double[] doubleArray19 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess20 = new org.apache.commons.math3.optim.InitialGuess(doubleArray19);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19, (int) 'a');
        double[] doubleArray23 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray23);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair28 = new org.apache.commons.math3.optim.PointValuePair(doubleArray26, (double) (byte) 1);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray22, doubleArray26);
        double double30 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray11, doubleArray26);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix31 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray11);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition32 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix31);
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess34 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33, (int) 'a');
        double[] doubleArray37 = diagonalMatrix31.preMultiply(doubleArray36);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair38 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray5, doubleArray36);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix40 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray5, false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 3.141592653589793d, (java.lang.Number) (-2.89663928E8d), (int) (byte) 100);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex31 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (short) 100, (double) 36, (double) 100.0f, (double) 1791095845, 640.0d);
        boolean boolean32 = diagonalMatrix23.equals((java.lang.Object) 100.0f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        java.lang.Double double6 = pointValuePair5.getValue();
        java.lang.Double double7 = pointValuePair5.getSecond();
        double[] doubleArray8 = pointValuePair5.getKey();
        double[] doubleArray9 = pointValuePair5.getKey();
        double[] doubleArray10 = pointValuePair5.getFirst();
        double[] doubleArray11 = pointValuePair5.getKey();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7.equals(1.0d));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        boolean boolean26 = diagonalMatrix23.equals((java.lang.Object) (-2.89663928E8d));
        int int27 = diagonalMatrix23.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 97 + "'", int27 == 97);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (-5.7932787E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.optim.SimpleBounds simpleBounds1 = org.apache.commons.math3.optim.SimpleBounds.unbounded(52);
        double[] doubleArray2 = simpleBounds1.getLower();
        double[] doubleArray3 = simpleBounds1.getLower();
        org.junit.Assert.assertNotNull(simpleBounds1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoBracketingException noBracketingException5 = new org.apache.commons.math3.exception.NoBracketingException(0.0d, (double) ' ', 0.0d, (double) 0);
        double double6 = noBracketingException5.getFLo();
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) 0, (double) (short) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(0);
        java.lang.Object obj13 = new java.lang.Object();
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 1, 0, obj13 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) noBracketingException5, localizable7, objArray14);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException16 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, objArray14);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer powellOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.PowellOptimizer((double) (short) 1, (double) 1252352413);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep bracketingStep1 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.BracketingStep((double) (byte) 10);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double[] doubleArray26 = diagonalMatrix23.getColumn((int) (byte) 0);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex27 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.ZeroException; message: equal vertices 0 and {1} in simplex configuration");
        } catch (org.apache.commons.math3.exception.ZeroException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker2 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(1.5931994782236123d, Double.NaN);
        double double3 = simpleUnivariateValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 2147483647, 1.5931994782236123d);
        int int3 = brentOptimizer2.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11);
        double double16 = arrayRealVector9.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        double double17 = arrayRealVector9.getMinValue();
        double[] doubleArray20 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess21 = new org.apache.commons.math3.optim.InitialGuess(doubleArray20);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair25 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, 2.718281828459045d);
        java.lang.Double[] doubleArray32 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, 1, 0);
        java.lang.Double[] doubleArray42 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector35.append(arrayRealVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, arrayRealVector35);
        double double48 = arrayRealVector35.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector9.combineToSelf((double) (byte) 100, (double) 52L, (org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray50 = arrayRealVector49.toArray();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        java.lang.Double[] doubleArray55 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, 1, 0);
        java.lang.Double[] doubleArray65 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector58, arrayRealVector68);
        java.lang.Double[] doubleArray78 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray78, 1, 0);
        java.lang.Double[] doubleArray88 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray88, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector81, arrayRealVector91);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = arrayRealVector68.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector81);
        org.apache.commons.math3.linear.RealVector realVector94 = arrayRealVector20.append((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        boolean boolean95 = arrayRealVector20.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector97 = arrayRealVector20.mapAdd(1.240276008560994d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(arrayRealVector93);
        org.junit.Assert.assertNotNull(realVector94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(realVector97);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(1);
        byte[] byteArray3 = new byte[] { (byte) 10 };
        mersenneTwister1.nextBytes(byteArray3);
        org.junit.Assert.assertNotNull(byteArray3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double2 = org.apache.commons.math3.util.FastMath.pow(1.5440680443502757d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4011670.227819987d + "'", double2 == 4011670.227819987d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3, 10, 0, (int) 'a', (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) '#', (-1.5931994782236123d), (double) (-1.0f), (double) 0, 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        double[] doubleArray27 = diagonalMatrix23.getDataRef();
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix28 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.optim.univariate.BrentOptimizer brentOptimizer2 = new org.apache.commons.math3.optim.univariate.BrentOptimizer((double) 6, 7.69269808255936E18d);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.univariate.UnivariatePointValuePair> univariatePointValuePairConvergenceChecker3 = brentOptimizer2.getConvergenceChecker();
        double double4 = brentOptimizer2.getStartValue();
        int int5 = brentOptimizer2.getMaxEvaluations();
        org.junit.Assert.assertNull(univariatePointValuePairConvergenceChecker3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        java.lang.Double[] doubleArray57 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector60 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray57, 1, 0);
        java.lang.Double[] doubleArray67 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray67, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector60, arrayRealVector70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = arrayRealVector20.combineToSelf((double) (-1.0f), (double) (byte) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector70);
        org.apache.commons.math3.linear.RealVector realVector74 = arrayRealVector70.mapAddToSelf((double) 1.0f);
        double double75 = arrayRealVector70.getLInfNorm();
        java.lang.Double[] doubleArray82 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray82, 1, 0);
        double[] doubleArray86 = arrayRealVector85.getDataRef();
        boolean boolean87 = arrayRealVector70.equals((java.lang.Object) arrayRealVector85);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(arrayRealVector72);
        org.junit.Assert.assertNotNull(realVector74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        double[] doubleArray27 = diagonalMatrix23.getDataRef();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor28 = null;
        try {
            double double29 = diagonalMatrix23.walkInOptimizedOrder(realMatrixChangingVisitor28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.text.NumberFormat numberFormat2 = realMatrixFormat0.getFormat();
        java.lang.String str3 = realMatrixFormat0.getPrefix();
        java.lang.String str4 = realMatrixFormat0.getColumnSeparator();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{" + "'", str3.equals("{"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "," + "'", str4.equals(","));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair10 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        boolean boolean11 = simpleUnivariateValueChecker3.converged(0, univariatePointValuePair7, univariatePointValuePair10);
        double double12 = simpleUnivariateValueChecker3.getAbsoluteThreshold();
        org.apache.commons.math3.exception.util.Localizable localizable13 = null;
        double[] doubleArray14 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess15 = new org.apache.commons.math3.optim.InitialGuess(doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) 'a');
        double[] doubleArray18 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess19 = new org.apache.commons.math3.optim.InitialGuess(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair23 = new org.apache.commons.math3.optim.PointValuePair(doubleArray21, (double) (byte) 1);
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray17, doubleArray21);
        double[] doubleArray25 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess26 = new org.apache.commons.math3.optim.InitialGuess(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray25, (int) 'a');
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray32, (double) (byte) 1);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray28, doubleArray32);
        double double36 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray17, doubleArray32);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix37 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray17);
        double[][] doubleArray38 = diagonalMatrix37.getData();
        double[][] doubleArray39 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray38);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) simpleUnivariateValueChecker3, localizable13, (java.lang.Object[]) doubleArray39);
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex45 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray39, (double) (-5.7932787E8f), (double) 1252352413, 2.718281828459045d, 17.38905609893065d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 2,704 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.079574528E9d + "'", double1 == 1.079574528E9d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = null;
        try {
            diagonalMatrix23.setColumnMatrix((int) (byte) 1, realMatrix25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Double[] doubleArray9 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, 1, 0);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable2, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException14 = new org.apache.commons.math3.exception.NullArgumentException(localizable1, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) doubleArray9);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, (int) (short) -1, (-289663928));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math3.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.getColumnMatrix(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(3.4458315914355974E30d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a', 0.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.analysis.function.Sinc sinc29 = new org.apache.commons.math3.analysis.function.Sinc();
        double double31 = sinc29.value((double) 1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector27.mapToSelf((org.apache.commons.math3.analysis.UnivariateFunction) sinc29);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure33 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure34 = sinc29.value(derivativeStructure33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.8414709848078965d + "'", double31 == 0.8414709848078965d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        double[] doubleArray21 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess22 = new org.apache.commons.math3.optim.InitialGuess(doubleArray21);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21);
        double double26 = arrayRealVector20.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        try {
            arrayRealVector25.addToEntry((int) 'a', 2.718281828459045d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.verifyInterval(0.0d, (double) (short) 10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 1079574528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 30 + "'", int1 == 30);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = eigenDecomposition25.getD();
        double[] doubleArray27 = eigenDecomposition25.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = eigenDecomposition25.getVT();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double[] doubleArray2 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray2);
        double[] doubleArray4 = sigma3.getSigma();
        double[] doubleArray5 = sigma3.getSigma();
        org.apache.commons.math3.optim.PointValuePair pointValuePair7 = new org.apache.commons.math3.optim.PointValuePair(doubleArray5, (double) 100.0f);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray2 = initialGuess1.getInitialGuess();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray2, false);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapDivide(0.8414709848078965d);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray10 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        boolean boolean13 = org.apache.commons.math3.util.MathArrays.equals(doubleArray10, doubleArray11);
        java.lang.Object[] objArray14 = new java.lang.Object[] { doubleArray10 };
        org.apache.commons.math3.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math3.exception.NoBracketingException(localizable1, (double) (byte) 1, (double) '4', (double) 100L, (double) 'a', objArray14);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = mathArithmeticException16.getContext();
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(exceptionContext17);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(1, (double) 52.000004f, 1.1436832136579866E-4d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer simplexOptimizer2 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.SimplexOptimizer(32.0d, (double) (byte) -1);
        double[] doubleArray3 = simplexOptimizer2.getUpperBound();
        double[] doubleArray4 = simplexOptimizer2.getUpperBound();
        org.junit.Assert.assertNull(doubleArray3);
        org.junit.Assert.assertNull(doubleArray4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 1, (int) (short) 0, (int) (short) -1, (int) 'a');
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 97 + "'", int5 == 97);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 2.718281828459045d);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, 1, 0);
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector15.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector15);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair34 = new org.apache.commons.math3.optim.PointValuePair(doubleArray29, 2.718281828459045d);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray41, 1, 0);
        java.lang.Double[] doubleArray51 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector44.append(arrayRealVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector56 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray29, arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector28.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector56);
        java.lang.Double[] doubleArray64 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray64, 1, 0);
        boolean boolean68 = arrayRealVector67.isNaN();
        double double69 = arrayRealVector57.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector67);
        try {
            arrayRealVector57.addToEntry((int) (byte) 0, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-43.636130838093536d) + "'", double1 == (-43.636130838093536d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(52.000004f, (float) 100L, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker(0.0d, 640.0d, (int) ' ');
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 1.0d, 0.0d);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure4 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure5 = sinc0.value(derivativeStructure4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Double[] doubleArray7 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 1, 0);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7, 2147483647, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor16 = null;
        try {
            double double19 = arrayRealVector15.walkInDefaultOrder(realVectorPreservingVisitor16, 6, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (6)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "hi!", "hi!");
        java.lang.String str4 = realVectorFormat3.getSeparator();
        java.lang.Double[] doubleArray11 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, 1, 0);
        java.lang.Double[] doubleArray21 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector14.append(arrayRealVector24);
        int int26 = arrayRealVector24.getMaxIndex();
        java.lang.StringBuffer stringBuffer27 = null;
        java.text.FieldPosition fieldPosition28 = null;
        try {
            java.lang.StringBuffer stringBuffer29 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector24, stringBuffer27, fieldPosition28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray0, (double) 97, (-2.89663928E8d), (double) 0, 0.07075766826391931d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtractToSelf((double) 52.000004f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        double[] doubleArray27 = diagonalMatrix23.getDataRef();
        java.lang.String str28 = diagonalMatrix23.toString();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double30 = diagonalMatrix23.walkInOptimizedOrder(realMatrixPreservingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray1 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.0d, (double) 10L, 10);
        double[] doubleArray8 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray11 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma12 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray11);
        org.apache.commons.math3.optim.InitialGuess initialGuess13 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair15 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray8, doubleArray11, true);
        double[] doubleArray19 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray22 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma23 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray22);
        org.apache.commons.math3.optim.InitialGuess initialGuess24 = new org.apache.commons.math3.optim.InitialGuess(doubleArray22);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair26 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray19, doubleArray22, true);
        boolean boolean27 = simpleVectorValueChecker3.converged(0, pointVectorValuePair15, pointVectorValuePair26);
        double[] doubleArray28 = pointVectorValuePair26.getKey();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        double double27 = diagonalMatrix23.getEntry(6, (int) (short) 1);
        int int28 = diagonalMatrix23.getRowDimension();
        java.io.ObjectOutputStream objectOutputStream29 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, objectOutputStream29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 97 + "'", int28 == 97);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math3.analysis.function.Sinc sinc0 = new org.apache.commons.math3.analysis.function.Sinc();
        boolean boolean3 = org.apache.commons.math3.analysis.solvers.UnivariateSolverUtils.isBracketing((org.apache.commons.math3.analysis.UnivariateFunction) sinc0, 1.0d, 0.0d);
        org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction univariateObjectiveFunction4 = new org.apache.commons.math3.optim.univariate.UnivariateObjectiveFunction((org.apache.commons.math3.analysis.UnivariateFunction) sinc0);
        org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure5 = null;
        try {
            org.apache.commons.math3.analysis.differentiation.DerivativeStructure derivativeStructure6 = sinc0.value(derivativeStructure5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        double[] doubleArray27 = diagonalMatrix23.getDataRef();
        int int28 = diagonalMatrix23.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 97 + "'", int28 == 97);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        java.lang.Double[] doubleArray16 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray16, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector19);
        java.lang.Double[] doubleArray27 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, 1, 0);
        java.lang.Double[] doubleArray37 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray37, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30, arrayRealVector40);
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray42);
        double double47 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector20.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector41);
        java.lang.Double[] doubleArray55 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray55, 1, 0);
        java.lang.Double[] doubleArray65 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray65, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector58, arrayRealVector68);
        java.lang.Double[] doubleArray78 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray78, 1, 0);
        java.lang.Double[] doubleArray88 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray88, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector81, arrayRealVector91);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = arrayRealVector68.combine(0.0d, (double) 0L, (org.apache.commons.math3.linear.RealVector) arrayRealVector81);
        org.apache.commons.math3.linear.RealVector realVector94 = arrayRealVector20.append((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        boolean boolean95 = arrayRealVector20.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector97 = arrayRealVector20.mapSubtract(1.1436832136579866E-4d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector98 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20);
        boolean boolean99 = arrayRealVector98.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(arrayRealVector93);
        org.junit.Assert.assertNotNull(realVector94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertNotNull(realVector97);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.text.NumberFormat numberFormat2 = realMatrixFormat0.getFormat();
        java.lang.String str3 = realMatrixFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "}" + "'", str3.equals("}"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 100);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        boolean boolean25 = diagonalMatrix23.isTransposable();
        double[] doubleArray26 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess27 = new org.apache.commons.math3.optim.InitialGuess(doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) 'a');
        double[] doubleArray30 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess31 = new org.apache.commons.math3.optim.InitialGuess(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair35 = new org.apache.commons.math3.optim.PointValuePair(doubleArray33, (double) (byte) 1);
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray29, doubleArray33);
        double[] doubleArray37 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess38 = new org.apache.commons.math3.optim.InitialGuess(doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) 'a');
        double[] doubleArray41 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess42 = new org.apache.commons.math3.optim.InitialGuess(doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair46 = new org.apache.commons.math3.optim.PointValuePair(doubleArray44, (double) (byte) 1);
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray40, doubleArray44);
        double double48 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray29, doubleArray44);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix49 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray29);
        double[][] doubleArray50 = diagonalMatrix49.getData();
        double double53 = diagonalMatrix49.getEntry(6, (int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = diagonalMatrix23.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix49);
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor55 = null;
        try {
            double double56 = diagonalMatrix49.walkInRowOrder(realMatrixPreservingVisitor55);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = diagonalMatrix23.power((int) '4');
        double[] doubleArray27 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess28 = new org.apache.commons.math3.optim.InitialGuess(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) 'a');
        double[] doubleArray31 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess32 = new org.apache.commons.math3.optim.InitialGuess(doubleArray31);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray31, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair36 = new org.apache.commons.math3.optim.PointValuePair(doubleArray34, (double) (byte) 1);
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray30, doubleArray34);
        double[] doubleArray38 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess39 = new org.apache.commons.math3.optim.InitialGuess(doubleArray38);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38, (int) 'a');
        double[] doubleArray42 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess43 = new org.apache.commons.math3.optim.InitialGuess(doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair47 = new org.apache.commons.math3.optim.PointValuePair(doubleArray45, (double) (byte) 1);
        boolean boolean48 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray41, doubleArray45);
        double double49 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray30, doubleArray45);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix50 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray30);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition51 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix50);
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = diagonalMatrix23.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix50);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition53 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix50);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition54 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix50);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix52);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math3.util.FastMath.log((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex(anyMatrix0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.Double[] doubleArray6 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6, 1, 0);
        boolean boolean10 = arrayRealVector9.isNaN();
        int int11 = arrayRealVector9.getDimension();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector9.mapDivide((double) 10L);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector9.mapSubtract(1.5931994782236123d);
        java.lang.String str16 = arrayRealVector9.toString();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{}" + "'", str16.equals("{}"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 1, (int) (byte) 0, 0.0d);
        double double4 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException(0, (int) '#', 0, 50);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) 0, (float) 52L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma4 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray3);
        double[] doubleArray5 = sigma4.getSigma();
        double[] doubleArray6 = sigma4.getSigma();
        try {
            double double7 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (byte) 1, (double) 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 2.718281828459045d);
        java.lang.Double double6 = pointValuePair5.getValue();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.718281828459045d + "'", double6.equals(2.718281828459045d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner identityPreconditioner0 = new org.apache.commons.math3.optim.nonlinear.scalar.gradient.NonLinearConjugateGradientOptimizer.IdentityPreconditioner();
        double[] doubleArray4 = new double[] { 52.000004f, 0L, 100.0f };
        double[] doubleArray7 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma8 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray7);
        org.apache.commons.math3.optim.InitialGuess initialGuess9 = new org.apache.commons.math3.optim.InitialGuess(doubleArray7);
        org.apache.commons.math3.optim.PointVectorValuePair pointVectorValuePair11 = new org.apache.commons.math3.optim.PointVectorValuePair(doubleArray4, doubleArray7, true);
        double[] doubleArray12 = pointVectorValuePair11.getValue();
        double[] doubleArray13 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess14 = new org.apache.commons.math3.optim.InitialGuess(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13, (int) 'a');
        double[] doubleArray17 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess18 = new org.apache.commons.math3.optim.InitialGuess(doubleArray17);
        double[] doubleArray20 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray17, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair22 = new org.apache.commons.math3.optim.PointValuePair(doubleArray20, (double) (byte) 1);
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray16, doubleArray20);
        double[] doubleArray24 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess25 = new org.apache.commons.math3.optim.InitialGuess(doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) 'a');
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair33 = new org.apache.commons.math3.optim.PointValuePair(doubleArray31, (double) (byte) 1);
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray27, doubleArray31);
        double double35 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray16, doubleArray31);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix36 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray16);
        double[] doubleArray37 = identityPreconditioner0.precondition(doubleArray12, doubleArray16);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray0, 2.718281828459045d);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, 1, 0);
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray22, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector15.append(arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector15);
        java.lang.Double[] doubleArray34 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray34, 1, 0);
        java.lang.Double[] doubleArray44 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray44, 1, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector37.append(arrayRealVector47);
        int int49 = arrayRealVector47.getMaxIndex();
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector47.mapSubtract((double) (byte) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector15.add(realVector51);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double2 = org.apache.commons.math3.util.FastMath.pow(7.69269808255936E18d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2999340273956262E-19d + "'", double2 == 1.2999340273956262E-19d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double[] doubleArray4 = new double[] { (byte) 0, '#', 1.0f, 1 };
        double[] doubleArray5 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess6 = new org.apache.commons.math3.optim.InitialGuess(doubleArray5);
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray5);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, Double.POSITIVE_INFINITY, 32.0d, 1.5931994782236123d, (double) 1, 100.0d);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math3.optim.SimpleVectorValueChecker simpleVectorValueChecker2 = new org.apache.commons.math3.optim.SimpleVectorValueChecker(0.9999877116507956d, (double) 97);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((-0.7615941559557649d), (double) 0L);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker11 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair15 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair18 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        boolean boolean19 = simpleUnivariateValueChecker11.converged(0, univariatePointValuePair15, univariatePointValuePair18);
        boolean boolean20 = simpleUnivariateValueChecker3.converged(1, univariatePointValuePair7, univariatePointValuePair15);
        double double21 = simpleUnivariateValueChecker3.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math3.optim.MaxIter maxIter1 = new org.apache.commons.math3.optim.MaxIter((int) (short) 10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        double[] doubleArray6 = pointValuePair5.getPointRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix8.walkInRowOrder(realMatrixChangingVisitor9, (int) (short) 10, (int) (byte) 1, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: initial row 10 after final row 1");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian modelFunctionJacobian1 = new org.apache.commons.math3.optim.nonlinear.vector.ModelFunctionJacobian(multivariateMatrixFunction0);
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction2 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction3 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.apache.commons.math3.analysis.MultivariateMatrixFunction multivariateMatrixFunction4 = modelFunctionJacobian1.getModelFunctionJacobian();
        org.junit.Assert.assertNull(multivariateMatrixFunction2);
        org.junit.Assert.assertNull(multivariateMatrixFunction3);
        org.junit.Assert.assertNull(multivariateMatrixFunction4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) 2.89663936E8f, 52.0d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        double double26 = eigenDecomposition25.getDeterminant();
        double double28 = eigenDecomposition25.getRealEigenvalue((int) '4');
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, number1, (java.lang.Number) 1.2296210822213825E32d, (java.lang.Number) (byte) -1);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker3 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair7 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((-0.7615941559557649d), (double) 0L);
        org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker simpleUnivariateValueChecker11 = new org.apache.commons.math3.optim.univariate.SimpleUnivariateValueChecker((double) 0L, (double) 0L, 6);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair15 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        org.apache.commons.math3.optim.univariate.UnivariatePointValuePair univariatePointValuePair18 = new org.apache.commons.math3.optim.univariate.UnivariatePointValuePair((double) '4', (double) 52);
        boolean boolean19 = simpleUnivariateValueChecker11.converged(0, univariatePointValuePair15, univariatePointValuePair18);
        boolean boolean20 = simpleUnivariateValueChecker3.converged(1, univariatePointValuePair7, univariatePointValuePair15);
        double double21 = univariatePointValuePair15.getValue();
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 52.0d + "'", double21 == 52.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) 1252352413);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair5 = new org.apache.commons.math3.optim.PointValuePair(doubleArray3, (double) (byte) 1);
        double[] doubleArray6 = pointValuePair5.getPointRef();
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma7 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        double[] doubleArray9 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess10 = new org.apache.commons.math3.optim.InitialGuess(doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix11.createMatrix((int) '4', 10);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = array2DRowRealMatrix8.subtract(array2DRowRealMatrix11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix2.createMatrix((int) '4', 10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor6, 1079574528, 0, (int) (short) 100, 1252352413);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,079,574,528)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex3 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex((int) (byte) 100, 1.5440680443502757d, (double) 'a');
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker1 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer6 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer((double) (byte) 10, pointVectorValuePairConvergenceChecker1, 0.0d, (double) (short) 100, (double) 1.0f, (double) (short) 10);
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker7 = levenbergMarquardtOptimizer6.getConvergenceChecker();
        java.lang.Double[] doubleArray14 = new java.lang.Double[] { 10.0d, (-0.5063656411097588d), (-0.5063656411097588d), 10.0d, (-1.0d), 1.0d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, 1, 0);
        double[] doubleArray18 = arrayRealVector17.getDataRef();
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18, (int) (short) 0, 0);
        try {
            double[] doubleArray24 = levenbergMarquardtOptimizer6.computeSigma(doubleArray18, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(pointVectorValuePairConvergenceChecker7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointVectorValuePair> pointVectorValuePairConvergenceChecker0 = null;
        org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer1 = new org.apache.commons.math3.optim.nonlinear.vector.jacobian.LevenbergMarquardtOptimizer(pointVectorValuePairConvergenceChecker0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 50);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.0d + "'", double1 == 50.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition24 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23);
        org.apache.commons.math3.linear.LUDecomposition lUDecomposition26 = new org.apache.commons.math3.linear.LUDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix23, 0.0d);
        double[] doubleArray27 = diagonalMatrix23.getDataRef();
        double[] doubleArray28 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess29 = new org.apache.commons.math3.optim.InitialGuess(doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) 'a');
        double[] doubleArray32 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess33 = new org.apache.commons.math3.optim.InitialGuess(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair37 = new org.apache.commons.math3.optim.PointValuePair(doubleArray35, (double) (byte) 1);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray31, doubleArray35);
        double[] doubleArray39 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess40 = new org.apache.commons.math3.optim.InitialGuess(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) 'a');
        double[] doubleArray43 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess44 = new org.apache.commons.math3.optim.InitialGuess(doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray43, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair48 = new org.apache.commons.math3.optim.PointValuePair(doubleArray46, (double) (byte) 1);
        boolean boolean49 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray42, doubleArray46);
        double double50 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray31, doubleArray46);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix51 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray31);
        double[] doubleArray54 = new double[] { (short) 0, (short) 0 };
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma55 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray54);
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray54);
        org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma sigma57 = new org.apache.commons.math3.optim.nonlinear.scalar.noderiv.CMAESOptimizer.Sigma(doubleArray54);
        double[] doubleArray58 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess59 = new org.apache.commons.math3.optim.InitialGuess(doubleArray58);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray58, (int) 'a');
        double[] doubleArray62 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess63 = new org.apache.commons.math3.optim.InitialGuess(doubleArray62);
        double[] doubleArray65 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray62, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair67 = new org.apache.commons.math3.optim.PointValuePair(doubleArray65, (double) (byte) 1);
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray61, doubleArray65);
        double[] doubleArray69 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess70 = new org.apache.commons.math3.optim.InitialGuess(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) 'a');
        double[] doubleArray73 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess74 = new org.apache.commons.math3.optim.InitialGuess(doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair78 = new org.apache.commons.math3.optim.PointValuePair(doubleArray76, (double) (byte) 1);
        boolean boolean79 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray76);
        double double80 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray61, doubleArray76);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix81 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray61);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition82 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix81);
        double[] doubleArray83 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess84 = new org.apache.commons.math3.optim.InitialGuess(doubleArray83);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83, (int) 'a');
        double[] doubleArray87 = diagonalMatrix81.preMultiply(doubleArray86);
        double double88 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray54, doubleArray86);
        double[] doubleArray89 = diagonalMatrix51.operate(doubleArray86);
        org.apache.commons.math3.linear.RealMatrix realMatrix90 = diagonalMatrix23.multiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix51);
        double[] doubleArray91 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess92 = new org.apache.commons.math3.optim.InitialGuess(doubleArray91);
        double[] doubleArray93 = initialGuess92.getInitialGuess();
        double[] doubleArray95 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray93, 0);
        try {
            double[] doubleArray96 = diagonalMatrix51.operate(doubleArray95);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(realMatrix90);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray95);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double[] doubleArray0 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess1 = new org.apache.commons.math3.optim.InitialGuess(doubleArray0);
        double[] doubleArray3 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray0, (int) 'a');
        double[] doubleArray4 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess5 = new org.apache.commons.math3.optim.InitialGuess(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray4, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair9 = new org.apache.commons.math3.optim.PointValuePair(doubleArray7, (double) (byte) 1);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray7);
        double[] doubleArray11 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess12 = new org.apache.commons.math3.optim.InitialGuess(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) 'a');
        double[] doubleArray15 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess16 = new org.apache.commons.math3.optim.InitialGuess(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair20 = new org.apache.commons.math3.optim.PointValuePair(doubleArray18, (double) (byte) 1);
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray18);
        double double22 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray3, doubleArray18);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix23 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray3);
        double[][] doubleArray24 = diagonalMatrix23.getData();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a', 0.0d);
        org.apache.commons.math3.linear.RealVector realVector28 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        double[] doubleArray29 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess30 = new org.apache.commons.math3.optim.InitialGuess(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, (int) 'a');
        double[] doubleArray33 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess34 = new org.apache.commons.math3.optim.InitialGuess(doubleArray33);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray33, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair38 = new org.apache.commons.math3.optim.PointValuePair(doubleArray36, (double) (byte) 1);
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray32, doubleArray36);
        double[] doubleArray40 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess41 = new org.apache.commons.math3.optim.InitialGuess(doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) 'a');
        double[] doubleArray44 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess45 = new org.apache.commons.math3.optim.InitialGuess(doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair49 = new org.apache.commons.math3.optim.PointValuePair(doubleArray47, (double) (byte) 1);
        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray43, doubleArray47);
        double double51 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray32, doubleArray47);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix52 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray32);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition53 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition54 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        double[] doubleArray55 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess56 = new org.apache.commons.math3.optim.InitialGuess(doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) 'a');
        double[] doubleArray59 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess60 = new org.apache.commons.math3.optim.InitialGuess(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray59, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair64 = new org.apache.commons.math3.optim.PointValuePair(doubleArray62, (double) (byte) 1);
        boolean boolean65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray58, doubleArray62);
        double[] doubleArray66 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess67 = new org.apache.commons.math3.optim.InitialGuess(doubleArray66);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray66, (int) 'a');
        double[] doubleArray70 = new double[] {};
        org.apache.commons.math3.optim.InitialGuess initialGuess71 = new org.apache.commons.math3.optim.InitialGuess(doubleArray70);
        double[] doubleArray73 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray70, (int) 'a');
        org.apache.commons.math3.optim.PointValuePair pointValuePair75 = new org.apache.commons.math3.optim.PointValuePair(doubleArray73, (double) (byte) 1);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray69, doubleArray73);
        double double77 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray58, doubleArray73);
        org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix78 = new org.apache.commons.math3.linear.DiagonalMatrix(doubleArray58);
        double[][] doubleArray79 = diagonalMatrix78.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix80 = diagonalMatrix52.add((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix78);
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = diagonalMatrix23.preMultiply((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52);
        double[] doubleArray82 = diagonalMatrix52.getDataRef();
        boolean boolean84 = org.apache.commons.math3.linear.MatrixUtils.isSymmetric((org.apache.commons.math3.linear.RealMatrix) diagonalMatrix52, (double) 10.0f);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(realMatrix80);
        org.junit.Assert.assertNotNull(realMatrix81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
    }
}

