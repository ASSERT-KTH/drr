import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double1 = org.apache.commons.math.util.FastMath.rint(52.49761899362675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable throwable9 = null;
        try {
            nonMonotonousSequenceException5.addSuppressed(throwable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        java.lang.Number number1 = null;
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray7 = new double[] { (-36288110L) };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray7);
        double[] doubleArray11 = new double[] { (-36288110L) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray14 = new double[] { (-36288110L) };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass23 = nonMonotonousSequenceException22.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection24, false);
        double[] doubleArray28 = new double[] { (-36288110L) };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray31 = new double[] { (-36288110L) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray31);
        double[] doubleArray40 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) (short) -1);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray43);
        double[] doubleArray46 = new double[] { (-36288110L) };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray49 = new double[] { (-36288110L) };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray49);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int57 = nonMonotonousSequenceException56.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = nonMonotonousSequenceException56.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46, orderDirection58, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection58, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException64 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.896296018268069E13d, number1, (-448071173), orderDirection58, false);
        java.lang.Number number65 = nonMonotonousSequenceException64.getArgument();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1316925998) + "'", int8 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1316925998) + "'", int17 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1316925998) + "'", int29 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.628811271828183E7d + "'", double41 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 3.628811E7d + "'", double44 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1316925998) + "'", int47 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1316925998) + "'", int50 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1316925998) + "'", int52 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 7.896296018268069E13d + "'", number65.equals(7.896296018268069E13d));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 50, 5, orderDirection7, true);
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(number10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7640043648110827d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7012995248445115d + "'", double1 == 0.7012995248445115d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(32, (-1259979967));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.624972813284271d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 264.9914225639356d + "'", double1 == 264.9914225639356d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 889554711222L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 943162.0810984717d + "'", double1 == 943162.0810984717d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7817974362806788d + "'", double1 == 1.7817974362806788d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.149548905166106d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4199944758249483d + "'", double1 == 1.4199944758249483d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.10158570369662134d, 7.211102550927978d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8639043791385335d) + "'", double2 == (-0.8639043791385335d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 18769.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-543645888), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.634728988229636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.634728988229637d + "'", double1 == 4.634728988229637d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 9191955381386663201L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int12 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection13, true);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 1.5707963267948966d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int1 = org.apache.commons.math.util.MathUtils.sign(137);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(4.778516039144078E22d, 0.0d, (-5.4364591E8d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 42.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-75743232), 1316926008);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-2.126564180389231E7d), 2.154434690031884d, (double) 36288113L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.FastMath.atanh(7.046745412134694E21d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 0.0d);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray25);
        double[] doubleArray29 = new double[] { (-36288110L) };
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1316925998) + "'", int30 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.628811E7d + "'", double33 == 3.628811E7d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(137);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 540.4169241059977d + "'", double1 == 540.4169241059977d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 1120L);
        double[] doubleArray6 = new double[] { (-36288110L) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = new double[] { (-36288110L) };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray9);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray14 = new double[] { 10 };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) ' ');
        double[] doubleArray18 = new double[] { (-36288110L) };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 1.5422326689561365d);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        double[] doubleArray25 = new double[] { 10 };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) ' ');
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray22);
        double[] doubleArray32 = new double[] { (-36288110L) };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray35 = new double[] { (-36288110L) };
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray35);
        double[] doubleArray39 = new double[] { (-36288110L) };
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray39);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        double[] doubleArray43 = null;
        double[] doubleArray45 = new double[] { (-36288110L) };
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray48 = new double[] { (-36288110L) };
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray51 = new double[] { (-36288110L) };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray51);
        double[] doubleArray55 = new double[] { (-36288110L) };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray45);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        double[] doubleArray62 = new double[] { (-36288110L) };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray65 = null;
        double[] doubleArray67 = new double[] { (-36288110L) };
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray67);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray67);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray67);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1316925998) + "'", int10 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1316925998) + "'", int19 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 30.457767331043865d + "'", double23 == 30.457767331043865d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.457767331043863d + "'", double29 == 8.457767331043863d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.628811154223267E7d + "'", double30 == 3.628811154223267E7d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1316925998) + "'", int33 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1316925998) + "'", int36 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1316925998) + "'", int40 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1316925998) + "'", int46 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1316925998) + "'", int49 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1316925998) + "'", int52 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1316925998) + "'", int56 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1316925998) + "'", int63 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1316925998) + "'", int64 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1316925998) + "'", int68 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1903521209));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-2758547353515625L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.814573389102363E13d) + "'", double1 == (-4.814573389102363E13d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-543645910L), 2.154434690031884d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.5707963267948244d, (-1182143360));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9733344454997704E-270d + "'", double2 == 2.9733344454997704E-270d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-36288110L) };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.5422326689561365d);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray11 = new double[] { (-36288110L) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray11);
        double[] doubleArray20 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (byte) 0);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray28 = new double[] { (-36288110L) };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray28);
        double[] doubleArray32 = new double[] { (-36288110L) };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray20);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray20);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1316925998) + "'", int4 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.628811271828183E7d + "'", double21 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1316925998) + "'", int29 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1316925998) + "'", int33 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.628811E7d + "'", double35 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        float float2 = org.apache.commons.math.util.FastMath.max(51.0f, (float) 18769L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18769.0f + "'", float2 == 18769.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.6239715800000026E9d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.62397158E9d + "'", double2 == 1.62397158E9d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.FastMath.acosh(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-10L), (-1903521261));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.029552803973744E160d) + "'", double2 == (-7.029552803973744E160d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(4.0d, 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 54.26548245743669d + "'", double2 == 54.26548245743669d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-1.648922900715552E-8d), 1182143360);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.711169507123836E261d) + "'", double2 == (-8.711169507123836E261d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.3999999999999995d, 137);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.181389724724491E41d + "'", double2 == 4.181389724724491E41d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-54364591), (float) (-392210912));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.92210912E8f) + "'", float2 == (-3.92210912E8f));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628810L, (java.lang.Number) 10L, 0, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, (java.lang.Number) 1.0d, 0, orderDirection6, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = new double[] { 10 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) ' ');
        double[] doubleArray13 = new double[] { (-36288110L) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 1.5422326689561365d);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double[] doubleArray20 = new double[] { 10 };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) ' ');
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray20);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray17);
        double[] doubleArray27 = new double[] { (-36288110L) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray30 = new double[] { (-36288110L) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray30);
        double[] doubleArray34 = new double[] { (-36288110L) };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray34);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34);
        double[] doubleArray38 = null;
        double[] doubleArray40 = new double[] { (-36288110L) };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray43 = new double[] { (-36288110L) };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray46 = new double[] { (-36288110L) };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray46);
        double[] doubleArray50 = new double[] { (-36288110L) };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray50);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray50);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray40);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray40);
        double[] doubleArray57 = new double[] { (-36288110L) };
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray60 = null;
        double[] doubleArray62 = new double[] { (-36288110L) };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray62);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray62);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray62);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray62);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        java.lang.Number number72 = nonMonotonousSequenceException71.getArgument();
        int int73 = nonMonotonousSequenceException71.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = nonMonotonousSequenceException71.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62, orderDirection74, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1316925998) + "'", int14 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 30.457767331043865d + "'", double18 == 30.457767331043865d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.457767331043863d + "'", double24 == 8.457767331043863d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.628811154223267E7d + "'", double25 == 3.628811154223267E7d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1316925998) + "'", int28 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1316925998) + "'", int31 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1316925998) + "'", int35 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1316925998) + "'", int41 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1316925998) + "'", int44 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1316925998) + "'", int47 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1316925998) + "'", int51 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1316925998) + "'", int58 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1316925998) + "'", int59 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1316925998) + "'", int63 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 1.0f + "'", number72.equals(1.0f));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-549367016), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 549367016 + "'", int2 == 549367016);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 50L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9318256327243257d + "'", double1 == 3.9318256327243257d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 36.0f, 1.1555561473249476d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1555561473249476d + "'", double2 == 1.1555561473249476d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) 1120L);
        double[] doubleArray6 = new double[] { (-36288110L) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = new double[] { (-36288110L) };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray9);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray14 = new double[] { 10 };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) ' ');
        double[] doubleArray18 = new double[] { (-36288110L) };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 1.5422326689561365d);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        double[] doubleArray25 = new double[] { 10 };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) ' ');
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray22);
        double[] doubleArray32 = new double[] { (-36288110L) };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray35 = new double[] { (-36288110L) };
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray35);
        double[] doubleArray39 = new double[] { (-36288110L) };
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray39);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
        double[] doubleArray43 = null;
        double[] doubleArray45 = new double[] { (-36288110L) };
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray48 = new double[] { (-36288110L) };
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray51 = new double[] { (-36288110L) };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray51);
        double[] doubleArray55 = new double[] { (-36288110L) };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray45);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray45);
        double[] doubleArray62 = new double[] { (-36288110L) };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray65 = null;
        double[] doubleArray67 = new double[] { (-36288110L) };
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray67);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray67);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray67);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray6);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException77 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (int) (short) 0);
        java.lang.Throwable[] throwableArray78 = nonMonotonousSequenceException77.getSuppressed();
        java.lang.Number number79 = nonMonotonousSequenceException77.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = nonMonotonousSequenceException77.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection81 = nonMonotonousSequenceException77.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection81, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1316925998) + "'", int10 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1316925998) + "'", int19 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 30.457767331043865d + "'", double23 == 30.457767331043865d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 10.0d + "'", double28 == 10.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 8.457767331043863d + "'", double29 == 8.457767331043863d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.628811154223267E7d + "'", double30 == 3.628811154223267E7d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1316925998) + "'", int33 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1316925998) + "'", int36 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1316925998) + "'", int40 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1316925998) + "'", int46 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1316925998) + "'", int49 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1316925998) + "'", int52 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1316925998) + "'", int56 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1316925998) + "'", int63 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1316925998) + "'", int64 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1316925998) + "'", int68 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 10.0d + "'", number79.equals(10.0d));
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection81 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection81.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.505149978319906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5048292063421678d + "'", double1 == 3.5048292063421678d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.7853981633974482d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.105427357601003E-15d, (double) (-2525687434369141219L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        long long1 = org.apache.commons.math.util.FastMath.round(1.2458971430711452E19d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 10 };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) ' ');
        double[] doubleArray6 = new double[] { (-36288110L) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = new double[] { (-36288110L) };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray9);
        double[] doubleArray18 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray18);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) (byte) 0);
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray21);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { (-36288110L) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray27);
        double[] doubleArray31 = new double[] { (-36288110L) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray31);
        double[] doubleArray34 = new double[] {};
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray34);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray24);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 9.332621544395286E157d);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1316925998) + "'", int10 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.628811271828183E7d + "'", double19 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1316925998) + "'", int28 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-10.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.FastMath.expm1(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(500000000000L, (long) 42);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 499999999958L + "'", long2 == 499999999958L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-543645888));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-2.52568734E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1.90352128E9f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(123.44001497540268d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 126402.57533481234d + "'", double2 == 126402.57533481234d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double1 = org.apache.commons.math.util.FastMath.exp(20.796610300773246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0761011510000002E9d + "'", double1 == 1.0761011510000002E9d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(41, 549367016);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(35.0d, 123.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1182143360), (-1316925998));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 134782638 + "'", int2 == 134782638);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 3.628812E7f, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.628812E7d + "'", double2 == 3.628812E7d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double double1 = org.apache.commons.math.util.FastMath.atan(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.568047112528285d + "'", double1 == 1.568047112528285d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        int int2 = org.apache.commons.math.util.FastMath.min(535367281, (-1235562761));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1235562761) + "'", int2 == (-1235562761));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 1182143360);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 537673695, (long) (-1869044465));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1331370770L) + "'", long2 == (-1331370770L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1869044465));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 3.92210912E8f, (double) 54364589L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9001336360447174d + "'", double2 == 0.9001336360447174d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.7421541968137826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2882713316228034d + "'", double1 == 1.2882713316228034d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-10), 54364556);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-543645560) + "'", int2 == (-543645560));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 499999999958L, (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (int) (short) 0);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger10, (java.lang.Number) 0.41073645028673067d, (-1100362503), orderDirection18, false);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-101L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 0.0d);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1316925998) + "'", int18 == (-1316925998));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-581316669), 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 53);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 537673695);
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (-2758547353515624L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7330382858376184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7480182249660278d + "'", double1 == 0.7480182249660278d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 13L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger3, (java.lang.Number) 50, 5, orderDirection8, true);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 1);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 117.77188139974507d, (java.lang.Number) bigInteger13, 36288113);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger21, (java.lang.Number) 50, 5, orderDirection26, true);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (short) 1);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger31);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger37, (java.lang.Number) 50, 5, orderDirection42, true);
        java.math.BigInteger bigInteger45 = null;
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 0L);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (int) (short) 1);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger47);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 42);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger52);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger53);
        java.lang.Class<?> wildcardClass55 = bigInteger53.getClass();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(wildcardClass55);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        long long1 = org.apache.commons.math.util.FastMath.abs(1192192432L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1192192432L + "'", long1 == 1192192432L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1120, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0440315826549555E18d + "'", double2 == 5.0440315826549555E18d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '#', 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 700 + "'", int2 == 700);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        java.lang.Class<?> wildcardClass15 = doubleArray13.getClass();
        double[] doubleArray17 = new double[] { (-36288110L) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray20 = new double[] { (-36288110L) };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray20);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int28 = nonMonotonousSequenceException27.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection29, true);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1316925998) + "'", int18 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1316925998) + "'", int21 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1869044465));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (byte) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 1120);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1316925999L, 42.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 42.0f + "'", float2 == 42.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 3.3452526613163927E49d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 137L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.575121374985726E59d + "'", double1 == 1.575121374985726E59d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(31.79444869601266d, (int) 'a', 54364556);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.192092895507818E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000000000000007d + "'", double1 == 1.000000000000007d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 54364556);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.4364556E7f + "'", float1 == 5.4364556E7f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5.745303344399952d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1932407958) + "'", int1 == (-1932407958));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.1736481776669303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17277680358713735d) + "'", double1 == (-0.17277680358713735d));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(117.77188139974507d, (double) 41.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-36288164L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 53);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 537673695);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 1);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) (short) 1);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) ' ');
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 42);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (byte) 100, 535367281, (-1182143360));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray12 = new double[] { (-36288110L) };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray12);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (-57.29577951308232d));
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1316925998) + "'", int13 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-54364591), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-54364591) + "'", int2 == (-54364591));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        int int2 = org.apache.commons.math.util.FastMath.max((-1316925952), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.5053085831756794d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1182143360, (double) 700);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1821433599999998E9d + "'", double2 == 1.1821433599999998E9d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        double double1 = org.apache.commons.math.util.FastMath.sin(10.742378968025232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9681169420246947d) + "'", double1 == (-0.9681169420246947d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.823823792371784d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1528444521, 0.3097029445424562d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628810L, (java.lang.Number) 10L, 0, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.8575532158463934d, 42, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (-1316925998), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(18769, 134782638);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 1.5422326689561365d);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray9);
        double[] doubleArray12 = new double[] { 10 };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) ' ');
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray12);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 30.457767331043865d + "'", double10 == 30.457767331043865d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 8.457767331043863d + "'", double16 == 8.457767331043863d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.2421640531326297E-9d, 137.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray7 = new double[] { (-36288110L) };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray7);
        double[] doubleArray11 = new double[] { (-36288110L) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray14 = new double[] { (-36288110L) };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass23 = nonMonotonousSequenceException22.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection24, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.POSITIVE_INFINITY, (java.lang.Number) 1.5511187532874088E66d, 1182143360, orderDirection24, true);
        java.lang.Number number29 = nonMonotonousSequenceException28.getArgument();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1316925998) + "'", int8 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1316925998) + "'", int17 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + Double.POSITIVE_INFINITY + "'", number29.equals(Double.POSITIVE_INFINITY));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.628811271828183E7d, 0.9999999835107711d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.628810230257819E7d + "'", double2 == 3.628810230257819E7d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.26548245743668986d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1316926050, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1316926050 + "'", int2 == 1316926050);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double1 = org.apache.commons.math.util.FastMath.cosh(53.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.206879716514581E22d + "'", double1 == 5.206879716514581E22d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1903521261));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray8);
        double[] doubleArray17 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (byte) 0);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        double[] doubleArray23 = new double[] { (-36288110L) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray26 = new double[] { (-36288110L) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray26);
        double[] doubleArray30 = new double[] { (-36288110L) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray30);
        double[] doubleArray33 = new double[] {};
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray23);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 9.332621544395286E157d);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.628811271828183E7d + "'", double18 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1316925998) + "'", int24 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1316925998) + "'", int27 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1316925998) + "'", int31 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1316925998) + "'", int40 == (-1316925998));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 535367281);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray8);
        double[] doubleArray17 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (byte) 0);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection22, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.628811271828183E7d + "'", double18 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1316925998));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 943162.0810984717d, 0.917047545405684d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray12 = new double[] { (-36288110L) };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray12);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 117.77188139974507d);
        double[] doubleArray18 = new double[] { (-36288110L) };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray21);
        double[] doubleArray30 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) (byte) 0);
        double[] doubleArray35 = new double[] { (-36288110L) };
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray38 = new double[] { (-36288110L) };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray38);
        double[] doubleArray42 = new double[] { (-36288110L) };
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray35);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 0.917047545405684d);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1316925998) + "'", int13 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1316925998) + "'", int19 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 3.628811271828183E7d + "'", double31 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1316925998) + "'", int36 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1316925998) + "'", int39 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1316925998) + "'", int43 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 3.628811E7d + "'", double45 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1100362503));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.100362503E9d) + "'", double1 == (-1.100362503E9d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 137);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (byte) 10);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1316925999L, 1316925999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2633851998L + "'", long2 == 2633851998L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 2756, (int) (byte) 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 5L, 0, orderDirection9, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-10.0d), number1, 0, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        int int1 = org.apache.commons.math.util.FastMath.round(3.92210912E8f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 392210912 + "'", int1 == 392210912);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, number1, 581316670);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1259979967), (-543645560));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-549367016));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9866275920404841d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double1 = org.apache.commons.math.util.MathUtils.sign(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double double1 = org.apache.commons.math.util.FastMath.log(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (int) (short) 0);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35.0f, (java.lang.Number) (-572.9577951308232d), (-392210900), orderDirection9, false);
        boolean boolean12 = nonMonotonousSequenceException11.getStrict();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10.0d + "'", number8.equals(10.0d));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) -1, (-1100362503));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double1 = org.apache.commons.math.util.FastMath.ulp(74.20321057778875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(36288113L, (long) 102);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36288215L + "'", long2 == 36288215L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1331370770L), 3628800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 483127825017600L + "'", long2 == 483127825017600L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1316925998), 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3950777994L + "'", long2 == 3950777994L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 0, 1.505149978319906d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = new double[] { 10 };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) ' ');
        double[] doubleArray13 = new double[] { (-36288110L) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 1.5422326689561365d);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        double[] doubleArray20 = new double[] { 10 };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) ' ');
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double24 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray20);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray17);
        java.lang.Class<?> wildcardClass26 = doubleArray1.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1316925998) + "'", int14 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 30.457767331043865d + "'", double18 == 30.457767331043865d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 10.0d + "'", double23 == 10.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.457767331043863d + "'", double24 == 8.457767331043863d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.628811154223267E7d + "'", double25 == 3.628811154223267E7d);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1316926008, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1316926040 + "'", int2 == 1316926040);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.3452526613163927E49d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int int1 = org.apache.commons.math.util.MathUtils.sign(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-980072951), Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 97L, 51, 52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        int int2 = org.apache.commons.math.util.FastMath.min(137, 137);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 137 + "'", int2 == 137);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 51L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.0d + "'", double1 == 51.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 53, 20.796610300773246d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1968684363059843d + "'", double2 == 1.1968684363059843d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.584967478670572d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 0.0d);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray22);
        double[] doubleArray26 = new double[] { (-36288110L) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray29 = new double[] { (-36288110L) };
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray26);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass38 = nonMonotonousSequenceException37.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection39 = nonMonotonousSequenceException37.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection39, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection39, false);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1316925998) + "'", int27 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1316925998) + "'", int30 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + orderDirection39 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection39.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1316925998) + "'", int44 == (-1316925998));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1235562761));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(42, 392210912);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 42.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.00000000000001d + "'", double1 == 42.00000000000001d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-980072951));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, 1316926040);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1074790400 + "'", int1 == 1074790400);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(18769, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-1.3284353259397996E-6d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.02037802257932855d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27314128383291475d) + "'", double1 == (-0.27314128383291475d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        double double2 = org.apache.commons.math.util.FastMath.pow(5729.5779513082325d, 4.0210218095903336E45d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly decreasing (0 <= 10)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly decreasing (0 <= 10)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 10 + "'", number9.equals((short) 10));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double1 = org.apache.commons.math.util.FastMath.log10(41.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6127838567197355d + "'", double1 == 1.6127838567197355d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4788236111538746d + "'", double1 == 0.4788236111538746d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        long long1 = org.apache.commons.math.util.FastMath.round(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(21.901287759092718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.679881169334615d + "'", double1 == 4.679881169334615d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 50, 5, orderDirection7, true);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 1);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 18769);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.7817974362806788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.031098231866691712d + "'", double1 == 0.031098231866691712d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1444554559021708921L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.159733949250207d + "'", double1 == 18.159733949250207d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.316930997614366E9d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.5603300648936855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 47.80228759098004d + "'", double1 == 47.80228759098004d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double1 = org.apache.commons.math.util.FastMath.log10(7.203601339639328E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.142450329831618d) + "'", double1 == (-7.142450329831618d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-1259979967), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.259979967E9d) + "'", double2 == (-1.259979967E9d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-18L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-18) + "'", int1 == (-18));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-581316669), (-1095479173));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray11 = new double[] {};
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray11);
        double[] doubleArray15 = new double[] { 10 };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) ' ');
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 1.5422326689561365d);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray17);
        double[] doubleArray27 = new double[] { 10 };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) ' ');
        double[] doubleArray31 = new double[] { (-36288110L) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray34 = new double[] { (-36288110L) };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray34);
        double[] doubleArray43 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (byte) 0);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray46);
        double[] doubleArray49 = new double[] { (-36288110L) };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double[] doubleArray52 = new double[] { (-36288110L) };
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray52);
        double[] doubleArray56 = new double[] { (-36288110L) };
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray56);
        double[] doubleArray59 = new double[] {};
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray59);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray49);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1316925998) + "'", int21 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 30.457767331043865d + "'", double24 == 30.457767331043865d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 3.6288142E7d + "'", double25 == 3.6288142E7d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1316925998) + "'", int35 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 3.628811271828183E7d + "'", double44 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.0d + "'", double47 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1316925998) + "'", int50 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1316925998) + "'", int53 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1316925998) + "'", int57 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 3.628812E7d + "'", double64 == 3.628812E7d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 0, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1316925871);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963260355524d + "'", double1 == 1.5707963260355524d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-392210900));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray22);
        double[] doubleArray31 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (byte) 0);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray31);
        double[] doubleArray38 = new double[] { (-36288110L) };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 1.5422326689561365d);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray42);
        double[] doubleArray46 = new double[] { (-36288110L) };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray49 = new double[] { (-36288110L) };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray49);
        double[] doubleArray58 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        try {
            double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.628811271828183E7d + "'", double32 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-392210900) + "'", int35 == (-392210900));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.3205548258598745E9d + "'", double36 == 1.3205548258598745E9d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1316925998) + "'", int39 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1316925998) + "'", int40 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 373782665 + "'", int43 == 373782665);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1316925998) + "'", int47 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1316925998) + "'", int50 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 3.628811271828183E7d + "'", double59 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.628811E7d + "'", double60 == 3.628811E7d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean10 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number11 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0L + "'", number11.equals(0L));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 36.0f + "'", number5.equals(36.0f));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger3, (java.lang.Number) 50, 5, orderDirection8, true);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 1);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 117.77188139974507d, (java.lang.Number) bigInteger13, 36288113);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger21, (java.lang.Number) 50, 5, orderDirection26, true);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (short) 1);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger31);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException44 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger37, (java.lang.Number) 50, 5, orderDirection42, true);
        java.math.BigInteger bigInteger45 = null;
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 0L);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (int) (short) 1);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger47);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 42);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger52);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger53);
        try {
            java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (-610875763L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(8309);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.7615941559557649d), 1.5574077211246418d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5574077211246418d + "'", double2 == 1.5574077211246418d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-543645560));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.436455599999999E8d) + "'", double1 == (-5.436455599999999E8d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.718281828459045d, (-1057.3612456853957d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (short) -1);
        double[] doubleArray17 = null;
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.3328089960826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) ' ');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9191955381386663201L);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger17, (java.lang.Number) 50, 5, orderDirection22, true);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 1);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger27);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 42);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger17);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (int) (short) 1);
        java.math.BigInteger bigInteger39 = null;
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 0L);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (int) (short) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger43);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (int) ' ');
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 0L);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger49, (java.lang.Number) 50, 5, orderDirection54, true);
        java.math.BigInteger bigInteger57 = null;
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, 0L);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, (int) (short) 1);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, bigInteger59);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 0L);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection70 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger65, (java.lang.Number) 50, 5, orderDirection70, true);
        java.math.BigInteger bigInteger73 = null;
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger73, 0L);
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, (int) (short) 1);
        java.math.BigInteger bigInteger78 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, bigInteger75);
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, 42);
        java.math.BigInteger bigInteger81 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, bigInteger80);
        java.math.BigInteger bigInteger82 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger49);
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger82);
        java.math.BigInteger bigInteger85 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 1120);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertTrue("'" + orderDirection70 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection70.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger78);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger81);
        org.junit.Assert.assertNotNull(bigInteger82);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(bigInteger85);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        int int2 = org.apache.commons.math.util.FastMath.max(5, (-1182143411));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 102, (float) 483127825017600L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.83127818E14f + "'", float2 == 4.83127818E14f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 41.0f, (-3.628811E7d), (double) (-1100362503));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1316925998) + "'", int4 == (-1316925998));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.628811154223267E7d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1037513638 + "'", int1 == 1037513638);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(9.306852817379049d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.30685281737905d + "'", double1 == 9.30685281737905d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1120L, (long) (-1869044465));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 581316670, (java.lang.Number) 0.4273649781234616d, 0, orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        int int2 = org.apache.commons.math.util.MathUtils.pow(54364591, (long) 700);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-137143103) + "'", int2 == (-137143103));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        double[] doubleArray3 = new double[] { (-36288110L) };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray6 = new double[] { (-36288110L) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = new double[] { (-36288110L) };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray9);
        double[] doubleArray13 = new double[] { (-36288110L) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray13);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray13);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) (-36288164L));
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1316925998) + "'", int4 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1316925998) + "'", int10 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1316925998) + "'", int14 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection11, false);
        double[] doubleArray15 = new double[] { (-36288110L) };
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 1120L);
        double[] doubleArray20 = new double[] { (-36288110L) };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray23 = new double[] { (-36288110L) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray23);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray28 = new double[] { 10 };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) ' ');
        double[] doubleArray32 = new double[] { (-36288110L) };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 1.5422326689561365d);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray36);
        double[] doubleArray39 = new double[] { 10 };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) ' ');
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray39);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray36);
        double[] doubleArray46 = new double[] { (-36288110L) };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray49 = new double[] { (-36288110L) };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray49);
        double[] doubleArray53 = new double[] { (-36288110L) };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray53);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
        double[] doubleArray57 = null;
        double[] doubleArray59 = new double[] { (-36288110L) };
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray62 = new double[] { (-36288110L) };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray65 = new double[] { (-36288110L) };
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray65);
        double[] doubleArray69 = new double[] { (-36288110L) };
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray69);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray69);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray59);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray59);
        double[] doubleArray76 = new double[] { (-36288110L) };
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double[] doubleArray79 = null;
        double[] doubleArray81 = new double[] { (-36288110L) };
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray79, doubleArray81);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray81);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray81);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray81);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray20);
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1316925998) + "'", int16 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1316925998) + "'", int21 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1316925998) + "'", int24 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1316925998) + "'", int33 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1316925998) + "'", int34 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 30.457767331043865d + "'", double37 == 30.457767331043865d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 10.0d + "'", double42 == 10.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 8.457767331043863d + "'", double43 == 8.457767331043863d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 3.628811154223267E7d + "'", double44 == 3.628811154223267E7d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1316925998) + "'", int47 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1316925998) + "'", int50 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1316925998) + "'", int54 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1316925998) + "'", int60 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1316925998) + "'", int63 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1316925998) + "'", int66 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1316925998) + "'", int70 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1316925998) + "'", int77 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1316925998) + "'", int78 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1316925998) + "'", int82 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.expm1(7.424674656066977d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1675.8539300086604d + "'", double1 == 1675.8539300086604d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.149548905166106d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        float float1 = org.apache.commons.math.util.MathUtils.sign(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1120, (long) (-1932407958));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2164296912960L) + "'", long2 == (-2164296912960L));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        long long1 = org.apache.commons.math.util.FastMath.abs(53495558235L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 53495558235L + "'", long1 == 53495558235L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray8);
        double[] doubleArray17 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (byte) 0);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        double[] doubleArray23 = new double[] { (-36288110L) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray26 = new double[] { (-36288110L) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray26);
        double[] doubleArray30 = new double[] { (-36288110L) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray30);
        double[] doubleArray33 = new double[] {};
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray23);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (-543645910L));
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) (-980072951));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.628811271828183E7d + "'", double18 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1316925998) + "'", int24 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1316925998) + "'", int27 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1316925998) + "'", int31 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 8268L, (-3.628811E7d), (double) 32L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.5607966601082315d, 4.979113068385778d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.149548905166106d, 0.0d, (double) 1528444521L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double double2 = org.apache.commons.math.util.FastMath.pow(5.65228217112E280d, 6.350809011846739d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03490658503988659d) + "'", double1 == (-0.03490658503988659d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1192192432L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(41, 8309);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8350 + "'", int2 == 8350);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double1 = org.apache.commons.math.util.FastMath.acos((-57.29577951308232d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 549367016, (long) (-54364591));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.481030142506818d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3974733726782866d + "'", double1 == 3.3974733726782866d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 50);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1076101151, 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 373.59658937814817d + "'", double2 == 373.59658937814817d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int11 = nonMonotonousSequenceException10.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException5.getDirection();
        int int14 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(orderDirection13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 32 + "'", int14 == 32);
        org.junit.Assert.assertNull(orderDirection15);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { 52 };
        int[] intArray9 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray9);
        try {
            int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 42 + "'", int10 == 42);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        int int2 = org.apache.commons.math.util.FastMath.max((-1259979967), 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1932407958), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-448071173), 36288113L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16259657357866549L + "'", long2 == 16259657357866549L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1100362503), 20.09846357773239d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.09846357773239d + "'", double2 == 20.09846357773239d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.628810230257819E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6288102E7d + "'", double1 == 3.6288102E7d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 50, 5, orderDirection7, true);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 1);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 42);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0);
        try {
            java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (-543645888));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 36288215L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6288215E7d + "'", double1 == 3.6288215E7d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628810L, (java.lang.Number) 10L, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection9, true);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Number number13 = nonMonotonousSequenceException11.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str15 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection19, true);
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException21.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int27 = nonMonotonousSequenceException26.getIndex();
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException21.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 10 + "'", number13.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (10 <= 3,628,810)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly decreasing (10 <= 3,628,810)"));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(orderDirection29);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-2.126564180389231E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-277.0508571484106d) + "'", double1 == (-277.0508571484106d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.4260624389053682d, (double) 3950777994L, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(54364592, (-2525687434369141167L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 548.317035155212d + "'", double1 == 548.317035155212d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 50, 5, orderDirection7, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection14, true);
        java.lang.Number number17 = nonMonotonousSequenceException16.getPrevious();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        java.lang.Number number19 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0L + "'", number17.equals(0L));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0L + "'", number19.equals(0L));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.FastMath.atanh(123.44001497540268d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-137143103), (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 54364592);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1120 + "'", int1 == 1120);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1, 1316925871);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9923897780966253d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 10 + "'", number8.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 10 + "'", number9.equals((short) 10));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 102L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.931324180688272E43d + "'", double1 == 9.931324180688272E43d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.628812E7d, (-0.5659220343821235d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.2694187474616235E-5d + "'", double2 == 5.2694187474616235E-5d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double1 = org.apache.commons.math.util.FastMath.sin(5.318095963758534d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8220997867805403d) + "'", double1 == (-0.8220997867805403d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5626927764648464d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 2756);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        float float2 = org.apache.commons.math.util.FastMath.max(36.0f, (float) 97L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 36288113L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.asin((-2.4492935982947064E-16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.4492935982947064E-16d) + "'", double1 == (-2.4492935982947064E-16d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray12 = new double[] { (-36288110L) };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray12);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628810L, (java.lang.Number) 10L, 0, orderDirection19, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection19, true);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1316925998) + "'", int13 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double1 = org.apache.commons.math.util.FastMath.floor(128.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 128.0d + "'", double1 == 128.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 50, 36288113L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36288113L + "'", long2 == 36288113L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 537673695);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 537673695 + "'", int2 == 537673695);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray22);
        double[] doubleArray31 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (byte) 0);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray31);
        double[] doubleArray38 = new double[] { (-36288110L) };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray41 = new double[] { (-36288110L) };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray41);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        java.lang.Class<?> wildcardClass45 = doubleArray38.getClass();
        double[] doubleArray47 = new double[] { (-36288110L) };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray50 = new double[] { (-36288110L) };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray50);
        double[] doubleArray59 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray59);
        double[] doubleArray62 = new double[] { 10 };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) ' ');
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray50);
        java.lang.Class<?> wildcardClass67 = doubleArray38.getClass();
        try {
            double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.628811271828183E7d + "'", double32 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-392210900) + "'", int35 == (-392210900));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.3205548258598745E9d + "'", double36 == 1.3205548258598745E9d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1316925998) + "'", int39 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1316925998) + "'", int42 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1316925998) + "'", int44 == (-1316925998));
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1316925998) + "'", int48 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1316925998) + "'", int51 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.628811271828183E7d + "'", double60 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 3.6288142E7d + "'", double65 == 3.6288142E7d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass67);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { 52 };
        int[] intArray9 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int10 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray9);
        int[] intArray13 = new int[] { (-1), 32 };
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray13);
        int[] intArray16 = new int[] { 52 };
        int[] intArray23 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        int[] intArray27 = new int[] { (-1), 32 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray16);
        int[] intArray31 = new int[] { 52 };
        int[] intArray38 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray31);
        int[] intArray42 = new int[] { 52 };
        int[] intArray49 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray49);
        int[] intArray53 = new int[] { (-1), 32 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance(intArray31, intArray53);
        try {
            int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 42 + "'", int10 == 42);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 42 + "'", int24 == 42);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 53 + "'", int28 == 53);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 42 + "'", int39 == 42);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 42 + "'", int50 == 42);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 53 + "'", int54 == 53);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 53.0d + "'", double55 == 53.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 32, (long) (-54364591));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        double double2 = org.apache.commons.math.util.FastMath.min(1.4199944758249483d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4199944758249483d + "'", double2 == 1.4199944758249483d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 18769, (int) 'a', 1182143351);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double1 = org.apache.commons.math.util.FastMath.log(4.823823792371784d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5735669314716323d + "'", double1 == 1.5735669314716323d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray11 = new double[] { (-36288110L) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray11);
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass20 = nonMonotonousSequenceException19.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection21, false);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray28 = new double[] { (-36288110L) };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray28);
        double[] doubleArray37 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (short) -1);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (-1.316925998E9d));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1316925998) + "'", int14 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1316925998) + "'", int29 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.628811271828183E7d + "'", double38 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.628811E7d + "'", double41 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray43);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 13L, (double) 2147483647, (double) 610875763L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(700);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.619275968248924E151d, (java.lang.Number) 9.223372E18f, 1182143361);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 9.223372E18f + "'", number4.equals(9.223372E18f));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int int1 = org.apache.commons.math.util.FastMath.abs(537673695);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 537673695 + "'", int1 == 537673695);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray22);
        double[] doubleArray31 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (byte) 0);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray31);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 26.937873935370604d);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.628811271828183E7d + "'", double32 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-392210900) + "'", int35 == (-392210900));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.3205548258598745E9d + "'", double36 == 1.3205548258598745E9d);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double1 = org.apache.commons.math.util.FastMath.log(1.239168827002623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.21444085406058522d + "'", double1 == 0.21444085406058522d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 1182143351);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1182143351L) + "'", long2 == (-1182143351L));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(134782638);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 102);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.67232872835526d + "'", double1 == 4.67232872835526d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.11738078017840028d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4896273442841823d + "'", double1 == 0.4896273442841823d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1120L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray8);
        double[] doubleArray17 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (byte) 0);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        double[] doubleArray23 = new double[] { (-36288110L) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray26 = new double[] { (-36288110L) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray26);
        double[] doubleArray30 = new double[] { (-36288110L) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray30);
        double[] doubleArray33 = new double[] {};
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray23);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 9.332621544395286E157d);
        double[] doubleArray41 = new double[] { 10 };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) ' ');
        double[] doubleArray45 = new double[] { (-36288110L) };
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray48 = new double[] { (-36288110L) };
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray48);
        double[] doubleArray57 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray57);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) (byte) 0);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray60);
        double[] doubleArray63 = new double[] { (-36288110L) };
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray66 = new double[] { (-36288110L) };
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray66);
        double[] doubleArray70 = new double[] { (-36288110L) };
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray70);
        double[] doubleArray73 = new double[] {};
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray73);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray63);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, 9.332621544395286E157d);
        double double80 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray63);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.628811271828183E7d + "'", double18 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1316925998) + "'", int24 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1316925998) + "'", int27 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1316925998) + "'", int31 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1316925998) + "'", int46 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1316925998) + "'", int49 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 3.628811271828183E7d + "'", double58 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.0d + "'", double61 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1316925998) + "'", int64 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1316925998) + "'", int67 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1316925998) + "'", int71 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 35.0f, (-10.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.62509637083283E-16d + "'", double2 == 3.62509637083283E-16d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 2756, (int) (byte) 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 5L, 0, orderDirection6, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.36787944117144233d + "'", number11.equals(0.36787944117144233d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        int int1 = org.apache.commons.math.util.MathUtils.hash(38.330552040511876d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-952179267) + "'", int1 == (-952179267));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) -1, 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-50) + "'", int2 == (-50));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1903521261), (-1192192432));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        double double1 = org.apache.commons.math.util.FastMath.abs(52.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-5.436455599999999E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8309.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.718241727846044d + "'", double1 == 9.718241727846044d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 20, (long) 41);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        int int1 = org.apache.commons.math.util.FastMath.abs((-18));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double2 = org.apache.commons.math.util.FastMath.max(42.00000000000001d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 42.00000000000001d + "'", double2 == 42.00000000000001d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(20, 535367281);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double1 = org.apache.commons.math.util.FastMath.acosh(548.317035155212d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 139, (long) 1316925998);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5926099723339219209L + "'", long2 == 5926099723339219209L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 53.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.0d + "'", double1 == 53.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1095479173);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.276633315738177E10d + "'", double1 == 6.276633315738177E10d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.979113068385778d, 0.0d, 4.634728988229636d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(52.0d, (double) 1.0f, (double) 373782665);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-581316669));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.81316669E8d + "'", double1 == 5.81316669E8d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-980072951), (-2525687434369141167L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2525687434369141167L) + "'", long2 == (-2525687434369141167L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05232886219155788d + "'", double1 == 0.05232886219155788d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 10 };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) ' ');
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray24);
        double[] doubleArray33 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (byte) 0);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray17);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.628811271828183E7d + "'", double34 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.628812E7d + "'", double38 == 3.628812E7d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 10.0d + "'", double39 == 10.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(137L, (long) 1316926008);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 180418863096L + "'", long2 == 180418863096L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3628800L, (float) 700);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 700.0f + "'", float2 == 700.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        double[] doubleArray12 = null;
        double[] doubleArray14 = new double[] { (-36288110L) };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray17 = new double[] { (-36288110L) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray20 = new double[] { (-36288110L) };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray20);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray24);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray24);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray14);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1316925998) + "'", int18 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1316925998) + "'", int21 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        long long2 = org.apache.commons.math.util.FastMath.min((-36288164L), (long) 134782638);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-36288164L) + "'", long2 == (-36288164L));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-36288110L) };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray5);
        double[] doubleArray9 = new double[] { (-36288110L) };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = new double[] { (-36288110L) };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray12);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass21 = nonMonotonousSequenceException20.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException20.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection22, false);
        double[] doubleArray26 = new double[] { (-36288110L) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray29 = new double[] { (-36288110L) };
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray29);
        double[] doubleArray38 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) (short) -1);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray41);
        double[] doubleArray44 = new double[] { (-36288110L) };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray47 = new double[] { (-36288110L) };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray47);
        double[] doubleArray56 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) (byte) 0);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray56);
        try {
            double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1316925998) + "'", int10 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1316925998) + "'", int13 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1316925998) + "'", int27 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1316925998) + "'", int30 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 3.628811271828183E7d + "'", double39 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 3.628811E7d + "'", double42 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1316925998) + "'", int45 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1316925998) + "'", int48 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 3.628811271828183E7d + "'", double57 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-392210900) + "'", int60 == (-392210900));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.316925997002748E9d + "'", double61 == 1.316925997002748E9d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.713572066704308d, (java.lang.Number) (-6.1087578E8f), (-1259979967));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(535367281, 18769);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 211304.6509480044d + "'", double2 == 211304.6509480044d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double2 = org.apache.commons.math.util.FastMath.pow((-8.711169507123836E261d), (double) 18769L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(102, (-1316925998));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628810L, (java.lang.Number) 10L, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection9, true);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Number number13 = nonMonotonousSequenceException11.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        java.lang.String str16 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 10 + "'", number13.equals((short) 10));
        org.junit.Assert.assertNull(orderDirection15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly decreasing (0 <= 10)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly decreasing (0 <= 10)"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-50), 1182143360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1182143410) + "'", int2 == (-1182143410));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(35, 1074790400);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.3205548258598745E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.538709198146722d + "'", double1 == 0.538709198146722d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(54364592, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54364592 + "'", int2 == 54364592);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger3, (java.lang.Number) 50, 5, orderDirection8, true);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 1);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 18769.0f, (java.lang.Number) bigInteger13, (-392210912));
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 1316926008);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (short) -1);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (2.718 >= -1,316,925,998)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        double[] doubleArray12 = null;
        double[] doubleArray14 = new double[] { (-36288110L) };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray17 = new double[] { (-36288110L) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray20 = new double[] { (-36288110L) };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray20);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray24);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray24);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray14);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray14);
        double[] doubleArray31 = new double[] { (-36288110L) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray34 = null;
        double[] doubleArray36 = new double[] { (-36288110L) };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray36);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray36);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray43 = new double[] { (-36288110L) };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray46 = new double[] { (-36288110L) };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray46);
        double[] doubleArray50 = new double[] { (-36288110L) };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray50);
        double[] doubleArray53 = new double[] {};
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray53);
        try {
            double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray8, doubleArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1316925998) + "'", int18 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1316925998) + "'", int21 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1316925998) + "'", int33 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1316925998) + "'", int37 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.628811E7d + "'", double41 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1316925998) + "'", int44 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1316925998) + "'", int47 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1316925998) + "'", int51 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = null;
        double[] doubleArray6 = new double[] { (-36288110L) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray6);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double[] doubleArray11 = new double[] { (-36288110L) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray14 = new double[] { (-36288110L) };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray14);
        double[] doubleArray18 = new double[] { (-36288110L) };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray21);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass30 = nonMonotonousSequenceException29.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException29.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection31, false);
        double[] doubleArray35 = new double[] { (-36288110L) };
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray38 = new double[] { (-36288110L) };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray38);
        double[] doubleArray47 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) (short) -1);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray50);
        double[] doubleArray53 = new double[] { (-36288110L) };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray56 = new double[] { (-36288110L) };
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray56);
        double[] doubleArray65 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray65);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) (byte) 0);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray65);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1316925998) + "'", int19 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1316925998) + "'", int24 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1316925998) + "'", int36 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1316925998) + "'", int39 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 3.628811271828183E7d + "'", double48 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.628811E7d + "'", double51 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1316925998) + "'", int54 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1316925998) + "'", int57 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 3.628811271828183E7d + "'", double66 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-392210900) + "'", int69 == (-392210900));
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.316925997002748E9d + "'", double70 == 1.316925997002748E9d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0d + "'", number7.equals(1.0d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 582L, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1066939021802304E276d + "'", double2 == 3.1066939021802304E276d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) ' ');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9191955381386663201L);
        java.lang.Class<?> wildcardClass15 = bigInteger14.getClass();
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger18, (java.lang.Number) 50, 5, orderDirection23, true);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (int) (short) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger28);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 42);
        java.lang.Class<?> wildcardClass34 = bigInteger18.getClass();
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger39, (java.lang.Number) 50, 5, orderDirection44, true);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 0L);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (int) (short) 1);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger49);
        java.math.BigInteger bigInteger53 = null;
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, 0L);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger55, (java.lang.Number) 50, 5, orderDirection60, true);
        java.math.BigInteger bigInteger63 = null;
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 0L);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger65, (int) (short) 1);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, bigInteger65);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, 42);
        java.math.BigInteger bigInteger71 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger70);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger70);
        java.math.BigInteger bigInteger73 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger72);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection60.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger71);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger73);
        org.junit.Assert.assertNotNull(bigInteger75);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray7 = new double[] { (-36288110L) };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray7);
        double[] doubleArray11 = new double[] { (-36288110L) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray11);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray11);
        double[] doubleArray16 = new double[] { (-36288110L) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray19);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray19);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { (-36288110L) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray27);
        double[] doubleArray36 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 0.0d);
        double[] doubleArray42 = new double[] { (-36288110L) };
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray45 = new double[] { (-36288110L) };
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray48 = new double[] { (-36288110L) };
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray48);
        double[] doubleArray52 = new double[] { (-36288110L) };
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray52);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray42);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1316925998) + "'", int8 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1316925998) + "'", int17 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1316925998) + "'", int28 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 3.628811271828183E7d + "'", double37 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.628811E7d + "'", double38 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1316925998) + "'", int43 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1316925998) + "'", int46 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1316925998) + "'", int49 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1316925998) + "'", int53 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 3.628811E7d + "'", double56 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 3.628811E7d + "'", double57 == 3.628811E7d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 32.0f, (double) (-1316925952));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 54364591L, (java.lang.Number) 0.0d, 32);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(Double.NaN, (double) Float.NaN, 5.81316669E8d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        double double1 = org.apache.commons.math.util.FastMath.floor((-6.10875763E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.10875764E8d) + "'", double1 == (-6.10875764E8d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(7.046745412134694E21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9671567457086963d, (-21.592207009361697d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9671567457086963d + "'", double2 == 0.9671567457086963d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double[] doubleArray18 = new double[] { (-36288110L) };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray21);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 0.917047545405684d);
        double[] doubleArray33 = new double[] { (-36288110L) };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray36 = new double[] { (-36288110L) };
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray36);
        double[] doubleArray45 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) (short) -1);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1316925998) + "'", int19 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.628811E7d + "'", double28 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1316925998) + "'", int34 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1316925998) + "'", int37 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 3.628811271828183E7d + "'", double46 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.8012342830533612d + "'", double49 == 1.8012342830533612d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        float float2 = org.apache.commons.math.util.MathUtils.round(53.0f, 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double1 = org.apache.commons.math.util.FastMath.expm1(10.742378968025232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 46275.010221279845d + "'", double1 == 46275.010221279845d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        double double1 = org.apache.commons.math.util.FastMath.tanh(9.306852817379049d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999835107711d + "'", double1 == 0.9999999835107711d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        long long2 = org.apache.commons.math.util.FastMath.min(1316926051L, 8309L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8309L + "'", long2 == 8309L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.192092895507818E-7d, 5, (-549367016));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = new double[] { 10 };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) ' ');
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray18);
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray24);
        double[] doubleArray33 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (byte) 0);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray33);
        double[] doubleArray40 = new double[] { (-36288110L) };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray43 = new double[] { (-36288110L) };
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray43);
        double[] doubleArray47 = new double[] { (-36288110L) };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray47);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
        try {
            double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.6288142E7d + "'", double19 == 3.6288142E7d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.628811271828183E7d + "'", double34 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-392210900) + "'", int37 == (-392210900));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.628811271828183E7d + "'", double38 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1316925998) + "'", int41 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1316925998) + "'", int44 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1316925998) + "'", int48 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) 1, (-1869044465));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(46275.010221279845d, 4.5603300648936855d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 53);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (short) 1);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (int) (short) 1);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger16);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) ' ');
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 9191955381386663201L);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger24, (java.lang.Number) 50, 5, orderDirection29, true);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 0L);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (int) (short) 1);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger34);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 42);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger24);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger21);
        try {
            java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (-448071173));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1L), (java.lang.Number) 153.66964095568503d, 1316926050);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1L) + "'", number4.equals((-1L)));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 2756);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.7581226324091722d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3014054446583831d + "'", double1 == 1.3014054446583831d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 18);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9444389791664403d + "'", double1 == 2.9444389791664403d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1192192432), 54364591, 1528444521);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1057.3612456853957d), (double) (-1903521209));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.141592098113321d) + "'", double2 == (-3.141592098113321d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 20.09846357773239d, (java.lang.Number) (byte) -1, (-1192192432));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-10.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999958776927d) + "'", double1 == (-0.9999999958776927d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-10));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(151L, (long) 1182143361);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1182143210L) + "'", long2 == (-1182143210L));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-980072951));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-75743232L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(7.211102550927978d, (double) 5926099723339219209L, (double) 83291670L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 581316670);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.823823792371784d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.823823792371785d + "'", double1 == 4.823823792371785d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1037513638, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 103751363800L + "'", long2 == 103751363800L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        int int1 = org.apache.commons.math.util.FastMath.abs(18769);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18769 + "'", int1 == 18769);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray9 = new double[] { (-36288110L) };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = new double[] { (-36288110L) };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray12);
        double[] doubleArray16 = new double[] { (-36288110L) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray16);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
        double[] doubleArray20 = null;
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray28 = new double[] { (-36288110L) };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray28);
        double[] doubleArray32 = new double[] { (-36288110L) };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray32);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray22);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray22);
        double[] doubleArray39 = new double[] { (-36288110L) };
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray42 = null;
        double[] doubleArray44 = new double[] { (-36288110L) };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray44);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray44);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray44);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1316925998) + "'", int10 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1316925998) + "'", int13 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1316925998) + "'", int17 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1316925998) + "'", int29 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1316925998) + "'", int33 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1316925998) + "'", int40 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1316925998) + "'", int41 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1316925998) + "'", int45 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-610875763));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray12 = new double[] { (-36288110L) };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray12);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (-57.29577951308232d));
        java.lang.Number number17 = null;
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray24);
        double[] doubleArray33 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (byte) 0);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double[] doubleArray39 = new double[] { (-36288110L) };
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray42 = new double[] { (-36288110L) };
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray42);
        double[] doubleArray51 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) (byte) 0);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray51);
        double[] doubleArray58 = new double[] { (-36288110L) };
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray61 = new double[] { (-36288110L) };
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray61);
        double[] doubleArray65 = new double[] { (-36288110L) };
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray65);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65);
        java.lang.Number number70 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, number70, 0, orderDirection72, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65, orderDirection72, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray36, orderDirection72, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException80 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number17, (java.lang.Number) 0.7853981633974483d, (int) (byte) 1, orderDirection72, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1, orderDirection72, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1316925998) + "'", int13 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.628811271828183E7d + "'", double34 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1316925998) + "'", int40 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1316925998) + "'", int43 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.628811271828183E7d + "'", double52 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-392210900) + "'", int55 == (-392210900));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.3205548258598745E9d + "'", double56 == 1.3205548258598745E9d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1316925998) + "'", int59 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1316925998) + "'", int62 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1316925998) + "'", int66 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-7.142450329831618d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.142450329831617d) + "'", double1 == (-7.142450329831617d));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger3, (java.lang.Number) 50, 5, orderDirection8, true);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 1);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger13);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 42);
        java.lang.Class<?> wildcardClass19 = bigInteger3.getClass();
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { (-36288110L) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray27);
        double[] doubleArray31 = new double[] { (-36288110L) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray31);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31);
        double[] doubleArray37 = new double[] { (-36288110L) };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray40 = new double[] { (-36288110L) };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray40);
        double[] doubleArray49 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 0.0d);
        double[] doubleArray55 = new double[] { (-36288110L) };
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double[] doubleArray58 = new double[] { (-36288110L) };
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray55, doubleArray58);
        double[] doubleArray62 = new double[] { (-36288110L) };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray65 = new double[] { (-36288110L) };
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray65);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray55, doubleArray62);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass74 = nonMonotonousSequenceException73.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = nonMonotonousSequenceException73.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62, orderDirection75, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection75, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection75, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException83 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 18769, (java.lang.Number) bigInteger3, 53, orderDirection75, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1316925998) + "'", int28 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1316925998) + "'", int38 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1316925998) + "'", int41 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 3.628811271828183E7d + "'", double50 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 3.628811E7d + "'", double51 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1316925998) + "'", int56 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1316925998) + "'", int59 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1316925998) + "'", int63 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1316925998) + "'", int66 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1316925998) + "'", int68 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }
}

