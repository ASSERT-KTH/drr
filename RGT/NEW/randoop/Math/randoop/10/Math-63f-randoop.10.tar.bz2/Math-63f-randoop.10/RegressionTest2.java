import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double2 = org.apache.commons.math.util.MathUtils.round(23.428064530957435d, 50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 23.428064530957435d + "'", double2 == 23.428064530957435d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 102);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.624972813284271d + "'", double1 == 4.624972813284271d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int2 = org.apache.commons.math.util.FastMath.max(2756, 137);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2756 + "'", int2 == 2756);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 54364591L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1L), 3628800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628800L + "'", long2 == 3628800L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(20.796610300773246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5603300648936855d + "'", double1 == 4.5603300648936855d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-6.1087578E8f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-2.52568734E18f), (java.lang.Number) 5.436459294160986E7d, (int) 'a');
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.11765201552461488d, 0.0d, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.39998531498835127d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1100362503) + "'", int1 == (-1100362503));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1903521261), (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1903521209) + "'", int2 == (-1903521209));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(9.306852817379049d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1034601171403002d + "'", double1 == 2.1034601171403002d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1076101151, (-1182143411));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1120L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1120.0f + "'", float1 == 1120.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 5, (-1182143395L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1528444521);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.628811E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double1 = org.apache.commons.math.util.FastMath.acosh(23138.005121444676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.742378968025232d + "'", double1 == 10.742378968025232d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double1 = org.apache.commons.math.util.FastMath.tan(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 10 + "'", number9.equals((short) 10));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.619275968248924E151d, (java.lang.Number) 9.223372E18f, 1182143361);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.006420707498838454d, 1182143360);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.392024657658111E267d + "'", double2 == 3.392024657658111E267d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 42);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(7.930067261567154E14d, 30.457767331043865d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 53.0f, (java.lang.Number) 153.66964095568503d, (int) (short) -1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection7, true);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException9.getPrevious();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException9.getSuppressed();
        boolean boolean14 = nonMonotonousSequenceException9.getStrict();
        java.lang.Number number15 = nonMonotonousSequenceException9.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException9.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1182143411), (java.lang.Number) 1.3840578361895723E13d, (int) (short) -1);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException21);
        int int23 = nonMonotonousSequenceException9.getIndex();
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0L + "'", number12.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0L + "'", number15.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 32 + "'", int23 == 32);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1057.3612456853957d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-60582.336798468496d) + "'", double1 == (-60582.336798468496d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1218431524L), (long) 1182143360);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-36288164L) + "'", long2 == (-36288164L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1182143361, (float) 83291670L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.3291672E7f + "'", float2 == 8.3291672E7f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        long long2 = org.apache.commons.math.util.MathUtils.pow(8268L, (long) 535367281);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8575532158463934d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3573856176314845d + "'", double1 == 2.3573856176314845d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        long long1 = org.apache.commons.math.util.MathUtils.sign(32L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (-2758547353515624L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 123L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 7124L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.871365005136852d + "'", double1 == 8.871365005136852d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.MathUtils.sign(4.979113068385778d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double double1 = org.apache.commons.math.util.FastMath.cos(81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9923897780966252d + "'", double1 == 0.9923897780966252d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.21744899477579852d), (double) (-1316925998));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.316925998E9d) + "'", double2 == (-1.316925998E9d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        int int1 = org.apache.commons.math.util.FastMath.round(1120.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1120 + "'", int1 == 1120);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.005848633036073d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5881743523808807d + "'", double1 == 1.5881743523808807d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        int[] intArray1 = new int[] { 52 };
        int[] intArray8 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray12 = new int[] { (-1), 32 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray15 = new int[] { 52 };
        int[] intArray22 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int[] intArray26 = new int[] { (-1), 32 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray15);
        int[] intArray30 = new int[] { 52 };
        int[] intArray37 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray41 = new int[] { (-1), 32 };
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray41);
        int[] intArray44 = new int[] { 52 };
        int[] intArray51 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray51);
        int[] intArray55 = new int[] { (-1), 32 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray44);
        int[] intArray59 = new int[] { 52 };
        int[] intArray66 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray59);
        int[] intArray70 = new int[] { 52 };
        int[] intArray77 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray59, intArray77);
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray77);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42 + "'", int23 == 42);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 42 + "'", int38 == 42);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 53 + "'", int42 == 53);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 42 + "'", int52 == 42);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 53 + "'", int56 == 53);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 42 + "'", int67 == 42);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 42 + "'", int78 == 42);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 42 + "'", int79 == 42);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 42 + "'", int80 == 42);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.8448296708124096d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1265320129322687d + "'", double1 == 1.1265320129322687d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.778516039144078E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.628811E7d + "'", double1 == 3.628811E7d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 8309L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8309.0d + "'", double1 == 8309.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.26548245743668986d), (double) 35);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1182143360, 54364591);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-2525687434369141167L), (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2525687434369141219L) + "'", long2 == (-2525687434369141219L));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double2 = org.apache.commons.math.util.MathUtils.log(3720292.779055934d, 0.9950371902099892d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.2884278688159225E-4d) + "'", double2 == (-3.2884278688159225E-4d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, (float) 1316926008);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 139);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        double[] doubleArray13 = new double[] { (-36288110L) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray16 = new double[] { (-36288110L) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray16);
        double[] doubleArray25 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (byte) 0);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray31 = new double[] { (-36288110L) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray34 = new double[] { (-36288110L) };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray34);
        double[] doubleArray43 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) (byte) 0);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray43);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1316925998) + "'", int14 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1316925998) + "'", int17 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 3.628811271828183E7d + "'", double26 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1316925998) + "'", int35 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 3.628811271828183E7d + "'", double44 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-392210900) + "'", int47 == (-392210900));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.3205548258598745E9d + "'", double48 == 1.3205548258598745E9d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 3.628811E7d + "'", double49 == 3.628811E7d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.060570643504345004d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12114128700869001d + "'", double2 == 0.12114128700869001d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1095479173, (-1100362503));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.11711288762622143d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1242463360274868d + "'", double1 == 1.1242463360274868d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, (-1316925998));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger3, (java.lang.Number) 50, 5, orderDirection8, true);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 1);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 117.77188139974507d, (java.lang.Number) bigInteger13, 36288113);
        try {
            java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) (-1182143411));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 41);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2349.1269600363753d + "'", double1 == 2349.1269600363753d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 137, (long) 137);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 18769L + "'", long2 == 18769L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) ' ', (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 41.0f, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 41.0d + "'", double2 == 41.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 83291670L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 151L, 52);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.6045824459415916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.690885240525607d + "'", double1 == 0.690885240525607d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-36288112), 373782665);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(32, 139);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-30.422048691767916d), 1316926050);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2926644703615653E185d) + "'", double2 == (-1.2926644703615653E185d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int[] intArray1 = new int[] { 52 };
        int[] intArray8 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray12 = new int[] { (-1), 32 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray15 = new int[] { 52 };
        int[] intArray22 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int[] intArray26 = new int[] { (-1), 32 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray15);
        int[] intArray30 = new int[] { 52 };
        int[] intArray37 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray30);
        int[] intArray41 = new int[] { 52 };
        int[] intArray48 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray48);
        int[] intArray52 = new int[] { (-1), 32 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray52);
        int[] intArray55 = new int[] { 52 };
        int[] intArray62 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray62);
        int[] intArray66 = new int[] { (-1), 32 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray55);
        int[] intArray70 = new int[] { 52 };
        int[] intArray77 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray70);
        int[] intArray81 = new int[] { 52 };
        int[] intArray88 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray81, intArray88);
        int[] intArray92 = new int[] { (-1), 32 };
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray81, intArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray70, intArray92);
        int int95 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray70);
        java.lang.Class<?> wildcardClass96 = intArray15.getClass();
        int[] intArray97 = null;
        try {
            int int98 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42 + "'", int23 == 42);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 42 + "'", int38 == 42);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 42 + "'", int49 == 42);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 53 + "'", int53 == 53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 42 + "'", int63 == 42);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 53 + "'", int67 == 53);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 42 + "'", int78 == 42);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 42 + "'", int89 == 42);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 53 + "'", int93 == 53);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 53.0d + "'", double94 == 53.0d);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertNotNull(wildcardClass96);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29937.070865949758d + "'", double1 == 29937.070865949758d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-610875763), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-610875763L) + "'", long2 == (-610875763L));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35L, (java.lang.Number) (-54364591), 1316925871);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1903521261), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.90352128E9f) + "'", float2 == (-1.90352128E9f));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        int[] intArray1 = new int[] { 52 };
        int[] intArray8 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray12 = new int[] { (-1), 32 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray15 = new int[] { 52 };
        int[] intArray22 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int[] intArray26 = new int[] { (-1), 32 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray15);
        int[] intArray30 = new int[] { 52 };
        int[] intArray37 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray30);
        int[] intArray41 = new int[] { 52 };
        int[] intArray48 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray48);
        int[] intArray52 = new int[] { (-1), 32 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray52);
        int[] intArray55 = new int[] { 52 };
        int[] intArray62 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray62);
        int[] intArray66 = new int[] { (-1), 32 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray55);
        int[] intArray70 = new int[] { 52 };
        int[] intArray77 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray70);
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray70);
        int[] intArray81 = null;
        try {
            int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42 + "'", int23 == 42);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 42 + "'", int38 == 42);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 42 + "'", int49 == 42);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 53 + "'", int53 == 53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 42 + "'", int63 == 42);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 53 + "'", int67 == 53);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 42 + "'", int78 == 42);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-980072951));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 980072951L + "'", long1 == 980072951L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        long long2 = org.apache.commons.math.util.FastMath.min(7124L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14782604738794858d + "'", double1 == 0.14782604738794858d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 2756, (int) (byte) 0, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 5L, 0, orderDirection6, true);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection15, true);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException17.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int23 = nonMonotonousSequenceException22.getIndex();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException17.getDirection();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5 >= 0.368)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (5 >= 0.368)"));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNull(orderDirection25);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-51816111));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 1, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double1 = org.apache.commons.math.util.FastMath.log10(6.38856140554563d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8054030734992291d + "'", double1 == 0.8054030734992291d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-36288110L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.14782604738794858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14728823957175083d + "'", double1 == 0.14728823957175083d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-33L), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-33L) + "'", long2 == (-33L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray7 = new double[] { (-36288110L) };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray7);
        double[] doubleArray11 = new double[] { (-36288110L) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray14 = new double[] { (-36288110L) };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass23 = nonMonotonousSequenceException22.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection24, false);
        double[] doubleArray28 = new double[] { (-36288110L) };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray31 = new double[] { (-36288110L) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray31);
        double[] doubleArray40 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) (short) -1);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1316925998) + "'", int8 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1316925998) + "'", int17 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1316925998) + "'", int29 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.628811271828183E7d + "'", double41 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 3.628811E7d + "'", double44 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.2676506002282294E32d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.61303542254257d + "'", double1 == 74.61303542254257d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection9, true);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Number number13 = nonMonotonousSequenceException11.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str15 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0L + "'", number12.equals(0L));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 10 + "'", number13.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 1.5422326689561365d);
        double[] doubleArray7 = new double[] { (-36288110L) };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray10 = new double[] { (-36288110L) };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray10);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1316925998) + "'", int8 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1316925998) + "'", int11 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.628811154223267E7d + "'", double13 == 3.628811154223267E7d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 53495558235L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        long long2 = org.apache.commons.math.util.FastMath.min(53495558235L, (long) (-75743232));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-75743232L) + "'", long2 == (-75743232L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(36288113, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36288113 + "'", int2 == 36288113);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 54364591L, 0.14782604738794858d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.914935835708583d + "'", double2 == 13.914935835708583d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5707963267948244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.023227478547491d + "'", double1 == 1.023227478547491d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 139);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double1 = org.apache.commons.math.util.FastMath.cos((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7336545584598283d + "'", double1 == 0.7336545584598283d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9999999989694232d, (double) 54364592);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9455137108826147d + "'", double2 == 0.9455137108826147d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        long long2 = org.apache.commons.math.util.MathUtils.pow(9191955381386663201L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 307529390150365025L + "'", long2 == 307529390150365025L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1, (long) 1316925998);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1316925999L + "'", long2 == 1316925999L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (-1218431524L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 50, 5, orderDirection7, true);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 1);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 42);
        java.math.BigInteger bigInteger18 = null;
        try {
            java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11013.232874703393d, (double) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-54364591), (-1182143360));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.6094379124341003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3999999999999995d + "'", double1 == 2.3999999999999995d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(12.396355954702376d, 1.4260624389053682d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1182143360), (float) 8309L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8309.0f + "'", float2 == 8309.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(42.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4760266448864496d + "'", double1 == 3.4760266448864496d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0000000000000284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557767d + "'", double1 == 0.7615941559557767d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4411627128891868d + "'", double1 == 1.4411627128891868d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-31.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 9191955381386663201L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 50, 10000000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 500000000000L + "'", long2 == 500000000000L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.MathUtils.sign(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double2 = org.apache.commons.math.util.FastMath.max(0.7853981633974483d, (double) 53);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 53.0d + "'", double2 == 53.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        long long1 = org.apache.commons.math.util.FastMath.round(133.66010988568357d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 134L + "'", long1 == 134L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-36288110L) };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray2);
        try {
            double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (short) -1);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (-54364591L));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.2676506002282294E32d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2676506002282294E32d + "'", double1 == 1.2676506002282294E32d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1316925998));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 9191955381386663201L, 0.41073645028673067d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.02037802257932855d) + "'", double2 == (-0.02037802257932855d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.20321057778875d + "'", double1 == 74.20321057778875d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int2 = org.apache.commons.math.util.FastMath.max(53, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        long long2 = org.apache.commons.math.util.FastMath.min(9223372036854775807L, 7475653300L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7475653300L + "'", long2 == 7475653300L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double2 = org.apache.commons.math.util.FastMath.atan2(74.61303542254257d, 0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5596161275567795d + "'", double2 == 1.5596161275567795d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(2, (-1182143411));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger5, (java.lang.Number) 50, 5, orderDirection10, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 43.66827237527655d, (java.lang.Number) (-0.5440211108893698d), 51, orderDirection10, false);
        java.lang.Class<?> wildcardClass15 = orderDirection10.getClass();
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double2 = org.apache.commons.math.util.FastMath.max(2349.1269600363753d, (-3.628811E7d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2349.1269600363753d + "'", double2 == 2349.1269600363753d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 10 };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) ' ');
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray24);
        double[] doubleArray33 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (byte) 0);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray17);
        double[] doubleArray40 = new double[] { 10 };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) ' ');
        double[] doubleArray44 = new double[] { (-36288110L) };
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray47 = new double[] { (-36288110L) };
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray47);
        double[] doubleArray56 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double57 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray56);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) (byte) 0);
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray40, doubleArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.628811271828183E7d + "'", double34 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.628812E7d + "'", double38 == 3.628812E7d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1316925998) + "'", int45 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1316925998) + "'", int48 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 3.628811271828183E7d + "'", double57 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10.0d + "'", double60 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0L, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1316925998), 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1316925998), 54364592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 0.0d);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray25);
        double[] doubleArray29 = new double[] { (-36288110L) };
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray19);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1316925998) + "'", int30 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.628811E7d + "'", double33 == 3.628811E7d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.3124383412727525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.481030142506818d + "'", double1 == 1.481030142506818d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(41, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 41.0d + "'", double2 == 41.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9923897780966252d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9923897780966253d + "'", double1 == 0.9923897780966253d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int int2 = org.apache.commons.math.util.MathUtils.pow(20, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(21.901287759092718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6239715800000026E9d + "'", double1 == 1.6239715800000026E9d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(102, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.41073645028673067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.994057971217675d + "'", double1 == 1.994057971217675d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 35.0f, 0.9671567457086961d, 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.lang.Number number1 = null;
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray7 = new double[] { (-36288110L) };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray7);
        double[] doubleArray11 = new double[] { (-36288110L) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray14 = new double[] { (-36288110L) };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray14);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass23 = nonMonotonousSequenceException22.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection24, false);
        double[] doubleArray28 = new double[] { (-36288110L) };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray31 = new double[] { (-36288110L) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray31);
        double[] doubleArray40 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray40);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) (short) -1);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray43);
        double[] doubleArray46 = new double[] { (-36288110L) };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray49 = new double[] { (-36288110L) };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray49);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int57 = nonMonotonousSequenceException56.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = nonMonotonousSequenceException56.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46, orderDirection58, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection58, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException64 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.896296018268069E13d, number1, (-448071173), orderDirection58, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException68 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5626927764648464d, (java.lang.Number) 0.11765201552461488d, 100);
        java.lang.Number number69 = nonMonotonousSequenceException68.getArgument();
        nonMonotonousSequenceException64.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException68);
        boolean boolean71 = nonMonotonousSequenceException64.getStrict();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1316925998) + "'", int8 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1316925998) + "'", int17 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1316925998) + "'", int29 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 3.628811271828183E7d + "'", double41 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 3.628811E7d + "'", double44 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1316925998) + "'", int47 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1316925998) + "'", int50 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1316925998) + "'", int52 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 1.5626927764648464d + "'", number69.equals(1.5626927764648464d));
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray8);
        double[] doubleArray17 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (byte) 0);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.628811271828183E7d + "'", double18 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1259979967) + "'", int22 == (-1259979967));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.917047545405684d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double2 = org.apache.commons.math.util.FastMath.min(3720292.779055934d, 0.8054030734992291d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8054030734992291d + "'", double2 == 0.8054030734992291d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5422326689561365d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.5707963259489757d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-3.2884278688159225E-4d), 1.550547237255589d, 41);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, (-610875763));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = null;
        double[] doubleArray6 = new double[] { (-36288110L) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray6);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1316925998, 42L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 27655445958L + "'", long2 == 27655445958L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-75743232));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-75743232L) + "'", long1 == (-75743232L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1076101151, (long) 1076101151);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 537673695 + "'", int2 == 537673695);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        int int1 = org.apache.commons.math.util.FastMath.round(32.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1120L, 9.306852817378905d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3912409814000136E28d + "'", double2 == 2.3912409814000136E28d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int int1 = org.apache.commons.math.util.FastMath.abs(41);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 41 + "'", int1 == 41);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2758547353515624L), (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2758547353515625L) + "'", long2 == (-2758547353515625L));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.12114128700869001d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1235562761) + "'", int1 == (-1235562761));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 137);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97L, (java.lang.Number) 2.2250738585072014E-308d, 50);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 49 and 50 are not strictly increasing (0 >= 97)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 49 and 50 are not strictly increasing (0 >= 97)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 49 and 50 are not strictly increasing (0 >= 97)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 49 and 50 are not strictly increasing (0 >= 97)"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1555561473249476d, (double) 8268L, (-0.21744899477579852d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean10 = nonMonotonousSequenceException5.getStrict();
        java.lang.String str11 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly decreasing (0 <= 10)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly decreasing (0 <= 10)"));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 137L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 137.0d + "'", double1 == 137.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.436459294160986E7d, 123.4d, 0.03760197886023983d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.atanh(20.796610300773246d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double[] doubleArray18 = new double[] { (-36288110L) };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray21);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1316925998) + "'", int19 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.628811E7d + "'", double28 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-392210900) + "'", int30 == (-392210900));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.MathUtils.sign(3.3452526613163927E49d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 53495558235L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9283870093054236d) + "'", double1 == (-0.9283870093054236d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5626927764648464d, (java.lang.Number) 0.11765201552461488d, 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.5626927764648464d + "'", number4.equals(1.5626927764648464d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.11765201552461488d + "'", number5.equals(0.11765201552461488d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 1, (-448071173));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22026.465794806718d, (java.lang.Number) (-1.316925998E9d), 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 10000000000L, (double) 373782665, (double) (-75743232));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        long long1 = org.apache.commons.math.util.MathUtils.sign(7475653300L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (byte) 100, (int) (byte) 100, 1316925998);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-448071173), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(12.396355954702376d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2163572266587615d + "'", double1 == 0.2163572266587615d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-581316669));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-549367016) + "'", int1 == (-549367016));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        float float2 = org.apache.commons.math.util.FastMath.max(9.223372E18f, (float) 42L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 42.0f + "'", float2 == 42.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 53.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53.0d + "'", double1 == 53.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.FastMath.log10((-31.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        java.lang.Number number14 = nonMonotonousSequenceException13.getArgument();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException13.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Number number17 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0f + "'", number14.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0L + "'", number17.equals(0L));
        org.junit.Assert.assertNull(orderDirection18);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1L, 0.9671567457086963d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1259979967), 1316925998);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1182143395L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.58374224469896d) + "'", double1 == (-21.58374224469896d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.3284353259397996E-6d), 0.0d, 4.778516039144078E22d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger3, (java.lang.Number) 50, 5, orderDirection8, true);
        double[] doubleArray13 = new double[] { (-36288110L) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray16 = new double[] { (-36288110L) };
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray16);
        double[] doubleArray20 = new double[] { (-36288110L) };
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double[] doubleArray23 = new double[] { (-36288110L) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray23);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray20);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass32 = nonMonotonousSequenceException31.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException31.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection33, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 54364591L, (java.lang.Number) 5, 0, orderDirection33, true);
        boolean boolean38 = nonMonotonousSequenceException37.getStrict();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1316925998) + "'", int14 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1316925998) + "'", int17 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1316925998) + "'", int21 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1316925998) + "'", int24 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray22);
        double[] doubleArray31 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (byte) 0);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray31);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.628811271828183E7d + "'", double32 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-392210900) + "'", int35 == (-392210900));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.3205548258598745E9d + "'", double36 == 1.3205548258598745E9d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-392210900) + "'", int37 == (-392210900));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 102L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.318095963758534d + "'", double1 == 5.318095963758534d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray22);
        double[] doubleArray31 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (byte) 0);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray31);
        double[] doubleArray38 = new double[] { (-36288110L) };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 1.5422326689561365d);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray42);
        java.lang.Class<?> wildcardClass45 = doubleArray42.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.628811271828183E7d + "'", double32 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-392210900) + "'", int35 == (-392210900));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.3205548258598745E9d + "'", double36 == 1.3205548258598745E9d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1316925998) + "'", int39 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1316925998) + "'", int40 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 373782665 + "'", int43 == 373782665);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double1 = org.apache.commons.math.util.FastMath.cos(153.66964095568503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9641966794244571d) + "'", double1 == (-0.9641966794244571d));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9999999989694232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023067353402d + "'", double1 == 0.5403023067353402d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1235562761), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-75743232L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.atanh(633347.051185757d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1182143361);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        long long2 = org.apache.commons.math.util.MathUtils.pow(11L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (short) -1);
        double[] doubleArray17 = null;
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 1.5422326689561365d);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray28 = new double[] { (-36288110L) };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray28);
        double[] doubleArray37 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) (byte) 0);
        double[] doubleArray42 = new double[] { (-36288110L) };
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray45 = new double[] { (-36288110L) };
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray42, doubleArray45);
        double[] doubleArray49 = new double[] { (-36288110L) };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray42, doubleArray49);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray42);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray37);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray37);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1316925998) + "'", int21 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1316925998) + "'", int29 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.628811271828183E7d + "'", double38 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1316925998) + "'", int43 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1316925998) + "'", int46 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1316925998) + "'", int50 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.628811E7d + "'", double52 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.3169309966171105E9d + "'", double56 == 1.3169309966171105E9d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1903521209), 52, 36288113);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.3536728099999994E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.09846357773239d + "'", double1 == 20.09846357773239d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-2758547353515625L), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8170176069297290577L + "'", long2 == 8170176069297290577L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 0.0f, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.552713678800501E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800502E-15d + "'", double1 == 3.552713678800502E-15d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        float float2 = org.apache.commons.math.util.MathUtils.round(102.0f, 1095479173);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-543645910L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.4364589E8f + "'", float1 == 5.4364589E8f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 139, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 10, 1316925998);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 53);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53L + "'", long2 == 53L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 20, (-1218431524L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1218431524L) + "'", long2 == (-1218431524L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 8170176069297290577L, 1.450795069539857d, 0.14782604738794858d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.7853981633974483d), (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7853981633974482d) + "'", double2 == (-0.7853981633974482d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.tanh(153.66964095568503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 8309L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8309 + "'", int1 == 8309);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        int int2 = org.apache.commons.math.util.FastMath.max((-581316669), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math.util.FastMath.tan(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.4492935982947064E-16d) + "'", double1 == (-2.4492935982947064E-16d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-610875763));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628810L, (java.lang.Number) 10L, 0, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.940141468803501d + "'", double1 == 11.940141468803501d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (int) (short) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0L, (-549367016));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 1, 1528444521);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444521 + "'", int2 == 1528444521);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.6288142E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.559764732328286d + "'", double1 == 7.559764732328286d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 8.457767331043863d, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(3.2145754835518945E13d, 10, (-1259979967));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double2 = org.apache.commons.math.util.MathUtils.log(7.0d, (-3.628811E7d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8575532158463934d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2840234699668809d + "'", double1 == 1.2840234699668809d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-6.1087578E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
        java.lang.Number number13 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, number13, 0, orderDirection15, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.628811E7d + "'", double20 == 3.628811E7d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1182143360));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-36288110L) };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        boolean boolean4 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray2);
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(6.38856140554563d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.388561405545629d + "'", double2 == 6.388561405545629d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.3124383412727525d, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0414296452073216E16d + "'", double2 == 1.0414296452073216E16d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-18L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-18L) + "'", long1 == (-18L));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.380515006246586d) + "'", double1 == (-3.380515006246586d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        long long1 = org.apache.commons.math.util.FastMath.round(3.628812E7d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 36288120L + "'", long1 == 36288120L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.3573856176314845d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7062640254801993d + "'", double1 == 0.7062640254801993d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1120, 137);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double1 = org.apache.commons.math.util.FastMath.ulp(7.92060156978698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-101L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-3.380515006246586d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(53.0d, 935.564598636671d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 53.00000000000001d + "'", double2 == 53.00000000000001d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number10 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number11 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 10 + "'", number10.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) 10 + "'", number11.equals((short) 10));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(8170176069297290577L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8170176069297290577L + "'", long2 == 8170176069297290577L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1.90352128E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 8309);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5706759753693134d + "'", double1 == 1.5706759753693134d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 2756, (long) (-980072951));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13L + "'", long2 == 13L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (int) (short) 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.586013452313441E15d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 373782665, 1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.73782665E8d + "'", double2 == 3.73782665E8d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.9923897780966252d, (-2.99822295029797d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.abs(2349.1269600363753d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2349.1269600363753d + "'", double1 == 2349.1269600363753d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.626860407847019d + "'", double1 == 3.626860407847019d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(9.306852817379049d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5506.616482752442d + "'", double1 == 5506.616482752442d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2147483647, (-1182143411));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 537673695, (float) 13L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 13.0f + "'", float2 == 13.0f);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(980072951L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9800729510L + "'", long2 == 9800729510L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 0, (-33L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 10 };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) ' ');
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray24);
        double[] doubleArray33 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (byte) 0);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray17);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.628811271828183E7d + "'", double34 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.628812E7d + "'", double38 == 3.628812E7d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.21744899477579852d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.917047545405684d, number1, 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 500000000000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 26.937873935370604d + "'", double1 == 26.937873935370604d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0414296452073216E16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.9455137108826147d, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 968.2060399437975d + "'", double2 == 968.2060399437975d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1182143360);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, (-581316669));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 581316670 + "'", int2 == 581316670);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 54364592);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        long long1 = org.apache.commons.math.util.FastMath.abs((-610875763L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 610875763L + "'", long1 == 610875763L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 8.329167E7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 7475653300L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int int2 = org.apache.commons.math.util.FastMath.min(1076101151, (-980072951));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-980072951) + "'", int2 == (-980072951));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1, (long) 1316926050);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1316926051L + "'", long2 == 1316926051L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.9641966794244571d), 0.7330382858376184d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.1265320129322687d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0613821238989607d + "'", double1 == 1.0613821238989607d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.823823792371784d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 62.215989487542d + "'", double1 == 62.215989487542d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double1 = org.apache.commons.math.util.FastMath.tan(123.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5179274715856552d + "'", double1 == 0.5179274715856552d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-2758547353515625L), (double) 9800729510L, 3.552713678800502E-15d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray8);
        double[] doubleArray17 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (byte) 0);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        double[] doubleArray23 = new double[] { (-36288110L) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray26 = new double[] { (-36288110L) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray26);
        double[] doubleArray30 = new double[] { (-36288110L) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray30);
        double[] doubleArray33 = new double[] {};
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray33);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray23);
        double[] doubleArray39 = new double[] { (-36288110L) };
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray42 = new double[] { (-36288110L) };
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray42);
        double[] doubleArray46 = new double[] { (-36288110L) };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray46);
        double[] doubleArray50 = new double[] { (-36288110L) };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray50);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 117.77188139974507d);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.628811271828183E7d + "'", double18 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1316925998) + "'", int24 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1316925998) + "'", int27 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1316925998) + "'", int31 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1316925998) + "'", int40 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1316925998) + "'", int43 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1316925998) + "'", int47 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1316925998) + "'", int51 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 3.628812E7d + "'", double55 == 3.628812E7d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 6L, (double) 8.3291672E7f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.203601339639321E-8d + "'", double2 == 7.203601339639321E-8d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1120.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1182143411), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-54364591));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', (-610875763));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(13.596393425240077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.38675536586914d + "'", double1 == 2.38675536586914d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) ' ');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9191955381386663201L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0);
        try {
            java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (-2758547353515625L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        int int2 = org.apache.commons.math.util.FastMath.max(54364592, 8309);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54364592 + "'", int2 == 54364592);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-581316669));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.813166689999999E8d) + "'", double1 == (-5.813166689999999E8d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 537673695);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double1 = org.apache.commons.math.util.FastMath.floor(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-2097151.9999998813d), 12.396355954702376d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.892718677874655d + "'", double2 == 11.892718677874655d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 9.223372E18f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(100, (-10));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray19 = new double[] { (-36288110L) };
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray22 = new double[] { (-36288110L) };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray22);
        double[] doubleArray31 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (byte) 0);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray31);
        java.lang.Class<?> wildcardClass37 = doubleArray31.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1316925998) + "'", int20 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1316925998) + "'", int23 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.628811271828183E7d + "'", double32 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-392210900) + "'", int35 == (-392210900));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.3205548258598745E9d + "'", double36 == 1.3205548258598745E9d);
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6L, (java.lang.Number) 102, 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int7 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.896296018268069E13d, (java.lang.Number) 3.948148009134034E13d, 2756, orderDirection8, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 7.896296018268069E13d + "'", number11.equals(7.896296018268069E13d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 7.896296018268069E13d + "'", number12.equals(7.896296018268069E13d));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 123L, (float) 42);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 42.0f + "'", float2 == 42.0f);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 4.5399929762484854E-5d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray11 = new double[] {};
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray11);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(88.83981263041517d, 4.158638853279167d, 1.9644301815580163d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 42);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.0d + "'", double1 == 42.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-75743232));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2.3573856176314845d, 1.0081267156555943E-20d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.690885240525607d, 0.7336545584598283d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.690885240525607d + "'", double2 == 0.690885240525607d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.192092895507818E-7d + "'", double1 == 1.192092895507818E-7d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 18769L, (float) 83291670L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 18769.0f + "'", float2 == 18769.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(52.49761899362675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.203601339639321E-8d, (java.lang.Number) 5L, 42);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-5.4364592E7f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-378.8250690081161d) + "'", double1 == (-378.8250690081161d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.9455137108826147d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.239168827002623d + "'", double1 == 1.239168827002623d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.3328089960825995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787918142418824d + "'", double1 == 0.36787918142418824d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.619275968248924E151d, (java.lang.Number) 9.223372E18f, 1182143361);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 9.619275968248924E151d + "'", number5.equals(9.619275968248924E151d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 53.0f, (java.lang.Number) 153.66964095568503d, (int) (short) -1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (153.67 >= 53)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (153.67 >= 53)"));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-549367016), (-54364591L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 50L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        int int2 = org.apache.commons.math.util.FastMath.min((-10), 137);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-10) + "'", int2 == (-10));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-392210900));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-392210912) + "'", int1 == (-392210912));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1182143361, 2756);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) ' ');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 9191955381386663201L);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger17, (java.lang.Number) 50, 5, orderDirection22, true);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 1);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger27);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 42);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger17);
        java.math.BigInteger bigInteger34 = null;
        try {
            java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(582L, (long) 1528444521);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 889554711222L + "'", long2 == 889554711222L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(373782665, 1316926050);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int2 = org.apache.commons.math.util.FastMath.min(54364591, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 10, 52);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 18769L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18769 + "'", int1 == 18769);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1903521261));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1528444521);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) '#', 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        long long2 = org.apache.commons.math.util.MathUtils.pow(102L, 18769L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.7640043648110827d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2012470872 + "'", int1 == 2012470872);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double1 = org.apache.commons.math.util.FastMath.sin(100.17495033507774d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3485415033556803d) + "'", double1 == (-0.3485415033556803d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 980072951L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(581316670, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 581316670 + "'", int2 == 581316670);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1095479173, (float) (-10L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-10.0f) + "'", float2 == (-10.0f));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.FastMath.exp(8.329167E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-392210900));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double1 = org.apache.commons.math.util.FastMath.log((-3.628811E7d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int int2 = org.apache.commons.math.util.FastMath.max(1076101151, (-581316669));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101151 + "'", int2 == 1076101151);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int int2 = org.apache.commons.math.util.FastMath.min(50, 54364592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1182143360, 139);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(54364592);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-543645910L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.4364591E8d) + "'", double1 == (-5.4364591E8d));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.4260624389053682d, 1.0771787365603915d, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 13L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.0d + "'", double1 == 13.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 50, 5, orderDirection7, true);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 1);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 42);
        java.lang.Class<?> wildcardClass18 = bigInteger2.getClass();
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger21, (java.lang.Number) 50, 5, orderDirection26, true);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (short) 1);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger31);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 42);
        java.lang.Class<?> wildcardClass37 = bigInteger21.getClass();
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(bigInteger38);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2005.3522829578812d, (-0.21744899477579852d), (double) 36.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.11711288762622143d, (java.lang.Number) (-0.5440211108893698d), (-1259979967));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-448071173), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1316925998));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1316925952) + "'", int1 == (-1316925952));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 0, 1095479173);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1095479173) + "'", int2 == (-1095479173));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double2 = org.apache.commons.math.util.FastMath.pow(41.0d, (double) 980072951L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.624972813284271d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.624972813284272d + "'", double1 == 4.624972813284272d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 81.55795945611504d, (java.lang.Number) 83291670L, (-1100362503));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.FastMath.tan(23.428064530957435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.424674656066977d + "'", double1 == 7.424674656066977d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1192192432));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.592207009361697d) + "'", double1 == (-21.592207009361697d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(9.306852817378902d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        int int11 = nonMonotonousSequenceException10.getIndex();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int7 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.896296018268069E13d, (java.lang.Number) 3.948148009134034E13d, 2756, orderDirection8, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number13 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 7.896296018268069E13d + "'", number11.equals(7.896296018268069E13d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 3.948148009134034E13d + "'", number12.equals(3.948148009134034E13d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 3.948148009134034E13d + "'", number13.equals(3.948148009134034E13d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.1736481776669303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        float float2 = org.apache.commons.math.util.FastMath.max(11.0f, (float) 36288120L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.628812E7f + "'", float2 == 3.628812E7f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        long long1 = org.apache.commons.math.util.FastMath.abs((-10L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 0, 36288113L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 307529390150365025L, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 128.0d + "'", double2 == 128.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1182143361);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(581316670, (-392210912));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.7853981633974482d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.970291913552122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        long long1 = org.apache.commons.math.util.FastMath.round(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.8421709430404007E-14d, 1.0414296452073216E16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.8421709430404014E-14d + "'", double2 == 2.8421709430404014E-14d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8405291802459339d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.3999999999999995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3999999999999995d + "'", double1 == 2.3999999999999995d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 36.0f, 4.624972813284272d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4273649781234616d + "'", double2 == 0.4273649781234616d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (short) 1);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (short) 1);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10L);
        try {
            java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double1 = org.apache.commons.math.util.MathUtils.sign(8.457767331043863d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.0d, 7.896296018268069E13d, (-0.9283870093054236d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double1 = org.apache.commons.math.util.FastMath.floor(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.73937555556364d + "'", double1 == 363.73937555556364d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 581316670);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 54364591, (-448071173));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        int int2 = org.apache.commons.math.util.FastMath.max((-1316925952), 1316926008);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1316926008 + "'", int2 == 1316926008);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-18L), (-10L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 180L + "'", long2 == 180L);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(26.937873935370604d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5000000000050024E11d + "'", double1 == 2.5000000000050024E11d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int11 = nonMonotonousSequenceException10.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1095479173));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray17 = new double[] { 10 };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) ' ');
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray24);
        double[] doubleArray33 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray33);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) (byte) 0);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray17);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 99.78385316640734d);
        java.lang.Class<?> wildcardClass41 = doubleArray40.getClass();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.628811271828183E7d + "'", double34 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 3.628812E7d + "'", double38 == 3.628812E7d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(54364591, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54364556 + "'", int2 == 54364556);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 100, (-10));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 137, 1076101151);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2862202922521847111L) + "'", long2 == (-2862202922521847111L));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.9512437185814275d, (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2458971430711452E19d + "'", double2 == 1.2458971430711452E19d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(286.4788975654116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.592207650508868d + "'", double1 == 6.592207650508868d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        int[] intArray1 = new int[] { 52 };
        int[] intArray8 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray12 = new int[] { (-1), 32 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray15 = new int[] { 52 };
        int[] intArray22 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int[] intArray26 = new int[] { (-1), 32 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray26);
        int[] intArray29 = new int[] { 52 };
        int[] intArray36 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray36);
        int[] intArray40 = new int[] { (-1), 32 };
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray29);
        int[] intArray44 = new int[] { 52 };
        int[] intArray51 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray44);
        int[] intArray55 = new int[] { 52 };
        int[] intArray62 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray44);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42 + "'", int23 == 42);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 42 + "'", int37 == 42);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 53 + "'", int41 == 53);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 42 + "'", int52 == 42);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 42 + "'", int63 == 42);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 42 + "'", int64 == 42);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double double2 = org.apache.commons.math.util.FastMath.min(0.9999999835107711d, 4.005848633036073d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999835107711d + "'", double2 == 0.9999999835107711d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double1 = org.apache.commons.math.util.FastMath.sinh(7.203601339639321E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.203601339639328E-8d + "'", double1 == 7.203601339639328E-8d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 41.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.4031242374328485d + "'", double1 == 6.4031242374328485d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double double1 = org.apache.commons.math.util.FastMath.ceil(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        int int2 = org.apache.commons.math.util.MathUtils.pow(139, (long) 1182143361);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1151197557) + "'", int2 == (-1151197557));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-980072951), (-1192192432));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.917047545405684d, 0.14728823957175083d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.220446049250313E-16d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double[] doubleArray12 = new double[] { (-36288110L) };
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray12);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1316925998) + "'", int13 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        double double1 = org.apache.commons.math.util.FastMath.abs((-21.592207009361697d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.592207009361697d + "'", double1 == 21.592207009361697d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        int int4 = nonMonotonousSequenceException3.getIndex();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 3.141592653589793d + "'", number6.equals(3.141592653589793d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1182143361, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1182143351 + "'", int2 == 1182143351);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1528444521, (long) 1095479173);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1528444521L + "'", long2 == 1528444521L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9671567457086961d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(968.2060399437975d, (double) 134L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-543645910L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-543645888) + "'", int1 == (-543645888));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.2145754835518945E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.00390625d + "'", double1 == 0.00390625d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628810L, (java.lang.Number) 10L, 0, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection9, true);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Number number13 = nonMonotonousSequenceException11.getArgument();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number16 = nonMonotonousSequenceException11.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 10 + "'", number13.equals((short) 10));
        org.junit.Assert.assertNull(orderDirection15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 10 + "'", number16.equals((short) 10));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.3097029445424562d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.30495427331270974d + "'", double1 == 0.30495427331270974d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5706759753693134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.2163572266587615d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0234966681015711d + "'", double1 == 1.0234966681015711d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        long long1 = org.apache.commons.math.util.FastMath.round(5.318095963758534d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(102L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1100362503));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-3.141592626038454d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1869044465) + "'", int1 == (-1869044465));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int int2 = org.apache.commons.math.util.FastMath.max((-1182143360), 1182143361);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1182143361 + "'", int2 == 1182143361);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        int int2 = org.apache.commons.math.util.FastMath.max(1528444521, 2756);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1528444521 + "'", int2 == 1528444521);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1192192432), (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-1.174871113735541d), (double) 2L, (double) 500000000000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-36288110L) };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.5422326689561365d);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray11 = new double[] { (-36288110L) };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray11);
        double[] doubleArray20 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) (byte) 0);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray28 = new double[] { (-36288110L) };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray28);
        double[] doubleArray32 = new double[] { (-36288110L) };
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray25);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray20);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray20);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1316925998) + "'", int4 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1316925998) + "'", int12 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.628811271828183E7d + "'", double21 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1316925998) + "'", int29 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1316925998) + "'", int33 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.628811E7d + "'", double35 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.316930997614366E9d + "'", double39 == 1.316930997614366E9d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0L, (float) 41);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(30.457767331043865d, (double) 0.0f, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException5.getClass();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number12 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0L + "'", number12.equals(0L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 42L, (java.lang.Number) 2.99822295029797d, (-54364591));
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.99822295029797d + "'", number4.equals(2.99822295029797d));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1218431524L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 10 + "'", number8.equals((short) 10));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(537673695, 1095479173);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1182143360), 54364556);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(4.624972813284271d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.004901960784295d + "'", double1 == 51.004901960784295d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.FastMath.sin(2.231796269985182d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.789378754627349d + "'", double1 == 0.789378754627349d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-2758547353515624L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number8 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        java.lang.Class<?> wildcardClass11 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 10 + "'", number8.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 10 + "'", number9.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly decreasing (0 <= 10)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly decreasing (0 <= 10)"));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        long long1 = org.apache.commons.math.util.FastMath.abs(6L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int11 = nonMonotonousSequenceException10.getIndex();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number14 = nonMonotonousSequenceException5.getArgument();
        boolean boolean15 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(orderDirection13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 10 + "'", number14.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        java.lang.Number number14 = nonMonotonousSequenceException13.getArgument();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException13.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException13.getClass();
        java.lang.Number number18 = nonMonotonousSequenceException13.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0f + "'", number14.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 2.718281828459045d + "'", number18.equals(2.718281828459045d));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        float float2 = org.apache.commons.math.util.FastMath.max(Float.NaN, 52.0f);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray1);
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int2 = org.apache.commons.math.util.FastMath.max((-1100362503), (-1100362503));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1100362503) + "'", int2 == (-1100362503));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        java.lang.Class<?> wildcardClass8 = doubleArray1.getClass();
        double[] doubleArray10 = new double[] { (-36288110L) };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray13 = new double[] { (-36288110L) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray13);
        double[] doubleArray17 = new double[] { (-36288110L) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray17);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1316925998) + "'", int11 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1316925998) + "'", int14 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1316925998) + "'", int18 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1316925998) + "'", int21 == (-1316925998));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1192192432));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1192192432L + "'", long1 == 1192192432L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-610875763L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.10875763E8d) + "'", double1 == (-6.10875763E8d));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 83291670L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.3291672E7f + "'", float2 == 8.3291672E7f);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.316925998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }
}

