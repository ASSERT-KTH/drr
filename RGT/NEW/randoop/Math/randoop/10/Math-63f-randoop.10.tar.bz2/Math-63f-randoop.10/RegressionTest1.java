import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.9997860728793259d), 3.141592653589793d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(41, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double2 = org.apache.commons.math.util.MathUtils.round(123.44001497540268d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 123.4400149754d + "'", double2 == 123.4400149754d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long long1 = org.apache.commons.math.util.FastMath.round(0.5350353514628688d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(7.105427357601003E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1076101151, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5626954032401152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        int int2 = org.apache.commons.math.util.FastMath.min(2756, 41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 41 + "'", int2 == 41);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3840578361895723E13d + "'", double1 == 1.3840578361895723E13d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.006420707498838454d + "'", double1 == 0.006420707498838454d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.3097029445424562d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31488060064222984d + "'", double1 == 0.31488060064222984d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 3628810L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628810.0d + "'", double1 == 3628810.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-3628811L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double[] doubleArray4 = new double[] { (-1L), 1.5511187532874088E66d, 22025.465794806718d, 1.505149978319906d };
        double[] doubleArray6 = new double[] { (-36288110L) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = new double[] { (-36288110L) };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray9);
        double[] doubleArray13 = new double[] { (-36288110L) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray13);
        double[] doubleArray17 = new double[] { (-36288110L) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray17);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1316925998) + "'", int10 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1316925998) + "'", int14 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1316925998) + "'", int18 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) ' ', (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1120L + "'", long2 == 1120L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.3383347192042695E42d, 36.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6989700043360189d + "'", double1 == 0.6989700043360189d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 54364591);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 54364591L + "'", long1 == 54364591L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1192192432), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 6L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-3.141592653589793d), 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.808448792630022d) + "'", double2 == (-0.808448792630022d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(36.0f, (-1182143411), 42);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-36288110L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-101L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.560895660206908d) + "'", double1 == (-1.560895660206908d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.220446049250313E-16d, (-1182143411), 53);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.6989700043360189d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8405291802459339d + "'", double1 == 0.8405291802459339d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(97L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1182143360), (long) (-54364591));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        long long1 = org.apache.commons.math.util.FastMath.round(123.4d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 123L + "'", long1 == 123L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4965075614664802d + "'", double1 == 3.4965075614664802d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 53);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        long long1 = org.apache.commons.math.util.FastMath.round(1.505149978319906d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(373782665, 535367281);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        long long1 = org.apache.commons.math.util.FastMath.round(4.778516039144078E22d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1316926050);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) -1, (long) 535367281);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1192192432), (-610875763));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-581316669) + "'", int2 == (-581316669));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.4965075614664802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5436344717724875d + "'", double1 == 0.5436344717724875d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-10.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.99822295029797d) + "'", double1 == (-2.99822295029797d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        int[] intArray1 = new int[] { 52 };
        int[] intArray8 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray12 = new int[] { (-1), 32 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray15 = new int[] { 52 };
        int[] intArray22 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int[] intArray26 = new int[] { (-1), 32 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray15);
        int[] intArray30 = new int[] { 52 };
        int[] intArray37 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray30);
        int[] intArray41 = new int[] { 52 };
        int[] intArray48 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray48);
        int[] intArray52 = new int[] { (-1), 32 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray52);
        int[] intArray55 = new int[] { 52 };
        int[] intArray62 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray62);
        int[] intArray66 = new int[] { (-1), 32 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray55);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray55);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42 + "'", int23 == 42);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 42 + "'", int38 == 42);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 42 + "'", int49 == 42);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 53 + "'", int53 == 53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 42 + "'", int63 == 42);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 53 + "'", int67 == 53);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 1, (double) (-101L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 32L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.5309649148733837d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.5350353514628688d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5350353514628688d + "'", double2 == 0.5350353514628688d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-30.422048691767916d), 1095479173, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-581316669), (-1316925998));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.log10(8.329167E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.92060156978698d + "'", double1 == 7.92060156978698d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.03760197886023983d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0L + "'", number7.equals(0L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1316925998), 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double2 = org.apache.commons.math.util.MathUtils.log(1587.7603709497232d, 1.5626927764648464d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.060570643504345004d + "'", double2 == 0.060570643504345004d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(41.0f, 35, (-1182143411));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.log(4.5399929762484854E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.0d) + "'", double1 == (-10.0d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.5399929762484854E-5d, 42.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = org.apache.commons.math.util.FastMath.min(2756, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 53 + "'", int2 == 53);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        long long1 = org.apache.commons.math.util.FastMath.round(8.329167E7d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 83291670L + "'", long1 == 83291670L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-54364591));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int[] intArray1 = new int[] { 52 };
        int[] intArray8 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray11 = new int[] { 52 };
        int[] intArray18 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray18);
        int[] intArray22 = new int[] { (-1), 32 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray22);
        int[] intArray25 = new int[] { 52 };
        int[] intArray32 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray32);
        int[] intArray36 = new int[] { (-1), 32 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray25);
        int[] intArray40 = new int[] { 52 };
        int[] intArray47 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray40);
        int[] intArray51 = new int[] { 52 };
        int[] intArray58 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray58);
        int[] intArray62 = new int[] { (-1), 32 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray62);
        int[] intArray65 = new int[] { 52 };
        int[] intArray72 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray72);
        int[] intArray76 = new int[] { (-1), 32 };
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray65);
        int[] intArray80 = new int[] { 52 };
        int[] intArray87 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray80, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray80);
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray65);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray25);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 42 + "'", int19 == 42);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 53 + "'", int23 == 53);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 42 + "'", int33 == 42);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 53 + "'", int37 == 53);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 42 + "'", int48 == 42);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 42 + "'", int59 == 42);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 53 + "'", int63 == 53);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 42 + "'", int73 == 42);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 53 + "'", int77 == 53);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 42 + "'", int88 == 42);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.rint(8.329167E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.329167E7d + "'", double1 == 8.329167E7d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-610875763), (long) (-36288112));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1120L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(35, 102);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 137 + "'", int2 == 137);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000284d + "'", double1 == 1.0000000000000284d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.5399929762484854E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999989694232d + "'", double1 == 0.9999999989694232d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(22026.465794806718d, 0.020063413307844603d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 53, 51.0d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-36288110L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5659220343821235d) + "'", double1 == (-0.5659220343821235d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-1.0d), 37.63740485995193d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-1L), (-101L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 54364591);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 54364591 + "'", int2 == 54364591);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1095479173, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 2756, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8268L + "'", long2 == 8268L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 0, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        long long1 = org.apache.commons.math.util.FastMath.round((-18.100147877930027d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-18L) + "'", long1 == (-18L));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-36288112), (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 42, 0, 51);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double[] doubleArray18 = new double[] { (-36288110L) };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray21);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (2.718 >= -1,316,925,998)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1316925998) + "'", int19 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.628811E7d + "'", double28 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 10, 3628800L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.586013452313441E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 41, (double) 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1316925998), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-54364591), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-543645910L) + "'", long2 == (-543645910L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1182143360));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1182143360 + "'", int1 == 1182143360);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 0, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double2 = org.apache.commons.math.util.FastMath.pow(9.306852817378902d, 1.000000000000007d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.306852817379049d + "'", double2 == 9.306852817379049d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.log1p(123.44001497540266d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.823823792371784d + "'", double1 == 4.823823792371784d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        long long1 = org.apache.commons.math.util.FastMath.abs(42L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 42L + "'", long1 == 42L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5430256902014756d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1555561473249476d + "'", double1 == 1.1555561473249476d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1316925998));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1316925998 + "'", int1 == 1316925998);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, number1, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-610875763));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.718281828459045d, (int) (byte) 10, 1528444521);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1120L, (long) (-1182143360));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1076101151);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.796610300773246d + "'", double1 == 20.796610300773246d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-54364591), (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(52, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 23.484542330258197d + "'", double2 == 23.484542330258197d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(8268L, (long) 41);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8309L + "'", long2 == 8309L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.exp(99.78385316640734d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1655928716045763E43d + "'", double1 == 2.1655928716045763E43d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(2L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-33L) + "'", long2 == (-33L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1182143360);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.18214336E9f + "'", float1 == 1.18214336E9f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1L, (long) 50);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50L + "'", long2 == 50L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.log(1.5626954032401152d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.44641215288298425d + "'", double1 == 0.44641215288298425d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-581316669), (int) 'a', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 51.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9318256327243257d + "'", double1 == 3.9318256327243257d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-36288110L) };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray5);
        double[] doubleArray14 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (byte) 0);
        try {
            double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811271828183E7d + "'", double15 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.7421541968137826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.917047545405684d + "'", double1 == 0.917047545405684d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 0L, (double) 83291670L, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 23.484542330258197d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17632698070846498d + "'", double1 == 0.17632698070846498d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1587.7603709497232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.6094379124341003d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(32, (-1182143411));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-581316669));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-3628811L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3628810.9999999995d) + "'", double2 == (-3628810.9999999995d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) 1, (-1182143411), (-54364591));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(37.63740485995193d, (double) 1076101151);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.5436344717724875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 51);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7084297692661896d + "'", double1 == 3.7084297692661896d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double[] doubleArray3 = new double[] { 9191955381386663201L, 1587.7603709497232d, (byte) -1 };
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (9,191,955,381,386,662,900 >= 1,587.76)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 1, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.3097029445424562d, 0.0d, 35.00000000000001d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 51, (int) 'a');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9671567457086961d, 92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9671567457086963d + "'", double2 == 0.9671567457086963d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1736481776669303d) + "'", double1 == (-0.1736481776669303d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        long long1 = org.apache.commons.math.util.MathUtils.sign(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException5.getClass();
        int int11 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 10, (float) (-2525687434369141167L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.52568734E18f) + "'", float2 == (-2.52568734E18f));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9671567457086963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 2758547353515625L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double[] doubleArray3 = new double[] { 3628810.0d, (-18.100147877930027d), 99.78385316640734d };
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(42.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7330382858376184d + "'", double1 == 0.7330382858376184d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-54364591), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-5.4364592E7f) + "'", float2 == (-5.4364592E7f));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.628811E7d + "'", double7 == 3.628811E7d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1316926050, 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1316926008 + "'", int2 == 1316926008);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) -1, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 52, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-581316669), 1316925998);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-36288112), (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double2 = org.apache.commons.math.util.FastMath.max(2.220446049250313E-16d, 0.03760197886023983d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03760197886023983d + "'", double2 == 0.03760197886023983d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(35, 51);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double2 = org.apache.commons.math.util.FastMath.pow(20.796610300773246d, (double) (-101L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.633998381416968E-134d + "'", double2 == 7.633998381416968E-134d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1182143360), 373782665);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.3383347192042695E42d, (-0.7615941559557649d), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 1.5422326689561365d);
        double[] doubleArray6 = null;
        try {
            double double7 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '4', 1182143360);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable throwable5 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-6.1087578E8f), 0.7853981633974483d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double[] doubleArray18 = new double[] { (-36288110L) };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray21 = new double[] { (-36288110L) };
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray21);
        double[] doubleArray25 = new double[] { (-36288110L) };
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray25);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray18);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger32, (java.lang.Number) 50, 5, orderDirection37, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection37, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1316925998) + "'", int19 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1316925998) + "'", int22 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1316925998) + "'", int26 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.628811E7d + "'", double28 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-10L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1182143360);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.FastMath.log(53.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        long long1 = org.apache.commons.math.util.FastMath.abs(8309L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8309L + "'", long1 == 8309L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1316926050, 53);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1057.3612456853957d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double2 = org.apache.commons.math.util.MathUtils.log((-30.422048691767916d), 12.396355954702376d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 100, (long) 373782665);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7475653300L + "'", long2 == 7475653300L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.3328089960826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.306852817378905d + "'", double1 == 9.306852817378905d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.174802103936399d + "'", double1 == 3.174802103936399d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.11765201552461488d, (double) 36288113);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2421640531326297E-9d + "'", double2 == 3.2421640531326297E-9d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 102);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        int int1 = org.apache.commons.math.util.MathUtils.sign(51);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 5, 42);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1444554559021708921L + "'", long2 == 1444554559021708921L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(51);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.FastMath.log1p(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1182143360), 2L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-75743232) + "'", int2 == (-75743232));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 7475653300L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.428064530957435d + "'", double1 == 23.428064530957435d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 137, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7124L + "'", long2 == 7124L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (-1182143360));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1182143360), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.acos(42.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.37623361672720984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.158638853279167d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 36288113);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 36288113L + "'", long1 == 36288113L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 36288113);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 633347.051185757d + "'", double1 == 633347.051185757d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950371902099892d + "'", double1 == 0.9950371902099892d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(99.78385316640734d, (int) (byte) 10, 1095479173);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 100.0f, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2676506002282294E32d + "'", double2 == 1.2676506002282294E32d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 41.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.0d + "'", double1 == 41.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int1 = org.apache.commons.math.util.FastMath.abs(42);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 42 + "'", int1 == 42);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.5872139151569291d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1903521261) + "'", int1 == (-1903521261));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(9191955381386663201L, (long) (-54364591));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5511187532874088E66d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5979252671570532d + "'", double1 == 0.5979252671570532d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 11L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 11.0f + "'", float1 == 11.0f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 2756, (int) (byte) 0, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 36288113);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (byte) 0);
        double[] doubleArray18 = new double[] { 10 };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) ' ');
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
        try {
            double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 535367281);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 535367281 + "'", int2 == 535367281);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.9997860728793259d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.174871113735541d) + "'", double1 == (-1.174871113735541d));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double[] doubleArray0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, number2, 0, orderDirection4, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.149548905166106d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.778516039144078E22d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-448071173) + "'", int1 == (-448071173));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-33L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(97L, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 582L + "'", long2 == 582L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 102, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.3840578361895723E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3720292.779055934d + "'", double1 == 3720292.779055934d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.8405291802459339d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7640043648110827d + "'", double1 == 0.7640043648110827d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.7330382858376184d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6691306063588582d + "'", double1 == 0.6691306063588582d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.floor(7.105427357601003E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1182143411), 36288113L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1218431524L) + "'", long2 == (-1218431524L));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-10.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-572.9577951308232d) + "'", double1 == (-572.9577951308232d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-543645910L), (-75743232), (-75743232));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        float float3 = org.apache.commons.math.util.MathUtils.round((-2.52568734E18f), (-1903521261), 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 102.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.634728988229636d + "'", double1 == 4.634728988229636d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9999999989694232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077211246418d + "'", double1 == 1.5574077211246418d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 1, 1182143360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1182143361 + "'", int2 == 1182143361);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int[] intArray6 = new int[] { (byte) 1, (-75743232), (short) 1, 1076101151, 137, 42 };
        int[] intArray8 = new int[] { 52 };
        int[] intArray15 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray15);
        int[] intArray19 = new int[] { (-1), 32 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray19);
        int[] intArray22 = new int[] { 52 };
        int[] intArray29 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray29);
        int[] intArray33 = new int[] { (-1), 32 };
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray22);
        int[] intArray37 = new int[] { 52 };
        int[] intArray44 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray44);
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray37);
        int[] intArray48 = new int[] { 52 };
        int[] intArray55 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray55);
        int[] intArray59 = new int[] { (-1), 32 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray59);
        int[] intArray62 = new int[] { 52 };
        int[] intArray69 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray69);
        int[] intArray73 = new int[] { (-1), 32 };
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray62);
        int[] intArray77 = new int[] { 52 };
        int[] intArray84 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int85 = org.apache.commons.math.util.MathUtils.distanceInf(intArray77, intArray84);
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray77);
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray62);
        try {
            double double88 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 42 + "'", int16 == 42);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 42 + "'", int30 == 42);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 42 + "'", int45 == 42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 42 + "'", int56 == 42);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 53 + "'", int60 == 53);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 42 + "'", int70 == 42);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 53 + "'", int74 == 53);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 42 + "'", int85 == 42);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(286.4788975654116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 286.47889756541167d + "'", double1 == 286.47889756541167d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3124383412727525d + "'", double1 == 2.3124383412727525d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.917047545405684d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.450795069539857d + "'", double1 == 1.450795069539857d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-75743232), (-36288112));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0504981725497873d + "'", double1 == 1.0504981725497873d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.log10(123.44001497540268d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.091455965742506d + "'", double1 == 2.091455965742506d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.signum(8958.81600130236d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        long long2 = org.apache.commons.math.util.FastMath.max(3628810L, (long) 42);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628810L + "'", long2 == 3628810L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double2 = org.apache.commons.math.util.FastMath.max(0.11765201552461488d, (double) 22167526884077930L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2167526884077928E16d + "'", double2 == 2.2167526884077928E16d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Class<?> wildcardClass4 = nonMonotonousSequenceException3.getClass();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int[] intArray1 = new int[] { 52 };
        int[] intArray8 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray12 = new int[] { (-1), 32 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray15 = new int[] { 52 };
        int[] intArray22 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int[] intArray26 = new int[] { (-1), 32 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray15);
        int[] intArray30 = new int[] { 52 };
        int[] intArray37 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray30);
        int[] intArray41 = new int[] { 52 };
        int[] intArray48 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray48);
        int[] intArray52 = new int[] { (-1), 32 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray52);
        int[] intArray55 = new int[] { 52 };
        int[] intArray62 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray62);
        int[] intArray66 = new int[] { (-1), 32 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray55);
        int[] intArray70 = new int[] { 52 };
        int[] intArray77 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray70);
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray55);
        int[] intArray81 = null;
        try {
            double double82 = org.apache.commons.math.util.MathUtils.distance(intArray55, intArray81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42 + "'", int23 == 42);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 42 + "'", int38 == 42);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 42 + "'", int49 == 42);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 53 + "'", int53 == 53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 42 + "'", int63 == 42);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 53 + "'", int67 == 53);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 42 + "'", int78 == 42);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1903521261), 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-980072951) + "'", int2 == (-980072951));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) ' ', (-1192192432), (-1316925998));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double1 = org.apache.commons.math.util.FastMath.log(5.745303344399952d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7483827113689034d + "'", double1 == 1.7483827113689034d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.1736481776669303d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1182143411), 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-51816111) + "'", int2 == (-51816111));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.5350353514628688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.00624673572957d + "'", double1 == 1.00624673572957d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1, (double) (-3628811L), (double) 54364591);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1182143360), 1316926008);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int1 = org.apache.commons.math.util.MathUtils.sign(50);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1316925998, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        long long1 = org.apache.commons.math.util.FastMath.round(52.49761899362675d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-54364591), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-54364591L) + "'", long2 == (-54364591L));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-448071173), (double) (-51816111));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7581226324091722d) + "'", double1 == (-0.7581226324091722d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1316925998));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 535367281, 53.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.3536728099999994E8d + "'", double2 == 5.3536728099999994E8d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.020063413307844603d, 102, (-75743232));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 51.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.046745412134694E21d + "'", double1 == 7.046745412134694E21d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double2 = org.apache.commons.math.util.MathUtils.log(53.00000000000001d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-610875763));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 11.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-15.249237972318797d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2097151.9999998813d) + "'", double1 == (-2097151.9999998813d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000000000L + "'", long2 == 10000000000L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9999999835107711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.648922900715552E-8d) + "'", double1 == (-1.648922900715552E-8d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray12 = null;
        double[] doubleArray14 = new double[] { (-36288110L) };
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray17 = new double[] { (-36288110L) };
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray17);
        double[] doubleArray26 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) -1);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray29);
        try {
            double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.628811E7d + "'", double11 == 3.628811E7d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1316925998) + "'", int15 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1316925998) + "'", int18 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.628811271828183E7d + "'", double27 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray8);
        double[] doubleArray17 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (byte) 0);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        try {
            double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 102.0f);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.628811271828183E7d + "'", double18 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.3840578361895723E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948244d + "'", double1 == 1.5707963267948244d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-36288112), 50);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double2 = org.apache.commons.math.util.FastMath.max(1.000000000000007d, (double) 1316926050);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.31692605E9d + "'", double2 == 1.31692605E9d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.08281907607655d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math.util.FastMath.abs(7.105427357601003E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601003E-15d + "'", double1 == 7.105427357601003E-15d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 22167526884077930L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2167526884077928E16d + "'", double1 == 2.2167526884077928E16d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1316926050, 2758547353515625L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 9.223372E18f, (double) 36.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.4260624389053682d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.70735907141041d + "'", double1 == 81.70735907141041d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-75743232), 41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1316926008, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1182143411));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963259489757d) + "'", double1 == (-1.5707963259489757d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 9.223372E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.66827237527655d + "'", double1 == 43.66827237527655d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07587629588596118d + "'", double1 == 0.07587629588596118d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.220446049250313E-16d, 22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0081267156555943E-20d + "'", double2 == 1.0081267156555943E-20d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 41.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.713572066704308d + "'", double1 == 3.713572066704308d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        java.lang.Number number14 = nonMonotonousSequenceException13.getArgument();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException13.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException13.getClass();
        boolean boolean18 = nonMonotonousSequenceException13.getStrict();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0f + "'", number14.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.ulp(153.66964095568503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(35, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.38856140554563d + "'", double2 == 6.38856140554563d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9227673888116062d + "'", double1 == 0.9227673888116062d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-51816111), (-1182143411));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(7.105427357601002E-15d, 1.5607966601082315d, 2756);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.00624673572957d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8448296708124096d + "'", double1 == 0.8448296708124096d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1095479173, (long) (-1192192432));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 53495558235L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 53495558235L + "'", long2 == 53495558235L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, (-1316925998));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.tan((-2097151.9999998813d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7982155842022706d) + "'", double1 == (-0.7982155842022706d));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1), 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51L + "'", long2 == 51L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1182143360, 1316926050);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.9671567457086963d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5053085831756794d + "'", double1 == 1.5053085831756794d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-392210900));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.92210912E8f + "'", float1 == 3.92210912E8f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1182143411), (double) 54364591L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.436459294160986E7d + "'", double2 == 5.436459294160986E7d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(50, (-1192192432));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 535367281);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23138.005121444676d + "'", double1 == 23138.005121444676d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 102, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-581316669));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        java.lang.Number number14 = nonMonotonousSequenceException13.getArgument();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException13.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        java.lang.String str22 = nonMonotonousSequenceException13.toString();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1.0f + "'", number14.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (2.718 >= 1)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (2.718 >= 1)"));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 1, 2758547353515625L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2758547353515624L) + "'", long2 == (-2758547353515624L));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.7483827113689034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.17495033507774d + "'", double1 == 100.17495033507774d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 51L, (-0.808448792630022d), 0.6989700043360189d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.628811E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(Double.POSITIVE_INFINITY, 1.00624673572957d, (double) (-36288112));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 54364591, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 54364589L + "'", long2 == 54364589L);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1), (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1316926008, 137);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1316925871 + "'", int2 == 1316925871);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.0d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(373782665);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(51L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 151L + "'", long2 == 151L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 2756, (int) (byte) 0, orderDirection4, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 51L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 51.0f + "'", float1 == 51.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 102, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(9223372036854775807L, 7475653300L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 22167526884077930L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.3124383412727525d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double2 = org.apache.commons.math.util.FastMath.pow(286.4788975654116d, 1587.7603709497232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double2 = org.apache.commons.math.util.FastMath.max(51.0d, 3.626860407847019d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        long long1 = org.apache.commons.math.util.FastMath.round(3.2421640531326297E-9d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double2 = org.apache.commons.math.util.FastMath.min(0.6045824459415916d, 23138.005121444676d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6045824459415916d + "'", double2 == 0.6045824459415916d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray8);
        double[] doubleArray17 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (byte) 0);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        double[] doubleArray22 = null;
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { (-36288110L) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray30 = new double[] { (-36288110L) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray30);
        double[] doubleArray34 = new double[] { (-36288110L) };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray34);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray24);
        try {
            double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.628811271828183E7d + "'", double18 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1316925998) + "'", int28 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1316925998) + "'", int31 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1316925998) + "'", int35 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.atanh(43.66827237527655d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) Float.POSITIVE_INFINITY, 30.457767331043865d, 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        float float2 = org.apache.commons.math.util.MathUtils.round((-2.52568734E18f), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.52568734E18f) + "'", float2 == (-2.52568734E18f));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(633347.051185757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.49824130708557135d) + "'", double1 == (-0.49824130708557135d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 54364591);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 54364592 + "'", int1 == 54364592);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9971172387049709d + "'", double1 == 0.9971172387049709d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        double[] doubleArray3 = new double[] { (-36288110L) };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray6 = new double[] { (-36288110L) };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray9 = new double[] { (-36288110L) };
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray9);
        double[] doubleArray13 = new double[] { (-36288110L) };
        int int14 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray13);
        double double16 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray13);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray3);
        try {
            double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1316925998) + "'", int4 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1316925998) + "'", int7 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1316925998) + "'", int10 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1316925998) + "'", int14 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 1, 1182143361);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1182143361 + "'", int2 == 1182143361);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        long long2 = org.apache.commons.math.util.FastMath.max((-36288110L), (long) 137);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 137L + "'", long2 == 137L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.11738078017840028d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11711288762622143d + "'", double1 == 0.11711288762622143d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628810L, (java.lang.Number) 10L, 0, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.9E-324d, (java.lang.Number) 1.0d, 0, orderDirection6, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Throwable throwable12 = null;
        try {
            nonMonotonousSequenceException10.addSuppressed(throwable12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0d + "'", number11.equals(1.0d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.550547237255589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.83981263041517d + "'", double1 == 88.83981263041517d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(53.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9250245035569947d + "'", double1 == 0.9250245035569947d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.3328089960826d, 137);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3328089960826d + "'", double2 == 2.3328089960826d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, 1.5422326689561365d);
        double[] doubleArray7 = new double[] { (-36288110L) };
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray10 = new double[] { (-36288110L) };
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray10);
        double[] doubleArray19 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) (byte) 0);
        double[] doubleArray24 = new double[] { (-36288110L) };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray27 = new double[] { (-36288110L) };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray27);
        double[] doubleArray31 = new double[] { (-36288110L) };
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray24);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray19);
        double[] doubleArray38 = new double[] { (-36288110L) };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray41 = new double[] { (-36288110L) };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray41);
        double[] doubleArray45 = new double[] { (-36288110L) };
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        try {
            double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1316925998) + "'", int8 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1316925998) + "'", int11 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 3.628811271828183E7d + "'", double20 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1316925998) + "'", int25 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1316925998) + "'", int28 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1316925998) + "'", int32 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.628811E7d + "'", double34 == 3.628811E7d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1316925998) + "'", int39 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1316925998) + "'", int42 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1316925998) + "'", int46 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 3.628811E7d + "'", double48 == 3.628811E7d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray13 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray16 = null;
        try {
            double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.628811271828183E7d + "'", double14 == 3.628811271828183E7d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811E7d + "'", double15 == 3.628811E7d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.sin(6.350809011846739d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0675721763064526d + "'", double1 == 0.0675721763064526d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 151L, (double) 535367281);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.005848633036073d + "'", double2 == 4.005848633036073d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 1, (long) (-1192192432));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 2.718281828459045d, (int) (short) 0);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.896296018268069E13d, (java.lang.Number) 3.948148009134034E13d, 2756, orderDirection11, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.3284353259397996E-6d), (java.lang.Number) 4.778516039144078E22d, 137, orderDirection11, false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.00000000000001d, (java.lang.Number) 0.11738078017840028d, 535367281);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 20);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) -1, (double) 582L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math.util.FastMath.ceil(6.38856140554563d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-392210900));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 53495558235L, 1182143361);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.65228217112E280d + "'", double2 == 5.65228217112E280d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) '#', 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.901287759092718d + "'", double2 == 21.901287759092718d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 42);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.39998531498835127d) + "'", double1 == (-0.39998531498835127d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 50L, 1.5574077211246418d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.26548245743668986d) + "'", double2 == (-0.26548245743668986d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 50, 5, orderDirection7, true);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 1);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 42);
        try {
            java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) (-581316669));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.5979252671570532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 52, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1218431524L), 0, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1218431524L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.126564180389231E7d) + "'", double1 == (-2.126564180389231E7d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 100, 1316925871);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double[] doubleArray1 = new double[] { 10 };
        double[] doubleArray3 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray1, (double) ' ');
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray8);
        double[] doubleArray17 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray17);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) (byte) 0);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray20);
        double[] doubleArray23 = new double[] { (-36288110L) };
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray26 = new double[] { (-36288110L) };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray26);
        double[] doubleArray30 = new double[] { (-36288110L) };
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray30);
        double[] doubleArray33 = new double[] {};
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray33);
        try {
            double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.628811271828183E7d + "'", double18 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1316925998) + "'", int24 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1316925998) + "'", int27 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1316925998) + "'", int31 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0.0f, 5.3536728099999994E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 50, 5, orderDirection7, true);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 1);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 42);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 42, (java.lang.Number) (-1192192432), 0);
        java.lang.Number number21 = nonMonotonousSequenceException20.getPrevious();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-1192192432) + "'", number21.equals((-1192192432)));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.596393425240077d + "'", double1 == 13.596393425240077d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 54364591);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 36288113L, 54364592, 1316926050);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.3328089960826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 133.66010988568357d + "'", double1 == 133.66010988568357d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.sin(52.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404841d + "'", double1 == 0.9866275920404841d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 3.141592653589793d, 156.3608363030788d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (-1192192432), 50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2005.3522829578812d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-448071173), (int) (short) 10, (-1316925998));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 582L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 582L + "'", long1 == 582L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 36.0f, (java.lang.Number) 1.0d, (int) (short) 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 41);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 22167526884077930L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 38.330552040511876d + "'", double1 == 38.330552040511876d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        int int2 = org.apache.commons.math.util.FastMath.max(52, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(20.796610300773246d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.79661030077325d + "'", double1 == 20.79661030077325d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-75743232), (long) (-54364591));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-51816111), (-1192192432));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 10, (java.lang.Number) 0L, (int) ' ', orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number9 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0L + "'", number9.equals(0L));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-36288110L) };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = new double[] { (-36288110L) };
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray5);
        double[] doubleArray14 = new double[] { 2.718281828459045d, (-1316925998), 3.141592653589793d, (-1L), 10.0f, (-3628811L) };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) (short) -1);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1316925998) + "'", int3 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1316925998) + "'", int6 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.628811271828183E7d + "'", double15 == 3.628811271828183E7d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 1, (-54364591));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-54364591) + "'", int2 == (-54364591));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2, 137);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 139 + "'", int2 == 139);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-2.126564180389231E7d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-10L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-448071173));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1L), (float) 54364591L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-54364591L), 139);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-30.422048691767916d), 12.396355954702376d, 50);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.55795945611504d + "'", double1 == 81.55795945611504d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 41);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.406867935097715d + "'", double1 == 4.406867935097715d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.FastMath.atanh(22026.465794806718d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) ' ');
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger15, (java.lang.Number) 50, 5, orderDirection20, true);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (int) (short) 1);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger25);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger31, (java.lang.Number) 50, 5, orderDirection36, true);
        java.math.BigInteger bigInteger39 = null;
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 0L);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (int) (short) 1);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger41);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 42);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger46);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger15);
        try {
            java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (-1218431524L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) (short) 1);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 10L);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-1182143411));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 2, (-54364591), 2756);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-51816111), (-448071173));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int int1 = org.apache.commons.math.util.FastMath.round((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) 3.141592653589793d, (int) (byte) 100);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.142 >= 0)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(7.633998381416968E-134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double[] doubleArray1 = new double[] { (-36288110L) };
        int int2 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        double[] doubleArray4 = new double[] { (-36288110L) };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray4);
        double[] doubleArray8 = new double[] { (-36288110L) };
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distance(doubleArray1, doubleArray8);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray12 = null;
        try {
            double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1316925998) + "'", int2 == (-1316925998));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1316925998) + "'", int5 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1316925998) + "'", int9 == (-1316925998));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.628811E7d + "'", double11 == 3.628811E7d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5626927764648464d, (java.lang.Number) 0.11765201552461488d, 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(20.796610300773246d, 535367281);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6107356981409304E-119d + "'", double2 == 1.6107356981409304E-119d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1316926008, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 935.564598636671d + "'", double2 == 935.564598636671d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(935.564598636671d, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2145754835518945E13d + "'", double2 == 3.2145754835518945E13d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        long long2 = org.apache.commons.math.util.FastMath.max((-18L), 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.2145754835518945E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.79444869601266d + "'", double1 == 31.79444869601266d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(50);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (-1316925998));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1182143360), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1182143395L) + "'", long2 == (-1182143395L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double2 = org.apache.commons.math.util.FastMath.pow(5.3536728099999994E8d, 5.3536728099999994E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 373782665);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.39998531498835127d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41073645028673067d) + "'", double1 == (-0.41073645028673067d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.41073645028673067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41073645028673067d + "'", double1 == 0.41073645028673067d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger2, (java.lang.Number) 50, 5, orderDirection7, true);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 1);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 42);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 42, (java.lang.Number) (-1192192432), 0);
        int int21 = nonMonotonousSequenceException20.getIndex();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (-610875763));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(23138.005121444676d, 2.8421709430404007E-14d, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.174802103936399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) '4', 1316926008);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 20);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int1 = org.apache.commons.math.util.FastMath.abs(1528444521);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1528444521 + "'", int1 == 1528444521);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1182143360), (-448071173));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        long long2 = org.apache.commons.math.util.MathUtils.pow(54364589L, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 54364589L + "'", long2 == 54364589L);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 7.046745412134694E21d, (-3628811.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1182143360);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1095479173, (-1L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(41);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3452526613163927E49d + "'", double1 == 3.3452526613163927E49d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(123.44001497540268d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.979113068385778d + "'", double1 == 4.979113068385778d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 22167526884077930L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        int[] intArray1 = new int[] { 52 };
        int[] intArray8 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray12 = new int[] { (-1), 32 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        int[] intArray15 = new int[] { 52 };
        int[] intArray22 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray22);
        int[] intArray26 = new int[] { (-1), 32 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray15);
        int[] intArray30 = new int[] { 52 };
        int[] intArray37 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray30);
        int[] intArray41 = new int[] { 52 };
        int[] intArray48 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray48);
        int[] intArray52 = new int[] { (-1), 32 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray52);
        int[] intArray55 = new int[] { 52 };
        int[] intArray62 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray62);
        int[] intArray66 = new int[] { (-1), 32 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray41, intArray55);
        int[] intArray70 = new int[] { 52 };
        int[] intArray77 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray70, intArray77);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray70);
        int[] intArray81 = new int[] { 52 };
        int[] intArray88 = new int[] { (byte) 10, (-1), 'a', 52, (short) 100, 52 };
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray81, intArray88);
        int[] intArray92 = new int[] { (-1), 32 };
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray81, intArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray70, intArray92);
        double double95 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray92);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 53 + "'", int13 == 53);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 42 + "'", int23 == 42);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 42 + "'", int38 == 42);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 42 + "'", int49 == 42);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 53 + "'", int53 == 53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 42 + "'", int63 == 42);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 53 + "'", int67 == 53);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 42 + "'", int78 == 42);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 42 + "'", int89 == 42);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 53 + "'", int93 == 53);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 53.0d + "'", double94 == 53.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 53.0d + "'", double95 == 53.0d);
    }
}

