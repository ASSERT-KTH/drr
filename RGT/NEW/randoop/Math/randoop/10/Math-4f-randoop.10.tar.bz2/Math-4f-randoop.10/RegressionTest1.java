import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(99.99999f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree0 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree2 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D1);
        spaceBSPTree0.insertInTree(spaceBSPTree2, false);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree5 = spaceBSPTree0.getMinus();
        org.apache.commons.math3.geometry.partitioning.BSPTreeVisitor<org.apache.commons.math3.geometry.Space> spaceBSPTreeVisitor6 = null;
        try {
            spaceBSPTree0.visit(spaceBSPTreeVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNull(spaceBSPTree5);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math3.util.FastMath.exp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.154262241479262d + "'", double1 == 15.154262241479262d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 0L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) (-0.1f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09983408038192852d) + "'", double1 == (-0.09983408038192852d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        double double1 = vector1D0.getNorm();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(97.0d, (double) 5);
        double double3 = intervalsSet2.getInf();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector4 = intervalsSet2.getBarycenter();
        double double5 = intervalsSet2.getSup();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.0d + "'", double3 == 97.0d);
        org.junit.Assert.assertNotNull(euclidean1DVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.0d + "'", double5 == 5.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str1 = vector1D0.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D2, false);
        orientedPoint4.revertSelf();
        orientedPoint4.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D12.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D16.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D13.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (byte) 100, vector1D9, 10.0d, vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str21 = vector1D20.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = vector1D20.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint24 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D22, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = vector1D26.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D31.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = vector1D35.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = vector1D32.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = vector1D40.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D44.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D41.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D37, (double) 10.0f, vector1D46);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = vector1D26.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D37);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = vector1D51.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D55.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = vector1D52.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D55);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = vector1D60.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = vector1D64.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = vector1D61.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D64);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D57, (double) 10.0f, vector1D66);
        double double68 = vector1D37.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D67);
        double double69 = orientedPoint24.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D67);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str71 = vector1D70.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = vector1D70.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint74 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D72, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet75 = orientedPoint74.wholeSpace();
        double double76 = intervalsSet75.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint77 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint24, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet75);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = orientedPoint24.getLocation();
        double double79 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D16, vector1D78);
        double double80 = vector1D7.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{(NaN)}" + "'", str1.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{(NaN)}" + "'", str21.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 37.474671492307515d + "'", double68 == 37.474671492307515d);
        org.junit.Assert.assertEquals((double) double69, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "{(NaN)}" + "'", str71.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D72);
        org.junit.Assert.assertNotNull(intervalsSet75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + Double.POSITIVE_INFINITY + "'", double76 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D78);
        org.junit.Assert.assertEquals((double) double79, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double80, Double.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math3.util.FastMath.rint(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 1.0f, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D2.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D3, (double) (short) 100, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D3);
        double double8 = vector3D3.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D3.add((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D13.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D14, (double) (short) 100, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Line line18 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D3, vector3D14);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D20.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = vector1D25.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = vector1D29.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = vector1D26.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D34.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = vector1D38.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D35.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D31, (double) 10.0f, vector1D40);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = vector1D20.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D31);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D45.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = vector1D49.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = vector1D46.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D49);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = vector1D54.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = vector1D58.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = vector1D55.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D58);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D51, (double) 10.0f, vector1D60);
        double double62 = vector1D31.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D61);
        double double63 = vector1D31.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D64 = line18.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D31);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D65 = line18.getOrigin();
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D42);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 37.474671492307515d + "'", double62 == 37.474671492307515d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 3.7474671492307516d + "'", double63 == 3.7474671492307516d);
        org.junit.Assert.assertNotNull(vector3D64);
        org.junit.Assert.assertNotNull(vector3D65);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D1.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = vector1D6.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = vector1D10.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D7.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D15.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D19.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D16.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D12, (double) 10.0f, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = vector1D1.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = vector1D25.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = vector1D30.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D34.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = vector1D31.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D34);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D39.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = vector1D43.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D40.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D36, (double) 10.0f, vector1D45);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = vector1D25.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D36);
        double double48 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distanceInf(vector1D23, vector1D36);
        java.lang.String str49 = vector1D23.toString();
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{6.2525328508}" + "'", str49.equals("{6.2525328508}"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D4, (double) (short) 100, vector3D6);
        boolean boolean9 = vector3D4.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line10 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D1, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = line10.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D16, (double) (short) 100, vector3D18);
        boolean boolean21 = vector3D16.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = line10.closestPoint(line22);
        double double24 = vector3D23.getNormSq();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = vector3D27.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D28, (double) (short) 100, vector3D30);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D28);
        double double33 = vector3D28.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D28.add((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D35);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D39 = vector3D38.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D39, (double) (short) 100, vector3D41);
        org.apache.commons.math3.geometry.euclidean.threed.Line line43 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D28, vector3D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D45.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = vector1D50.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = vector1D54.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D51.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = vector1D59.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = vector1D63.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = vector1D60.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D63);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D56, (double) 10.0f, vector1D65);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = vector1D45.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = vector1D70.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D75 = vector1D74.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = vector1D71.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D74);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D79 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = vector1D79.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D84 = vector1D83.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D85 = vector1D80.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D83);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D86 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D76, (double) 10.0f, vector1D85);
        double double87 = vector1D56.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D86);
        double double88 = vector1D56.getNorm();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D89 = line43.toSpace((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D56);
        double double90 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance(vector3D23, vector3D89);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertNotNull(vector3D38);
        org.junit.Assert.assertNotNull(vector3D39);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertNotNull(vector1D51);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D65);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(vector1D75);
        org.junit.Assert.assertNotNull(vector1D76);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertNotNull(vector1D84);
        org.junit.Assert.assertNotNull(vector1D85);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 37.474671492307515d + "'", double87 == 37.474671492307515d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 3.7474671492307516d + "'", double88 == 3.7474671492307516d);
        org.junit.Assert.assertNotNull(vector3D89);
        org.junit.Assert.assertEquals((double) double90, Double.NaN, 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double2 = org.apache.commons.math3.util.Precision.round((double) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.0d + "'", double2 == 50.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int[] intArray0 = new int[] {};
        int[] intArray1 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0);
        int[] intArray3 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1, 1);
        int[] intArray6 = new int[] { (short) 10, 0 };
        int[] intArray7 = org.apache.commons.math3.util.MathArrays.copyOf(intArray6);
        int[] intArray10 = new int[] { (short) 10, 0 };
        int[] intArray11 = org.apache.commons.math3.util.MathArrays.copyOf(intArray10);
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray7, intArray10);
        int int13 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray1, intArray10);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint2 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane3 = subOrientedPoint2.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane4 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion5 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint6 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane4, euclidean1DRegion5);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane7 = subOrientedPoint6.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane8 = euclidean1DAbstractSubHyperplane7.copySelf();
        try {
            org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane9 = subOrientedPoint2.reunite((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane3);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane7);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(2.6881171418161356E43d, 2.0989731760495502E-39d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D4, (double) (short) 100, vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D4);
        double double9 = vector3D4.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D4.add((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        java.lang.String str16 = vector3D15.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 1.4E-45f, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(3503.1415926535897d, vector3D12, 0.4747467149230752d, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = vector3D17.getZero();
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{0; 0; 0}" + "'", str16.equals("{0; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D19);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double[] doubleArray3 = new double[] { (byte) 0, (-1L), 100L };
        double double4 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray3);
        double[] doubleArray8 = new double[] { (byte) 0, (-1L), 100L };
        double double9 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, 0.0d);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray3, doubleArray8);
        double[] doubleArray15 = new double[] { 4.041932724685649d, (-3.7474671492307516d) };
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray15, 0);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray3, doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.00499987500625d + "'", double4 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.00499987500625d + "'", double9 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.getZero();
        double double2 = vector3D1.getNorm();
        double double3 = vector3D1.getNorm();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D0);
        org.apache.commons.math3.geometry.euclidean.twod.Line line3 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, 0.0d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree5 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double12 = vector2D11.getY();
        double double13 = vector2D10.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double14 = vector2D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double18 = vector2D17.getY();
        double double19 = vector2D16.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double20 = vector2D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double21 = vector2D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double26 = vector2D25.getY();
        double double27 = vector2D24.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        double double28 = vector2D23.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double32 = vector2D31.getY();
        double double33 = vector2D30.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double34 = vector2D29.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double35 = vector2D29.getNorm();
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D23, vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D7, (double) '4', vector2D15, (double) 3, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line38 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, vector2D15);
        double double39 = line38.getOriginOffset();
        double double40 = line38.getAngle();
        double double41 = line38.getOriginOffset();
        boolean boolean42 = line3.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double46 = vector2D45.getY();
        double double47 = vector2D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D45);
        double double48 = vector2D43.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double52 = vector2D51.getY();
        double double53 = vector2D50.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        double double54 = vector2D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        double double55 = vector2D49.getNorm();
        double double56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D43, vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double59 = vector2D58.getY();
        double double60 = vector2D57.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = vector2D49.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D58);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D66 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double68 = vector2D67.getY();
        double double69 = vector2D66.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        double double70 = vector2D65.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double74 = vector2D73.getY();
        double double75 = vector2D72.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D73);
        double double76 = vector2D71.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D73);
        double double77 = vector2D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D71);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double82 = vector2D81.getY();
        double double83 = vector2D80.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        double double84 = vector2D79.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D85 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D86 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D87 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double88 = vector2D87.getY();
        double double89 = vector2D86.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D87);
        double double90 = vector2D85.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D87);
        double double91 = vector2D85.getNorm();
        double double92 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D79, vector2D85);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D93 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D63, (double) '4', vector2D71, (double) 3, vector2D79);
        double double94 = vector2D49.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D93);
        boolean boolean95 = line38.contains(vector2D93);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertNotNull(vector2D66);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D71);
        org.junit.Assert.assertNotNull(vector2D72);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D85);
        org.junit.Assert.assertNotNull(vector2D86);
        org.junit.Assert.assertNotNull(vector2D87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertEquals((double) double94, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(97.0d, (double) 5);
        double double3 = intervalsSet2.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str5 = vector1D4.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = vector1D4.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint8 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D6, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = vector1D10.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D15.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D19.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D16.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = vector1D24.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = vector1D28.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = vector1D25.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D28);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D21, (double) 10.0f, vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D10.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = vector1D35.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D39.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = vector1D36.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D44.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = vector1D48.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = vector1D45.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D48);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D51 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D41, (double) 10.0f, vector1D50);
        double double52 = vector1D21.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D51);
        double double53 = orientedPoint8.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D51);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str55 = vector1D54.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = vector1D54.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint58 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D56, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet59 = orientedPoint58.wholeSpace();
        double double60 = intervalsSet59.getSup();
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint61 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint8, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet59);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str63 = vector1D62.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = vector1D62.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint66 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D64, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet67 = orientedPoint66.wholeSpace();
        double double68 = intervalsSet67.getSup();
        boolean boolean69 = intervalsSet59.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet67);
        boolean boolean70 = intervalsSet2.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet59);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector71 = intervalsSet59.getBarycenter();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{(NaN)}" + "'", str5.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D6);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D30);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 37.474671492307515d + "'", double52 == 37.474671492307515d);
        org.junit.Assert.assertEquals((double) double53, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "{(NaN)}" + "'", str55.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D56);
        org.junit.Assert.assertNotNull(intervalsSet59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + Double.POSITIVE_INFINITY + "'", double60 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "{(NaN)}" + "'", str63.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(intervalsSet67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + Double.POSITIVE_INFINITY + "'", double68 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(euclidean1DVector71);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(0.015625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.25d + "'", double1 == 0.25d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double3 = vector2D2.getY();
        double double4 = vector2D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        double double5 = vector2D0.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        java.lang.Class<?> wildcardClass6 = vector2D0.getClass();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str2 = vector1D1.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        double double5 = vector1D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree6 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) double5);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.Space> spaceVector7 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree8 = spaceBSPTree6.getCell(spaceVector7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree10 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D9);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree11 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        spaceBSPTree10.insertInTree(spaceBSPTree11, true);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane14 = spaceBSPTree10.getCut();
        float[] floatArray15 = null;
        float[] floatArray22 = new float[] { (byte) 1, (-1.0f), 100L, (-1L), (byte) 1, (byte) -1 };
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray15, floatArray22);
        float[] floatArray28 = new float[] { 10, (byte) 10, (byte) 0, 100L };
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(floatArray22, floatArray28);
        float[] floatArray34 = new float[] { 1, (short) 100, 1L, '#' };
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equals(floatArray22, floatArray34);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree36 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceBSPTree6, spaceBSPTree10, (java.lang.Object) boolean35);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree37 = spaceBSPTree10.getPlus();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree38 = spaceBSPTree10.getMinus();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{(NaN)}" + "'", str2.equals("{(NaN)}"));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(spaceBSPTree8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNull(spaceSubHyperplane14);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(spaceBSPTree37);
        org.junit.Assert.assertNull(spaceBSPTree38);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double8 = vector2D7.getY();
        double double9 = vector2D6.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double10 = vector2D5.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double14 = vector2D13.getY();
        double double15 = vector2D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double16 = vector2D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double17 = vector2D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double22 = vector2D21.getY();
        double double23 = vector2D20.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double24 = vector2D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double28 = vector2D27.getY();
        double double29 = vector2D26.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double30 = vector2D25.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double31 = vector2D25.getNorm();
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D19, vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D3, (double) '4', vector2D11, (double) 3, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D11);
        double double35 = line34.getOriginOffset();
        double double36 = line34.getAngle();
        double double37 = line34.getOriginOffset();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree39 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double46 = vector2D45.getY();
        double double47 = vector2D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D45);
        double double48 = vector2D43.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double52 = vector2D51.getY();
        double double53 = vector2D50.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        double double54 = vector2D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        double double55 = vector2D45.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double60 = vector2D59.getY();
        double double61 = vector2D58.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D59);
        double double62 = vector2D57.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D59);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double66 = vector2D65.getY();
        double double67 = vector2D64.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D65);
        double double68 = vector2D63.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D65);
        double double69 = vector2D63.getNorm();
        double double70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D57, vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D41, (double) '4', vector2D49, (double) 3, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line72 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D38, vector2D49);
        double double73 = line72.getOriginOffset();
        double double74 = line72.getAngle();
        boolean boolean75 = line34.isParallelTo(line72);
        double double76 = line72.getOriginOffset();
        double double77 = line72.getOriginOffset();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double1 = vector3D0.getZ();
        org.apache.commons.math3.geometry.Space space2 = vector3D0.getSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D8, (double) (short) 100, vector3D10);
        boolean boolean13 = vector3D8.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line14 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D5, vector3D8);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = line14.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D16.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = vector3D19.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D20, (double) (short) 100, vector3D22);
        boolean boolean25 = vector3D20.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line26 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D17, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = line14.closestPoint(line26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(7.896296018268084E13d, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Line line29 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D0, vector3D28);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D34.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D38 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D35, (double) (short) 100, vector3D37);
        boolean boolean39 = vector3D37.isInfinite();
        double double40 = vector3D37.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        java.lang.String str43 = vector3D42.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D31, (double) 100, vector3D37, 0.0d, vector3D42);
        java.lang.String str45 = vector3D31.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D46 = vector3D31.negate();
        boolean boolean47 = line29.contains(vector3D31);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
        org.junit.Assert.assertNotNull(space2);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "{0; 0; 0}" + "'", str43.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{0; 0; -1}" + "'", str45.equals("{0; 0; -1}"));
        org.junit.Assert.assertNotNull(vector3D46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double8 = vector2D7.getY();
        double double9 = vector2D6.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double10 = vector2D5.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double14 = vector2D13.getY();
        double double15 = vector2D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double16 = vector2D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double17 = vector2D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double22 = vector2D21.getY();
        double double23 = vector2D20.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double24 = vector2D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double28 = vector2D27.getY();
        double double29 = vector2D26.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double30 = vector2D25.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double31 = vector2D25.getNorm();
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D19, vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D3, (double) '4', vector2D11, (double) 3, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D11);
        double double35 = line34.getOriginOffset();
        double double36 = line34.getAngle();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector37 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = line34.toSpace(euclidean1DVector37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D2.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D3, (double) (short) 100, vector3D5);
        double double7 = vector3D6.getY();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D0, vector3D6);
        double double9 = vector3D8.getDelta();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) (-6), 9.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double2 = org.apache.commons.math3.util.Precision.round(30.181160530068937d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.181160530068937d + "'", double2 == 30.181160530068937d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane3 = subLine2.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion4 = subLine2.getRemainingRegion();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane5 = subLine2.copySelf();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane6 = euclidean2DAbstractSubHyperplane5.getHyperplane();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane7 = euclidean2DAbstractSubHyperplane5.copySelf();
        org.junit.Assert.assertNull(euclidean2DHyperplane3);
        org.junit.Assert.assertNull(euclidean1DRegion4);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane5);
        org.junit.Assert.assertNull(euclidean2DHyperplane6);
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100L, 0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(Double.NaN, vector3D1, (double) (byte) 100, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = vector3D7.scalarMultiply((double) (short) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100L, 0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(Double.NaN, vector3D11, (double) (byte) 100, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D15.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D9.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D15);
        double double19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.dotProduct(vector3D1, vector3D15);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str1 = vector1D0.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D2, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = orientedPoint4.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform6 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion7 = intervalsSet5.applyTransform(euclidean1DTransform6);
        double double8 = euclidean1DAbstractRegion7.getSize();
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DHyperplane9 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion10 = null;
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint11 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint(euclidean1DHyperplane9, euclidean1DRegion10);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane12 = subOrientedPoint11.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane13 = euclidean1DAbstractSubHyperplane12.copySelf();
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DSubHyperplane14 = euclidean1DAbstractRegion7.intersection((org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractSubHyperplane13);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane15 = euclidean1DAbstractSubHyperplane13.copySelf();
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractSubHyperplane16 = euclidean1DAbstractSubHyperplane15.copySelf();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{(NaN)}" + "'", str1.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(intervalsSet5);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.POSITIVE_INFINITY + "'", double8 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane12);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane13);
        org.junit.Assert.assertNotNull(euclidean1DSubHyperplane14);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane15);
        org.junit.Assert.assertNotNull(euclidean1DAbstractSubHyperplane16);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double2 = org.apache.commons.math3.util.FastMath.max(4.041932724685649d, (-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.041932724685649d + "'", double2 == 4.041932724685649d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D2.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D3, (double) (short) 100, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D3);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        java.lang.String str9 = vector3D8.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.crossProduct(vector3D7, vector3D8);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{0; 0; 0}" + "'", str9.equals("{0; 0; 0}"));
        org.junit.Assert.assertNotNull(vector3D10);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double[] doubleArray4 = new double[] { (byte) 0, (-1L), 100L };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray4, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray7);
        double[] doubleArray13 = new double[] { (byte) 0, (-1L), 100L };
        double double14 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray13, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray16);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray7, doubleArray16);
        double[] doubleArray22 = new double[] { (byte) 0, (-1L), 100L };
        double double23 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray22, 0.0d);
        double[] doubleArray29 = new double[] { (byte) 0, (-1L), 100L };
        double double30 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray29, 0.0d);
        double double33 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray25, doubleArray29);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray16, doubleArray25);
        double[] doubleArray39 = new double[] { (byte) 0, (-1L), 100L };
        double double40 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray42);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray16, doubleArray42);
        double[] doubleArray49 = new double[] { (byte) 0, (-1L), 100L };
        double double50 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray49, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray52);
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray52);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray44, doubleArray52);
        double[] doubleArray59 = new double[] { (byte) 0, (-1L), 100L };
        double double60 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray59);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray59, 0.0d);
        double double63 = org.apache.commons.math3.util.MathArrays.distance(doubleArray44, doubleArray59);
        double[] doubleArray68 = new double[] { (byte) 0, (-1L), 100L };
        double double69 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray68);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray68, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray71);
        double[] doubleArray77 = new double[] { (byte) 0, (-1L), 100L };
        double double78 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray77);
        double[] doubleArray80 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray77, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray80);
        double[] doubleArray82 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray71, doubleArray80);
        double[] doubleArray86 = new double[] { (byte) 0, (-1L), 100L };
        double double87 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray86);
        double[] doubleArray89 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray86, 0.0d);
        double[] doubleArray93 = new double[] { (byte) 0, (-1L), 100L };
        double double94 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray93);
        double[] doubleArray96 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray93, 0.0d);
        double double97 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray89, doubleArray93);
        double[] doubleArray98 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray80, doubleArray89);
        double[] doubleArray99 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray59, doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.00499987500625d + "'", double5 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.00499987500625d + "'", double14 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.00499987500625d + "'", double23 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.00499987500625d + "'", double30 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.00499987500625d + "'", double40 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.00499987500625d + "'", double50 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 100.00499987500625d + "'", double60 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 100.00499987500625d + "'", double63 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 100.00499987500625d + "'", double69 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 100.00499987500625d + "'", double78 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 100.00499987500625d + "'", double87 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 100.00499987500625d + "'", double94 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray98);
        org.junit.Assert.assertNotNull(doubleArray99);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(100.0f, (float) (short) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray2 = new double[] { 4.041932724685649d, (-3.7474671492307516d) };
        double[] doubleArray4 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray2, 0);
        double[] doubleArray9 = new double[] { (byte) 0, (-1L), 100L };
        double double10 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray9, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 0, (-1L), 100L };
        double double19 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray18);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray18, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray21);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray12, doubleArray21);
        double[] doubleArray27 = new double[] { (byte) 0, (-1L), 100L };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray32 = new double[] { (byte) 0, (-1L), 100L };
        double double33 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray32, 0.0d);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray27, doubleArray32);
        double[] doubleArray37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray21, doubleArray32);
        try {
            double double38 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray4, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.00499987500625d + "'", double10 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.00499987500625d + "'", double19 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.00499987500625d + "'", double33 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D1.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = vector1D6.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = vector1D10.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D7.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D15.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D19.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D16.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D12, (double) 10.0f, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = vector1D1.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = vector1D26.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = vector1D30.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D27.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = vector1D35.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D39.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = vector1D36.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D32, (double) 10.0f, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = vector1D32.normalize();
        double double44 = vector1D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        double double45 = vector1D32.getNormInf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = vector1D48.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = vector1D52.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = vector1D49.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = vector1D57.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = vector1D61.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = vector1D58.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D61);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D54, (double) 10.0f, vector1D63);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str67 = vector1D66.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = vector1D66.negate();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = vector1D54.add((double) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D66);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = vector1D72.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = vector1D76.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = vector1D73.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D76);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D79 = vector1D66.subtract(4.041932724685649d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D73);
        boolean boolean80 = vector1D79.isInfinite();
        double double81 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D32, vector1D79);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D83 = vector1D32.scalarMultiply((double) 100);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector84 = null;
        try {
            double double85 = vector1D32.distanceInf(euclidean1DVector84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-37.474671492307515d) + "'", double44 == (-37.474671492307515d));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 3.7474671492307516d + "'", double45 == 3.7474671492307516d);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D58);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "{(NaN)}" + "'", str67.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertNotNull(vector1D73);
        org.junit.Assert.assertNotNull(vector1D77);
        org.junit.Assert.assertNotNull(vector1D78);
        org.junit.Assert.assertNotNull(vector1D79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertEquals((double) double81, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D83);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(2.4081805928436055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double1 = vector3D0.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D6.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D7, (double) (short) 100, vector3D9);
        boolean boolean12 = vector3D7.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line13 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D4, vector3D7);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = line13.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D0.subtract(10.0d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = null;
        try {
            double double17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceSq(vector3D15, vector3D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double[] doubleArray0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(number1, (java.lang.Number) (-1.1752011936438014d), (int) 'a', orderDirection4, false);
        try {
            boolean boolean8 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray0, orderDirection4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D4, (double) (short) 100, vector3D6);
        boolean boolean9 = vector3D4.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line10 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D1, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D11.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = vector3D14.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D15, (double) (short) 100, vector3D17);
        boolean boolean20 = vector3D15.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line21 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D12, vector3D15);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = line21.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D23.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = vector3D26.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D27, (double) (short) 100, vector3D29);
        boolean boolean32 = vector3D27.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D24, vector3D27);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D34 = line21.closestPoint(line33);
        boolean boolean35 = line10.isSimilarTo(line21);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D37 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D41 = vector3D40.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D44 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D41, (double) (short) 100, vector3D43);
        boolean boolean45 = vector3D43.isInfinite();
        double double46 = vector3D43.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D48 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        java.lang.String str49 = vector3D48.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D50 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D37, (double) 100, vector3D43, 0.0d, vector3D48);
        java.lang.String str51 = vector3D37.toString();
        double double52 = line10.distance(vector3D37);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D53 = line10.getOrigin();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D27);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(vector3D34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(vector3D37);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertNotNull(vector3D41);
        org.junit.Assert.assertNotNull(vector3D43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{0; 0; 0}" + "'", str49.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{0; 0; -1}" + "'", str51.equals("{0; 0; -1}"));
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D53);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 5.0d, false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double6 = vector2D5.getY();
        double double7 = vector2D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        double double8 = vector2D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double12 = vector2D11.getY();
        double double13 = vector2D10.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double14 = vector2D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double15 = vector2D5.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double20 = vector2D19.getY();
        double double21 = vector2D18.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double22 = vector2D17.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double26 = vector2D25.getY();
        double double27 = vector2D24.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        double double28 = vector2D23.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        double double29 = vector2D23.getNorm();
        double double30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D17, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D1, (double) '4', vector2D9, (double) 3, vector2D17);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double33 = vector2D32.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D17, vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Line line35 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = line34.intersection(line35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) '4', 4.578239276804769E-18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (byte) 100);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = vector1D1.scalarMultiply(32.0d);
        org.junit.Assert.assertNotNull(vector1D3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double[] doubleArray4 = new double[] { (byte) 0, (-1L), 100L };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray4, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray7);
        double[] doubleArray13 = new double[] { (byte) 0, (-1L), 100L };
        double double14 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray13, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray16);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray7, doubleArray16);
        double[] doubleArray22 = new double[] { (byte) 0, (-1L), 100L };
        double double23 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray22, 0.0d);
        double[] doubleArray29 = new double[] { (byte) 0, (-1L), 100L };
        double double30 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray29, 0.0d);
        double double33 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray25, doubleArray29);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray16, doubleArray25);
        double[] doubleArray39 = new double[] { (byte) 0, (-1L), 100L };
        double double40 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray42);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray16, doubleArray42);
        double[] doubleArray49 = new double[] { (byte) 0, (-1L), 100L };
        double double50 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray49);
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray49, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray52);
        double double54 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray52);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.convolve(doubleArray44, doubleArray52);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (0 >= -0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.00499987500625d + "'", double5 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.00499987500625d + "'", double14 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.00499987500625d + "'", double23 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.00499987500625d + "'", double30 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.00499987500625d + "'", double40 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 100.00499987500625d + "'", double50 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree0 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = spaceBSPTree0.getMinus();
        int[] intArray4 = new int[] { (short) 10, 0 };
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray4);
        int[] intArray8 = new int[] { (short) 10, 0 };
        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8);
        int int10 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray8);
        int[] intArray11 = org.apache.commons.math3.util.MathArrays.copyOf(intArray8);
        int[] intArray14 = new int[] { (short) 10, 0 };
        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray14);
        int[] intArray18 = new int[] { (short) 10, 0 };
        int[] intArray19 = org.apache.commons.math3.util.MathArrays.copyOf(intArray18);
        double double20 = org.apache.commons.math3.util.MathArrays.distance(intArray14, intArray18);
        int int21 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray8, intArray14);
        try {
            spaceBSPTree1.setAttribute((java.lang.Object) int21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(spaceBSPTree1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree2 = intervalsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree5 = intervalsSet3.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet6 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree5);
        boolean boolean7 = intervalsSet0.isEmpty(euclidean1DBSPTree5);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree2);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        long long2 = org.apache.commons.math3.util.FastMath.min(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(100.00001f, 0.0f, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.scalarMultiply((double) (short) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100L, 0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(Double.NaN, vector3D5, (double) (byte) 100, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D9.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D3.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        double double15 = vector3D12.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D14);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(97.0d, (double) 5);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(97.0d, (double) 5);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector6 = intervalsSet5.getBarycenter();
        boolean boolean7 = intervalsSet2.contains((org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) intervalsSet5);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str9 = vector1D8.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = vector1D8.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint12 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D10, false);
        orientedPoint12.revertSelf();
        boolean boolean14 = orientedPoint12.isDirect();
        org.apache.commons.math3.geometry.partitioning.Side side15 = intervalsSet2.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint12);
        org.junit.Assert.assertNotNull(euclidean1DVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{(NaN)}" + "'", str9.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + side15 + "' != '" + org.apache.commons.math3.geometry.partitioning.Side.PLUS + "'", side15.equals(org.apache.commons.math3.geometry.partitioning.Side.PLUS));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double[] doubleArray3 = new double[] { (byte) 0, (-1L), 100L };
        double double4 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray3);
        double[] doubleArray8 = new double[] { (byte) 0, (-1L), 100L };
        double double9 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, 0.0d);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray3, doubleArray8);
        double double13 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        double[] doubleArray17 = new double[] { (byte) 0, (-1L), 100L };
        double double18 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray17);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray8, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray19, 1);
        double[] doubleArray27 = new double[] { (byte) 0, (-1L), 100L };
        double double28 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray27, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray30);
        double[] doubleArray36 = new double[] { (byte) 0, (-1L), 100L };
        double double37 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray36, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray39);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray30, doubleArray39);
        double[] doubleArray45 = new double[] { (byte) 0, (-1L), 100L };
        double double46 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray45);
        double[] doubleArray50 = new double[] { (byte) 0, (-1L), 100L };
        double double51 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray50);
        double[] doubleArray53 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray50, 0.0d);
        double[] doubleArray54 = org.apache.commons.math3.util.MathArrays.ebeMultiply(doubleArray45, doubleArray50);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray39, doubleArray50);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.scale((-1.1752011936438014d), doubleArray39);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D57 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(doubleArray56);
        double[] doubleArray61 = new double[] { (byte) 0, (-1L), 100L };
        double double62 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray61);
        double double63 = org.apache.commons.math3.util.MathArrays.distance(doubleArray56, doubleArray61);
        double[] doubleArray67 = new double[] { (byte) 0, (-1L), 100L };
        double double68 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray67);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray67, 0.0d);
        double[] doubleArray74 = new double[] { (byte) 0, (-1L), 100L };
        double double75 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray74);
        double[] doubleArray77 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray74, 0.0d);
        double double78 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray70, doubleArray74);
        double[] doubleArray82 = new double[] { (byte) 0, (-1L), 100L };
        double double83 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray82);
        double[] doubleArray85 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray82, 0.0d);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray70, doubleArray82);
        boolean boolean87 = org.apache.commons.math3.util.MathArrays.equals(doubleArray56, doubleArray70);
        try {
            double double88 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray21, doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.00499987500625d + "'", double4 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.00499987500625d + "'", double9 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.00499987500625d + "'", double13 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.00499987500625d + "'", double18 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.00499987500625d + "'", double37 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 100.00499987500625d + "'", double46 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.00499987500625d + "'", double51 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 100.00499987500625d + "'", double62 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 100.00499987500625d + "'", double63 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.00499987500625d + "'", double68 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 100.00499987500625d + "'", double75 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 100.00499987500625d + "'", double83 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double8 = vector2D7.getY();
        double double9 = vector2D6.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double10 = vector2D5.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double14 = vector2D13.getY();
        double double15 = vector2D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double16 = vector2D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double17 = vector2D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double22 = vector2D21.getY();
        double double23 = vector2D20.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double24 = vector2D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double28 = vector2D27.getY();
        double double29 = vector2D26.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double30 = vector2D25.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double31 = vector2D25.getNorm();
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D19, vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D3, (double) '4', vector2D11, (double) 3, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D11);
        double double35 = line34.getOriginOffset();
        double double36 = line34.getAngle();
        double double37 = line34.getOriginOffset();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree39 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double46 = vector2D45.getY();
        double double47 = vector2D44.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D45);
        double double48 = vector2D43.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D45);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double52 = vector2D51.getY();
        double double53 = vector2D50.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        double double54 = vector2D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        double double55 = vector2D45.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D58 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double60 = vector2D59.getY();
        double double61 = vector2D58.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D59);
        double double62 = vector2D57.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D59);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double66 = vector2D65.getY();
        double double67 = vector2D64.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D65);
        double double68 = vector2D63.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D65);
        double double69 = vector2D63.getNorm();
        double double70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D57, vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D71 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D41, (double) '4', vector2D49, (double) 3, vector2D57);
        org.apache.commons.math3.geometry.euclidean.twod.Line line72 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D38, vector2D49);
        double double73 = line72.getOriginOffset();
        double double74 = line72.getAngle();
        boolean boolean75 = line34.isParallelTo(line72);
        org.apache.commons.math3.geometry.euclidean.twod.Line line76 = null;
        try {
            double double77 = line72.getOffset(line76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertNotNull(vector2D44);
        org.junit.Assert.assertNotNull(vector2D45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertNotNull(vector2D58);
        org.junit.Assert.assertNotNull(vector2D59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.scalarMultiply((double) (short) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100L, 0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(Double.NaN, vector3D5, (double) (byte) 100, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D9.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D3.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D12);
        double double14 = vector3D13.getY();
        double double15 = vector3D13.getY();
        double double16 = vector3D13.getAlpha();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 17.722797438841557d + "'", double14 == 17.722797438841557d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 17.722797438841557d + "'", double15 == 17.722797438841557d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.6106277387164094d + "'", double16 == 2.6106277387164094d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D0.scalarMultiply((double) (short) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        boolean boolean5 = vector3D4.isNaN();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = vector3D4.negate();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = vector3D2.add(Double.POSITIVE_INFINITY, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D11.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double15 = vector3D14.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D9, Double.NEGATIVE_INFINITY, vector3D11, (double) (byte) 0, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.Line line17 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D7, vector3D14);
        org.apache.commons.math3.geometry.euclidean.threed.SubLine subLine18 = line17.wholeLine();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
        org.junit.Assert.assertNotNull(subLine18);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(3.831008000716577E22d, (-2));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.577520001791442E21d + "'", double2 == 9.577520001791442E21d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, 11013.232874703393d, (double) '#');
        double double4 = vector3D3.getZ();
        double double5 = vector3D3.getX();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double3 = vector2D2.getY();
        double double4 = vector2D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree6 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D5);
        boolean boolean8 = vector2D5.equals((java.lang.Object) 7.896296018268069E13d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D2.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree12 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double19 = vector2D18.getY();
        double double20 = vector2D17.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        double double21 = vector2D16.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D22 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double25 = vector2D24.getY();
        double double26 = vector2D23.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        double double27 = vector2D22.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D24);
        double double28 = vector2D18.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D22);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double33 = vector2D32.getY();
        double double34 = vector2D31.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        double double35 = vector2D30.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D32);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double39 = vector2D38.getY();
        double double40 = vector2D37.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        double double41 = vector2D36.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        double double42 = vector2D36.getNorm();
        double double43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D30, vector2D36);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D44 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D14, (double) '4', vector2D22, (double) 3, vector2D30);
        org.apache.commons.math3.geometry.euclidean.twod.Line line45 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D11, vector2D22);
        double double46 = line45.getOriginOffset();
        double double47 = line45.getAngle();
        double double48 = line45.getOriginOffset();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree50 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D49);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double57 = vector2D56.getY();
        double double58 = vector2D55.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        double double59 = vector2D54.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D56);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D61 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double63 = vector2D62.getY();
        double double64 = vector2D61.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        double double65 = vector2D60.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D62);
        double double66 = vector2D56.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double71 = vector2D70.getY();
        double double72 = vector2D69.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        double double73 = vector2D68.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D76 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double77 = vector2D76.getY();
        double double78 = vector2D75.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D76);
        double double79 = vector2D74.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D76);
        double double80 = vector2D74.getNorm();
        double double81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D68, vector2D74);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D82 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D52, (double) '4', vector2D60, (double) 3, vector2D68);
        org.apache.commons.math3.geometry.euclidean.twod.Line line83 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D49, vector2D60);
        double double84 = line83.getOriginOffset();
        double double85 = line83.getAngle();
        boolean boolean86 = line45.isParallelTo(line83);
        double double87 = line83.getOriginOffset();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D88 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D89 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D90 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double91 = vector2D90.getY();
        double double92 = vector2D89.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D90);
        double double93 = vector2D88.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D90);
        double double94 = line83.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D90);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D95 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 5, vector2D5, 13.74746714923075d, vector2D90);
        java.lang.Object obj96 = null;
        boolean boolean97 = vector2D5.equals(obj96);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D22);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D60);
        org.junit.Assert.assertNotNull(vector2D61);
        org.junit.Assert.assertNotNull(vector2D62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertNotNull(vector2D76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D88);
        org.junit.Assert.assertNotNull(vector2D89);
        org.junit.Assert.assertNotNull(vector2D90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane3 = subLine2.copySelf();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree5 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double12 = vector2D11.getY();
        double double13 = vector2D10.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double14 = vector2D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double18 = vector2D17.getY();
        double double19 = vector2D16.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double20 = vector2D15.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D17);
        double double21 = vector2D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double26 = vector2D25.getY();
        double double27 = vector2D24.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        double double28 = vector2D23.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D29 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double32 = vector2D31.getY();
        double double33 = vector2D30.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double34 = vector2D29.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D31);
        double double35 = vector2D29.getNorm();
        double double36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D23, vector2D29);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D7, (double) '4', vector2D15, (double) 3, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Line line38 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D4, vector2D15);
        double double39 = line38.getOriginOffset();
        double double40 = line38.getAngle();
        double double41 = line38.getOriginOffset();
        try {
            org.apache.commons.math3.geometry.partitioning.Side side42 = subLine2.side((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) line38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D29);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet0 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree2 = intervalsSet0.getTree(false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet3 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree2);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet4 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree2);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(euclidean1DBSPTree2);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double2 = org.apache.commons.math3.util.FastMath.max(1.579259203653617E14d, 0.9149994957367078d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.579259203653617E14d + "'", double2 == 1.579259203653617E14d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D4, (double) (short) 100, vector3D6);
        boolean boolean9 = vector3D4.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line10 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D1, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = line10.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D16, (double) (short) 100, vector3D18);
        boolean boolean21 = vector3D16.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = line10.closestPoint(line22);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = line10.getDirection();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 35L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double2 = vector2D1.getY();
        double double3 = vector2D0.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        double double4 = vector2D1.getNorm1();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double8 = vector2D7.getY();
        double double9 = vector2D6.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double10 = vector2D5.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double14 = vector2D13.getY();
        double double15 = vector2D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double16 = vector2D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double17 = vector2D11.getNorm();
        double double18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D5, vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double21 = vector2D20.getY();
        double double22 = vector2D19.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = vector2D11.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D20);
        double double24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceInf(vector2D1, vector2D11);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray4 = new double[] { (byte) 0, (-1L), 100L };
        double double5 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray4, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray7);
        double[] doubleArray13 = new double[] { (byte) 0, (-1L), 100L };
        double double14 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray13);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray13, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray16);
        double[] doubleArray18 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray7, doubleArray16);
        double[] doubleArray22 = new double[] { (byte) 0, (-1L), 100L };
        double double23 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray22, 0.0d);
        double[] doubleArray29 = new double[] { (byte) 0, (-1L), 100L };
        double double30 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray29, 0.0d);
        double double33 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray25, doubleArray29);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray16, doubleArray25);
        double[] doubleArray39 = new double[] { (byte) 0, (-1L), 100L };
        double double40 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, 0.0d);
        org.apache.commons.math3.util.MathArrays.scaleInPlace((double) 10L, doubleArray42);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(doubleArray16, doubleArray42);
        double[][] doubleArray45 = new double[][] {};
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray44, doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.00499987500625d + "'", double5 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.00499987500625d + "'", double14 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.00499987500625d + "'", double23 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.00499987500625d + "'", double30 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.00499987500625d + "'", double40 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = vector1D3.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = vector1D7.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = vector1D4.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D7);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D13 = vector1D12.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D16.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = vector1D13.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D16);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D9, (double) 10.0f, vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 3, vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = vector1D22.normalize();
        double double24 = vector1D19.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D22);
        java.lang.String str25 = vector1D22.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = vector1D22.scalarMultiply(0.40107661044664544d);
        org.junit.Assert.assertNotNull(vector1D4);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D9);
        org.junit.Assert.assertNotNull(vector1D13);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D18);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 51.222138641538265d + "'", double24 == 51.222138641538265d);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{10}" + "'", str25.equals("{10}"));
        org.junit.Assert.assertNotNull(vector1D27);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D5, (double) (short) 100, vector3D7);
        boolean boolean9 = vector3D7.isInfinite();
        double double10 = vector3D7.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        java.lang.String str13 = vector3D12.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D1, (double) 100, vector3D7, 0.0d, vector3D12);
        java.lang.String str15 = vector3D1.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D16.scalarMultiply((double) (short) 10);
        double double19 = vector3D1.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D18);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D22.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D23, (double) (short) 100, vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D27 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D30 = vector3D29.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D30, (double) (short) 100, vector3D32);
        boolean boolean35 = vector3D30.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = vector3D23.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        double double37 = vector3D1.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D30);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{0; 0; 0}" + "'", str13.equals("{0; 0; 0}"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0; 0; -1}" + "'", str15.equals("{0; 0; -1}"));
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D30);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(vector3D36);
        org.junit.Assert.assertEquals((double) double37, Double.NaN, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (byte) 1, (-17));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(100.0f, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D1.scalarMultiply((double) (short) 10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100L, 0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(Double.NaN, vector3D5, (double) (byte) 100, vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D9.orthogonal();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = vector3D3.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D9);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D12);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D13.normalize();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D14);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double7 = vector3D6.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1, Double.NEGATIVE_INFINITY, vector3D3, (double) (byte) 0, vector3D6);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = vector3D9.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D8.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.orthogonal();
        double double14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D10, vector3D13);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = vector3D17.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D18, (double) (short) 100, vector3D20);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D18);
        double double23 = vector3D18.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.PLUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D18.add((double) 100, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D25);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D28 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = vector3D28.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D31 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D29, (double) (short) 100, vector3D31);
        org.apache.commons.math3.geometry.euclidean.threed.Line line33 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D18, vector3D29);
        double double34 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance(vector3D10, vector3D29);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = vector3D29.getZero();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertNotNull(vector3D20);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertNotNull(vector3D28);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D31);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D35);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100L, 0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(Double.NaN, vector3D1, (double) (byte) 100, vector3D5);
        double[] doubleArray7 = vector3D1.toArray();
        double[] doubleArray11 = new double[] { (byte) 0, (-1L), 100L };
        double double12 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray11, 0.0d);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray7, doubleArray11);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection16 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray15, orderDirection16, false);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.00499987500625d + "'", double12 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection16.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.371095219025714E7d + "'", double1 == 3.371095219025714E7d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644298430695373d + "'", double1 == 4.644298430695373d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double[] doubleArray3 = new double[] { (byte) 0, (-1L), 100L };
        double double4 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray3);
        double[] doubleArray8 = new double[] { (byte) 0, (-1L), 100L };
        double double9 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, 0.0d);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.ebeDivide(doubleArray3, doubleArray8);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.00499987500625d + "'", double4 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.00499987500625d + "'", double9 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 100L, 0.0d);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(Double.NaN, vector3D1, (double) (byte) 100, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double8 = vector3D7.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D9 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = vector3D9.scalarMultiply((double) (short) 10);
        double double12 = vector3D7.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D11);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D16.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double20 = vector3D19.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D21 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D14, Double.NEGATIVE_INFINITY, vector3D16, (double) (byte) 0, vector3D19);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D22 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = vector3D22.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = vector3D21.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_I;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D25.orthogonal();
        double double27 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.angle(vector3D23, vector3D26);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D29 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D32 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D33 = vector3D32.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D35 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D36 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D33, (double) (short) 100, vector3D35);
        boolean boolean37 = vector3D35.isInfinite();
        double double38 = vector3D35.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D40 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        java.lang.String str41 = vector3D40.toString();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D42 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(0.0d, vector3D29, (double) 100, vector3D35, 0.0d, vector3D40);
        double double43 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance(vector3D23, vector3D42);
        double double44 = vector3D7.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D45 = vector3D1.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D7);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D9);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D22);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D25);
        org.junit.Assert.assertNotNull(vector3D26);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D29);
        org.junit.Assert.assertNotNull(vector3D32);
        org.junit.Assert.assertNotNull(vector3D33);
        org.junit.Assert.assertNotNull(vector3D35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(vector3D40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "{0; 0; 0}" + "'", str41.equals("{0; 0; 0}"));
        org.junit.Assert.assertEquals((double) double43, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double44, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector3D45);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = vector1D2.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = vector1D6.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = vector1D3.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D6);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D11.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D15.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D12.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D8, (double) 10.0f, vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str21 = vector1D20.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = vector1D20.negate();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = vector1D8.add((double) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = vector1D20.scalarMultiply(4.644298430695373d);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{(NaN)}" + "'", str21.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D22);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D25);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double7 = vector3D6.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) 0, vector3D1, Double.NEGATIVE_INFINITY, vector3D3, (double) (byte) 0, vector3D6);
        double double9 = vector3D8.getNorm();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0d) + "'", double7 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.POSITIVE_INFINITY + "'", double9 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (-0.1f), true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) 100, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        double double2 = vector1D1.getNormInf();
        java.lang.String str3 = vector1D1.toString();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector4 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D1.subtract(euclidean1DVector4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{10}" + "'", str3.equals("{10}"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str1 = vector1D0.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D2, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet5 = orientedPoint4.wholeSpace();
        double double6 = intervalsSet5.getSup();
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion7 = intervalsSet5.copySelf();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{(NaN)}" + "'", str1.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(intervalsSet5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(97.0d, (double) 5);
        double double3 = intervalsSet2.getSup();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector4 = intervalsSet2.getBarycenter();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.0d + "'", double3 == 5.0d);
        org.junit.Assert.assertNotNull(euclidean1DVector4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (-6));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 201.7156361224559d + "'", double1 == 201.7156361224559d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double3 = vector3D2.getZ();
        org.apache.commons.math3.geometry.Space space4 = vector3D2.getSpace();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = vector3D7.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D10 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D8, (double) (short) 100, vector3D10);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D8);
        double double13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D2, vector3D8);
        double double14 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distanceInf(vector3D1, vector3D8);
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
        org.junit.Assert.assertNotNull(space4);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertNotNull(vector3D8);
        org.junit.Assert.assertNotNull(vector3D10);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.ZERO;
        boolean boolean2 = vector1D0.equals((java.lang.Object) '4');
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D3 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str4 = vector1D3.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D5 = vector1D3.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint7 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D5, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D9 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = vector1D9.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D14 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = vector1D14.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D18 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = vector1D18.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D15.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D18);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = vector1D23.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = vector1D27.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D29 = vector1D24.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D27);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D20, (double) 10.0f, vector1D29);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = vector1D9.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D20);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D34 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = vector1D34.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D38 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = vector1D38.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D35.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D38);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = vector1D43.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = vector1D47.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = vector1D44.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D40, (double) 10.0f, vector1D49);
        double double51 = vector1D20.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        double double52 = orientedPoint7.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D50);
        double double53 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.distance(vector1D0, vector1D50);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D56 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = vector1D56.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D61 = vector1D60.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = vector1D57.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D60);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D66 = vector1D65.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = vector1D69.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D71 = vector1D66.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D69);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D72 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D62, (double) 10.0f, vector1D71);
        org.apache.commons.math3.geometry.Space space73 = vector1D62.getSpace();
        boolean boolean74 = vector1D62.isNaN();
        double double75 = vector1D62.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D76 = vector1D50.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D62);
        org.apache.commons.math3.geometry.Space space77 = vector1D50.getSpace();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(vector1D3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{(NaN)}" + "'", str4.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D5);
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertNotNull(vector1D15);
        org.junit.Assert.assertNotNull(vector1D19);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D24);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D29);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D35);
        org.junit.Assert.assertNotNull(vector1D39);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D48);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 37.474671492307515d + "'", double51 == 37.474671492307515d);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 41.222138641538265d + "'", double53 == 41.222138641538265d);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertNotNull(vector1D61);
        org.junit.Assert.assertNotNull(vector1D62);
        org.junit.Assert.assertNotNull(vector1D66);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertNotNull(vector1D71);
        org.junit.Assert.assertNotNull(space73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + (-3.7474671492307516d) + "'", double75 == (-3.7474671492307516d));
        org.junit.Assert.assertNotNull(vector1D76);
        org.junit.Assert.assertNotNull(space77);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        long long1 = org.apache.commons.math3.util.FastMath.round(3.0000000000000004d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1.0f), 0.10517091972248063d, 0.10517091972248063d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.MINUS_K;
        double double1 = vector3D0.getZ();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D2.scalarMultiply((double) (short) 10);
        double double5 = vector3D0.distanceSq((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.threed.Euclidean3D>) vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = null;
        try {
            double double7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.distance(vector3D0, vector3D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = vector3D1.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = vector3D4.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D8 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D5, (double) (short) 100, vector3D7);
        boolean boolean10 = vector3D5.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line11 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D2, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = line11.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D14 = vector3D13.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D17 = vector3D16.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D20 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D17, (double) (short) 100, vector3D19);
        boolean boolean22 = vector3D17.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line23 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D14, vector3D17);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D24 = line11.closestPoint(line23);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D25 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(7.896296018268084E13d, vector3D24);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D26 = vector3D25.orthogonal();
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(vector3D7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D14);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D17);
        org.junit.Assert.assertNotNull(vector3D19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(vector3D24);
        org.junit.Assert.assertNotNull(vector3D26);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 3, (short) 1, (byte) 100, (short) 10, 0.0f, (-1.0d) };
        org.apache.commons.math3.exception.MathInternalError mathInternalError10 = new org.apache.commons.math3.exception.MathInternalError(localizable2, objArray9);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException11 = new org.apache.commons.math3.exception.MathArithmeticException(localizable1, objArray9);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException12 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, objArray9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = mathArithmeticException12.getContext();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(exceptionContext13);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D0);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree2 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        spaceBSPTree1.insertInTree(spaceBSPTree2, true);
        java.lang.Object obj5 = spaceBSPTree2.getAttribute();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.Space> spaceVector6 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree7 = spaceBSPTree2.getCell(spaceVector6);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(spaceBSPTree7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = null;
        try {
            org.apache.commons.math3.geometry.euclidean.twod.Line line2 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(vector2D0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException2 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D1 = vector3D0.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D4 = vector3D3.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D4, (double) (short) 100, vector3D6);
        boolean boolean9 = vector3D4.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line10 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D1, vector3D4);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D11 = line10.getDirection();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D12 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D13 = vector3D12.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D15 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D16 = vector3D15.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D18 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D19 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D16, (double) (short) 100, vector3D18);
        boolean boolean21 = vector3D16.equals((java.lang.Object) 100);
        org.apache.commons.math3.geometry.euclidean.threed.Line line22 = new org.apache.commons.math3.geometry.euclidean.threed.Line(vector3D13, vector3D16);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D23 = line10.closestPoint(line22);
        org.apache.commons.math3.geometry.euclidean.threed.Line line24 = line10.revert();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertNotNull(vector3D1);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D4);
        org.junit.Assert.assertNotNull(vector3D6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(vector3D11);
        org.junit.Assert.assertNotNull(vector3D12);
        org.junit.Assert.assertNotNull(vector3D13);
        org.junit.Assert.assertNotNull(vector3D15);
        org.junit.Assert.assertNotNull(vector3D16);
        org.junit.Assert.assertNotNull(vector3D18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(vector3D23);
        org.junit.Assert.assertNotNull(line24);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((-0.1f), (int) (byte) 100, (-3));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method -3, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = dimensionMismatchException2.getContext();
        java.lang.Number number4 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str1 = vector1D0.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D2, false);
        orientedPoint4.revertSelf();
        orientedPoint4.revertSelf();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = orientedPoint4.getLocation();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D8 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str9 = vector1D8.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = vector1D8.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint12 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D10, false);
        orientedPoint12.revertSelf();
        boolean boolean14 = orientedPoint4.sameOrientationAs((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint12);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint15 = orientedPoint4.wholeHyperplane();
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{(NaN)}" + "'", str1.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{(NaN)}" + "'", str9.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(subOrientedPoint15);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        float float3 = org.apache.commons.math3.util.Precision.round((float) 10, 2, 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 10.01f + "'", float3 == 10.01f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        float float2 = org.apache.commons.math3.util.FastMath.min(0.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D0);
        org.apache.commons.math3.geometry.euclidean.twod.Line line3 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, 0.023577388297507898d);
        org.junit.Assert.assertNotNull(vector2D0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double3 = vector2D2.getY();
        double double4 = vector2D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        double double5 = vector2D0.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double9 = vector2D8.getY();
        double double10 = vector2D7.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        double double11 = vector2D6.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D8);
        double double12 = vector2D2.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D6);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D14 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D15 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double16 = vector2D15.getY();
        double double17 = vector2D14.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        double double18 = vector2D13.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D15);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double22 = vector2D21.getY();
        double double23 = vector2D20.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double24 = vector2D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double25 = vector2D19.getNorm();
        double double26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D13, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double29 = vector2D28.getY();
        double double30 = vector2D27.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = vector2D19.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D28);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D35 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double38 = vector2D37.getY();
        double double39 = vector2D36.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        double double40 = vector2D35.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D42 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double44 = vector2D43.getY();
        double double45 = vector2D42.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double46 = vector2D41.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D43);
        double double47 = vector2D37.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D41);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D49 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D50 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D51 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double52 = vector2D51.getY();
        double double53 = vector2D50.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        double double54 = vector2D49.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D51);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D55 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D56 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D57 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double58 = vector2D57.getY();
        double double59 = vector2D56.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        double double60 = vector2D55.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D57);
        double double61 = vector2D55.getNorm();
        double double62 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D49, vector2D55);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D33, (double) '4', vector2D41, (double) 3, vector2D49);
        double double64 = vector2D19.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D63);
        org.apache.commons.math3.geometry.euclidean.twod.Line line65 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D2, vector2D63);
        boolean boolean66 = vector2D2.isInfinite();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D67 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D68 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D69 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double70 = vector2D69.getY();
        double double71 = vector2D68.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D69);
        double double72 = vector2D67.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D69);
        double double73 = vector2D67.getNorm();
        double double74 = vector2D2.distanceInf((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D67);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertNotNull(vector2D14);
        org.junit.Assert.assertNotNull(vector2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D31);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D35);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertNotNull(vector2D42);
        org.junit.Assert.assertNotNull(vector2D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D49);
        org.junit.Assert.assertNotNull(vector2D50);
        org.junit.Assert.assertNotNull(vector2D51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D55);
        org.junit.Assert.assertNotNull(vector2D56);
        org.junit.Assert.assertNotNull(vector2D57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(vector2D67);
        org.junit.Assert.assertNotNull(vector2D68);
        org.junit.Assert.assertNotNull(vector2D69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(3.371095219025714E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.02648051389328d + "'", double1 == 18.02648051389328d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.62939453139803E-6d + "'", double1 == 7.62939453139803E-6d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 2, (-1023));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        long[] longArray4 = new long[] { 0L, (byte) 0, 0L, (byte) 100 };
        long[] longArray9 = new long[] { 0L, (byte) 0, 0L, (byte) 100 };
        long[] longArray14 = new long[] { 0L, (byte) 0, 0L, (byte) 100 };
        long[] longArray19 = new long[] { 0L, (byte) 0, 0L, (byte) 100 };
        long[] longArray24 = new long[] { 0L, (byte) 0, 0L, (byte) 100 };
        long[] longArray29 = new long[] { 0L, (byte) 0, 0L, (byte) 100 };
        long[][] longArray30 = new long[][] { longArray4, longArray9, longArray14, longArray19, longArray24, longArray29 };
        org.apache.commons.math3.util.MathArrays.checkNonNegative(longArray30);
        org.apache.commons.math3.util.MathArrays.checkRectangular(longArray30);
        org.junit.Assert.assertNotNull(longArray4);
        org.junit.Assert.assertNotNull(longArray9);
        org.junit.Assert.assertNotNull(longArray14);
        org.junit.Assert.assertNotNull(longArray19);
        org.junit.Assert.assertNotNull(longArray24);
        org.junit.Assert.assertNotNull(longArray29);
        org.junit.Assert.assertNotNull(longArray30);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double2 = vector2D1.getY();
        double double3 = vector2D0.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D1);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree5 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D4);
        boolean boolean7 = vector2D4.equals((java.lang.Object) 7.896296018268069E13d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = vector2D1.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = vector2D8.negate();
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(vector2D8);
        org.junit.Assert.assertNotNull(vector2D9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D2 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.NEGATIVE_INFINITY;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D3 = vector3D2.normalize();
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D5 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.ZERO;
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D6 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D(100.0d, vector3D3, (double) (short) 100, vector3D5);
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D7 = new org.apache.commons.math3.geometry.euclidean.threed.Vector3D((double) '#', vector3D3);
        org.apache.commons.math3.geometry.Space space8 = vector3D7.getSpace();
        org.junit.Assert.assertNotNull(vector3D2);
        org.junit.Assert.assertNotNull(vector3D3);
        org.junit.Assert.assertNotNull(vector3D5);
        org.junit.Assert.assertNotNull(space8);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D2 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double5 = vector2D4.getY();
        double double6 = vector2D3.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        double double7 = vector2D2.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D4);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D8 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(Double.POSITIVE_INFINITY, vector2D2);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double13 = vector2D12.getY();
        double double14 = vector2D11.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        double double15 = vector2D10.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D12);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D16 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double19 = vector2D18.getY();
        double double20 = vector2D17.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        double double21 = vector2D16.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D18);
        double double22 = vector2D16.getNorm();
        double double23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D10, vector2D16);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double26 = vector2D25.getY();
        double double27 = vector2D24.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D28 = vector2D16.subtract((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double35 = vector2D34.getY();
        double double36 = vector2D33.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        double double37 = vector2D32.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D38 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D39 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D40 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double41 = vector2D40.getY();
        double double42 = vector2D39.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        double double43 = vector2D38.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D40);
        double double44 = vector2D34.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D38);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D46 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D47 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D48 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double49 = vector2D48.getY();
        double double50 = vector2D47.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        double double51 = vector2D46.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D48);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D52 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D53 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D54 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double55 = vector2D54.getY();
        double double56 = vector2D53.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D54);
        double double57 = vector2D52.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D54);
        double double58 = vector2D52.getNorm();
        double double59 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D46, vector2D52);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D60 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D30, (double) '4', vector2D38, (double) 3, vector2D46);
        double double61 = vector2D16.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D60);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D63 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D64 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D65 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double66 = vector2D65.getY();
        double double67 = vector2D64.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D65);
        double double68 = vector2D63.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D65);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D70 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double71 = vector2D70.getY();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D72 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D((double) 10.0f, vector2D8, (double) (byte) 0, vector2D16, (double) (byte) 10, vector2D65, 7.896296018268084E13d, vector2D70);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D73 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D74 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D75 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double76 = vector2D75.getY();
        double double77 = vector2D74.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D75);
        double double78 = vector2D73.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D75);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D79 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D80 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D81 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double82 = vector2D81.getY();
        double double83 = vector2D80.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        double double84 = vector2D79.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D81);
        double double85 = vector2D75.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D79);
        double double86 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D72, vector2D79);
        double[] doubleArray87 = vector2D79.toArray();
        double double88 = vector2D79.getY();
        org.junit.Assert.assertNotNull(vector2D2);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D16);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D28);
        org.junit.Assert.assertNotNull(vector2D30);
        org.junit.Assert.assertNotNull(vector2D32);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D38);
        org.junit.Assert.assertNotNull(vector2D39);
        org.junit.Assert.assertNotNull(vector2D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D46);
        org.junit.Assert.assertNotNull(vector2D47);
        org.junit.Assert.assertNotNull(vector2D48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D52);
        org.junit.Assert.assertNotNull(vector2D53);
        org.junit.Assert.assertNotNull(vector2D54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D63);
        org.junit.Assert.assertNotNull(vector2D64);
        org.junit.Assert.assertNotNull(vector2D65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D73);
        org.junit.Assert.assertNotNull(vector2D74);
        org.junit.Assert.assertNotNull(vector2D75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D79);
        org.junit.Assert.assertNotNull(vector2D80);
        org.junit.Assert.assertNotNull(vector2D81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertEquals((double) double86, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math3.util.FastMath.cos(3.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9899924966004455d) + "'", double1 == (-0.9899924966004455d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D0 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree1 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D0);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D6 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D7 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double8 = vector2D7.getY();
        double double9 = vector2D6.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        double double10 = vector2D5.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D12 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D13 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double14 = vector2D13.getY();
        double double15 = vector2D12.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double16 = vector2D11.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D13);
        double double17 = vector2D7.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D20 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D21 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double22 = vector2D21.getY();
        double double23 = vector2D20.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        double double24 = vector2D19.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D21);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D26 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D27 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double28 = vector2D27.getY();
        double double29 = vector2D26.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double30 = vector2D25.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D27);
        double double31 = vector2D25.getNorm();
        double double32 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D19, vector2D25);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D3, (double) '4', vector2D11, (double) 3, vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Line line34 = new org.apache.commons.math3.geometry.euclidean.twod.Line(vector2D0, vector2D11);
        double double35 = line34.getOriginOffset();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D36 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NEGATIVE_INFINITY;
        line34.translateToPoint(vector2D36);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet40 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(97.0d, (double) 5);
        double double41 = intervalsSet40.getInf();
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DVector42 = intervalsSet40.getBarycenter();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D43 = line34.toSpace(euclidean1DVector42);
        org.junit.Assert.assertNotNull(vector2D0);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertNotNull(vector2D6);
        org.junit.Assert.assertNotNull(vector2D7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertNotNull(vector2D12);
        org.junit.Assert.assertNotNull(vector2D13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertNotNull(vector2D20);
        org.junit.Assert.assertNotNull(vector2D21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertNotNull(vector2D26);
        org.junit.Assert.assertNotNull(vector2D27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D36);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 97.0d + "'", double41 == 97.0d);
        org.junit.Assert.assertNotNull(euclidean1DVector42);
        org.junit.Assert.assertNotNull(vector2D43);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) mathIllegalStateException0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double2 = org.apache.commons.math3.util.FastMath.copySign((double) '4', 140.43510034563656d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> euclidean2DHyperplane0 = null;
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion1 = null;
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine2 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(euclidean2DHyperplane0, euclidean1DRegion1);
        org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean2DAbstractSubHyperplane3 = subLine2.copySelf();
        org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DRegion4 = euclidean2DAbstractSubHyperplane3.getRemainingRegion();
        try {
            double double5 = euclidean2DAbstractSubHyperplane3.getSize();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(euclidean2DAbstractSubHyperplane3);
        org.junit.Assert.assertNull(euclidean1DRegion4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 140.43510034563656d, (java.lang.Number) 0.0d, true);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) (short) -1);
        boolean boolean2 = vector1D1.isInfinite();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet2 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet(1.1102230246251565E-16d, (double) (byte) -1);
        boolean boolean3 = intervalsSet2.isEmpty();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D1 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.NaN;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D3 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D4 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D5 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double6 = vector2D5.getY();
        double double7 = vector2D4.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        double double8 = vector2D3.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D5);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D10 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D11 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double12 = vector2D11.getY();
        double double13 = vector2D10.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double14 = vector2D9.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D11);
        double double15 = vector2D5.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D9);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D17 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D18 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D19 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double20 = vector2D19.getY();
        double double21 = vector2D18.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        double double22 = vector2D17.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D19);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D23 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D24 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D25 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double26 = vector2D25.getY();
        double double27 = vector2D24.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        double double28 = vector2D23.distance((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D25);
        double double29 = vector2D23.getNorm();
        double double30 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.distanceSq(vector2D17, vector2D23);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D31 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(3.141592653589793d, vector2D1, (double) '4', vector2D9, (double) 3, vector2D17);
        double double32 = vector2D1.getX();
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D33 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D34 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        double double35 = vector2D34.getY();
        double double36 = vector2D33.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D37 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree38 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D37);
        boolean boolean40 = vector2D37.equals((java.lang.Object) 7.896296018268069E13d);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D41 = vector2D34.add((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D37);
        double double42 = vector2D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>) vector2D34);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D45 = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(Double.NEGATIVE_INFINITY, 41.222138641538265d);
        org.apache.commons.math3.geometry.euclidean.twod.SubLine subLine46 = new org.apache.commons.math3.geometry.euclidean.twod.SubLine(vector2D34, vector2D45);
        org.junit.Assert.assertNotNull(vector2D1);
        org.junit.Assert.assertNotNull(vector2D3);
        org.junit.Assert.assertNotNull(vector2D4);
        org.junit.Assert.assertNotNull(vector2D5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNotNull(vector2D10);
        org.junit.Assert.assertNotNull(vector2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D17);
        org.junit.Assert.assertNotNull(vector2D18);
        org.junit.Assert.assertNotNull(vector2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D23);
        org.junit.Assert.assertNotNull(vector2D24);
        org.junit.Assert.assertNotNull(vector2D25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector2D33);
        org.junit.Assert.assertNotNull(vector2D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(vector2D37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(vector2D41);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane0 = null;
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str2 = vector1D1.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D4 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        double double5 = vector1D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D4);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree6 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) double5);
        org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.Space> spaceVector7 = null;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree8 = spaceBSPTree6.getCell(spaceVector7);
        org.apache.commons.math3.geometry.euclidean.twod.Vector2D vector2D9 = org.apache.commons.math3.geometry.euclidean.twod.Vector2D.ZERO;
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree10 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>((java.lang.Object) vector2D9);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree11 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>();
        spaceBSPTree10.insertInTree(spaceBSPTree11, true);
        org.apache.commons.math3.geometry.partitioning.SubHyperplane<org.apache.commons.math3.geometry.Space> spaceSubHyperplane14 = spaceBSPTree10.getCut();
        float[] floatArray15 = null;
        float[] floatArray22 = new float[] { (byte) 1, (-1.0f), 100L, (-1L), (byte) 1, (byte) -1 };
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray15, floatArray22);
        float[] floatArray28 = new float[] { 10, (byte) 10, (byte) 0, 100L };
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(floatArray22, floatArray28);
        float[] floatArray34 = new float[] { 1, (short) 100, 1L, '#' };
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equals(floatArray22, floatArray34);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree36 = new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space>(spaceSubHyperplane0, spaceBSPTree6, spaceBSPTree10, (java.lang.Object) boolean35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D39.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = vector1D43.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D40.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D43);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D48 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = vector1D48.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = vector1D52.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = vector1D49.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D52);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D45, (double) 10.0f, vector1D54);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D57 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str58 = vector1D57.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = vector1D57.negate();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D60 = vector1D45.add((double) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D57);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = vector1D63.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D68 = vector1D67.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = vector1D64.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D67);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = vector1D57.subtract(4.041932724685649d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D64);
        boolean boolean71 = vector1D70.isInfinite();
        spaceBSPTree36.setAttribute((java.lang.Object) boolean71);
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.Space> spaceBSPTree73 = spaceBSPTree36.getMinus();
        org.junit.Assert.assertNotNull(vector1D1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{(NaN)}" + "'", str2.equals("{(NaN)}"));
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNotNull(spaceBSPTree8);
        org.junit.Assert.assertNotNull(vector2D9);
        org.junit.Assert.assertNull(spaceSubHyperplane14);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D44);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D49);
        org.junit.Assert.assertNotNull(vector1D53);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D57);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{(NaN)}" + "'", str58.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D60);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D68);
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(spaceBSPTree73);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math3.geometry.euclidean.threed.Vector3D vector3D0 = org.apache.commons.math3.geometry.euclidean.threed.Vector3D.POSITIVE_INFINITY;
        double double1 = vector3D0.getDelta();
        org.junit.Assert.assertNotNull(vector3D0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D1 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D1.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = vector1D6.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D10 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = vector1D10.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D7.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D10);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D15.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D19 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = vector1D19.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D16.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D19);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D22 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D12, (double) 10.0f, vector1D21);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D23 = vector1D1.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D12);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = vector1D26.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D30 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = vector1D30.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D27.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D30);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = vector1D35.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D39 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = vector1D39.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = vector1D36.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D39);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D42 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D32, (double) 10.0f, vector1D41);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D43 = vector1D32.normalize();
        double double44 = vector1D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D32);
        java.lang.String str45 = vector1D1.toString();
        double double46 = vector1D1.getX();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D49 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = vector1D49.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D53 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D54 = vector1D53.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D55 = vector1D50.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D53);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D58 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D59 = vector1D58.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D62 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D63 = vector1D62.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D64 = vector1D59.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D62);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D65 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D55, (double) 10.0f, vector1D64);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D67 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str68 = vector1D67.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D69 = vector1D67.negate();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D70 = vector1D55.add((double) 0, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D67);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D73 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D74 = vector1D73.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D77 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D78 = vector1D77.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D79 = vector1D74.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D77);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D80 = vector1D67.subtract(4.041932724685649d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D74);
        double double81 = vector1D1.dotProduct((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D74);
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D11);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D20);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D23);
        org.junit.Assert.assertNotNull(vector1D27);
        org.junit.Assert.assertNotNull(vector1D31);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D40);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-37.474671492307515d) + "'", double44 == (-37.474671492307515d));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{10}" + "'", str45.equals("{10}"));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 10.0d + "'", double46 == 10.0d);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertNotNull(vector1D54);
        org.junit.Assert.assertNotNull(vector1D55);
        org.junit.Assert.assertNotNull(vector1D59);
        org.junit.Assert.assertNotNull(vector1D63);
        org.junit.Assert.assertNotNull(vector1D64);
        org.junit.Assert.assertNotNull(vector1D67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "{(NaN)}" + "'", str68.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D69);
        org.junit.Assert.assertNotNull(vector1D70);
        org.junit.Assert.assertNotNull(vector1D74);
        org.junit.Assert.assertNotNull(vector1D78);
        org.junit.Assert.assertNotNull(vector1D79);
        org.junit.Assert.assertNotNull(vector1D80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 10.0d + "'", double81 == 10.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D0 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str1 = vector1D0.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D2 = vector1D0.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint4 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D2, false);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D6 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D7 = vector1D6.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D11 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D12 = vector1D11.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D15 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D16 = vector1D15.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D17 = vector1D12.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D15);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D20 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D21 = vector1D20.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D24 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D25 = vector1D24.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D26 = vector1D21.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D24);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D27 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D17, (double) 10.0f, vector1D26);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D28 = vector1D6.subtract((double) (-1.0f), (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D17);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D31 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D32 = vector1D31.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D35 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D36 = vector1D35.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D37 = vector1D32.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D35);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D40 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D41 = vector1D40.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D44 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(10.0d);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D45 = vector1D44.normalize();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D46 = vector1D41.subtract(0.4747467149230752d, (org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D44);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D47 = new org.apache.commons.math3.geometry.euclidean.oned.Vector1D((double) 1L, vector1D37, (double) 10.0f, vector1D46);
        double double48 = vector1D17.distance1((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D47);
        double double49 = orientedPoint4.getOffset((org.apache.commons.math3.geometry.Vector<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) vector1D47);
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D50 = org.apache.commons.math3.geometry.euclidean.oned.Vector1D.NaN;
        java.lang.String str51 = vector1D50.toString();
        org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D52 = vector1D50.negate();
        org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint orientedPoint54 = new org.apache.commons.math3.geometry.euclidean.oned.OrientedPoint(vector1D52, false);
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet55 = orientedPoint54.wholeSpace();
        org.apache.commons.math3.geometry.partitioning.Transform<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DTransform56 = null;
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion57 = intervalsSet55.applyTransform(euclidean1DTransform56);
        org.apache.commons.math3.geometry.partitioning.AbstractRegion<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D, org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DAbstractRegion58 = euclidean1DAbstractRegion57.copySelf();
        org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet intervalsSet59 = new org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet();
        org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D> euclidean1DBSPTree61 = intervalsSet59.getTree(false);
        boolean boolean62 = euclidean1DAbstractRegion57.isEmpty(euclidean1DBSPTree61);
        org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint subOrientedPoint63 = new org.apache.commons.math3.geometry.euclidean.oned.SubOrientedPoint((org.apache.commons.math3.geometry.partitioning.Hyperplane<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) orientedPoint4, (org.apache.commons.math3.geometry.partitioning.Region<org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D>) euclidean1DAbstractRegion57);
        org.junit.Assert.assertNotNull(vector1D0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{(NaN)}" + "'", str1.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D2);
        org.junit.Assert.assertNotNull(vector1D7);
        org.junit.Assert.assertNotNull(vector1D12);
        org.junit.Assert.assertNotNull(vector1D16);
        org.junit.Assert.assertNotNull(vector1D17);
        org.junit.Assert.assertNotNull(vector1D21);
        org.junit.Assert.assertNotNull(vector1D25);
        org.junit.Assert.assertNotNull(vector1D26);
        org.junit.Assert.assertNotNull(vector1D28);
        org.junit.Assert.assertNotNull(vector1D32);
        org.junit.Assert.assertNotNull(vector1D36);
        org.junit.Assert.assertNotNull(vector1D37);
        org.junit.Assert.assertNotNull(vector1D41);
        org.junit.Assert.assertNotNull(vector1D45);
        org.junit.Assert.assertNotNull(vector1D46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 37.474671492307515d + "'", double48 == 37.474671492307515d);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertNotNull(vector1D50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{(NaN)}" + "'", str51.equals("{(NaN)}"));
        org.junit.Assert.assertNotNull(vector1D52);
        org.junit.Assert.assertNotNull(intervalsSet55);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion57);
        org.junit.Assert.assertNotNull(euclidean1DAbstractRegion58);
        org.junit.Assert.assertNotNull(euclidean1DBSPTree61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }
}

