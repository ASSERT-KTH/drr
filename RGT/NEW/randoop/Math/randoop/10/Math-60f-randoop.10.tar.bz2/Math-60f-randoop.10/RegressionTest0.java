import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6098494453571889d + "'", double1 == 0.6098494453571889d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.ulp(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.log(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 100, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException4.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.506844020238002d) + "'", double1 == (-1.506844020238002d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) ' ', (double) 0.0f, (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '4', (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.tan(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590892d + "'", double1 == 0.6483608274590892d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8657694832396586d) + "'", double1 == (-0.8657694832396586d));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 32, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2679114584199251d + "'", double2 == 1.2679114584199251d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.8845158039790166d + "'", double0 == 0.8845158039790166d);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        try {
            double double5 = normalDistributionImpl0.cumulativeProbability((double) 32, (double) 10L);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        float float2 = org.apache.commons.math.util.FastMath.max((float) ' ', (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.cos(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036922050915067d) + "'", double1 == (-0.9036922050915067d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 1, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) 10, Double.NEGATIVE_INFINITY, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -∞ is smaller than, or equal to, the minimum (0): standard deviation (-∞)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 1.0f, (double) (-1L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.506844020238002d), number1, false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double2 = org.apache.commons.math.util.FastMath.pow(35.0d, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) -1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 10, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1142547833872074E-7d + "'", double2 == 1.1142547833872074E-7d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(100);
        outOfRangeException12.addSuppressed((java.lang.Throwable) maxIterationsExceededException14);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.40507128902104855d + "'", double1 == 0.40507128902104855d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.Throwable throwable1 = null;
        try {
            convergenceException0.addSuppressed(throwable1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (-1.506844020238002d), (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d));
        java.lang.Number number17 = outOfRangeException16.getHi();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-1.0d) + "'", number17.equals((-1.0d)));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double2 = randomDataImpl0.nextExponential((double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.1142547833872074E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9447414676202983E-9d + "'", double1 == 1.9447414676202983E-9d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.4706422502884551d), 0.6483608274590892d, 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.6483608274590892d, 1.0d, 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean6 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.6483608274590892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.8845158039790166d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4173627661473032d + "'", double1 == 1.4173627661473032d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.606111934732855d + "'", double1 == 0.606111934732855d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695754d + "'", double1 == 359.1342053695754d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.acosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        try {
//            int int5 = randomDataImpl0.nextSecureInt((int) 'a', (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (52): lower bound (97) must be strictly less than upper bound (52)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.23962617740436296d + "'", double2 == 0.23962617740436296d);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.010050166663333094d + "'", double1 == 0.010050166663333094d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7440230792707043d) + "'", double1 == (-0.7440230792707043d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.1752011936438014d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710663101885897d + "'", double1 == 3.2710663101885897d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.853988047997524d + "'", double1 == 0.853988047997524d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double2 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        try {
//            long long5 = randomDataImpl0.nextLong((long) (short) 10, (long) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (10): lower bound (10) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.28383623708628786d + "'", double2 == 0.28383623708628786d);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6038806745841075d + "'", double1 == 0.6038806745841075d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 10, (double) 97L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E97d + "'", double2 == 1.0E97d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.4173627661473032d, (-0.8657694832396586d), Double.NEGATIVE_INFINITY, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, (java.lang.Number) (-0.9036922050915067d), false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.718281828459045d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999998099d + "'", double2 == 0.9999999999998099d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10L, 1.0E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963266948965d + "'", double2 == 1.5707963266948965d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.010050166663333094d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (-1.506844020238002d), (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 0.017453292519943295d);
        boolean boolean19 = notStrictlyPositiveException18.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        try {
//            long long8 = randomDataImpl0.nextPoisson((double) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24.647602722541485d + "'", double3 == 24.647602722541485d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(5.298292365610485d, 0.0d, (-0.8657694832396586d), (-1));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        try {
//            long long16 = randomDataImpl0.nextLong((long) 1, (long) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (1): lower bound (1) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.753702047029988d + "'", double3 == 14.753702047029988d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "55ccee2118f3222986547d0cc65d41c4ba6c08eadb7b3067a8d78e444cdc96317ec94c13fbd7ecc0c57f9a8808a407ef4434" + "'", str13.equals("55ccee2118f3222986547d0cc65d41c4ba6c08eadb7b3067a8d78e444cdc96317ec94c13fbd7ecc0c57f9a8808a407ef4434"));
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.6483608274590892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 97L, 1.0E97d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.699999999999999E-96d + "'", double2 == 9.699999999999999E-96d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0E97d, 0.3595072663974203d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.450833191230467E34d + "'", double2 == 7.450833191230467E34d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.3595072663974203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.885320602561484d) + "'", double1 == (-2.885320602561484d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6483608274590866d, (-0.8390715290764524d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.839 is smaller than, or equal to, the minimum (0): standard deviation (-0.839)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation((int) (byte) 1, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-61.54217895933719d) + "'", double3 == (-61.54217895933719d));
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.6038806745841075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5432680528474173d + "'", double1 == 0.5432680528474173d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 0, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        try {
//            int int6 = randomDataImpl0.nextZipf((int) (short) 0, 20.473321410692023d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-39.47418369068117d) + "'", double3 == (-39.47418369068117d));
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        try {
//            long long17 = randomDataImpl0.nextLong((long) (byte) 10, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.97685838847776d + "'", double3 == 3.97685838847776d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "06eb0ecd1940bf2849569048dd068ab4754baadab0904789992c3d4a4b294925be393d8f9059a0ddff8160874050685c4655" + "'", str13.equals("06eb0ecd1940bf2849569048dd068ab4754baadab0904789992c3d4a4b294925be393d8f9059a0ddff8160874050685c4655"));
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '#');
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.9447414676202983E-9d, 0.010050166663333094d, (double) 100, (int) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9900001597529149d + "'", double4 == 0.9900001597529149d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.605170185988092d, 4.605170185988092d);
        try {
            double double4 = normalDistributionImpl2.inverseCumulativeProbability((double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.08209350777524616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08227867589781208d + "'", double1 == 0.08227867589781208d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.NaN, (java.lang.Number) 0.0d, true);
        outOfRangeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 0, 0.8845158039790166d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.699999999999999E-96d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.114482300479487E-48d + "'", double1 == 3.114482300479487E-48d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        try {
//            int int16 = randomDataImpl0.nextZipf(1, (double) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.829792345351706d + "'", double3 == 9.829792345351706d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "d73adfb4a56cd8f7670c91c6ee0fd5238243d0255719c2a2a9741affeab8f3077c8dc36b62154c20dabaa132a6471fac38a6" + "'", str13.equals("d73adfb4a56cd8f7670c91c6ee0fd5238243d0255719c2a2a9741affeab8f3077c8dc36b62154c20dabaa132a6471fac38a6"));
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        try {
//            double double6 = randomDataImpl0.nextWeibull((double) 1L, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-35.02218159634133d) + "'", double3 == (-35.02218159634133d));
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math.util.FastMath.min(3.114482300479487E-48d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) ' ', (-0.4706422502884551d), (double) 100.0f, 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        try {
            java.lang.String str12 = mathException11.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.6931471805599453d, (-1.1752011936438014d), (-32.16418743325655d), (int) 'a');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7970747335500249d + "'", double1 == 0.7970747335500249d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.2660741690044164d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.10177419206008143d) + "'", double1 == (-0.10177419206008143d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        float float2 = org.apache.commons.math.util.FastMath.max(100.0f, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable12 = outOfRangeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException17);
        java.lang.Object[] objArray19 = mathException18.getArguments();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6, localizable12, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable17, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray19);
        java.lang.String str22 = convergenceException21.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable24, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable32, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException("", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable29, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable40, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("", objArray42);
        java.lang.String str45 = convergenceException44.getPattern();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException44);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable49, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray51);
        java.lang.String str54 = convergenceException53.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Number number58 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable56, (java.lang.Number) (short) 1, number58, true);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable63, objArray65);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException60, localizable61, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException44, localizable55, objArray65);
        java.lang.Object[] objArray70 = new java.lang.Object[] { mathIllegalArgumentException37, localizable55, (-0.5772156677920679d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable14, objArray70);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-1.0f), (java.lang.Number) 1.2679114584199251d, false);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException75);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertNotNull(localizable55);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray70);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) (byte) 1, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01745417862959511d + "'", double1 == 0.01745417862959511d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.3595072663974203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3673015798072035d + "'", double1 == 0.3673015798072035d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.9447414676202983E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9447414676202983E-9d + "'", double1 == 1.9447414676202983E-9d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.3673015798072035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.04483033144034d + "'", double1 == 21.04483033144034d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.3595072663974203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3447799471387694d + "'", double1 == 0.3447799471387694d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable17, objArray49);
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 359.1342053695754d, (java.lang.Number) 10.0d, number54);
        java.lang.Number number56 = outOfRangeException55.getLo();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 10.0d + "'", number56.equals(10.0d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        double double16 = randomDataImpl0.nextChiSquare(1.0000000000000002d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 43.828371924135645d + "'", double3 == 43.828371924135645d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "743c12338cf4ef37a4a63c9974ed52613eefdde7cc9242aea667c18999440b25af85521d8ef5f45728a7817974dc0dd9dc57" + "'", str13.equals("743c12338cf4ef37a4a63c9974ed52613eefdde7cc9242aea667c18999440b25af85521d8ef5f45728a7817974dc0dd9dc57"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.9802279607563054d + "'", double16 == 1.9802279607563054d);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test164");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        try {
//            java.lang.String str16 = randomDataImpl0.nextHexString((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.603514528881064d + "'", double3 == 35.603514528881064d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "d70cac97ad55d511f0a45c7252ecb1712b826b3cf7504c929a4d11c83e81545772aa512f44ec3c4aef11dd5275960ee58ab9" + "'", str13.equals("d70cac97ad55d511f0a45c7252ecb1712b826b3cf7504c929a4d11c83e81545772aa512f44ec3c4aef11dd5275960ee58ab9"));
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(9.699999999999999E-96d, 4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 0, (double) (short) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        try {
//            long long23 = randomDataImpl0.nextSecureLong(10L, (long) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (-1): lower bound (10) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.982970114757066d + "'", double3 == 33.982970114757066d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "fe6118a217af09831aa9f6d2862d99fad2d3a828328f010c8db4dbcb730be9b644d490767f10522c3d2ec3e1ecb98ba1e258" + "'", str13.equals("fe6118a217af09831aa9f6d2862d99fad2d3a828328f010c8db4dbcb730be9b644d490767f10522c3d2ec3e1ecb98ba1e258"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.6954770637000812d + "'", double19 == 0.6954770637000812d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.123930775485945d + "'", double20 == 1.123930775485945d);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.4706422502884551d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-0.10177419206008143d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.1752011936438014d), 9.699999999999999E-96d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 'a', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.3673015798072035d, (-0.7440230792707043d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1068473899378932d + "'", double2 == 2.1068473899378932d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.853988047997524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8539880479975241d + "'", double1 == 0.8539880479975241d);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        try {
//            double double16 = randomDataImpl0.nextF(7.450833191230467E34d, 43.828371924135645d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.048 p = 0.631");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11.364119251566166d + "'", double3 == 11.364119251566166d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1667eeb8b69de2faf90dd195fced4acef8acab4214f26ef8644da7dbdd275ef8907c9127a89fd2028b95b895ca900749e290" + "'", str13.equals("1667eeb8b69de2faf90dd195fced4acef8acab4214f26ef8644da7dbdd275ef8907c9127a89fd2028b95b895ca900749e290"));
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NaN, 0.0d, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000004d + "'", double1 == 100.00000000000004d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        long long2 = org.apache.commons.math.util.FastMath.max((long) ' ', (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.6098494453571889d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6487212707001282d + "'", double1 == 1.6487212707001282d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.rint(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (double) (short) 100);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test187");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
//        double double4 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.11989046844828717d + "'", double4 == 0.11989046844828717d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.595451132473584d) + "'", double5 == (-1.595451132473584d));
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.acos(100.00000000000004d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-20.512631014974332d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable8, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.String str13 = convergenceException12.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException12.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] { 'a', 1.0d, '4', localizable14, (-1.0d), (short) 0 };
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(throwable0, "aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray17);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable22, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("", objArray24);
        java.lang.String str27 = convergenceException26.getPattern();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable31, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray33);
        java.lang.String str36 = convergenceException35.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) (short) 1, number40, true);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable45, objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException42, localizable43, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException26, localizable37, objArray47);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable51, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException55);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException(localizable57, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable62 = outOfRangeException61.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException(localizable63, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException67);
        java.lang.Object[] objArray69 = mathException68.getArguments();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException56, localizable62, objArray69);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable37, objArray69);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.1622776601683795d, (java.lang.Number) 0.3595072663974203d, false);
        java.lang.Number number77 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number77, false);
        java.lang.Number number80 = numberIsTooSmallException79.getArgument();
        boolean boolean81 = numberIsTooSmallException79.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass82 = numberIsTooSmallException79.getClass();
        org.apache.commons.math.exception.util.Localizable localizable83 = numberIsTooSmallException79.getGeneralPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException85 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException85);
        java.lang.Object[] objArray87 = mathException86.getArguments();
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException75, localizable83, objArray87);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException19, localizable37, objArray87);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + (-1.0f) + "'", number80.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(wildcardClass82);
        org.junit.Assert.assertTrue("'" + localizable83 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable83.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray87);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        try {
//            int int24 = randomDataImpl0.nextHypergeometric((int) (short) 100, (int) (short) 100, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.361818608849291d + "'", double3 == 5.361818608849291d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "12cbdfd6ff5cc882d57acfae4a7e2469d9e24039189e5b449be123b4335d766e8655acab5f88efd3f8f2a4b98aed2b8beedf" + "'", str13.equals("12cbdfd6ff5cc882d57acfae4a7e2469d9e24039189e5b449be123b4335d766e8655acab5f88efd3f8f2a4b98aed2b8beedf"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.2872230201534125d + "'", double19 == 1.2872230201534125d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.4896562784033601d + "'", double20 == 0.4896562784033601d);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.10177419206008143d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.067330721670848d + "'", double1 == 9.067330721670848d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 0.40507128902104855d);
        java.lang.Number number33 = notStrictlyPositiveException32.getMin();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 0 + "'", number33.equals(0));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-20.15821253309177d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8416492588916045E8d + "'", double1 == 2.8416492588916045E8d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.3595072663974203d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        long long1 = org.apache.commons.math.util.FastMath.round(100.00000000000004d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        try {
//            int int11 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 65.98404518802208d + "'", double3 == 65.98404518802208d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
//        double double4 = normalDistributionImpl0.sample();
//        try {
//            double double7 = normalDistributionImpl0.cumulativeProbability((double) 100.0f, (double) 0);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.3396195802886453d + "'", double4 == 1.3396195802886453d);
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        float float2 = org.apache.commons.math.util.FastMath.min(10.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        long long1 = org.apache.commons.math.util.FastMath.round(1.1680965989262542d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.015772404403454655d) + "'", double1 == (-0.015772404403454655d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.4173627661473032d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1842882874806984d + "'", double1 == 2.1842882874806984d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4711276743037347d, (java.lang.Number) 0.8845158039790166d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.8845158039790166d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07829815576435584d + "'", double1 == 0.07829815576435584d);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test208");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        try {
//            double double10 = randomDataImpl0.nextT((-0.7440230792707043d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.744 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.744)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-38.85200813675005d) + "'", double3 == (-38.85200813675005d));
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.0E97d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2235075402042246E99d + "'", double1 == 2.2235075402042246E99d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(23.363034433648068d, (double) (short) 1, 0.07829815576435584d, (int) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (short) 10);
        try {
            int int5 = randomDataImpl0.nextInt((int) (byte) 100, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (32): lower bound (100) must be strictly less than upper bound (32)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test212");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        try {
//            java.lang.String str16 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.10052648075499d) + "'", double3 == (-2.10052648075499d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "7afe5a1be13f89b1f4758f9d7d8c3a920d9adc4bc3ed214c543c389dd1f49b831bce0eede0da0c4089e04089ba2010d257c5" + "'", str13.equals("7afe5a1be13f89b1f4758f9d7d8c3a920d9adc4bc3ed214c543c389dd1f49b831bce0eede0da0c4089e04089ba2010d257c5"));
//    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.8539880479975241d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.774273095146928d + "'", double1 == 0.774273095146928d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020687957244708476d + "'", double1 == 0.020687957244708476d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.15865525393145702d, 0.6038806745841075d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3289803051047428d + "'", double2 == 0.3289803051047428d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8325546111576977d + "'", double1 == 0.8325546111576977d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.853988047997524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.06854820744336733d) + "'", double1 == (-0.06854820744336733d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6011681475703368d + "'", double1 == 2.6011681475703368d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int2 = org.apache.commons.math.util.FastMath.max(10, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.6483608274590866d, (-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.663999375826442d + "'", double2 == 1.663999375826442d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.020687957244708476d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        try {
//            java.lang.String str10 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.46629775518595d + "'", double3 == 17.46629775518595d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test225");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        try {
//            double double11 = randomDataImpl0.nextBeta((-32.16418743325655d), 2.3978952727983707d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.729");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-18.726370860967258d) + "'", double3 == (-18.726370860967258d));
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.606111934732855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7785319099002012d + "'", double1 == 0.7785319099002012d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test228");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 0, (long) '#');
//        try {
//            int int8 = randomDataImpl0.nextPascal((int) (short) 100, (-44.44377415455416d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -44.444 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.041642201733504344d + "'", double2 == 0.041642201733504344d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 8L + "'", long5 == 8L);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
//        double double3 = normalDistributionImpl0.sample();
//        try {
//            double double6 = normalDistributionImpl0.cumulativeProbability(0.9999999999998099d, 0.0d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.3008293652104577d) + "'", double3 == (-1.3008293652104577d));
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable17, objArray49);
        java.lang.String str52 = convergenceException51.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.tan((-44.44377415455416d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4972896813789087d) + "'", double1 == (-0.4972896813789087d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-28.77361862970824d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5021943828015879d) + "'", double1 == (-0.5021943828015879d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 31, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 3.114482300479487E-48d, number2);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.ceil(71.32400509670025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 72.0d + "'", double1 == 72.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.signum((-24.725268680222683d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray14 = outOfRangeException13.getArguments();
        java.lang.Class<?> wildcardClass15 = objArray14.getClass();
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable0, objArray14);
        try {
            java.lang.String str17 = convergenceException16.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.781072417990198d + "'", double1 == 1.781072417990198d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 4, (-0.06854820744336733d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9093474783445679d + "'", double2 == 0.9093474783445679d);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        try {
//            int int8 = randomDataImpl1.nextHypergeometric((int) (byte) 0, 1, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.6263465764652947d) + "'", double4 == (-0.6263465764652947d));
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable13 = outOfRangeException12.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException12);
        java.lang.Number number15 = outOfRangeException12.getLo();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 2147483647, 0.5039893563146316d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.special.Erf.erf(9.067330721670848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
        double double5 = normalDistributionImpl0.inverseCumulativeProbability(0.6483608274590866d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.3808987971294274d + "'", double5 == 0.3808987971294274d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (-4.281642508279315d), (java.lang.Number) 0.9999999999998099d, false);
        java.lang.Object[] objArray13 = numberIsTooSmallException12.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 31L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1776.169164905552d + "'", double1 == 1776.169164905552d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable17, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable23, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray25);
        java.lang.String str28 = convergenceException27.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray34 = outOfRangeException33.getArguments();
        java.lang.Class<?> wildcardClass35 = objArray34.getClass();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable20, objArray34);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable17, objArray34);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(wildcardClass35);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        double double13 = randomDataImpl0.nextExponential(4.605170185988092d);
//        try {
//            double double16 = randomDataImpl0.nextGamma(0.8325546111576977d, (-6.814282900389825d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -6.814 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 51.38575968879417d + "'", double3 == 51.38575968879417d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.1173519924328823d + "'", double13 == 2.1173519924328823d);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 0, (long) '#');
//        try {
//            int int9 = randomDataImpl0.nextHypergeometric((int) (byte) 0, 32, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4159565080923455d + "'", double2 == 1.4159565080923455d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 15L + "'", long5 == 15L);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 2.8416492588916045E8d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.08227867589781208d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.321163845707952d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.948868668336558d + "'", double1 == 0.948868668336558d);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test263");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(1, 52);
//        try {
//            int[] intArray20 = randomDataImpl0.nextPermutation((int) (byte) -1, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than the maximum (-1): permutation size (1) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.85955173129345d + "'", double3 == 18.85955173129345d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "cdc1f9961c56028e4b75f6adba17c79f80542f3a1174b08e9b23f7ad9f830c66c658ba0404db62edf4d2c9f430be084cc683" + "'", str13.equals("cdc1f9961c56028e4b75f6adba17c79f80542f3a1174b08e9b23f7ad9f830c66c658ba0404db62edf4d2c9f430be084cc683"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 18 + "'", int17 == 18);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        java.lang.String str32 = mathException31.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{0}" + "'", str32.equals("{0}"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000003E-9d + "'", double1 == 1.0000000000000003E-9d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 100, (java.lang.Number) (-2.885320602561484d), false);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.getMean();
//        double double3 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.3931070963995558d) + "'", double3 == (-1.3931070963995558d));
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.7440230792707043d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.782878676944483d) + "'", double1 == (-2.782878676944483d));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = maxIterationsExceededException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.exp(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.774273095146928d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.919396437280402E-24d + "'", double2 == 8.919396437280402E-24d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test276");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
//        double double4 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.getMean();
//        double double7 = normalDistributionImpl0.cumulativeProbability((double) 0.0f);
//        try {
//            double double9 = normalDistributionImpl0.inverseCumulativeProbability((-2.885320602561484d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -2.885 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.5754551260740524d) + "'", double4 == (-0.5754551260740524d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) 1, number8, true);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable13, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, localizable11, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException17);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable21, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.String str26 = convergenceException25.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException25.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException(localizable27, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray32 = outOfRangeException31.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable33 = outOfRangeException31.getGeneralPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException35);
        java.lang.Object[] objArray37 = maxIterationsExceededException35.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable50 = outOfRangeException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable51, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException55);
        java.lang.Object[] objArray57 = mathException56.getArguments();
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException44, localizable50, objArray57);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException35, "", objArray57);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException18, localizable33, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable63, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException("", objArray65);
        java.lang.String str68 = convergenceException67.getPattern();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException67);
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable72, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("", objArray74);
        java.lang.String str77 = convergenceException76.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable78 = convergenceException76.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        java.lang.Number number81 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException83 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable79, (java.lang.Number) (short) 1, number81, true);
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        org.apache.commons.math.exception.util.Localizable localizable86 = null;
        java.lang.Object[] objArray88 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException89 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable86, objArray88);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException83, localizable84, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException91 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException67, localizable78, objArray88);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable33, objArray88);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "" + "'", str68.equals(""));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
        org.junit.Assert.assertNotNull(localizable78);
        org.junit.Assert.assertNotNull(objArray88);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.853988047997524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3489961061146651d + "'", double1 == 1.3489961061146651d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.3808987971294274d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1);
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2, "aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException2.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test282");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        long long5 = randomDataImpl0.nextSecureLong((long) (byte) 0, (long) '#');
//        try {
//            int int8 = randomDataImpl0.nextSecureInt((-1), (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: -1 is larger than, or equal to, the maximum (-1): lower bound (-1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.06056664902710747d + "'", double2 == 0.06056664902710747d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9L + "'", long5 == 9L);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        try {
//            double double11 = randomDataImpl0.nextWeibull(0.853988047997524d, (-0.015772404403454655d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.016 is smaller than, or equal to, the minimum (0): scale (-0.016)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-34.48290432377993d) + "'", double3 == (-34.48290432377993d));
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6681539175313869d + "'", double1 == 0.6681539175313869d);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        try {
//            int int16 = randomDataImpl0.nextBinomial((int) (short) -1, (-0.8390715290764524d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24.116794101577035d + "'", double3 == 24.116794101577035d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.030595689761717d) + "'", double13 == (-1.030595689761717d));
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        randomDataImpl1.reSeed(0L);
//        try {
//            long long9 = randomDataImpl1.nextLong((long) 2147483647, (long) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than, or equal to, the maximum (10): lower bound (2,147,483,647) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.7617536398207533d) + "'", double4 == (-0.7617536398207533d));
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.util.FastMath.abs(21.04483033144034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.04483033144034d + "'", double1 == 21.04483033144034d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.8390715290764524d), 2.8416492588916045E8d, 0.9900001597529149d, (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.07829815576435584d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.4706422502884551d), (java.lang.Number) 1, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1 + "'", number4.equals(1));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.020687957244708476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6681539175313869d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6263821600327261d + "'", double1 == 0.6263821600327261d);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        double double13 = randomDataImpl0.nextExponential(4.605170185988092d);
//        randomDataImpl0.reSeed(0L);
//        try {
//            int int18 = randomDataImpl0.nextInt((int) (short) 1, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (0): lower bound (1) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-24.272552436597877d) + "'", double3 == (-24.272552436597877d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.1173519924328823d + "'", double13 == 2.1173519924328823d);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        try {
//            long long11 = randomDataImpl0.nextLong((long) 52, (long) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (35): lower bound (52) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-11.3157013225832d) + "'", double3 == (-11.3157013225832d));
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000005000001E-9d + "'", double1 == 1.0000000005000001E-9d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 0.40507128902104855d);
        java.lang.String str33 = notStrictlyPositiveException32.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.405 is smaller than, or equal to, the minimum (0): " + "'", str33.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.405 is smaller than, or equal to, the minimum (0): "));
    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test299");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        double double13 = randomDataImpl0.nextExponential(4.605170185988092d);
//        try {
//            double double15 = randomDataImpl0.nextT((-1.506844020238002d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.507 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.507)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.718497573946367d + "'", double3 == 3.718497573946367d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.1173519924328823d + "'", double13 == 2.1173519924328823d);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.log10(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double3 = randomDataImpl1.nextT((-0.7685777552590246d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.769 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.769)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.8845158039790166d, 1.2679114584199251d);
        try {
            double double4 = normalDistributionImpl2.inverseCumulativeProbability(21.04483033144034d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 21.045 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.util.FastMath.log(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6673845734742283d + "'", double1 == 1.6673845734742283d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (-1.595451132473584d), (-0.9036922050915067d), (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
        try {
            double double5 = normalDistributionImpl0.inverseCumulativeProbability(Double.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: ∞ out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        double double13 = randomDataImpl0.nextExponential(4.605170185988092d);
//        randomDataImpl0.reSeed(0L);
//        try {
//            int[] intArray18 = randomDataImpl0.nextPermutation((int) (byte) 1, 49);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 49 is larger than the maximum (1): permutation size (49) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-6.746889292421246d) + "'", double3 == (-6.746889292421246d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.1173519924328823d + "'", double13 == 2.1173519924328823d);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.605170185988092d, 4.605170185988092d);
        try {
            double double4 = normalDistributionImpl2.inverseCumulativeProbability((-28.77361862970824d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -28.774 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        try {
//            int int7 = randomDataImpl1.nextInt(0, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.7448816342473273d) + "'", double4 == (-0.7448816342473273d));
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        double double4 = randomDataImpl0.nextChiSquare(0.3595072663974203d);
//        try {
//            double double7 = randomDataImpl0.nextF(0.3673015798072035d, (double) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.44093887869402004d + "'", double2 == 0.44093887869402004d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.11023074181824E-4d + "'", double4 == 6.11023074181824E-4d);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.6487212707001282d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07784610394702793d) + "'", double1 == (-0.07784610394702793d));
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        try {
//            double double17 = randomDataImpl0.nextWeibull(0.0d, (double) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.20250998863184d + "'", double3 == 9.20250998863184d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "91ca07364ef7d5c6964e2181f97ff3b65955c35bede7376a86ddc9b7ca0bb1d7b9e33634768717fc0290dd4b30b373e96d15" + "'", str13.equals("91ca07364ef7d5c6964e2181f97ff3b65955c35bede7376a86ddc9b7ca0bb1d7b9e33634768717fc0290dd4b30b373e96d15"));
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(1, 52);
//        try {
//            double double20 = randomDataImpl0.nextCauchy((double) (short) 100, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.695644157133601d + "'", double3 == 5.695644157133601d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "71925daa2eab7b822df68bf7f12d2f8bd58f6187fd861aac22dd151130f443d5cdba211720f76a5b424d2b522677fcf527de" + "'", str13.equals("71925daa2eab7b822df68bf7f12d2f8bd58f6187fd861aac22dd151130f443d5cdba211720f76a5b424d2b522677fcf527de"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 38 + "'", int17 == 38);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3678794411714424d + "'", double1 == 0.3678794411714424d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.9802279607563054d, 1.9802279607563054d, 22026.465794806718d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.779109627299853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5773894904459439d + "'", double1 == 0.5773894904459439d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextGaussian(7.450833191230467E34d, 1.5707963266948965d);
        int[] intArray7 = randomDataImpl1.nextPermutation(10, (int) (short) 10);
        try {
            double double10 = randomDataImpl1.nextBeta(1.303909551780072d, (-40.36328959251109d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.913");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.450833191230467E34d + "'", double4 == 7.450833191230467E34d);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0f + "'", number6.equals(1.0f));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.log10(26.938162984706857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.430367976212243d + "'", double1 == 1.430367976212243d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.8657694832396586d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        java.lang.Throwable throwable32 = null;
        try {
            convergenceException30.addSuppressed(throwable32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException30.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNull(localizable32);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        try {
//            double double11 = randomDataImpl0.nextGaussian((double) (short) 100, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.33347378005689d + "'", double3 == 18.33347378005689d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable8, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.String str13 = convergenceException12.getPattern();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException12);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable17, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray19);
        java.lang.String str22 = convergenceException21.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) (short) 1, number26, true);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable31, objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException28, localizable29, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException12, localizable23, objArray33);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36);
        java.lang.String str38 = convergenceException36.getPattern();
        java.lang.Throwable[] throwableArray39 = convergenceException36.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable5, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math.exception.util.Localizable localizable41 = convergenceException40.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNull(localizable41);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray8);
        java.lang.String str11 = convergenceException10.getPattern();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable15, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("", objArray17);
        java.lang.String str20 = convergenceException19.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) (short) 1, number24, true);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable29, objArray31);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException26, localizable27, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, localizable21, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable38, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        java.lang.String str43 = convergenceException42.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException42.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException(localizable44, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable49 = outOfRangeException48.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable53, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray55);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("hi!", objArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable49, objArray55);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable21, objArray55);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(throwable1, localizable2, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(localizable0, objArray55);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertNotNull(localizable21);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(localizable49);
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.abs(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(39.56893168362026d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6906081393758767d + "'", double1 == 0.6906081393758767d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8975852141610587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.4278445247748d + "'", double1 == 51.4278445247748d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.010050166663333094d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        try {
//            double double7 = randomDataImpl1.nextGamma(0.0d, (-0.4265928141503621d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.7542981760489252d) + "'", double4 == (-0.7542981760489252d));
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.06854820744336733d), 0.948868668336558d, 20.473321410692023d, (int) 'a');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.833336070820506d + "'", double1 == 11.833336070820506d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        int int2 = org.apache.commons.math.util.FastMath.min(9, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test341");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        double double16 = randomDataImpl0.nextCauchy((double) '#', 0.5d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-7.977806869851621d) + "'", double3 == (-7.977806869851621d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "8d7aee51f97d2c63862aec17a58a0ca87ad0543368584d699190014fc74eb85a57e25d00b430fb497134863fc011f2a6de84" + "'", str13.equals("8d7aee51f97d2c63862aec17a58a0ca87ad0543368584d699190014fc74eb85a57e25d00b430fb497134863fc011f2a6de84"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 35.21903082555857d + "'", double16 == 35.21903082555857d);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.8325546111576977d, 0.5773894904459439d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47468363820737447d + "'", double2 == 0.47468363820737447d);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) '4');
//        long long12 = randomDataImpl0.nextLong((long) 0, (long) (short) 100);
//        double double15 = randomDataImpl0.nextGamma(0.3289803051047428d, 23.363034433648068d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.7809026943111093d) + "'", double3 == (-2.7809026943111093d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 61L + "'", long12 == 61L);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 18.004700740227015d + "'", double15 == 18.004700740227015d);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable12, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.String str17 = convergenceException16.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (short) 1, number21, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable26, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException23, localizable24, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable18, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable43 = outOfRangeException42.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException(localizable44, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException48);
        java.lang.Object[] objArray50 = mathException49.getArguments();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, localizable43, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable18, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("320e4281407b99bd2f8b7596083901590a3ae01f33de675165fec30849d7a28f4ecf04f4981154029c58011100836db8b0d2", objArray50);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.6011681475703368d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.702643995590282d + "'", double1 == 6.702643995590282d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 100.00000000000004d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        try {
//            double double11 = randomDataImpl0.nextBeta((-0.48064673079510956d), 6.691673596021348E41d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.889");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.49100227954994d + "'", double3 == 28.49100227954994d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 31, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.ulp(19.241467490659986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test353");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        randomDataImpl0.reSeedSecure((-1L));
//        double double17 = randomDataImpl0.nextChiSquare(39.701154568539714d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.03163666419798d + "'", double3 == 32.03163666419798d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.9972144990387393d) + "'", double13 == (-1.9972144990387393d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 69.45945350175526d + "'", double17 == 69.45945350175526d);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.05538936600958528d, (-0.48064673079510956d), 0.0d, (int) (byte) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        try {
//            int[] intArray16 = randomDataImpl0.nextPermutation(32, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (32): permutation size (35) exceeds permuation domain (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 39.57930220166403d + "'", double3 == 39.57930220166403d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ce6951f71760cbf91b878bf2080ea15b20dd75d38e7338614be14e3c19ca8c3565930b65e30ecd032ad324a15ef7a1fbe6ac" + "'", str13.equals("ce6951f71760cbf91b878bf2080ea15b20dd75d38e7338614be14e3c19ca8c3565930b65e30ecd032ad324a15ef7a1fbe6ac"));
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 49, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 49L + "'", long2 == 49L);
    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test358");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.405 is smaller than, or equal to, the minimum (0): ", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.6802408319707441d) + "'", double4 == (-0.6802408319707441d));
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.1752011936438014d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-1.1752011936438014d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5d, (-0.7685777552590246d), (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.769 is smaller than, or equal to, the minimum (0): standard deviation (-0.769)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        long long2 = org.apache.commons.math.util.FastMath.min(97L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability((-1.0d));
        normalDistributionImpl0.reseedRandomGenerator((long) 100);
        double double5 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15865525393145702d + "'", double2 == 0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.6438381202745753d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.66643604627261d + "'", double1 == 13.66643604627261d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray13 = outOfRangeException12.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (short) 1, number17, true);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable22, objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException19, localizable20, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException12, localizable14, objArray24);
        java.lang.Number number28 = outOfRangeException12.getLo();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1L + "'", number28.equals(1L));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) 100, (-0.8390715290764524d));
        double double5 = normalDistributionImpl3.cumulativeProbability(1.0d);
        double double6 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5039893563146316d + "'", double5 == 0.5039893563146316d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(9.067330721670848d, 39.701154568539714d);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double22 = normalDistributionImpl15.density(0.9093474783445679d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.240716167464921d) + "'", double3 == (-2.240716167464921d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "e69457ceb932a770a6015b1b69761fa98599089aee3eb9128cad0685b517ac5de71f2a29fb4492ecbf72bb6d26428997d1bf" + "'", str13.equals("e69457ceb932a770a6015b1b69761fa98599089aee3eb9128cad0685b517ac5de71f2a29fb4492ecbf72bb6d26428997d1bf"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.61612795865597d + "'", double19 == 1.61612795865597d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.6755687965113603d + "'", double20 == 0.6755687965113603d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2638446090032678d + "'", double22 == 0.2638446090032678d);
//    }

//    @Test
//    public void test369() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test369");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        double double13 = randomDataImpl0.nextExponential(4.605170185988092d);
//        try {
//            double double16 = randomDataImpl0.nextCauchy(5729.5779513082325d, (double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.791925225698563d + "'", double3 == 15.791925225698563d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.1173519924328823d + "'", double13 == 2.1173519924328823d);
//    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.1842882874806984d, (java.lang.Number) 0.5d, (java.lang.Number) 0.6098494453571889d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
        double double4 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        java.lang.Class<?> wildcardClass17 = numberIsTooSmallException16.getClass();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        int int5 = randomDataImpl0.nextBinomial(52, 0.5772156649015329d);
//        try {
//            double double8 = randomDataImpl0.nextF(0.3665121065625489d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0210308861130448d + "'", double2 == 1.0210308861130448d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 36 + "'", int5 == 36);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.3665121065625489d, 0.6755687965113603d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8267766011773737d + "'", double2 == 0.8267766011773737d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double2 = org.apache.commons.math.util.FastMath.pow((-20.15821253309177d), (-32.16418743325655d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable4, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.String str9 = convergenceException8.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable19, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable16, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(throwable0, "e69457ceb932a770a6015b1b69761fa98599089aee3eb9128cad0685b517ac5de71f2a29fb4492ecbf72bb6d26428997d1bf", objArray21);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability((-1.0d));
        double double5 = normalDistributionImpl0.cumulativeProbability((-0.7440230792707043d), 2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15865525393145702d + "'", double2 == 0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7633239541263961d + "'", double5 == 0.7633239541263961d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.8416492588916045E8d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.40507128902104855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7837811557474641d + "'", double1 == 0.7837811557474641d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.7853981633974483d, 0.6755687965113603d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.849426874816484d + "'", double2 == 0.849426874816484d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int2 = org.apache.commons.math.util.FastMath.max(31, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = normalDistributionImpl15.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 55.328857578305815d + "'", double3 == 55.328857578305815d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "f8b387d0081be7d9fc5eb5f7d78f6f1ed6f5722d0e2787f7fa863edb6e2779a720d074fb81f516d17becbc5bb86061e13541" + "'", str13.equals("f8b387d0081be7d9fc5eb5f7d78f6f1ed6f5722d0e2787f7fa863edb6e2779a720d074fb81f516d17becbc5bb86061e13541"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.6562329739400842d + "'", double19 == 0.6562329739400842d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.23998629493553567d + "'", double20 == 0.23998629493553567d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable4, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.String str9 = convergenceException8.getPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable13, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray15);
        java.lang.String str18 = convergenceException17.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) (short) 1, number22, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable27, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24, localizable25, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, localizable19, objArray29);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable44 = outOfRangeException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException49);
        java.lang.Object[] objArray51 = mathException50.getArguments();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException38, localizable44, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable19, objArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray51);
        java.lang.Object[] objArray55 = maxIterationsExceededException54.getArguments();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (short) 10);
        try {
            int int5 = randomDataImpl0.nextSecureInt(32, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (6): lower bound (32) must be strictly less than upper bound (6)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable17, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException21);
        java.lang.Object[] objArray23 = maxIterationsExceededException21.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable17, objArray23);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable17, objArray25);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        long long2 = org.apache.commons.math.util.FastMath.min(32L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test391");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        double double6 = randomDataImpl0.nextF(0.5d, 1.4173627661473032d);
//        try {
//            int int9 = randomDataImpl0.nextInt(2147483647, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than, or equal to, the maximum (0): lower bound (2,147,483,647) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6120849256960739d + "'", double3 == 0.6120849256960739d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9670515328255233d + "'", double6 == 0.9670515328255233d);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(16.087138852654263d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06413348263674616d + "'", double1 == 0.06413348263674616d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 3.2710663101885897d, (java.lang.Number) 1.2660741690044164d, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray8);
        java.lang.String str11 = convergenceException10.getPattern();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException10);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException10.getGeneralPattern();
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable13, objArray14);
        java.lang.Object[] objArray16 = mathException15.getArguments();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.abs(21.862836871826794d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.862836871826794d + "'", double1 == 21.862836871826794d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 61L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        double double13 = randomDataImpl0.nextExponential(4.605170185988092d);
//        randomDataImpl0.reSeed(0L);
//        int int18 = randomDataImpl0.nextInt((int) (byte) 0, 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.026500708453856d + "'", double3 == 6.026500708453856d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.1173519924328823d + "'", double13 == 2.1173519924328823d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-56.77721167882673d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
//        double double5 = normalDistributionImpl0.cumulativeProbability(0.8975852141610587d, 1.9802279607563054d);
//        double double6 = normalDistributionImpl0.getStandardDeviation();
//        double double7 = normalDistributionImpl0.sample();
//        double double9 = normalDistributionImpl0.density(0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.16086440265790714d + "'", double5 == 0.16086440265790714d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.16386466025171564d) + "'", double7 == (-0.16386466025171564d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.36842577779469815d + "'", double9 == 0.36842577779469815d);
//    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test402");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.getMean();
//        double double3 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString((int) (byte) 10);
//        try {
//            int[] intArray8 = randomDataImpl0.nextPermutation((int) (short) 0, 2147483647);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than the maximum (0): permutation size (2,147,483,647) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.2093083500090337d) + "'", double3 == (-0.2093083500090337d));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "32eda72d98" + "'", str5.equals("32eda72d98"));
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.ceil(43.828371924135645d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.0d + "'", double1 == 44.0d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.acos((-28.77361862970824d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.1680965989262542d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 230.0152230995558d + "'", double2 == 230.0152230995558d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.15761044494741813d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 0, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(7.012254107578257d, (-0.48064673079510956d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.481 is smaller than, or equal to, the minimum (0): standard deviation (-0.481)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.1622776601683795d, (java.lang.Number) 0.3595072663974203d, false);
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number5, false);
        java.lang.Number number8 = numberIsTooSmallException7.getArgument();
        boolean boolean9 = numberIsTooSmallException7.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass10 = numberIsTooSmallException7.getClass();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException13);
        java.lang.Object[] objArray15 = mathException14.getArguments();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable11, objArray15);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Number number18 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0f) + "'", number8.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.3595072663974203d + "'", number18.equals(0.3595072663974203d));
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test410");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution14 = null;
//        try {
//            double double15 = randomDataImpl0.nextInversionDeviate(continuousDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 66.53574924461594d + "'", double3 == 66.53574924461594d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.160357325541992d) + "'", double13 == (-1.160357325541992d));
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195432d + "'", double1 == 0.8813735870195432d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable20, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray22);
        java.lang.String str25 = convergenceException24.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) (short) 1, number29, true);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable34, objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException31, localizable32, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, localizable26, objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", objArray36);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException4, "", objArray36);
        java.lang.String str42 = mathException41.toString();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.apache.commons.math.MathException: " + "'", str42.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.321163845707952d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.31588426736961117d) + "'", double1 == (-0.31588426736961117d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable12, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.String str17 = convergenceException16.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (short) 1, number21, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable26, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException23, localizable24, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable18, objArray28);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable18, (java.lang.Number) 0.40507128902104855d);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable36, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("", objArray38);
        java.lang.String str41 = convergenceException40.getPattern();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException40);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable45, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("", objArray47);
        java.lang.String str50 = convergenceException49.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = convergenceException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) (short) 1, number54, true);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable59, objArray61);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException56, localizable57, objArray61);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException40, localizable51, objArray61);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable51, (java.lang.Number) 0.40507128902104855d);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable70, objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("", objArray72);
        java.lang.String str75 = convergenceException74.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = convergenceException74.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException(localizable76, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable81 = outOfRangeException80.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        java.lang.Object[] objArray87 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable85, objArray87);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException("", objArray87);
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException("hi!", objArray87);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable81, objArray87);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable51, objArray87);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException94);
        java.lang.Object[] objArray96 = mathException95.getArguments();
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException(throwable0, localizable18, objArray96);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "" + "'", str41.equals(""));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "" + "'", str50.equals(""));
        org.junit.Assert.assertNotNull(localizable51);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
        org.junit.Assert.assertNotNull(localizable76);
        org.junit.Assert.assertNotNull(localizable81);
        org.junit.Assert.assertNotNull(objArray87);
        org.junit.Assert.assertNotNull(objArray96);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.0d, (double) 49, (int) '4');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, number1, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 0.6681539175313869d);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
        double double4 = normalDistributionImpl0.getMean();
        try {
            double double6 = normalDistributionImpl0.inverseCumulativeProbability((-0.321163845707952d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.321 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int1 = org.apache.commons.math.util.FastMath.abs(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.48064673079510956d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7833250184011098d) + "'", double1 == (-0.7833250184011098d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.1142547833872074E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.384209639035074E-6d + "'", double1 == 6.384209639035074E-6d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        long long1 = org.apache.commons.math.util.FastMath.abs(85L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 85L + "'", long1 == 85L);
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test424");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        java.lang.Class<?> wildcardClass15 = randomDataImpl0.getClass();
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution16 = null;
//        try {
//            int int17 = randomDataImpl0.nextInversionDeviate(integerDistribution16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.4681768092384d + "'", double3 == 14.4681768092384d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "38e24d3719fe70d86f72712b8e0618c4147deb6ff1207403ec7e32d8aca2ee4d0d4576705d7c7228924f324a43e8b825b581" + "'", str13.equals("38e24d3719fe70d86f72712b8e0618c4147deb6ff1207403ec7e32d8aca2ee4d0d4576705d7c7228924f324a43e8b825b581"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5707963267948966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.180709777452588d + "'", double1 == 22.180709777452588d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test428");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long13 = randomDataImpl0.nextPoisson(1.499039715843948d);
//        try {
//            int[] intArray16 = randomDataImpl0.nextPermutation(4, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 19.38636557646413d + "'", double3 == 19.38636557646413d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9999999958776927d, (-40.36328959251109d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4711276743037347d, (java.lang.Number) 0.8845158039790166d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, number5, (java.lang.Number) 0.7970747335500249d, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        double double17 = randomDataImpl0.nextGamma(1.0000000000000002d, 1.4173627661473032d);
//        try {
//            int int20 = randomDataImpl0.nextSecureInt((int) (short) 100, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 50.152068723663426d + "'", double3 == 50.152068723663426d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ac7f932a683214acf2d5e6d07e474b9061c03006f91015d199e52f78bd791532a25aeccf53045d76890b6540ab9016a28cca" + "'", str13.equals("ac7f932a683214acf2d5e6d07e474b9061c03006f91015d199e52f78bd791532a25aeccf53045d76890b6540ab9016a28cca"));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.313074887058615d + "'", double17 == 2.313074887058615d);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (-1.506844020238002d), (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable20, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray22);
        java.lang.String str25 = convergenceException24.getPattern();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException24);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable29, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.String str34 = convergenceException33.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable36, (java.lang.Number) (short) 1, number38, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable43, objArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException40, localizable41, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException24, localizable35, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException(localizable49, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException53);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable60 = outOfRangeException59.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException(localizable61, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException65);
        java.lang.Object[] objArray67 = mathException66.getArguments();
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException54, localizable60, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable35, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable9, objArray67);
        java.lang.Class<?> wildcardClass71 = objArray67.getClass();
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.OutOfRangeException: 1 out of [0, null] range", objArray67);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(wildcardClass71);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.303909551780072d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.552713678800501E-15d, (java.lang.Number) 8, true);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.7963230106584364d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6993397042844088d + "'", double1 == 0.6993397042844088d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 3.2710663101885897d, (java.lang.Number) 1.2660741690044164d, (java.lang.Number) 10);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4711276743037347d, (java.lang.Number) 0.8845158039790166d, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number11, false);
        java.lang.Number number14 = numberIsTooSmallException13.getArgument();
        java.lang.Number number15 = numberIsTooSmallException13.getMin();
        java.lang.Object[] objArray16 = numberIsTooSmallException13.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("7a5cc44f1e2ac5cced1152a6b05c5838082ebe2a350e03e25e772c619d524a6a6da447231c8811d4b89c1dc2e2480a771f54", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable8, objArray16);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-1.0f) + "'", number14.equals((-1.0f)));
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable5, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(100, "", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable14, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray16);
        java.lang.String str19 = convergenceException18.getPattern();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException18);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable23, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray25);
        java.lang.String str28 = convergenceException27.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) (short) 1, number32, true);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable37, objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException34, localizable35, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, localizable29, objArray39);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable45, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException("", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException11, localizable29, objArray47);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) 2147483647, (java.lang.Number) 1.9802279607563054d, false);
        java.lang.Number number55 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, number55, (java.lang.Number) (-6.814282900389825d), false);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertNotNull(localizable29);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray47);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.1765978079212231d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.176597807921223d) + "'", double1 == (-1.176597807921223d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) -1, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(20);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        java.lang.Class<?> wildcardClass15 = randomDataImpl0.getClass();
//        try {
//            double double18 = randomDataImpl0.nextWeibull(0.0d, 0.8539880479975241d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 21.737058554403802d + "'", double3 == 21.737058554403802d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5c8845787b0c9834f1d14395ddb819991fd22668e9c8a3b86a5eeba892b67b52e32c624628e06a09537c7aea8b479f470df3" + "'", str13.equals("5c8845787b0c9834f1d14395ddb819991fd22668e9c8a3b86a5eeba892b67b52e32c624628e06a09537c7aea8b479f470df3"));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = org.apache.commons.math.util.FastMath.abs(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.floor(35.21903082555857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.1543323524692711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4158446527912376d + "'", double1 == 1.4158446527912376d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(22.180709777452588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.18070977745259d + "'", double1 == 22.18070977745259d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-13.51125965630726d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-13.511259656307258d) + "'", double1 == (-13.511259656307258d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.6555667522640304d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 192.2171757448326d + "'", double1 == 192.2171757448326d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(39.701154568539714d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02550806974095435d + "'", double1 == 0.02550806974095435d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double1 = org.apache.commons.math.util.FastMath.log10(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.342944819032518d + "'", double1 == 4.342944819032518d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 32L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.ulp(22.180709777452588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-13.511259656307258d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.40507128902104855d, (-0.12720663811558966d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.Class<?> wildcardClass1 = convergenceException0.getClass();
        java.lang.Throwable[] throwableArray2 = convergenceException0.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray8);
        java.lang.String str11 = convergenceException10.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray17 = outOfRangeException16.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (short) 1, number21, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable26, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException23, localizable24, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16, localizable18, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, "87f9d0062ada37283c59b895489a095f416e6c9eba8dabcd6518d867cee69261382956d916babd719bdbf4e6e4a6cc54fc82", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable37, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("", objArray39);
        java.lang.String str42 = convergenceException41.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException(localizable44, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable49 = outOfRangeException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable52, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, localizable49, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, "7a5cc44f1e2ac5cced1152a6b05c5838082ebe2a350e03e25e772c619d524a6a6da447231c8811d4b89c1dc2e2480a771f54", objArray54);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray54);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.signum(18.004700740227015d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
//        double double3 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.inverseCumulativeProbability(0.0d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.764899880377996d + "'", double3 == 1.764899880377996d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(1.2679114584199251d);
        try {
            double double4 = normalDistributionImpl0.inverseCumulativeProbability(26.938162984706857d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 26.938 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8975852141610587d + "'", double2 == 0.8975852141610587d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3842507050922375d + "'", double1 == 1.3842507050922375d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(24.546862012672648d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.954478984986479d + "'", double1 == 4.954478984986479d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.special.Gamma.digamma(6.026500708453856d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7109113749806553d + "'", double1 == 1.7109113749806553d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-2.7809026943111093d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7467862820231248d) + "'", double1 == (-1.7467862820231248d));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable17, objArray49);
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 359.1342053695754d, (java.lang.Number) 10.0d, number54);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable58, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("", objArray60);
        java.lang.String str63 = convergenceException62.getPattern();
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException62);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable67, objArray69);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException("", objArray69);
        java.lang.String str72 = convergenceException71.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable73 = convergenceException71.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable74, (java.lang.Number) (short) 1, number76, true);
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        java.lang.Object[] objArray83 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException84 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable81, objArray83);
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException78, localizable79, objArray83);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException62, localizable73, objArray83);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException86);
        java.lang.String str88 = convergenceException86.getPattern();
        java.lang.Throwable[] throwableArray89 = convergenceException86.getSuppressed();
        outOfRangeException55.addSuppressed((java.lang.Throwable) convergenceException86);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "" + "'", str72.equals(""));
        org.junit.Assert.assertNotNull(localizable73);
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "" + "'", str88.equals(""));
        org.junit.Assert.assertNotNull(throwableArray89);
    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        try {
//            double double4 = randomDataImpl0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7228221051703273d + "'", double2 == 0.7228221051703273d);
//    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        double double6 = randomDataImpl0.nextF(0.5d, 1.4173627661473032d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) 100, (-0.8390715290764524d));
//        double double12 = normalDistributionImpl10.cumulativeProbability(1.0d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        try {
//            double double16 = randomDataImpl0.nextGaussian(192.2171757448326d, (-0.8813735870195429d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.881 is smaller than, or equal to, the minimum (0): standard deviation (-0.881)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.77330153122987d + "'", double3 == 28.77330153122987d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9358976170979104d + "'", double6 == 0.9358976170979104d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5039893563146316d + "'", double12 == 0.5039893563146316d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-31.525488034691797d) + "'", double13 == (-31.525488034691797d));
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        int int2 = org.apache.commons.math.util.FastMath.max(3, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (short) 10);
        randomDataImpl0.reSeed();
        randomDataImpl0.reSeed();
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.8657694832396586d));
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long13 = randomDataImpl0.nextPoisson(1.499039715843948d);
//        int[] intArray16 = randomDataImpl0.nextPermutation((int) ' ', 9);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-10.879063549397843d) + "'", double3 == (-10.879063549397843d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3L + "'", long13 == 3L);
//        org.junit.Assert.assertNotNull(intArray16);
//    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        double double4 = randomDataImpl0.nextChiSquare(0.3595072663974203d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("87f9d0062ada37283c59b895489a095f416e6c9eba8dabcd6518d867cee69261382956d916babd719bdbf4e6e4a6cc54fc82", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1707831000912297d + "'", double2 == 3.1707831000912297d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0220707061171746E-6d + "'", double4 == 2.0220707061171746E-6d);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.7302875164411025d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(21.694670652999555d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.69467065299955d + "'", double2 == 21.69467065299955d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        int int1 = org.apache.commons.math.util.FastMath.abs(6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 21.862836871826794d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double14 = randomDataImpl0.nextGamma(71.32400509670025d, (double) (short) 100);
//        java.lang.String str16 = randomDataImpl0.nextSecureHexString(9);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 45.868551673160134d + "'", double3 == 45.868551673160134d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6481.76977102266d + "'", double14 == 6481.76977102266d);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "6681ed166" + "'", str16.equals("6681ed166"));
//    }

//    @Test
//    public void test479() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test479");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        int int7 = randomDataImpl1.nextBinomial(9, 0.5432680528474173d);
//        double double10 = randomDataImpl1.nextWeibull(0.853988047997524d, 0.07829815576435584d);
//        try {
//            int int13 = randomDataImpl1.nextBinomial((int) (byte) 0, (double) 2060935566L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2,060,935,566 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.6647651869855201d) + "'", double4 == (-0.6647651869855201d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.014598308428216395d + "'", double10 == 0.014598308428216395d);
//    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.06413348263674616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06404576977911534d + "'", double1 == 0.06404576977911534d);
    }

//    @Test
//    public void test481() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test481");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("9f1491551a2e478748187bbde5dc3fc8e0c4a4d4f151152a7a798010e82f97afa29ce3376727747a6996a1dcd4de4e05c09a", "602214db9cfc5d09efe15e4e34497a2c9e56c8fd70b99dd18213dad04f3ae3c106358811699e5b57eb4102e679e51c2bf6e5");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 602214db9cfc5d09efe15e4e34497a2c9e56c8fd70b99dd18213dad04f3ae3c106358811699e5b57eb4102e679e51c2bf6e5");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 13.643464061708691d + "'", double3 == 13.643464061708691d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.7168474605568271d) + "'", double13 == (-0.7168474605568271d));
//    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 8, (float) 6);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 0.40507128902104855d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 1.7182818284590453d);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.064143466679078d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.064143466679078d + "'", double1 == 4.064143466679078d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (-4.281642508279315d), (java.lang.Number) 0.9999999999998099d, false);
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable18, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray20);
        java.lang.String str23 = convergenceException22.getPattern();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException22);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable27, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("", objArray29);
        java.lang.String str32 = convergenceException31.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) (short) 1, number36, true);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable41, objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException38, localizable39, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException22, localizable33, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable50, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray52);
        java.lang.String str55 = convergenceException54.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = convergenceException54.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException(localizable56, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable61 = outOfRangeException60.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable65, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException("", objArray67);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException("hi!", objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable61, objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable33, objArray67);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(throwable13, localizable14, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable8, objArray67);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "" + "'", str55.equals(""));
        org.junit.Assert.assertNotNull(localizable56);
        org.junit.Assert.assertNotNull(localizable61);
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double2 = org.apache.commons.math.util.FastMath.atan2(58.238235140851195d, 2.1842882874806984d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5333078121057784d + "'", double2 == 1.5333078121057784d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.141592653589793d, (java.lang.Number) Double.NEGATIVE_INFINITY, true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) Double.POSITIVE_INFINITY);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6755687965113603d, 10.000000000000002d);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double22 = randomDataImpl0.nextExponential(1.2660741690044164d);
//        try {
//            long long25 = randomDataImpl0.nextLong(52L, (long) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (10): lower bound (52) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.527290054265027d + "'", double3 == 14.527290054265027d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "e635ea836787d26edbe5864d2823e749a02ff8296057209f020f2c9dca888e28363410365dce93ab8ce4915a22c3a39841fa" + "'", str13.equals("e635ea836787d26edbe5864d2823e749a02ff8296057209f020f2c9dca888e28363410365dce93ab8ce4915a22c3a39841fa"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.32596378842797596d + "'", double19 == 0.32596378842797596d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7788708494408673d + "'", double20 == 0.7788708494408673d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2014140603815345d + "'", double22 == 0.2014140603815345d);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException5);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable8, objArray9);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.47468363820737447d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.197369073197468d + "'", double1 == 27.197369073197468d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.8416492588916045E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.453570472490746d + "'", double1 == 8.453570472490746d);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        double double6 = randomDataImpl0.nextF(0.5d, 1.4173627661473032d);
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 100);
//        long long12 = randomDataImpl0.nextLong(0L, 2L);
//        try {
//            long long15 = randomDataImpl0.nextSecureLong(2056318588L, 2L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,056,318,588 is larger than, or equal to, the maximum (2): lower bound (2,056,318,588) must be strictly less than upper bound (2)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 21.911935713023432d + "'", double3 == 21.911935713023432d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 63.94411496528959d + "'", double6 == 63.94411496528959d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 21.862836871826794d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable4, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.String str9 = convergenceException8.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable19, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable16, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray21);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable0, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray21);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        int int7 = randomDataImpl1.nextBinomial(9, 0.5432680528474173d);
//        double double10 = randomDataImpl1.nextWeibull(0.853988047997524d, 0.07829815576435584d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.8200406418170615d) + "'", double4 == (-0.8200406418170615d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.11276539834081348d + "'", double10 == 0.11276539834081348d);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextGaussian(7.450833191230467E34d, 1.5707963266948965d);
        try {
            int int7 = randomDataImpl1.nextZipf(32, (-1.9972144990387393d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.997 is smaller than, or equal to, the minimum (0): exponent (-1.997)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.450833191230467E34d + "'", double4 == 7.450833191230467E34d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 85L);
    }
}

