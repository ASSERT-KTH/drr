import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3862943611198906d + "'", double1 == 1.3862943611198906d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.6098494453571889d, (java.lang.Number) 0.0f, (java.lang.Number) (short) 0);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0f + "'", number4.equals(0.0f));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.log((-46.93738671994499d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, Double.POSITIVE_INFINITY, (double) 52, (int) (byte) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.774273095146928d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7742730951469279d + "'", double2 == 0.7742730951469279d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.special.Erf.erf(13.553442881548147d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.3289803051047428d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3233178168367433d + "'", double1 == 0.3233178168367433d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.5773894904459439d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6100100723669747d + "'", double1 == 0.6100100723669747d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 6, 12.534361464213815d, (-24.725268680222683d), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 12.534 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable5, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("hi!", objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(100, "", objArray7);
        java.lang.Class<?> wildcardClass12 = maxIterationsExceededException11.getClass();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.3842507050922375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 79.31172318979358d + "'", double1 == 79.31172318979358d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.4197593446761065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.188948566822469d + "'", double1 == 2.188948566822469d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.23998629493553567d, (java.lang.Number) (-12.16414205029549d), false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) (-1.506844020238002d), (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d));
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 0.017453292519943295d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 1.303909551780072d, (java.lang.Number) 0.3447799471387694d, true);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int5 = randomDataImpl1.nextHypergeometric(0, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.special.Erf.erf(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999326d + "'", double1 == 0.9999999999999326d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.6555667522640304d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0658549729464604d) + "'", double1 == (-1.0658549729464604d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 26.938162984706857d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.06854820744336733d), (-13.51125965630726d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.special.Gamma.digamma(7.012254107578257d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.874664126839149d + "'", double1 == 1.874664126839149d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.3595072663974203d, (-0.3374749637642045d), (double) (short) 100, (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.08227867589781208d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 52L, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable4, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.String str9 = convergenceException8.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray15 = outOfRangeException14.getArguments();
        java.lang.Class<?> wildcardClass16 = objArray15.getClass();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable1, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (null)", objArray15);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(localizable10);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        int int2 = org.apache.commons.math.util.FastMath.max(52, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.9900001597529149d, (java.lang.Number) (-77.0595521907205d), (java.lang.Number) 100L);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) '4');
//        java.lang.String str11 = randomDataImpl0.nextHexString((int) (byte) 100);
//        long long14 = randomDataImpl0.nextLong((long) 3, (long) (byte) 100);
//        try {
//            int int17 = randomDataImpl0.nextBinomial(8, 21.694670652999555d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 21.695 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.866778291427465d + "'", double3 == 34.866778291427465d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "f7d84deb6605e7083507a0fb5f382984c58fb021c099eb0ffda4aba7d4d5a873d6fd4fd9aa03127298e5d99d5a05be5ae675" + "'", str11.equals("f7d84deb6605e7083507a0fb5f382984c58fb021c099eb0ffda4aba7d4d5a873d6fd4fd9aa03127298e5d99d5a05be5ae675"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 19L + "'", long14 == 19L);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        int int2 = org.apache.commons.math.util.FastMath.max(32, 13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.log(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6094379124341003d + "'", double1 == 1.6094379124341003d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.cos(45.868551673160134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.31025208989080005d) + "'", double1 == (-0.31025208989080005d));
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.getMean();
//        double double3 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        randomDataImpl0.reSeedSecure(0L);
//        double double8 = randomDataImpl0.nextGamma(0.7970747335500249d, 1.663999375826442d);
//        int int11 = randomDataImpl0.nextInt(6, (int) (short) 100);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.6698777109326468d) + "'", double3 == (-0.6698777109326468d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.32875635635740336d + "'", double8 == 0.32875635635740336d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 83 + "'", int11 == 83);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.3595072663974203d, 22.18070977745259d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.397271607474473E-10d + "'", double2 == 1.397271607474473E-10d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable17, objArray49);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException(localizable52, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException56);
        java.lang.Object[] objArray58 = mathException57.getArguments();
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException(localizable17, objArray58);
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException59.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable60, (java.lang.Number) 0.3289803051047428d);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(localizable60);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.asin((-8.845673834601056d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.02550806974095435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5452854900566904d + "'", double1 == 1.5452854900566904d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 49L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 49 + "'", int1 == 49);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15354517795926734d + "'", double1 == 0.15354517795926734d);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        int int5 = randomDataImpl0.nextBinomial(52, 0.5772156649015329d);
//        double double7 = randomDataImpl0.nextChiSquare(62.992141413634215d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07519576107935486d + "'", double2 == 0.07519576107935486d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 28 + "'", int5 == 28);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 47.84523318774835d + "'", double7 == 47.84523318774835d);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.473814720414451d + "'", double1 == 0.473814720414451d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable17, objArray49);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException55 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) (-6.814282900389825d), (java.lang.Number) (-2.885320602561484d), true);
        boolean boolean56 = numberIsTooLargeException55.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.015772404403454655d), (java.lang.Number) 0.05538936600958528d, true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray9);
        java.lang.String str12 = convergenceException11.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable19 = outOfRangeException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable22, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable19, objArray24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 3.779109627299853d);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException();
        java.lang.Class<?> wildcardClass31 = convergenceException30.getClass();
        java.lang.Throwable[] throwableArray32 = convergenceException30.getSuppressed();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable19, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) (short) 1, number36, true);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable41, objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException38, localizable39, objArray43);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45);
        outOfRangeException4.addSuppressed((java.lang.Throwable) mathException45);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(wildcardClass31);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(objArray43);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int2 = org.apache.commons.math.util.FastMath.min(2147483647, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double22 = randomDataImpl0.nextExponential(1.2660741690044164d);
//        double double25 = randomDataImpl0.nextUniform((-20.15821253309177d), 9.699999999999999E-96d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-26.522256191997734d) + "'", double3 == (-26.522256191997734d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "3c3037b87b88741ca737ab8c06f9c073f4bdfe4ed94b0d16cc2962ac10456f5cbfa18d5ca90a3ab4f89d7f3eeb644e7b24c1" + "'", str13.equals("3c3037b87b88741ca737ab8c06f9c073f4bdfe4ed94b0d16cc2962ac10456f5cbfa18d5ca90a3ab4f89d7f3eeb644e7b24c1"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.7569674018397636d) + "'", double19 == (-0.7569674018397636d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.9596919507050334d) + "'", double20 == (-0.9596919507050334d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.924021495969763d + "'", double22 == 2.924021495969763d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + (-13.382265653023136d) + "'", double25 == (-13.382265653023136d));
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(5.298292365610485d, 2.718281828459045d, 0.853988047997524d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.718281828459045d + "'", double4 == 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.718281828459045d + "'", double5 == 2.718281828459045d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.31588426736961117d), 0.5039893563146316d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.31588426736961117d) + "'", double2 == (-0.31588426736961117d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) (byte) 1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Object[] objArray5 = numberIsTooLargeException3.getArguments();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 1 + "'", number4.equals((byte) 1));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.NaN, (java.lang.Number) 0.0d, true);
        outOfRangeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        boolean boolean10 = numberIsTooSmallException8.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double4 = normalDistributionImpl0.density(1.2044012063326326d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.19316130419452515d + "'", double4 == 0.19316130419452515d);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        int int5 = randomDataImpl0.nextBinomial(52, 0.5772156649015329d);
//        double double8 = randomDataImpl0.nextF(4.605170185988092d, 21.69467065299955d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05415379218112492d + "'", double2 == 0.05415379218112492d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5062353281850157d + "'", double8 == 0.5062353281850157d);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.5773894904459439d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 2, 0.2638446090032678d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.8416492588916045E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 657.4410600410091d + "'", double1 == 657.4410600410091d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException2);
        java.lang.Object[] objArray4 = maxIterationsExceededException2.getArguments();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("eda3225c6fbb4ceaa992f942764609704ebcd1016f5b140e0fd2", objArray4);
        org.junit.Assert.assertNotNull(objArray4);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) '4');
//        java.lang.String str11 = randomDataImpl0.nextHexString((int) (byte) 100);
//        long long14 = randomDataImpl0.nextLong((long) 3, (long) (byte) 100);
//        long long17 = randomDataImpl0.nextLong((long) 10, 62L);
//        randomDataImpl0.reSeed(0L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-4.683626434817649d) + "'", double3 == (-4.683626434817649d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "eedeedac141528574e80bec9a8c24b2a6a1c01916761bbb0352a41320317b90922c39f63e8c6b7d769c7617b3218603d70d5" + "'", str11.equals("eedeedac141528574e80bec9a8c24b2a6a1c01916761bbb0352a41320317b90922c39f63e8c6b7d769c7617b3218603d70d5"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 14L + "'", long14 == 14L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 52L + "'", long17 == 52L);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("45c55a206f7493edf3166781a745a0d6c978c702c5964d009162040500c024db957c621b7a19fe8df3e1eea8448376054feb", objArray1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        java.lang.Number number17 = numberIsTooSmallException16.getArgument();
        java.lang.Number number18 = numberIsTooSmallException16.getMin();
        boolean boolean19 = numberIsTooSmallException16.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.4173627661473032d + "'", number18.equals(1.4173627661473032d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-26.522256191997734d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6498312146082846E11d + "'", double1 == 1.6498312146082846E11d);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.getMean();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        try {
//            double double22 = normalDistributionImpl15.inverseCumulativeProbability((-10.575996802624607d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -10.576 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-26.06293136769318d) + "'", double3 == (-26.06293136769318d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "3c5cbc3c4ce4fd429aaca0a409500e69707f7ae9b2dd017ac36981c96d96d2d66cb00fba041bf9df2f689a315962db808dc0" + "'", str13.equals("3c5cbc3c4ce4fd429aaca0a409500e69707f7ae9b2dd017ac36981c96d96d2d66cb00fba041bf9df2f689a315962db808dc0"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.8709296092959338d) + "'", double20 == (-0.8709296092959338d));
//    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        int[] intArray16 = randomDataImpl0.nextPermutation(4, (int) (byte) 1);
//        try {
//            java.lang.String str18 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-17.866843657250776d) + "'", double3 == (-17.866843657250776d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.7416739843840975d) + "'", double13 == (-0.7416739843840975d));
//        org.junit.Assert.assertNotNull(intArray16);
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        long long6 = randomDataImpl0.nextLong(0L, (long) 2147483647);
//        randomDataImpl0.reSeedSecure((long) (-1));
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double12 = normalDistributionImpl9.cumulativeProbability(Double.NaN, (double) 0);
//        double double13 = normalDistributionImpl9.sample();
//        double double14 = normalDistributionImpl9.getMean();
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double[] doubleArray17 = normalDistributionImpl9.sample(1);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 249730124L + "'", long6 == 249730124L);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.616732435969026d) + "'", double13 == (-0.616732435969026d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.2094942883398025d) + "'", double15 == (-1.2094942883398025d));
//        org.junit.Assert.assertNotNull(doubleArray17);
//    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.getMean();
//        double double3 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        randomDataImpl0.reSeedSecure(0L);
//        int int8 = randomDataImpl0.nextBinomial(33, 0.40507128902104855d);
//        try {
//            double double11 = randomDataImpl0.nextGamma(Double.NaN, 12.911386656793239d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument � p = 0.117");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.1887194830035348d) + "'", double3 == (-1.1887194830035348d));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 11 + "'", int8 == 11);
//    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double14 = randomDataImpl0.nextGamma(71.32400509670025d, (double) (short) 100);
//        try {
//            double double17 = randomDataImpl0.nextGaussian((-1.0d), (-0.8657694832396586d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.866 is smaller than, or equal to, the minimum (0): standard deviation (-0.866)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.5725733147814083d) + "'", double3 == (-0.5725733147814083d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6739.459032238535d + "'", double14 == 6739.459032238535d);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        long long6 = randomDataImpl0.nextLong(0L, (long) 2147483647);
//        randomDataImpl0.reSeedSecure((long) (-1));
//        try {
//            int int11 = randomDataImpl0.nextPascal(4, (-0.9209101485048207d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.921 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 281856654L + "'", long6 == 281856654L);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double22 = randomDataImpl0.nextT(0.5092332054263046d);
//        try {
//            double double25 = randomDataImpl0.nextGamma((-0.7833250184011098d), 0.9999999999998099d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.783 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-11.5392305544221d) + "'", double3 == (-11.5392305544221d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "68c720600eee183a89585c5c33543906e2118d58ae5a4ab3f9e04193ac9da0610c49ee1ba42ee2842b941d0799938382bda0" + "'", str13.equals("68c720600eee183a89585c5c33543906e2118d58ae5a4ab3f9e04193ac9da0610c49ee1ba42ee2842b941d0799938382bda0"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0684844613525086d) + "'", double19 == (-1.0684844613525086d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.1319342473382399d) + "'", double20 == (-1.1319342473382399d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-0.5044001375725263d) + "'", double22 == (-0.5044001375725263d));
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        normalDistributionImpl0.reseedRandomGenerator(3L);
        try {
            double double7 = normalDistributionImpl0.inverseCumulativeProbability(18.004700740227015d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 18.005 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2L, number1, false);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        int int5 = randomDataImpl0.nextBinomial(52, 0.5772156649015329d);
//        double double8 = randomDataImpl0.nextGaussian(1.1680965989262542d, 7.69459862670642E-23d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02371244640026722d + "'", double2 == 0.02371244640026722d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.1680965989262542d + "'", double8 == 1.1680965989262542d);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy(39.56893168362026d, 1.764899880377996d);
//        try {
//            double double6 = randomDataImpl0.nextGaussian((-0.9151332082422362d), (-0.5021943828015879d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.502 is smaller than, or equal to, the minimum (0): standard deviation (-0.502)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.1606054299888d + "'", double3 == 35.1606054299888d);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7337131189871472d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.74702556553347d + "'", double1 == 0.74702556553347d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.16386466025171564d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1631323054034987d) + "'", double1 == (-0.1631323054034987d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.4972896813789087d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-28.492599938416912d) + "'", double1 == (-28.492599938416912d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable17, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable14, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable26, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.String str31 = convergenceException30.getPattern();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable35, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray37);
        java.lang.String str40 = convergenceException39.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = convergenceException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) (short) 1, number44, true);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable49, objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException46, localizable47, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, localizable41, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable58, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("", objArray60);
        java.lang.String str63 = convergenceException62.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = convergenceException62.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException(localizable64, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable69 = outOfRangeException68.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable73, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException("hi!", objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable69, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable41, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(localizable8, objArray75);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException85 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) (-44.44377415455416d), (java.lang.Number) 1.6673845734742283d, false);
        org.apache.commons.math.exception.util.Localizable localizable86 = numberIsTooLargeException85.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertNotNull(localizable69);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + localizable86 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable86.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 13.553442881548147d, (java.lang.Number) 0.47468363820737447d, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number3);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        java.lang.String str7 = outOfRangeException4.toString();
        java.lang.Number number8 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 1 out of [0, null] range" + "'", str7.equals("org.apache.commons.math.exception.OutOfRangeException: 1 out of [0, null] range"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0L + "'", number8.equals(0L));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 32, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        randomDataImpl0.reSeedSecure((-1L));
//        try {
//            double double18 = randomDataImpl0.nextGamma((double) (byte) 100, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 41.74974722512717d + "'", double3 == 41.74974722512717d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.1675945608889178d + "'", double13 == 1.1675945608889178d);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass6 = numberIsTooSmallException3.getClass();
        java.lang.Number number7 = numberIsTooSmallException3.getMin();
        boolean boolean8 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.9447414676202983E-9d, (double) 35, 0.7742730951469279d);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) '4');
//        int int12 = randomDataImpl0.nextPascal((int) '4', 3.114482300479487E-48d);
//        double double15 = randomDataImpl0.nextBeta(6.702643995590282d, 359.1342053695754d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.15842466027311d + "'", double3 == 33.15842466027311d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.017775971102762196d + "'", double15 == 0.017775971102762196d);
//    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
//        double double4 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.getMean();
//        double double7 = normalDistributionImpl0.density(0.0d);
//        try {
//            double double10 = normalDistributionImpl0.cumulativeProbability((double) 1.0f, (double) (-1.0f));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.3350771891555089d + "'", double4 == 1.3350771891555089d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3989422804014327d + "'", double7 == 0.3989422804014327d);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.6438381202745753d), (-2.7809026943111093d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6438381202745753d) + "'", double2 == (-1.6438381202745753d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable13 = outOfRangeException12.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable24, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray26);
        java.lang.String str29 = convergenceException28.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException28.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable35 = outOfRangeException34.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable38, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        java.lang.String str43 = convergenceException42.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException42.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable50 = outOfRangeException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable53, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable50, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable61, objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray63);
        java.lang.String str66 = convergenceException65.getPattern();
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException65);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable70, objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("", objArray72);
        java.lang.String str75 = convergenceException74.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = convergenceException74.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Number number79 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException81 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable77, (java.lang.Number) (short) 1, number79, true);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable84, objArray86);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException81, localizable82, objArray86);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException65, localizable76, objArray86);
        java.lang.Object[] objArray91 = new java.lang.Object[] { mathIllegalArgumentException58, localizable76, (-0.5772156677920679d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable35, objArray91);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException12, localizable20, objArray91);
        org.apache.commons.math.exception.util.Localizable localizable94 = mathException93.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "" + "'", str66.equals(""));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
        org.junit.Assert.assertNotNull(localizable76);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertNull(localizable94);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.sin((-34.843832110945996d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28241716898543195d + "'", double1 == 0.28241716898543195d);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        try {
//            int int6 = randomDataImpl0.nextSecureInt((int) (byte) 100, (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10): lower bound (100) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 30.222754284763163d + "'", double3 == 30.222754284763163d);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double2 = org.apache.commons.math.util.FastMath.pow(12.622322455558686d, 1.0614115375104693d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.748977948096709d + "'", double2 == 14.748977948096709d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable17, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable14, objArray19);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 3.779109627299853d);
        java.lang.Number number25 = notStrictlyPositiveException24.getMin();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable9, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray11);
        java.lang.String str14 = convergenceException13.getPattern();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException13);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable18, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray20);
        java.lang.String str23 = convergenceException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Number number27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) (short) 1, number27, true);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable32, objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException29, localizable30, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException13, localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException4, "hi!", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number43);
        java.lang.Object[] objArray45 = outOfRangeException44.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException4, "87f9d0062ada37283c59b895489a095f416e6c9eba8dabcd6518d867cee69261382956d916babd719bdbf4e6e4a6cc54fc82", objArray45);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
        org.junit.Assert.assertNotNull(localizable24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 7.450833191230467E34d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8200406418170615d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable17, objArray49);
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 359.1342053695754d, (java.lang.Number) 10.0d, number54);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable60, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray62);
        java.lang.String str65 = convergenceException64.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable66 = convergenceException64.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable67, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable72 = outOfRangeException71.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable75, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("", objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, localizable72, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException("", objArray77);
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException55, localizable56, objArray77);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "" + "'", str65.equals(""));
        org.junit.Assert.assertNotNull(localizable66);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray77);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 49, 0.0d, 12.924894896216891d, 28);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.1842882874806984d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long13 = randomDataImpl0.nextPoisson(1.499039715843948d);
//        try {
//            double double16 = randomDataImpl0.nextBeta(3.1622776601683795d, (-0.10177419206008143d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.929");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 39.14065503859191d + "'", double3 == 39.14065503859191d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 4L + "'", long13 == 4L);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5062353281850157d, 0.3289803051047428d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9945220102274002d + "'", double2 == 0.9945220102274002d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) (-20.15821253309177d), (java.lang.Number) 53.78804988277083d, false);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long14 = randomDataImpl0.nextLong(32L, (long) 100);
//        try {
//            double double16 = randomDataImpl0.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-27.490502205386797d) + "'", double3 == (-27.490502205386797d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 41L + "'", long14 == 41L);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
//        double double5 = normalDistributionImpl0.cumulativeProbability(0.8975852141610587d, 1.9802279607563054d);
//        double double6 = normalDistributionImpl0.getStandardDeviation();
//        double double7 = normalDistributionImpl0.sample();
//        double double9 = normalDistributionImpl0.inverseCumulativeProbability((double) 0);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.16086440265790714d + "'", double5 == 0.16086440265790714d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.48858171489322927d) + "'", double7 == (-0.48858171489322927d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-4.281642508279315d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-245.32004510821238d) + "'", double1 == (-245.32004510821238d));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4711276743037347d, (java.lang.Number) 0.8845158039790166d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.36842577779469815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) '4');
//        int int12 = randomDataImpl0.nextPascal((int) '4', 3.114482300479487E-48d);
//        try {
//            int int15 = randomDataImpl0.nextZipf(31, (-0.3374749637642045d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.337 is smaller than, or equal to, the minimum (0): exponent (-0.337)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.315180992347308d + "'", double3 == 15.315180992347308d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
//        double double4 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.getStandardDeviation();
//        try {
//            double double8 = normalDistributionImpl0.cumulativeProbability(0.7337131189871472d, 3.552713678800501E-15d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7990739692375164d + "'", double4 == 0.7990739692375164d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.log1p(34.68354111479325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5746895492780437d + "'", double1 == 3.5746895492780437d);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        long long6 = randomDataImpl0.nextLong(0L, (long) 2147483647);
//        randomDataImpl0.reSeedSecure((long) (-1));
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double12 = normalDistributionImpl9.cumulativeProbability(Double.NaN, (double) 0);
//        double double13 = normalDistributionImpl9.sample();
//        double double14 = normalDistributionImpl9.getMean();
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double18 = randomDataImpl0.nextGamma((double) (byte) 100, 5.298292365610485d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1920884239L + "'", long6 == 1920884239L);
//        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.08292144970559887d + "'", double13 == 0.08292144970559887d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.9538870854524366d) + "'", double15 == (-1.9538870854524366d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 444.3095895220466d + "'", double18 == 444.3095895220466d);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.ceil(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number4, false);
        java.lang.Number number7 = numberIsTooSmallException6.getArgument();
        java.lang.Number number8 = numberIsTooSmallException6.getMin();
        java.lang.Object[] objArray9 = numberIsTooSmallException6.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("7a5cc44f1e2ac5cced1152a6b05c5838082ebe2a350e03e25e772c619d524a6a6da447231c8811d4b89c1dc2e2480a771f54", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(2, "", objArray9);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0f) + "'", number7.equals((-1.0f)));
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray14 = outOfRangeException13.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable16, (java.lang.Number) (short) 1, number18, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable23, objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, localizable21, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooLargeException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number32);
        java.lang.Object[] objArray34 = outOfRangeException33.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable0, localizable15, objArray34);
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number38, false);
        java.lang.Number number41 = numberIsTooSmallException40.getMin();
        convergenceException36.addSuppressed((java.lang.Throwable) numberIsTooSmallException40);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10516633568161556d + "'", double1 == 0.10516633568161556d);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        try {
//            java.lang.String str6 = randomDataImpl1.nextHexString((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.6885921597876932d) + "'", double4 == (-0.6885921597876932d));
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.cumulativeProbability((-1.0d));
//        double double3 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15865525393145702d + "'", double2 == 0.15865525393145702d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.10564358756083168d + "'", double3 == 0.10564358756083168d);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-6.814282900389825d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-44.44377415455416d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable13 = outOfRangeException12.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException12);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable24, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray26);
        java.lang.String str29 = convergenceException28.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException28.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable35 = outOfRangeException34.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable38, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        java.lang.String str43 = convergenceException42.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException42.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable50 = outOfRangeException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable53, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException("", objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable50, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable61, objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray63);
        java.lang.String str66 = convergenceException65.getPattern();
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException65);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable70, objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("", objArray72);
        java.lang.String str75 = convergenceException74.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable76 = convergenceException74.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Number number79 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException81 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable77, (java.lang.Number) (short) 1, number79, true);
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable84, objArray86);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException81, localizable82, objArray86);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException65, localizable76, objArray86);
        java.lang.Object[] objArray91 = new java.lang.Object[] { mathIllegalArgumentException58, localizable76, (-0.5772156677920679d) };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable35, objArray91);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException12, localizable20, objArray91);
        org.apache.commons.math.exception.util.Localizable localizable94 = mathException93.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertNotNull(localizable30);
        org.junit.Assert.assertNotNull(localizable35);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "" + "'", str66.equals(""));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertTrue("'" + str75 + "' != '" + "" + "'", str75.equals(""));
        org.junit.Assert.assertNotNull(localizable76);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertTrue("'" + localizable94 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable94.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeed();
//        int int6 = randomDataImpl0.nextSecureInt(32, (int) '#');
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 34 + "'", int6 == 34);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 20 + "'", int1 == 20);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.floor((-42.147932465463775d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-43.0d) + "'", double1 == (-43.0d));
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double24 = randomDataImpl0.nextBeta((-8.152030403808633d), (-0.6698777109326468d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.368");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.8060501704444274d + "'", double3 == 1.8060501704444274d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1d31858679b3d55e6c3fc9b2960242e22d95eede287e3f52d2392b40cbaf9fe36cb6653335c832a43e44e38edcc8a01cb798" + "'", str13.equals("1d31858679b3d55e6c3fc9b2960242e22d95eede287e3f52d2392b40cbaf9fe36cb6653335c832a43e44e38edcc8a01cb798"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.20735987012703833d) + "'", double19 == (-0.20735987012703833d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.1887440150941204d) + "'", double20 == (-1.1887440150941204d));
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.11829152908655012d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11884638150958175d + "'", double1 == 0.11884638150958175d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 73.74865724833803d + "'", double1 == 73.74865724833803d);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
//        double double4 = normalDistributionImpl0.sample();
//        double double5 = normalDistributionImpl0.getMean();
//        double double7 = normalDistributionImpl0.density(0.0d);
//        double double8 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.6727189592340005d) + "'", double4 == (-0.6727189592340005d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3989422804014327d + "'", double7 == 0.3989422804014327d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-0.34432653910341665d) + "'", double8 == (-0.34432653910341665d));
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8, (float) 61L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 61.0f + "'", float2 == 61.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (-4.281642508279315d), (java.lang.Number) 0.9999999999998099d, false);
        boolean boolean13 = numberIsTooSmallException12.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1776.169164905552d, (-6.814282900389825d), (double) 100.0f, (int) (short) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.3665121065625489d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.8045721045361685d, 0.0d, 0.19316130419452515d, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.22016507684230757d, 0.8805632551649238d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.24500459614710832d + "'", double2 == 0.24500459614710832d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable14 = outOfRangeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable17, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable14, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable26, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.String str31 = convergenceException30.getPattern();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException30);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable35, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray37);
        java.lang.String str40 = convergenceException39.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = convergenceException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Number number44 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) (short) 1, number44, true);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable49, objArray51);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException46, localizable47, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException30, localizable41, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable58, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException("", objArray60);
        java.lang.String str63 = convergenceException62.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = convergenceException62.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException(localizable64, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable69 = outOfRangeException68.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable73, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException("hi!", objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable69, objArray75);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable41, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(localizable8, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException81);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertNotNull(localizable64);
        org.junit.Assert.assertNotNull(localizable69);
        org.junit.Assert.assertNotNull(objArray75);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1521132842L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.83586836556275d + "'", double1 == 21.83586836556275d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(12.622322455558686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 723.2058043567183d + "'", double1 == 723.2058043567183d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-41.30771945452246d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.546297637560345d + "'", double1 == 14.546297637560345d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 31L, (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        long long6 = randomDataImpl0.nextLong(0L, (long) 2147483647);
//        try {
//            double double8 = randomDataImpl0.nextExponential((-24.57882245744277d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -24.579 is smaller than, or equal to, the minimum (0): mean (-24.579)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1743907398L + "'", long6 == 1743907398L);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double2 = org.apache.commons.math.util.FastMath.max((-20.15821253309177d), (-10.879063549397843d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-10.879063549397843d) + "'", double2 == (-10.879063549397843d));
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test154");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        try {
//            int int19 = randomDataImpl0.nextBinomial(2, (-0.8794399162728251d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.879 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 53.2983567144936d + "'", double3 == 53.2983567144936d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "06097933bdc54e13c01aba433fc993877aa0fbeaf6d3eff275dd3c2cbe596a885d62d974a0989c55a30f8c3650de994eafe0" + "'", str13.equals("06097933bdc54e13c01aba433fc993877aa0fbeaf6d3eff275dd3c2cbe596a885d62d974a0989c55a30f8c3650de994eafe0"));
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        float float2 = org.apache.commons.math.util.FastMath.max(6.0f, (float) 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray13 = outOfRangeException12.getArguments();
        java.lang.Number number14 = outOfRangeException12.getHi();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0L + "'", number14.equals(0L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0E97d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E97d + "'", double1 == 1.0E97d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable4, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, "e0415bf92eb19e4afd034c2d36405149ebed5cf521f743ae67a53f3c3fca265378b120611d5f0bd51d27fe3f403e514e2980", objArray6);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.1622776601683795d, (java.lang.Number) 0.3595072663974203d, false);
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number15, false);
        java.lang.Number number18 = numberIsTooSmallException17.getArgument();
        boolean boolean19 = numberIsTooSmallException17.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass20 = numberIsTooSmallException17.getClass();
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooSmallException17.getGeneralPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException23);
        java.lang.Object[] objArray25 = mathException24.getArguments();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException13, localizable21, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable31, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException28, "e0415bf92eb19e4afd034c2d36405149ebed5cf521f743ae67a53f3c3fca265378b120611d5f0bd51d27fe3f403e514e2980", objArray33);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable21, objArray33);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.405 is smaller than, or equal to, the minimum (0): ", objArray33);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-1.0f) + "'", number18.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        double double6 = randomDataImpl0.nextF(0.5d, 1.4173627661473032d);
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 100);
//        long long12 = randomDataImpl0.nextLong(0L, 2L);
//        try {
//            double double15 = randomDataImpl0.nextUniform(39.701154568539714d, 16.087138852654263d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 39.701 is larger than, or equal to, the maximum (16.087): lower bound (39.701) must be strictly less than upper bound (16.087)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 25.531138207740845d + "'", double3 == 25.531138207740845d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.266312965789042E-8d + "'", double6 == 5.266312965789042E-8d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 22 + "'", int9 == 22);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        int int7 = randomDataImpl1.nextBinomial(9, 0.5432680528474173d);
//        double double10 = randomDataImpl1.nextWeibull(0.853988047997524d, 0.07829815576435584d);
//        randomDataImpl1.reSeed(62L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.6650935088464007d) + "'", double4 == (-0.6650935088464007d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 7 + "'", int7 == 7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.003001370211832367d + "'", double10 == 0.003001370211832367d);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) 100, (-0.8390715290764524d));
        try {
            double double6 = normalDistributionImpl3.cumulativeProbability(1.303909551780072d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.684317030204306d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.cos((-42.147932465463775d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.26052733325742544d) + "'", double1 == (-0.26052733325742544d));
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed();
//        long long9 = randomDataImpl0.nextPoisson(0.010050166663333094d);
//        double double11 = randomDataImpl0.nextT(0.11829152908655012d);
//        try {
//            int[] intArray14 = randomDataImpl0.nextPermutation(31, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 61.11378143574793d + "'", double3 == 61.11378143574793d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2455006.3483344736d + "'", double11 == 2455006.3483344736d);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double4 = normalDistributionImpl0.density((double) 10.0f);
        try {
            double double7 = normalDistributionImpl0.cumulativeProbability(4.61512051684126d, (double) 3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.69459862670642E-23d + "'", double4 == 7.69459862670642E-23d);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(1, 52);
//        double double19 = randomDataImpl0.nextChiSquare(2.000637772820911d);
//        double double22 = randomDataImpl0.nextGaussian(6.702643995590282d, 9102.631129507447d);
//        java.lang.Class<?> wildcardClass23 = randomDataImpl0.getClass();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.639231894800851d + "'", double3 == 6.639231894800851d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "8657144287203c947e9c0c2bfa0a78c65ce1509b7f9b9c65b8054d218eb0893f49eafe29f1e32deccb8764739e7476643213" + "'", str13.equals("8657144287203c947e9c0c2bfa0a78c65ce1509b7f9b9c65b8054d218eb0893f49eafe29f1e32deccb8764739e7476643213"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.44269092812265476d + "'", double19 == 0.44269092812265476d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-6146.22334164943d) + "'", double22 == (-6146.22334164943d));
//        org.junit.Assert.assertNotNull(wildcardClass23);
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl0.cumulativeProbability(Double.NaN, (double) 0);
//        double double4 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.cumulativeProbability(1.6673845734742283d);
//        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.43705891640772465d) + "'", double4 == (-0.43705891640772465d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9522810203286101d + "'", double6 == 0.9522810203286101d);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.7785319099002012d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1782720173633274d + "'", double1 == 2.1782720173633274d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (short) 10);
        randomDataImpl0.reSeedSecure();
        randomDataImpl0.reSeed(0L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.log(79.31172318979358d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.373385951129319d + "'", double1 == 4.373385951129319d);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
//        double double3 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.cumulativeProbability(0.7742730951469279d, (double) 20);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.21684857935902555d) + "'", double3 == (-0.21684857935902555d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.21938465531266094d + "'", double6 == 0.21938465531266094d);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.365840259013682d + "'", double1 == 2.365840259013682d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable8, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.String str13 = convergenceException12.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException12.getGeneralPattern();
        mathException5.addSuppressed((java.lang.Throwable) convergenceException12);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(number16, (java.lang.Number) (byte) 1, false);
        java.lang.Number number20 = numberIsTooLargeException19.getMax();
        convergenceException12.addSuppressed((java.lang.Throwable) numberIsTooLargeException19);
        boolean boolean22 = numberIsTooLargeException19.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable29, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException("", objArray31);
        java.lang.String str34 = convergenceException33.getPattern();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException33);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable38, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        java.lang.String str43 = convergenceException42.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException42.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) (short) 1, number47, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable52, objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException49, localizable50, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException33, localizable44, objArray54);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException(localizable58, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException62);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException(localizable64, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable69 = outOfRangeException68.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable70, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException74);
        java.lang.Object[] objArray76 = mathException75.getArguments();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException63, localizable69, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable44, objArray76);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray76);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray76);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException19, "e0104fd1a7a01ddf92b781f7e58bc78471e9edf449ed17c02e9fa706d7ca7d44f3bdcc88a9228905e1991661728d6dfe31a7", objArray76);
        org.apache.commons.math.exception.util.Localizable localizable82 = numberIsTooLargeException19.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (byte) 1 + "'", number20.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(localizable44);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + localizable69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable69.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        double double11 = randomDataImpl0.nextGaussian(0.05538936600958528d, (double) ' ');
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextUniform(0.0d, 0.39435368191090925d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 46.508499257421335d + "'", double3 == 46.508499257421335d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 44.399452998075375d + "'", double11 == 44.399452998075375d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.14862420533031015d + "'", double15 == 0.14862420533031015d);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 5729.5779513082325d, (java.lang.Number) (-0.9036922050915067d), false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4711276743037347d, (java.lang.Number) 0.8845158039790166d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        boolean boolean7 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.471 is larger than the maximum (0.885)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.471 is larger than the maximum (0.885)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.8845158039790166d + "'", number6.equals(0.8845158039790166d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.log((-20.15821253309177d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        int int7 = randomDataImpl1.nextBinomial(9, 0.5432680528474173d);
//        double double10 = randomDataImpl1.nextWeibull(0.853988047997524d, 0.07829815576435584d);
//        java.lang.String str12 = randomDataImpl1.nextHexString(52);
//        try {
//            double double15 = randomDataImpl1.nextGaussian(3.2710663101885897d, (-43.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -43 is smaller than, or equal to, the minimum (0): standard deviation (-43)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.7804131773685985d) + "'", double4 == (-0.7804131773685985d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.016345610534152916d + "'", double10 == 0.016345610534152916d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a57429052fe3872a1aaff8f19d0d300c07e2d887640170197dc7" + "'", str12.equals("a57429052fe3872a1aaff8f19d0d300c07e2d887640170197dc7"));
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.7440230792707043d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.924021495969763d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable5, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.String str10 = convergenceException9.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable17 = outOfRangeException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable20, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable17, objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException27);
        java.lang.Object[] objArray29 = maxIterationsExceededException27.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException27, "", objArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable17, objArray49);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException(12, "8d82d9db46adf7ac503ab3946dd276fd2e59f21d2a358f6330ffd498fca6aa1da593827c30290b80cf8a7703e2e7ba66ef55", objArray49);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double23 = normalDistributionImpl15.cumulativeProbability(39.56893168362026d, (double) 100.0f);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3761472716238394d + "'", double3 == 1.3761472716238394d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "59d6f71197055e56bdd381145268f18b89be546bd7fffd99f0c27e9877707778d5e99cd047e13aea5234bef4c251d484cb7c" + "'", str13.equals("59d6f71197055e56bdd381145268f18b89be546bd7fffd99f0c27e9877707778d5e99cd047e13aea5234bef4c251d484cb7c"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.0265041324964574d) + "'", double19 == (-2.0265041324964574d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.3468843757767034d) + "'", double20 == (-0.3468843757767034d));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("e0104fd1a7a01ddf92b781f7e58bc78471e9edf449ed17c02e9fa706d7ca7d44f3bdcc88a9228905e1991661728d6dfe31a7", objArray1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(97);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        int[] intArray16 = randomDataImpl0.nextPermutation(4, (int) (byte) 1);
//        double double19 = randomDataImpl0.nextWeibull(0.7785319099002012d, 0.7853981633974483d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-32.30489579766123d) + "'", double3 == (-32.30489579766123d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.1163929628214935d + "'", double13 == 1.1163929628214935d);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.13197404773409996d + "'", double19 == 0.13197404773409996d);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.floor((-6146.22334164943d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6147.0d) + "'", double1 == (-6147.0d));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.342944819032518d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable4, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.String str9 = convergenceException8.getPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable13, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray15);
        java.lang.String str18 = convergenceException17.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) (short) 1, number22, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable27, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24, localizable25, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, localizable19, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "hi!", objArray29);
        int int34 = maxIterationsExceededException33.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 1521132842L, 2.8416492588916045E8d, (double) (byte) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (100) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable5, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.String str10 = convergenceException9.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray16 = outOfRangeException15.getArguments();
        java.lang.Class<?> wildcardClass17 = objArray16.getClass();
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable2, objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', "01d847c5ca5334dcdd075a3ccf1987fa8a3933486fc70172df8c1c3b5145f09572878006e9580da67e7161733d9f54a6a609", objArray16);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.6011681475703368d, 1.303909551780072d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.21734377942179392d + "'", double2 == 0.21734377942179392d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 0.40507128902104855d);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable35, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray37);
        java.lang.String str40 = convergenceException39.getPattern();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException39);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException47 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable44, objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("", objArray46);
        java.lang.String str49 = convergenceException48.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Number number53 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException55 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable51, (java.lang.Number) (short) 1, number53, true);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable58, objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException55, localizable56, objArray60);
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException39, localizable50, objArray60);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException65 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 0.40507128902104855d);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable69, objArray71);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException("", objArray71);
        java.lang.String str74 = convergenceException73.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable75 = convergenceException73.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException79 = new org.apache.commons.math.exception.OutOfRangeException(localizable75, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable80 = outOfRangeException79.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException87 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable84, objArray86);
        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException("", objArray86);
        org.apache.commons.math.ConvergenceException convergenceException89 = new org.apache.commons.math.ConvergenceException("hi!", objArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable80, objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable50, objArray86);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException95 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable50, (java.lang.Number) 21.862836871826794d, (java.lang.Number) 0.22016507684230757d, false);
        org.apache.commons.math.exception.util.Localizable localizable96 = numberIsTooLargeException95.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
        org.junit.Assert.assertNotNull(localizable50);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "" + "'", str74.equals(""));
        org.junit.Assert.assertNotNull(localizable75);
        org.junit.Assert.assertNotNull(localizable80);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertTrue("'" + localizable96 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable96.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(28);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException(throwable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable8, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.String str13 = convergenceException12.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable23, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, localizable20, objArray25);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 3.779109627299853d);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable33, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable20, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, localizable4, objArray35);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.special.Erf.erf(0.8975852141610587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7956934299939183d + "'", double1 == 0.7956934299939183d);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test200");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long13 = randomDataImpl0.nextPoisson(1.499039715843948d);
//        double double16 = randomDataImpl0.nextCauchy(0.08209350777524616d, 19.241467490659986d);
//        try {
//            long long19 = randomDataImpl0.nextSecureLong((long) (byte) 10, (long) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-9.426432366371339d) + "'", double3 == (-9.426432366371339d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-12.287441977643287d) + "'", double16 == (-12.287441977643287d));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.6483608274590892d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number4, false);
        java.lang.Number number7 = numberIsTooSmallException6.getMin();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.floor(45.868551673160134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 45.0d + "'", double1 == 45.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.1068473899378932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.970847974576192d + "'", double1 == 0.970847974576192d);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextChiSquare(72.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-5.464793903946973d) + "'", double3 == (-5.464793903946973d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 83.42903899874347d + "'", double13 == 83.42903899874347d);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextChiSquare(1.0d);
//        double double4 = randomDataImpl0.nextChiSquare(0.3595072663974203d);
//        randomDataImpl0.reSeedSecure((long) 0);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) (short) 1, (int) (byte) 1);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0014252248232108698d + "'", double2 == 0.0014252248232108698d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.06597059443464866d + "'", double4 == 0.06597059443464866d);
//        org.junit.Assert.assertNotNull(intArray9);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(8.919396437280402E-24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9865358590313966E-12d + "'", double1 == 2.9865358590313966E-12d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.2660741690044164d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0575952384920808d + "'", double1 == 1.0575952384920808d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        normalDistributionImpl0.reseedRandomGenerator(3L);
        double double6 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
//        double double5 = normalDistributionImpl0.cumulativeProbability(0.8975852141610587d, 1.9802279607563054d);
//        double double6 = normalDistributionImpl0.getStandardDeviation();
//        double double7 = normalDistributionImpl0.sample();
//        double double8 = normalDistributionImpl0.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.16086440265790714d + "'", double5 == 0.16086440265790714d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.15431452139021756d) + "'", double7 == (-0.15431452139021756d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        boolean boolean17 = numberIsTooSmallException16.getBoundIsAllowed();
        boolean boolean18 = numberIsTooSmallException16.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        java.lang.Object[] objArray3 = mathException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) (short) 1, number6, true);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException8, localizable9, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number20);
        java.lang.Object[] objArray22 = outOfRangeException21.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray22);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable16, objArray24);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.47468363820737447d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6075055636920905d + "'", double1 == 0.6075055636920905d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        long long2 = org.apache.commons.math.util.FastMath.min(32L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.getMean();
//        double double3 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        java.lang.String str5 = randomDataImpl0.nextSecureHexString((int) (byte) 10);
//        int int8 = randomDataImpl0.nextZipf(20, 0.8267766011773737d);
//        double double11 = randomDataImpl0.nextWeibull(0.9999999958776927d, 1.3842507050922375d);
//        int int14 = randomDataImpl0.nextZipf((int) '#', 5.0d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.46444507420543907d) + "'", double3 == (-0.46444507420543907d));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "965c52c03d" + "'", str5.equals("965c52c03d"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.27546241645962116d + "'", double11 == 0.27546241645962116d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        int int7 = randomDataImpl1.nextBinomial(9, 0.5432680528474173d);
//        int int10 = randomDataImpl1.nextZipf((int) (short) 1, 0.32875635635740336d);
//        try {
//            double double13 = randomDataImpl1.nextUniform((double) (short) 10, 1.764899880377996d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (1.765): lower bound (10) must be strictly less than upper bound (1.765)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.827399971720676d) + "'", double4 == (-0.827399971720676d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.2660741690044164d, 0.09931997132584114d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4925094573555984d + "'", double2 == 1.4925094573555984d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        java.lang.Number number17 = numberIsTooSmallException16.getMin();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.4173627661473032d + "'", number17.equals(1.4173627661473032d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.05415379218112492d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
//        double double24 = randomDataImpl21.nextGaussian(10.000000000000002d, (double) 32);
//        double double27 = randomDataImpl21.nextF(0.5d, 1.4173627661473032d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl31 = new org.apache.commons.math.distribution.NormalDistributionImpl(5.298292365610485d, 2.718281828459045d, 0.853988047997524d);
//        double double32 = normalDistributionImpl31.getStandardDeviation();
//        double double33 = randomDataImpl21.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl31);
//        double double34 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl31);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.0929820122066154d) + "'", double3 == (-0.0929820122066154d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "d5d6184b217f9be4f304e316bd388b40af31f4b5fdfe6237605def02a3ccdee04d98917f9e37a9d7162978d25ce166984f6b" + "'", str13.equals("d5d6184b217f9be4f304e316bd388b40af31f4b5fdfe6237605def02a3ccdee04d98917f9e37a9d7162978d25ce166984f6b"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.1599261051828729d) + "'", double19 == (-1.1599261051828729d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.37804902863451373d) + "'", double20 == (-0.37804902863451373d));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + (-27.117635365851932d) + "'", double24 == (-27.117635365851932d));
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.43652767160112377d + "'", double27 == 0.43652767160112377d);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 2.718281828459045d + "'", double32 == 2.718281828459045d);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 2.58001053715144d + "'", double33 == 2.58001053715144d);
//        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.5800105371514399d + "'", double34 == 0.5800105371514399d);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 249730124L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796322790574d + "'", double1 == 1.570796322790574d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability(1.2679114584199251d);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8975852141610587d + "'", double2 == 0.8975852141610587d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.exp(47.84523318774835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.010640575850579E20d + "'", double1 == 6.010640575850579E20d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        float float1 = org.apache.commons.math.util.FastMath.abs(34.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 34.0f + "'", float1 == 34.0f);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextBinomial((int) (short) 1, 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-21.59101019312496d) + "'", double3 == (-21.59101019312496d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.4893918124572556d) + "'", double13 == (-1.4893918124572556d));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability((-1.0d));
        normalDistributionImpl0.reseedRandomGenerator(6L);
        double double5 = normalDistributionImpl0.sample();
        double double6 = normalDistributionImpl0.sample();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15865525393145702d + "'", double2 == 0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.6007714532002397d + "'", double5 == 1.6007714532002397d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5522878758283906d + "'", double6 == 0.5522878758283906d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.764899880377996d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.19288700055508054d) + "'", double1 == (-0.19288700055508054d));
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        double double11 = randomDataImpl0.nextGaussian(0.05538936600958528d, (double) ' ');
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-23.82969995856955d) + "'", double3 == (-23.82969995856955d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 44.399452998075375d + "'", double11 == 44.399452998075375d);
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) '4');
//        java.lang.String str11 = randomDataImpl0.nextHexString((int) (byte) 100);
//        long long14 = randomDataImpl0.nextLong((long) 3, (long) (byte) 100);
//        try {
//            double double17 = randomDataImpl0.nextF((-0.21684857935902555d), 47.84523318774835d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.217 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.217)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-32.785597622161475d) + "'", double3 == (-32.785597622161475d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3f91456e7d105b28138b2e396ef6b0f6fd4586811b67c5ad7e8b016ae9687a8b7702436d7b1af5225bd552f3a4185284d006" + "'", str11.equals("3f91456e7d105b28138b2e396ef6b0f6fd4586811b67c5ad7e8b016ae9687a8b7702436d7b1af5225bd552f3a4185284d006"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 4L + "'", long14 == 4L);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-20.512631014974332d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-28.492599938416912d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.32875635635740336d);
    }

//    @Test
//    public void test233() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test233");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long13 = randomDataImpl0.nextPoisson(1.499039715843948d);
//        double double16 = randomDataImpl0.nextCauchy(0.08209350777524616d, 19.241467490659986d);
//        long long18 = randomDataImpl0.nextPoisson(4.605170185988092d);
//        java.lang.String str20 = randomDataImpl0.nextHexString((int) '4');
//        try {
//            int int23 = randomDataImpl0.nextZipf(0, 10.962014479728863d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-44.48515423223762d) + "'", double3 == (-44.48515423223762d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3L + "'", long13 == 3L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 16.419004715955808d + "'", double16 == 16.419004715955808d);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 2L + "'", long18 == 2L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2bcb1e2617cfb558ef60562ad65e7f242d1fd44bbfe18dd4b127" + "'", str20.equals("2bcb1e2617cfb558ef60562ad65e7f242d1fd44bbfe18dd4b127"));
//    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double2 = org.apache.commons.math.util.FastMath.min(55.328857578305815d, 1.0046432596246453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0046432596246453d + "'", double2 == 1.0046432596246453d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        long long2 = org.apache.commons.math.util.FastMath.min(49L, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5432309669152122d + "'", double3 == 0.5432309669152122d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.6313653878198824d, 0.10516633568161556d, 12.911386656793239d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.log(4.978493100937017d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6051272550736282d + "'", double1 == 1.6051272550736282d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 1.4173627661473032d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.getMean();
//        double double3 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        randomDataImpl0.reSeedSecure(0L);
//        double double8 = randomDataImpl0.nextGamma(0.7970747335500249d, 1.663999375826442d);
//        double double10 = randomDataImpl0.nextChiSquare((double) 10);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.8791534114021116d) + "'", double3 == (-0.8791534114021116d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.236703947923252d + "'", double8 == 1.236703947923252d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.060398482839707d + "'", double10 == 8.060398482839707d);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable17, objArray18);
        java.lang.Throwable throwable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.String str30 = convergenceException29.getPattern();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException29);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable34, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray36);
        java.lang.String str39 = convergenceException38.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) (short) 1, number43, true);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable48, objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException45, localizable46, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException29, localizable40, objArray50);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable57, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException("", objArray59);
        java.lang.String str62 = convergenceException61.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable63 = convergenceException61.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException(localizable63, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable68 = outOfRangeException67.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable72, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("", objArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("hi!", objArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable68, objArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable40, objArray74);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(throwable20, localizable21, objArray74);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray74);
        java.lang.Number number83 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException85 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) (-0.07784610394702793d), number83, (java.lang.Number) 2);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "" + "'", str62.equals(""));
        org.junit.Assert.assertNotNull(localizable63);
        org.junit.Assert.assertNotNull(localizable68);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0E-9d, 1.7896353172533552d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000003E-9d + "'", double2 == 1.0000000000000003E-9d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.6993397042844088d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 33);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 33.0f + "'", float1 == 33.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 0.6483608274590892d, true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.2660741690044164d, (-44.44377415455416d), 0.05415379218112492d, (int) (short) 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability((-1.0d));
        normalDistributionImpl0.reseedRandomGenerator(6L);
        double double6 = normalDistributionImpl0.density(1.2660741690044164d);
        double double8 = normalDistributionImpl0.density(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15865525393145702d + "'", double2 == 0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.1789926681717207d + "'", double6 == 0.1789926681717207d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.3989422804014327d + "'", double8 == 0.3989422804014327d);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        double double6 = randomDataImpl0.nextF(0.5d, 1.4173627661473032d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl(5.298292365610485d, 2.718281828459045d, 0.853988047997524d);
//        double double11 = normalDistributionImpl10.getStandardDeviation();
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        try {
//            double double14 = normalDistributionImpl10.inverseCumulativeProbability((-0.10177419206008143d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.102 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.358231266052936d + "'", double3 == 14.358231266052936d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.44067825691174933d + "'", double6 == 0.44067825691174933d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.718281828459045d + "'", double11 == 2.718281828459045d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.01657419406953d + "'", double12 == 8.01657419406953d);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable5, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.String str10 = convergenceException9.getPattern();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable14, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray16);
        java.lang.String str19 = convergenceException18.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) (short) 1, number23, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable28, objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException25, localizable26, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, localizable20, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable45 = outOfRangeException44.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException(localizable46, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException50);
        java.lang.Object[] objArray52 = mathException51.getArguments();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException39, localizable45, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable20, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException(localizable55, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException59);
        java.lang.Object[] objArray61 = mathException60.getArguments();
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable20, objArray61);
        java.lang.Class<?> wildcardClass63 = objArray61.getClass();
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.405 is smaller than, or equal to, the minimum (0): ", objArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(33, "1fe6b20bcbccebec406bc8dd456e7a69205db9337fea572a913c581453bf98d237d1c1b1abdf0fb4c964c5eb4ca2a4bd63e0", objArray61);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(wildcardClass63);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException6.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(localizable31);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        normalDistributionImpl15.reseedRandomGenerator((long) '4');
//        normalDistributionImpl15.reseedRandomGenerator((long) 33);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-11.346470410340524d) + "'", double3 == (-11.346470410340524d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "659d555419648103f5a7d2bdefcd77197cea003bc0c4c7e24cb14c5c89b3768b53d660bdbd5953a807b489571be48f3269fd" + "'", str13.equals("659d555419648103f5a7d2bdefcd77197cea003bc0c4c7e24cb14c5c89b3768b53d660bdbd5953a807b489571be48f3269fd"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.0741221098310882d) + "'", double19 == (-2.0741221098310882d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.16633320995116946d) + "'", double20 == (-0.16633320995116946d));
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.atan((-24.725268680222683d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.53037390323524d) + "'", double1 == (-1.53037390323524d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.06854820744336733d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double5 = normalDistributionImpl0.cumulativeProbability(0.8975852141610587d, 1.9802279607563054d);
        double double6 = normalDistributionImpl0.getStandardDeviation();
        double double8 = normalDistributionImpl0.density((-0.1521089696203987d));
        double double10 = normalDistributionImpl0.cumulativeProbability(1.2859299586517579d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.16086440265790714d + "'", double5 == 0.16086440265790714d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.39435368191090925d + "'", double8 == 0.39435368191090925d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9007662464680126d + "'", double10 == 0.9007662464680126d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.4706422502884551d), 30.641979349655287d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4706422502884551d) + "'", double2 == (-0.4706422502884551d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable18, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable15, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable30, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("", objArray32);
        java.lang.String str35 = convergenceException34.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException34.getGeneralPattern();
        java.lang.Object[] objArray39 = new java.lang.Object[] { 'a', 1.0d, '4', localizable36, (-1.0d), (short) 0 };
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException40);
        java.lang.Throwable throwable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable50, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray52);
        java.lang.String str55 = convergenceException54.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = convergenceException54.getGeneralPattern();
        java.lang.Object[] objArray59 = new java.lang.Object[] { 'a', 1.0d, '4', localizable56, (-1.0d), (short) 0 };
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("", objArray59);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(throwable42, "aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray59);
        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getGeneralPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException64);
        java.lang.Object[] objArray66 = maxIterationsExceededException64.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException72 = new org.apache.commons.math.exception.OutOfRangeException(localizable68, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException72);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable74, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable79 = outOfRangeException78.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable80 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException84 = new org.apache.commons.math.exception.OutOfRangeException(localizable80, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException84);
        java.lang.Object[] objArray86 = mathException85.getArguments();
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException73, localizable79, objArray86);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException64, "", objArray86);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException41, localizable62, objArray86);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException(35, localizable15, objArray86);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertNotNull(localizable36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "" + "'", str55.equals(""));
        org.junit.Assert.assertNotNull(localizable56);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(localizable62);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + localizable79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable79.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray86);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.NaN, (java.lang.Number) 0.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 28, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-2.240716167464921d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.60023464126346d + "'", double1 == 20.60023464126346d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        double double5 = normalDistributionImpl0.inverseCumulativeProbability(0.3678794411714424d);
        double double7 = normalDistributionImpl0.cumulativeProbability((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.3374749637642045d) + "'", double5 == (-0.3374749637642045d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.1622776601683795d, (java.lang.Number) 0.3595072663974203d, false);
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number5, false);
        java.lang.Number number8 = numberIsTooSmallException7.getArgument();
        boolean boolean9 = numberIsTooSmallException7.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass10 = numberIsTooSmallException7.getClass();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException13);
        java.lang.Object[] objArray15 = mathException14.getArguments();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable11, objArray15);
        java.lang.Number number17 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0f) + "'", number8.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.3595072663974203d + "'", number17.equals(0.3595072663974203d));
        org.junit.Assert.assertNull(localizable18);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.sin(71.32400509670025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8031870489757308d + "'", double1 == 0.8031870489757308d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.1789926681717207d, 12.911386656793239d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.013862275799254567d + "'", double2 == 0.013862275799254567d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4711276743037347d, (java.lang.Number) 0.8845158039790166d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable16, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.String str21 = convergenceException20.getPattern();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException20);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray27);
        java.lang.String str30 = convergenceException29.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) (short) 1, number34, true);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray41 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable39, objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException36, localizable37, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException20, localizable31, objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", objArray41);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException9, "", objArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray41);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 22.180709777452588d, (java.lang.Number) 1.2044012063326326d, (java.lang.Number) (-77.0595521907205d));
        java.lang.Number number52 = outOfRangeException51.getHi();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (-77.0595521907205d) + "'", number52.equals((-77.0595521907205d)));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.31588426736961117d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0503076767261683d + "'", double1 == 1.0503076767261683d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 97, 0.42854669334927814d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.102716119010752d + "'", double2 == 7.102716119010752d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        double double6 = randomDataImpl0.nextF(0.5d, 1.4173627661473032d);
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 100);
//        long long12 = randomDataImpl0.nextLong(0L, 2L);
//        randomDataImpl0.reSeedSecure();
//        double double16 = randomDataImpl0.nextGaussian(1.764899880377996d, 7.450833191230467E34d);
//        double double18 = randomDataImpl0.nextT(51.4278445247748d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.927029897655906d + "'", double3 == 14.927029897655906d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.4135647028836558d + "'", double6 == 2.4135647028836558d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 63 + "'", int9 == 63);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.7822017428074856E34d + "'", double16 == 2.7822017428074856E34d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.7407612018040244d + "'", double18 == 0.7407612018040244d);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(1, 52);
//        double double19 = randomDataImpl0.nextChiSquare(2.000637772820911d);
//        double double21 = randomDataImpl0.nextExponential(0.7837811557474641d);
//        try {
//            double double24 = randomDataImpl0.nextBeta(0.0d, 1.7182818284590453d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.71");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 31.679941436918327d + "'", double3 == 31.679941436918327d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "e47703eca042a9a1e3d862ca657d6150ae7716fc39ee93135f02329524a52689f61084f6778c9969e9daf0ee4dc2273101fd" + "'", str13.equals("e47703eca042a9a1e3d862ca657d6150ae7716fc39ee93135f02329524a52689f61084f6778c9969e9daf0ee4dc2273101fd"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 38 + "'", int17 == 38);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.2787184494781383d + "'", double19 == 2.2787184494781383d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.10213171911846117d + "'", double21 == 0.10213171911846117d);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable12, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.String str17 = convergenceException16.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (short) 1, number21, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable26, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException23, localizable24, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable18, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable35, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray37);
        java.lang.String str40 = convergenceException39.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = convergenceException39.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable46 = outOfRangeException45.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable50, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("hi!", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable46, objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable18, objArray52);
        java.lang.String str58 = maxIterationsExceededException57.getPattern();
        java.lang.String str59 = maxIterationsExceededException57.toString();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str59.equals("org.apache.commons.math.MaxIterationsExceededException: "));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.36842577779469815d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number3);
        java.lang.Object[] objArray5 = outOfRangeException4.getArguments();
        java.lang.Class<?> wildcardClass6 = outOfRangeException4.getClass();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        double double6 = randomDataImpl0.nextF(0.5d, 1.4173627661473032d);
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 100);
//        long long12 = randomDataImpl0.nextLong(0L, 2L);
//        randomDataImpl0.reSeedSecure();
//        try {
//            randomDataImpl0.setSecureAlgorithm("3c3037b87b88741ca737ab8c06f9c073f4bdfe4ed94b0d16cc2962ac10456f5cbfa18d5ca90a3ab4f89d7f3eeb644e7b24c1", "eedeedac141528574e80bec9a8c24b2a6a1c01916761bbb0352a41320317b90922c39f63e8c6b7d769c7617b3218603d70d5");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: eedeedac141528574e80bec9a8c24b2a6a1c01916761bbb0352a41320317b90922c39f63e8c6b7d769c7617b3218603d70d5");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 42.13233595319487d + "'", double3 == 42.13233595319487d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 42.33029342838696d + "'", double6 == 42.33029342838696d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 80 + "'", int9 == 80);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl1 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl1.getMean();
//        double double3 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl1);
//        try {
//            int int7 = randomDataImpl0.nextHypergeometric((int) 'a', (int) (byte) 100, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (97): number of successes (100) must be less than or equal to population size (97)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.32816776019414196d + "'", double3 == 0.32816776019414196d);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long14 = randomDataImpl0.nextLong((long) 4, (long) 32);
//        try {
//            randomDataImpl0.setSecureAlgorithm("8657144287203c947e9c0c2bfa0a78c65ce1509b7f9b9c65b8054d218eb0893f49eafe29f1e32deccb8764739e7476643213", "1a02d21325309573de64b66c32a1b349c2b11672cfadde983a87e838aab97523dc8444f7798d506a645eaabeb803c5b35060");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 1a02d21325309573de64b66c32a1b349c2b11672cfadde983a87e838aab97523dc8444f7798d506a645eaabeb803c5b35060");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 42.55356633230703d + "'", double3 == 42.55356633230703d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.22814479126001017d, (java.lang.Number) 4.9E-324d, (java.lang.Number) 10);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number3);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        java.lang.Number number6 = outOfRangeException4.getHi();
        java.lang.Class<?> wildcardClass7 = outOfRangeException4.getClass();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 2060935566L, (-6.343603975763723E34d), (-0.06854820744336733d), 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.7910068511973d + "'", double1 == 11.7910068511973d);
    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        randomDataImpl0.reSeed();
//        try {
//            double double17 = randomDataImpl0.nextWeibull(0.0d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 39.58203159103562d + "'", double3 == 39.58203159103562d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.4975789803107471d) + "'", double13 == (-0.4975789803107471d));
//    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.7883157723668338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3523060680830907d + "'", double1 == 2.3523060680830907d);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        java.lang.String str15 = randomDataImpl0.nextSecureHexString((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 42.46714625617606d + "'", double3 == 42.46714625617606d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5055e110f0acee991e73d05988851084f4e2b50726d863c4ba1d48b45a57daf6a77b371ebb91c4fb2ee21d92ddb83fc7fb9e" + "'", str13.equals("5055e110f0acee991e73d05988851084f4e2b50726d863c4ba1d48b45a57daf6a77b371ebb91c4fb2ee21d92ddb83fc7fb9e"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "cf4d8a64b0" + "'", str15.equals("cf4d8a64b0"));
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.8805632551649238d, 1.0E-9d, (-34.843832110945996d), 9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (9) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 31);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 31 + "'", number2.equals(31));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.log(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4333079051049607d) + "'", double1 == (-0.4333079051049607d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7837811557474641d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.670065232495692d + "'", double1 == 0.670065232495692d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.abs((-27.117635365851932d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.117635365851932d + "'", double1 == 27.117635365851932d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1);
        java.lang.Object[] objArray3 = maxIterationsExceededException1.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable16 = outOfRangeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException21);
        java.lang.Object[] objArray23 = mathException22.getArguments();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10, localizable16, objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, "", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray23);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9L + "'", long1 == 9L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.sin(23.363034433648068d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9802824526286716d) + "'", double1 == (-0.9802824526286716d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(35);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) 1, number9, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable14, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException11, localizable12, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooLargeException11.getGeneralPattern();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, number20, (java.lang.Number) 1.4173627661473032d, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable24, objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException28);
        java.lang.Object[] objArray30 = maxIterationsExceededException28.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable24, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable34, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException("", objArray36);
        java.lang.String str39 = convergenceException38.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException38.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Number number47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) (short) 1, number47, true);
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable52, objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException49, localizable50, objArray54);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooLargeException49.getGeneralPattern();
        java.lang.Number number58 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, number58, (java.lang.Number) 1.4173627661473032d, true);
        boolean boolean62 = numberIsTooSmallException61.getBoundIsAllowed();
        java.lang.Object[] objArray63 = numberIsTooSmallException61.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable40, objArray63);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException4, "", objArray63);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(objArray63);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4925094573555984d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4711276743037347d, (java.lang.Number) 0.8845158039790166d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable17, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray19);
        java.lang.String str22 = convergenceException21.getPattern();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException21);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable26, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException("", objArray28);
        java.lang.String str31 = convergenceException30.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException30.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) (short) 1, number35, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable40, objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException37, localizable38, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21, localizable32, objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", objArray42);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException10, "", objArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray42);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 22.180709777452588d, (java.lang.Number) 1.2044012063326326d, (java.lang.Number) (-77.0595521907205d));
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable55, objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException("", objArray57);
        java.lang.String str60 = convergenceException59.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable61 = convergenceException59.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException(localizable61, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray66 = outOfRangeException65.getArguments();
        java.lang.Class<?> wildcardClass67 = objArray66.getClass();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException(throwable0, localizable5, objArray66);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertNotNull(localizable32);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "" + "'", str60.equals(""));
        org.junit.Assert.assertNotNull(localizable61);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(wildcardClass67);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.013276747223059479d) + "'", double1 == (-0.013276747223059479d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.9583489237149074d), 0.08227867589781208d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9583489237149074d) + "'", double2 == (-0.9583489237149074d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.82679529269723d) + "'", double1 == (-1.82679529269723d));
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        int int7 = randomDataImpl1.nextBinomial(9, 0.5432680528474173d);
//        double double10 = randomDataImpl1.nextWeibull(0.853988047997524d, 0.07829815576435584d);
//        java.lang.String str12 = randomDataImpl1.nextHexString(52);
//        try {
//            int int15 = randomDataImpl1.nextPascal(32, (-0.7302875164411025d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -0.73 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.9347649579176671d) + "'", double4 == (-0.9347649579176671d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.06464833660062756d + "'", double10 == 0.06464833660062756d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "f83851179ac836a3a45e553844b1753f0f81be56ee054f38d02c" + "'", str12.equals("f83851179ac836a3a45e553844b1753f0f81be56ee054f38d02c"));
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.8267766011773737d, (java.lang.Number) 1.2660741690044164d, (java.lang.Number) (-23.82969995856955d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9900001597529149d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.990000159752915d + "'", double2 == 0.990000159752915d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable20, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("", objArray22);
        java.lang.String str25 = convergenceException24.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Number number29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) (short) 1, number29, true);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable34, objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException31, localizable32, objArray36);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException15, localizable26, objArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException(0, "hi!", objArray36);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException4, "", objArray36);
        java.lang.Throwable[] throwableArray42 = maxIterationsExceededException4.getSuppressed();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertNotNull(localizable26);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(throwableArray42);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed();
//        long long9 = randomDataImpl0.nextPoisson(0.010050166663333094d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray18 = randomDataImpl12.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl12.reSeed((long) '4');
//        int[] intArray23 = randomDataImpl12.nextPermutation((int) (short) 10, 1);
//        java.lang.String str25 = randomDataImpl12.nextSecureHexString((int) (byte) 100);
//        randomDataImpl12.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl27 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double30 = normalDistributionImpl27.cumulativeProbability(Double.NaN, (double) 0);
//        double double31 = normalDistributionImpl27.sample();
//        double double32 = randomDataImpl12.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl27);
//        normalDistributionImpl27.reseedRandomGenerator((long) '4');
//        double[] doubleArray36 = normalDistributionImpl27.sample(52);
//        double double38 = normalDistributionImpl27.density((-4.281642508279315d));
//        double double39 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl27);
//        try {
//            double double42 = randomDataImpl0.nextCauchy(0.09931997132584114d, (double) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.342225298893025d) + "'", double3 == (-0.342225298893025d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-26.371726588851054d) + "'", double15 == (-26.371726588851054d));
//        org.junit.Assert.assertNotNull(intArray18);
//        org.junit.Assert.assertNotNull(intArray23);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "1a83993b20d5a6d6388e6dd2d1a01c582662a814384c8108fe7a8a974d88af57bd5a602c996297d70f0eb5a9af243a18e15f" + "'", str25.equals("1a83993b20d5a6d6388e6dd2d1a01c582662a814384c8108fe7a8a974d88af57bd5a602c996297d70f0eb5a9af243a18e15f"));
//        org.junit.Assert.assertEquals((double) double30, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.3178545862310915d) + "'", double31 == (-1.3178545862310915d));
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-0.49263596092385525d) + "'", double32 == (-0.49263596092385525d));
//        org.junit.Assert.assertNotNull(doubleArray36);
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.169331234015647E-5d + "'", double38 == 4.169331234015647E-5d);
//        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-0.6160140274389446d) + "'", double39 == (-0.6160140274389446d));
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 0.5079736859478915d, (java.lang.Number) (-0.12720663811558966d), (java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0787619161000124d) + "'", double1 == (-1.0787619161000124d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0658549729464604d), 38.448859429070346d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0658549729464601d) + "'", double2 == (-1.0658549729464601d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.4893918124572556d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9795136175666455d) + "'", double1 == (-0.9795136175666455d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 952.182499513481d, (java.lang.Number) 83.42903899874347d, true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.1752011936438014d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5452854900566904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5452854900566904d + "'", double1 == 1.5452854900566904d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable8, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.String str13 = convergenceException12.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException12.getGeneralPattern();
        mathException5.addSuppressed((java.lang.Throwable) convergenceException12);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException12.getGeneralPattern();
        java.lang.Throwable[] throwableArray17 = convergenceException12.getSuppressed();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double14 = randomDataImpl0.nextGamma(71.32400509670025d, (double) (short) 100);
//        randomDataImpl0.reSeedSecure(10L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-4.611737673576064d) + "'", double3 == (-4.611737673576064d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 5399.783345517765d + "'", double14 == 5399.783345517765d);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable5, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.String str10 = convergenceException9.getPattern();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException9);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable14, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("", objArray16);
        java.lang.String str19 = convergenceException18.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) (short) 1, number23, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable28, objArray30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException25, localizable26, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException9, localizable20, objArray30);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException(localizable34, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable40, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable45 = outOfRangeException44.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException(localizable46, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException50);
        java.lang.Object[] objArray52 = mathException51.getArguments();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException39, localizable45, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable20, objArray52);
        java.lang.Number number57 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException(localizable20, (java.lang.Number) 359.1342053695754d, (java.lang.Number) 10.0d, number57);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable64, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray66);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException("hi!", objArray66);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException(100, "", objArray66);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable20, objArray66);
        java.lang.Number number72 = null;
        java.lang.Number number73 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, number72, number73, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (-0.015772404403454655d), (java.lang.Number) (-0.5100926710131973d), false);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(localizable20);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray66);
    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double[] doubleArray22 = normalDistributionImpl15.sample((int) ' ');
//        try {
//            double double24 = normalDistributionImpl15.inverseCumulativeProbability((double) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.420292035472446d) + "'", double3 == (-2.420292035472446d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "af5a852723007cfbee9364b41dc1d329dfad5dfe782bf7b83287d41484472a0ae8c19ed1892a7d7ecf041e6cd39235a233ff" + "'", str13.equals("af5a852723007cfbee9364b41dc1d329dfad5dfe782bf7b83287d41484472a0ae8c19ed1892a7d7ecf041e6cd39235a233ff"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.6045433180169372d) + "'", double19 == (-0.6045433180169372d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.5045866659316905d) + "'", double20 == (-0.5045866659316905d));
//        org.junit.Assert.assertNotNull(doubleArray22);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable17, objArray49);
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 359.1342053695754d, (java.lang.Number) 10.0d, number54);
        org.apache.commons.math.exception.util.Localizable localizable56 = outOfRangeException55.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException(localizable56, (java.lang.Number) (-1.595451132473584d), (java.lang.Number) 10.0d, (java.lang.Number) (short) -1);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable64, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException("", objArray66);
        java.lang.String str69 = convergenceException68.getPattern();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException68);
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        java.lang.Object[] objArray75 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable73, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("", objArray75);
        java.lang.String str78 = convergenceException77.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable79 = convergenceException77.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable80 = null;
        java.lang.Number number82 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException84 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable80, (java.lang.Number) (short) 1, number82, true);
        org.apache.commons.math.exception.util.Localizable localizable85 = null;
        org.apache.commons.math.exception.util.Localizable localizable87 = null;
        java.lang.Object[] objArray89 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable87, objArray89);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException84, localizable85, objArray89);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException68, localizable79, objArray89);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException("hi!", objArray89);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException(localizable56, objArray89);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "" + "'", str69.equals(""));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "" + "'", str78.equals(""));
        org.junit.Assert.assertNotNull(localizable79);
        org.junit.Assert.assertNotNull(objArray89);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable19, objArray21);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray21);
        java.lang.String str24 = convergenceException23.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException23.getGeneralPattern();
        java.lang.Object[] objArray28 = new java.lang.Object[] { 'a', 1.0d, '4', localizable25, (-1.0d), (short) 0 };
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(throwable11, "aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray28);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getGeneralPattern();
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException10, localizable31, objArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException35);
        java.lang.Object[] objArray37 = mathException36.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException36.getGeneralPattern();
        java.lang.Object[] objArray39 = mathException36.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable31, objArray39);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(localizable25);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(localizable31);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 22.18070977745259d, (java.lang.Number) (-0.1392992365049787d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.07784610394702793d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07800373560073874d) + "'", double1 == (-0.07800373560073874d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.397271607474473E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.2044012063326326d, (-20.15821253309177d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -20.158 is smaller than, or equal to, the minimum (0): standard deviation (-20.158)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        double double4 = randomDataImpl1.nextGaussian(7.450833191230467E34d, 1.5707963266948965d);
        try {
            double double6 = randomDataImpl1.nextExponential((-0.19288700055508054d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.193 is smaller than, or equal to, the minimum (0): mean (-0.193)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.450833191230467E34d + "'", double4 == 7.450833191230467E34d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException4.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException4);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        java.lang.Object[] objArray8 = convergenceException6.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray8);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test326");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextCauchy(39.56893168362026d, 1.764899880377996d);
//        randomDataImpl0.reSeed((long) 83);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 39.362713675067404d + "'", double3 == 39.362713675067404d);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.signum((-21.59101019312496d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4711276743037347d, (java.lang.Number) 0.8845158039790166d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1.471 is larger than the maximum (0.885)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1.471 is larger than the maximum (0.885)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.8845158039790166d + "'", number6.equals(0.8845158039790166d));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0, (double) 100, (-0.8390715290764524d));
        double double5 = normalDistributionImpl3.cumulativeProbability(1.0d);
        double[] doubleArray7 = normalDistributionImpl3.sample(10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5039893563146316d + "'", double5 == 0.5039893563146316d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 61.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.25810163593826746d) + "'", double1 == (-0.25810163593826746d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable12, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.String str17 = convergenceException16.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (short) 1, number21, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable26, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException23, localizable24, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable18, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable35, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray37);
        java.lang.String str40 = convergenceException39.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = convergenceException39.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable41, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable46 = outOfRangeException45.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable50, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException("hi!", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable46, objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, localizable18, objArray52);
        int int58 = maxIterationsExceededException57.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable59 = maxIterationsExceededException57.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
        org.junit.Assert.assertNotNull(localizable41);
        org.junit.Assert.assertNotNull(localizable46);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(localizable59);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9945220102274002d, (-6146.22334164943d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        double double13 = randomDataImpl0.nextExponential(4.605170185988092d);
//        java.lang.String str15 = randomDataImpl0.nextSecureHexString(34);
//        try {
//            double double18 = randomDataImpl0.nextGaussian(0.0d, (-36.85197833288714d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -36.852 is smaller than, or equal to, the minimum (0): standard deviation (-36.852)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 56.4504812280747d + "'", double3 == 56.4504812280747d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.1173519924328823d + "'", double13 == 2.1173519924328823d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ccf084f0603b547af968d95e975b610fa9" + "'", str15.equals("ccf084f0603b547af968d95e975b610fa9"));
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 1.1163929628214935d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1163929628214935d + "'", double2 == 1.1163929628214935d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.rint(83.42903899874347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 83.0d + "'", double1 == 83.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray13 = outOfRangeException12.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) (short) 1, number17, true);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable22, objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException19, localizable20, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException12, localizable14, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable33, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray35);
        java.lang.String str38 = convergenceException37.getPattern();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException37);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable42, objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray44);
        java.lang.String str47 = convergenceException46.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable49, (java.lang.Number) (short) 1, number51, true);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable56, objArray58);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException53, localizable54, objArray58);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException37, localizable48, objArray58);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException61);
        java.lang.String str63 = convergenceException61.getPattern();
        java.lang.Throwable[] throwableArray64 = convergenceException61.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) '4', localizable30, (java.lang.Object[]) throwableArray64);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException12, "1f5d1a44b9a8d6315433e77466c6f6a830a2902e0edaed1f7671f6bce837b9c6d2060fe2b9c4097757f0e829c770f1132349", (java.lang.Object[]) throwableArray64);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(localizable48);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertNotNull(throwableArray64);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        double double6 = randomDataImpl0.nextF(0.5d, 1.4173627661473032d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl(5.298292365610485d, 2.718281828459045d, 0.853988047997524d);
//        double double11 = normalDistributionImpl10.getStandardDeviation();
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        try {
//            java.lang.String str14 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.22577275427185d + "'", double3 == 22.22577275427185d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.07143688557660866d + "'", double6 == 0.07143688557660866d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.718281828459045d + "'", double11 == 2.718281828459045d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.5800105371514395d + "'", double12 == 3.5800105371514395d);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.Class<?> wildcardClass1 = convergenceException0.getClass();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException0.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable4, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray6);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("hi!", objArray6);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("8d82d9db46adf7ac503ab3946dd276fd2e59f21d2a358f6330ffd498fca6aa1da593827c30290b80cf8a7703e2e7ba66ef55", objArray6);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.26151346896138d), (-4.281642508279315d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.cosh(8.060398482839707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1583.2760076493532d + "'", double1 == 1583.2760076493532d);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        int[] intArray9 = randomDataImpl0.nextPermutation((int) (byte) 100, (int) '4');
//        long long12 = randomDataImpl0.nextLong((long) 0, (long) (short) 100);
//        int int15 = randomDataImpl0.nextZipf((int) (byte) 100, (double) 5);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 53.978146586855836d + "'", double3 == 53.978146586855836d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray9);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double2 = org.apache.commons.math.util.FastMath.atan2(459.14268357897515d, 51.4278445247748d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.459252831380313d + "'", double2 == 1.459252831380313d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable8, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.String str13 = convergenceException12.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException12.getGeneralPattern();
        mathException5.addSuppressed((java.lang.Throwable) convergenceException12);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(number16, (java.lang.Number) (byte) 1, false);
        java.lang.Number number20 = numberIsTooLargeException19.getMax();
        convergenceException12.addSuppressed((java.lang.Throwable) numberIsTooLargeException19);
        boolean boolean22 = numberIsTooLargeException19.getBoundIsAllowed();
        java.lang.Number number23 = numberIsTooLargeException19.getMax();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (byte) 1 + "'", number20.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (byte) 1 + "'", number23.equals((byte) 1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double4 = normalDistributionImpl0.density((double) 10.0f);
        double double7 = normalDistributionImpl0.cumulativeProbability((-0.31025208989080005d), 1.1142547833872074E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.69459862670642E-23d + "'", double4 == 7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.12181541374840044d + "'", double7 == 0.12181541374840044d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double5 = normalDistributionImpl0.cumulativeProbability(0.8975852141610587d, 1.9802279607563054d);
        double double6 = normalDistributionImpl0.getStandardDeviation();
        normalDistributionImpl0.reseedRandomGenerator(0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.16086440265790714d + "'", double5 == 0.16086440265790714d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = outOfRangeException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException16);
        java.lang.Object[] objArray18 = mathException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable11, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException5.getSpecificPattern();
        java.lang.Object[] objArray21 = mathException5.getArguments();
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable10, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("", objArray12);
        java.lang.String str15 = convergenceException14.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException14.getGeneralPattern();
        java.lang.Object[] objArray19 = new java.lang.Object[] { 'a', 1.0d, '4', localizable16, (-1.0d), (short) 0 };
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(throwable2, "aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException21.getGeneralPattern();
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable22, objArray23);
        java.lang.Throwable[] throwableArray25 = maxIterationsExceededException1.getSuppressed();
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed();
//        try {
//            double double10 = randomDataImpl0.nextF((-0.07784610394702793d), (-1.2094942883398025d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.078 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.078)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 67.7186306979138d + "'", double3 == 67.7186306979138d);
//        org.junit.Assert.assertNotNull(intArray6);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test352");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double6 = normalDistributionImpl4.inverseCumulativeProbability((double) (short) 1);
//        double double9 = normalDistributionImpl4.cumulativeProbability(0.8975852141610587d, 1.9802279607563054d);
//        double double10 = normalDistributionImpl4.getStandardDeviation();
//        double double11 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            java.lang.String str13 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.POSITIVE_INFINITY + "'", double6 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.16086440265790714d + "'", double9 == 0.16086440265790714d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5041743052480656d + "'", double11 == 0.5041743052480656d);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (short) 10);
        randomDataImpl0.reSeedSecure();
        try {
            int int6 = randomDataImpl0.nextZipf(33, (-0.15431452139021756d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.154 is smaller than, or equal to, the minimum (0): exponent (-0.154)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.0d, 0.33771105105640853d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.948868668336558d, (java.lang.Number) 32, false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5008850900817288d, (java.lang.Number) 0.11276539834081348d, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.7837811557474641d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.627131208025269E-11d + "'", double2 == 2.627131208025269E-11d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.6075055636920905d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6075055636920906d + "'", double1 == 0.6075055636920906d);
    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test359");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long13 = randomDataImpl0.nextPoisson(1.499039715843948d);
//        double double16 = randomDataImpl0.nextCauchy(0.08209350777524616d, 19.241467490659986d);
//        java.lang.String str18 = randomDataImpl0.nextSecureHexString(31);
//        double double20 = randomDataImpl0.nextExponential(0.23998629493553567d);
//        double double22 = randomDataImpl0.nextT(0.3808987971294274d);
//        double double24 = randomDataImpl0.nextExponential(1.6007714532002397d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.25987911478766d + "'", double3 == 22.25987911478766d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3L + "'", long13 == 3L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 30.36494484403383d + "'", double16 == 30.36494484403383d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "edf6eea462cca1e705f8b7d95fa8dfe" + "'", str18.equals("edf6eea462cca1e705f8b7d95fa8dfe"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7403696354880825d + "'", double20 == 0.7403696354880825d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.4503130887214802d + "'", double22 == 0.4503130887214802d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 3.029488564301577d + "'", double24 == 3.029488564301577d);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int int2 = org.apache.commons.math.util.FastMath.max(13, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.special.Erf.erf(39.701154568539714d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure((long) 97);
//        double double8 = randomDataImpl0.nextGaussian((-0.25810163593826746d), 20.473321410692023d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 36.59564616294595d + "'", double8 == 36.59564616294595d);
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable17, objArray49);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException55 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) (-6.814282900389825d), (java.lang.Number) (-2.885320602561484d), true);
        org.apache.commons.math.exception.util.Localizable localizable56 = numberIsTooLargeException55.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException(localizable56, (java.lang.Number) 0.7824231037592737d, (java.lang.Number) (-1.1752011936438014d), (java.lang.Number) 444.3095895220466d);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable13 = outOfRangeException12.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException12);
        java.lang.Number number15 = outOfRangeException12.getHi();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(localizable13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0L + "'", number15.equals(0L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.3233178168367433d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.52474634612918d + "'", double1 == 18.52474634612918d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int4 = randomDataImpl0.nextHypergeometric((int) (short) 10, 31, 17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 31 is larger than the maximum (10): number of successes (31) must be less than or equal to population size (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381855d + "'", double1 == 0.5585053606381855d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(22.180709777452588d, (-0.8814691282277611d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double2 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.11276539834081348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11324581835703634d + "'", double1 == 0.11324581835703634d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass6 = numberIsTooSmallException3.getClass();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1.1680965989262542d, (java.lang.Number) 9, true);
        boolean boolean12 = numberIsTooSmallException11.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0f) + "'", number4.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test372");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian((-0.7440230792707043d), 0.08209350777524616d);
//        int int7 = randomDataImpl1.nextBinomial(9, 0.5432680528474173d);
//        try {
//            double double10 = randomDataImpl1.nextF((double) 23, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.6884220995384784d) + "'", double4 == (-0.6884220995384784d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 12, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable8, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("", objArray10);
        java.lang.String str13 = convergenceException12.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException12.getGeneralPattern();
        mathException5.addSuppressed((java.lang.Throwable) convergenceException12);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(number16, (java.lang.Number) (byte) 1, false);
        java.lang.Number number20 = numberIsTooLargeException19.getMax();
        convergenceException12.addSuppressed((java.lang.Throwable) numberIsTooLargeException19);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException12.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(localizable14);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (byte) 1 + "'", number20.equals((byte) 1));
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-32.16418743325655d), 0.0d, 0.3289803051047428d, (int) (byte) 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.2044012063326326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2044012063326328d + "'", double1 == 1.2044012063326328d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException4.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5008850900817288d, (java.lang.Number) 0.11276539834081348d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.5008850900817288d + "'", number4.equals(0.5008850900817288d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.6698777109326468d), (double) 62L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 62.0d + "'", double2 == 62.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.365840259013682d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.279557966937832d + "'", double1 == 5.279557966937832d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.4503130887214802d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-4.633146358949425d), (-0.48064673079510956d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.481 is smaller than, or equal to, the minimum (0): standard deviation (-0.481)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-11.346470410340524d), (-0.8375141847795038d), (-0.16386466025171564d), 9);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.cumulativeProbability((-1.0d));
        normalDistributionImpl0.reseedRandomGenerator(6L);
        double[] doubleArray6 = normalDistributionImpl0.sample(35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15865525393145702d + "'", double2 == 0.15865525393145702d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(31);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int2 = org.apache.commons.math.util.FastMath.max(23, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(0, "743c12338cf4ef37a4a63c9974ed52613eefdde7cc9242aea667c18999440b25af85521d8ef5f45728a7817974dc0dd9dc57", objArray2);
        java.lang.Throwable[] throwableArray4 = maxIterationsExceededException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number3);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getSpecificPattern();
        java.lang.Number number6 = outOfRangeException4.getLo();
        java.lang.Number number7 = outOfRangeException4.getHi();
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable24, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("hi!", objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(100, "", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) (short) 1, number35, true);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable40, objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException37, localizable38, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable32, objArray42);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable18, objArray42);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.3595072663974203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3071223299804224d + "'", double1 == 0.3071223299804224d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.0d, 3.029488564301577d, 7);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.11884638150958175d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7403696354880825d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.4200553931063d + "'", double1 == 42.4200553931063d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double1 = org.apache.commons.math.special.Gamma.digamma(73.74865724833803d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.293867681689406d + "'", double1 == 4.293867681689406d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 3, 2056318588L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2056318588L + "'", long2 == 2056318588L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable18, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable15, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("320e4281407b99bd2f8b7596083901590a3ae01f33de675165fec30849d7a28f4ecf04f4981154029c58011100836db8b0d2", objArray20);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-6146.22334164943d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable11, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("", objArray13);
        java.lang.String str16 = convergenceException15.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable18, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable25, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22, localizable23, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException6, localizable17, objArray27);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = outOfRangeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException47);
        java.lang.Object[] objArray49 = mathException48.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable17, objArray49);
        java.lang.Number number54 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 359.1342053695754d, (java.lang.Number) 10.0d, number54);
        org.apache.commons.math.exception.util.Localizable localizable56 = outOfRangeException55.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException(localizable56, (java.lang.Number) (-1.595451132473584d), (java.lang.Number) 10.0d, (java.lang.Number) (short) -1);
        java.lang.Object[] objArray61 = outOfRangeException60.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertNotNull(localizable17);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray61);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number3);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        java.lang.String str6 = outOfRangeException4.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 1 out of [0, null] range" + "'", str6.equals("org.apache.commons.math.exception.OutOfRangeException: 1 out of [0, null] range"));
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test401");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.sample();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        randomDataImpl0.reSeedSecure();
//        double double24 = randomDataImpl0.nextCauchy(44.0d, 64.21438644086723d);
//        double double27 = randomDataImpl0.nextUniform(0.8975852141610587d, 11.7910068511973d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.94501631110353d + "'", double3 == 10.94501631110353d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "185e559d255d5a831ee0665815032758bf75e35c36b58d1403067df6753a8215a49fbc3a67533b7c728f0957975014e549ed" + "'", str13.equals("185e559d255d5a831ee0665815032758bf75e35c36b58d1403067df6753a8215a49fbc3a67533b7c728f0957975014e549ed"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.5827225994544839d + "'", double19 == 0.5827225994544839d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.661874610004591d + "'", double20 == 1.661874610004591d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 352.51411830011034d + "'", double24 == 352.51411830011034d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.8454678287500104d + "'", double27 == 1.8454678287500104d);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.176597807921223d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) (short) 1, number4, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable9, objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException6, localizable7, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number18);
        java.lang.Object[] objArray20 = outOfRangeException19.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray20);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((-1), "8d82d9db46adf7ac503ab3946dd276fd2e59f21d2a358f6330ffd498fca6aa1da593827c30290b80cf8a7703e2e7ba66ef55", objArray20);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        boolean boolean17 = numberIsTooSmallException16.getBoundIsAllowed();
        java.lang.Object[] objArray18 = numberIsTooSmallException16.getArguments();
        java.lang.Throwable[] throwableArray19 = numberIsTooSmallException16.getSuppressed();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(5729.5779513082325d, 1.570796322790574d, 14.927029897655906d, (int) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable4, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.String str9 = convergenceException8.getPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable13, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray15);
        java.lang.String str18 = convergenceException17.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) (short) 1, number22, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable27, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24, localizable25, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException8, localizable19, objArray29);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException(localizable33, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException37);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException(localizable39, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable44 = outOfRangeException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable45, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException49);
        java.lang.Object[] objArray51 = mathException50.getArguments();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException38, localizable44, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable19, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException("aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray51);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray51);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(localizable19);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray51);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException7);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable12, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.String str17 = convergenceException16.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) (short) 1, number21, true);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable26, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException23, localizable24, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException7, localizable18, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable32, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable43 = outOfRangeException42.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException(localizable44, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException48);
        java.lang.Object[] objArray50 = mathException49.getArguments();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, localizable43, objArray50);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable18, objArray50);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException(localizable53, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException57);
        java.lang.Object[] objArray59 = mathException58.getArguments();
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(localizable18, objArray59);
        org.apache.commons.math.exception.util.Localizable localizable61 = mathException60.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable62 = mathException60.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable63 = mathException60.getGeneralPattern();
        java.lang.Object[] objArray64 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable63, objArray64);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(localizable18);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(localizable61);
        org.junit.Assert.assertNull(localizable62);
        org.junit.Assert.assertNotNull(localizable63);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.33771105105640853d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.25810163593826746d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2274832873441215d) + "'", double1 == (-0.2274832873441215d));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-43.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.String str8 = convergenceException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        java.lang.Object[] objArray14 = outOfRangeException13.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable15 = outOfRangeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable16, (java.lang.Number) (short) 1, number18, true);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable23, objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException20, localizable21, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooLargeException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Number number32 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number32);
        java.lang.Object[] objArray34 = outOfRangeException33.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(throwable0, localizable15, objArray34);
        java.lang.Number number38 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 1.6007714532002397d, number38, (java.lang.Number) 1.5860134523134308E15d);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double1 = org.apache.commons.math.util.FastMath.abs(55.571669069900985d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 55.571669069900985d + "'", double1 == 55.571669069900985d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.9583489237149074d), 0.20047201223075084d, 0.32875635635740336d, 2147483647);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3, (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test416");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        double double15 = randomDataImpl0.nextT(45.0d);
//        double double18 = randomDataImpl0.nextUniform(1.2044012063326326d, 2.0357687927483528d);
//        double double20 = randomDataImpl0.nextChiSquare((double) 4L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 60.000424215625884d + "'", double3 == 60.000424215625884d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0e9e1edc4dd8f59d0c7e44bdb40b5d86b488e89aae5ff8124d0388cbf1d3c944ebc973860c81f4f37d902afaf1febe50c874" + "'", str13.equals("0e9e1edc4dd8f59d0c7e44bdb40b5d86b488e89aae5ff8124d0388cbf1d3c944ebc973860c81f4f37d902afaf1febe50c874"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.33771105105640853d + "'", double15 == 0.33771105105640853d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.2404541798126112d + "'", double18 == 1.2404541798126112d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.6268292502157884d + "'", double20 == 1.6268292502157884d);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test417");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double18 = normalDistributionImpl15.cumulativeProbability(Double.NaN, (double) 0);
//        double double19 = normalDistributionImpl15.getMean();
//        double double20 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double23 = randomDataImpl0.nextUniform(0.0d, 1.7896353172533552d);
//        try {
//            double double26 = randomDataImpl0.nextF(0.0d, 0.7970747335500249d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 36.38603493924769d + "'", double3 == 36.38603493924769d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "db8b74b98d498ba849255d13ad53ff4eadb1c6419bdd8b72d469945e42d8778775fc0c1fb5c8b33394322a350d18d0d2a70e" + "'", str13.equals("db8b74b98d498ba849255d13ad53ff4eadb1c6419bdd8b72d469945e42d8778775fc0c1fb5c8b33394322a350d18d0d2a70e"));
//        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.4854040234818508d + "'", double20 == 0.4854040234818508d);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.6443547981231905d + "'", double23 == 1.6443547981231905d);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        java.lang.Object[] objArray3 = mathException2.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("", objArray9);
        java.lang.String str12 = convergenceException11.getPattern();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException11);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable16, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException("", objArray18);
        java.lang.String str21 = convergenceException20.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) (short) 1, number25, true);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable30, objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException27, localizable28, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException11, localizable22, objArray32);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable42, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable47 = outOfRangeException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable48, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException52);
        java.lang.Object[] objArray54 = mathException53.getArguments();
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException41, localizable47, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(localizable22, objArray54);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable58, objArray60);
        org.apache.commons.math.exception.util.Localizable localizable62 = maxIterationsExceededException61.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable66, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException("", objArray68);
        java.lang.String str71 = convergenceException70.getPattern();
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException70);
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable75, objArray77);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException("", objArray77);
        java.lang.String str80 = convergenceException79.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable81 = convergenceException79.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Number number84 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException86 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable82, (java.lang.Number) (short) 1, number84, true);
        org.apache.commons.math.exception.util.Localizable localizable87 = null;
        org.apache.commons.math.exception.util.Localizable localizable89 = null;
        java.lang.Object[] objArray91 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable89, objArray91);
        org.apache.commons.math.MathException mathException93 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException86, localizable87, objArray91);
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException70, localizable81, objArray91);
        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException61, "hi!", objArray91);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, localizable22, objArray91);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNull(localizable62);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "" + "'", str71.equals(""));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "" + "'", str80.equals(""));
        org.junit.Assert.assertNotNull(localizable81);
        org.junit.Assert.assertNotNull(objArray91);
    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test419");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextGaussian(7.450833191230467E34d, 1.5707963266948965d);
//        int[] intArray7 = randomDataImpl1.nextPermutation(10, (int) (short) 10);
//        double double10 = randomDataImpl1.nextCauchy(0.6098494453571889d, 0.5039893563146316d);
//        int int13 = randomDataImpl1.nextZipf(52, (double) 100.0f);
//        java.lang.String str15 = randomDataImpl1.nextSecureHexString(12);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 7.450833191230467E34d + "'", double4 == 7.450833191230467E34d);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 3.523013292603407d + "'", double10 == 3.523013292603407d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "896dc87d0ddc" + "'", str15.equals("896dc87d0ddc"));
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test420");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 26.051706224417586d + "'", double3 == 26.051706224417586d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b4713024564f5be636d4a1c1849560b7c6d523f54e85aad1ce9c32393e3ebb330044defc2fdf75d786b163f2557746fd0096" + "'", str10.equals("b4713024564f5be636d4a1c1849560b7c6d523f54e85aad1ce9c32393e3ebb330044defc2fdf75d786b163f2557746fd0096"));
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) 0L, number3);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test422");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed();
//        long long9 = randomDataImpl0.nextPoisson(0.010050166663333094d);
//        double double11 = randomDataImpl0.nextT(0.11829152908655012d);
//        double double13 = randomDataImpl0.nextExponential(23.363034433648068d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-18.955189435219978d) + "'", double3 == (-18.955189435219978d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-389599.9577362369d) + "'", double11 == (-389599.9577362369d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.064663919511124d + "'", double13 == 4.064663919511124d);
//    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test423");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed();
//        int int10 = randomDataImpl0.nextSecureInt(0, 20);
//        try {
//            double double13 = randomDataImpl0.nextWeibull(0.0d, 0.5522878758283906d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 50.47981668166902d + "'", double3 == 50.47981668166902d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 14 + "'", int10 == 14);
//    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test424");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double14 = randomDataImpl0.nextGamma(71.32400509670025d, (double) (short) 100);
//        int int17 = randomDataImpl0.nextPascal((int) ' ', 0.11884638150958175d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 38.441877578416616d + "'", double3 == 38.441877578416616d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 6067.318277418883d + "'", double14 == 6067.318277418883d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 206 + "'", int17 == 206);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        long long1 = org.apache.commons.math.util.FastMath.round(1.4925094573555984d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int int2 = org.apache.commons.math.util.FastMath.min(49, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) 1, number2, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable7, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, localizable5, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, number13, (java.lang.Number) 1.4173627661473032d, true);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable24, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException("", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("hi!", objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(100, "", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable33, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray35);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray35);
    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeed((long) '4');
//        int[] intArray11 = randomDataImpl0.nextPermutation((int) (short) 10, 1);
//        java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeed();
//        int int17 = randomDataImpl0.nextSecureInt(1, 52);
//        double double19 = randomDataImpl0.nextChiSquare(2.000637772820911d);
//        double double21 = randomDataImpl0.nextExponential(0.7837811557474641d);
//        long long24 = randomDataImpl0.nextSecureLong(0L, 35L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 49.846277886419905d + "'", double3 == 49.846277886419905d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "a043d6058dc82bcc9ed3c1a74cfdbcc40a924236ed1e746d851db9330bbe0023be873c98839f4d3846bfd2b5e80119228153" + "'", str13.equals("a043d6058dc82bcc9ed3c1a74cfdbcc40a924236ed1e746d851db9330bbe0023be873c98839f4d3846bfd2b5e80119228153"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 3 + "'", int17 == 3);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.655327588470906d + "'", double19 == 3.655327588470906d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.3068050337029581d + "'", double21 == 0.3068050337029581d);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 8L + "'", long24 == 8L);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable2, objArray4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.String str7 = convergenceException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) (-4.281642508279315d), (java.lang.Number) 0.9999999999998099d, false);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12, "", objArray14);
        java.lang.Object[] objArray16 = numberIsTooSmallException12.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.1622776601683795d, (java.lang.Number) 0.3595072663974203d, false);
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number23, false);
        java.lang.Number number26 = numberIsTooSmallException25.getArgument();
        boolean boolean27 = numberIsTooSmallException25.getBoundIsAllowed();
        java.lang.Class<?> wildcardClass28 = numberIsTooSmallException25.getClass();
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException25.getGeneralPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException31);
        java.lang.Object[] objArray33 = mathException32.getArguments();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException21, localizable29, objArray33);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable37, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("", objArray39);
        java.lang.String str42 = convergenceException41.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = convergenceException41.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException(localizable43, (java.lang.Number) 0.017453292519943295d, (java.lang.Number) 1L, (java.lang.Number) 0L);
        org.apache.commons.math.exception.util.Localizable localizable48 = outOfRangeException47.getSpecificPattern();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException(100);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException50);
        java.lang.Object[] objArray52 = mathException51.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable48, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable29, objArray52);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(localizable8);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (-1.0f) + "'", number26.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "" + "'", str42.equals(""));
        org.junit.Assert.assertNotNull(localizable43);
        org.junit.Assert.assertNotNull(localizable48);
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.990000159752915d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9900001597529151d + "'", double1 == 0.9900001597529151d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.4962487459667182d, 7.69459862670642E-23d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999880171d + "'", double2 == 0.9999999999880171d);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test432");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        double double13 = randomDataImpl0.nextT(2.1068473899378932d);
//        randomDataImpl0.reSeedSecure((-1L));
//        double double17 = randomDataImpl0.nextT((double) 13);
//        double double20 = randomDataImpl0.nextWeibull(0.5522878758283906d, Double.NaN);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 20.93961888826789d + "'", double3 == 20.93961888826789d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.8818045849173388d) + "'", double13 == (-1.8818045849173388d));
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2641958961730389d + "'", double17 == 0.2641958961730389d);
//        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double1 = org.apache.commons.math.util.FastMath.abs((-4.683626434817649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.683626434817649d + "'", double1 == 4.683626434817649d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 83, (float) 12);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 12.0f + "'", float2 == 12.0f);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test435");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (short) 10);
//        randomDataImpl0.reSeedSecure();
//        long long6 = randomDataImpl0.nextLong(0L, (long) 2147483647);
//        randomDataImpl0.reSeed(100L);
//        try {
//            long long10 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1728917522L + "'", long6 == 1728917522L);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
//        double double5 = normalDistributionImpl0.cumulativeProbability(0.8975852141610587d, 1.9802279607563054d);
//        double double6 = normalDistributionImpl0.getStandardDeviation();
//        double double7 = normalDistributionImpl0.sample();
//        double[] doubleArray9 = normalDistributionImpl0.sample(6);
//        double double10 = normalDistributionImpl0.getMean();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.16086440265790714d + "'", double5 == 0.16086440265790714d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7179009094898311d + "'", double7 == 0.7179009094898311d);
//        org.junit.Assert.assertNotNull(doubleArray9);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.4711276743037347d, (java.lang.Number) 0.8845158039790166d, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 49, (java.lang.Number) 23.363034433648068d, (java.lang.Number) 10.0f);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException13);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable17, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray19);
        java.lang.String str22 = convergenceException21.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException21.getGeneralPattern();
        mathException14.addSuppressed((java.lang.Throwable) convergenceException21);
        java.lang.Number number25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(number25, (java.lang.Number) (byte) 1, false);
        java.lang.Number number29 = numberIsTooLargeException28.getMax();
        convergenceException21.addSuppressed((java.lang.Throwable) numberIsTooLargeException28);
        boolean boolean31 = numberIsTooLargeException28.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable38, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        java.lang.String str43 = convergenceException42.getPattern();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException42);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException50 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable47, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException("", objArray49);
        java.lang.String str52 = convergenceException51.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = convergenceException51.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Number number56 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) (short) 1, number56, true);
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable61, objArray63);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException58, localizable59, objArray63);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, localizable53, objArray63);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException(localizable67, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException71);
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException77 = new org.apache.commons.math.exception.OutOfRangeException(localizable73, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable78 = outOfRangeException77.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException83 = new org.apache.commons.math.exception.OutOfRangeException(localizable79, (java.lang.Number) Double.NaN, (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException83);
        java.lang.Object[] objArray85 = mathException84.getArguments();
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException72, localizable78, objArray85);
        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException(localizable53, objArray85);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException88 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray85);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException("aa55a2132a95baf1a5334fcd6966170823af784da8e7f21310aaa0ab011a5903b7c5676f4f3f5c0e53047d83f8916c70992d", objArray85);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException28, "e0104fd1a7a01ddf92b781f7e58bc78471e9edf449ed17c02e9fa706d7ca7d44f3bdcc88a9228905e1991661728d6dfe31a7", objArray85);
        outOfRangeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException28);
        java.lang.String str92 = outOfRangeException8.toString();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(localizable23);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + (byte) 1 + "'", number29.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertNotNull(localizable53);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertTrue("'" + str92 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 49 out of [23.363, 10] range: 49 is larger than the maximum (23.363)" + "'", str92.equals("org.apache.commons.math.exception.OutOfRangeException: 49 out of [23.363, 10] range: 49 is larger than the maximum (23.363)"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3010299956639812d + "'", double1 == 0.3010299956639812d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray8);
        java.lang.String str11 = convergenceException10.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 'a', 1.0d, '4', localizable12, (-1.0d), (short) 0 };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.6483608274590892d);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) (short) 1, number22, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable27, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24, localizable25, objArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooLargeException24.getGeneralPattern();
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable32, number33, (java.lang.Number) 1.4173627661473032d, true);
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException36.getGeneralPattern();
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable37, objArray38);
        notStrictlyPositiveException19.addSuppressed((java.lang.Throwable) convergenceException39);
        mathException16.addSuppressed((java.lang.Throwable) notStrictlyPositiveException19);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable6, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray8);
        java.lang.String str11 = convergenceException10.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException10.getGeneralPattern();
        java.lang.Object[] objArray15 = new java.lang.Object[] { 'a', 1.0d, '4', localizable12, (-1.0d), (short) 0 };
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable19, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = maxIterationsExceededException22.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException22);
        mathException16.addSuppressed((java.lang.Throwable) maxIterationsExceededException22);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNull(localizable23);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.303909551780072d, (-0.8794399162728251d), 20.60023464126346d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.879 is smaller than, or equal to, the minimum (0): standard deviation (-0.879)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double double1 = org.apache.commons.math.special.Erf.erf(14.546297637560345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test443");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long13 = randomDataImpl0.nextPoisson(1.499039715843948d);
//        double double16 = randomDataImpl0.nextUniform(0.6906081393758767d, 1.0d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("9f1491551a2e478748187bbde5dc3fc8e0c4a4d4f151152a7a798010e82f97afa29ce3376727747a6996a1dcd4de4e05c09a", "eedeedac141528574e80bec9a8c24b2a6a1c01916761bbb0352a41320317b90922c39f63e8c6b7d769c7617b3218603d70d5");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: eedeedac141528574e80bec9a8c24b2a6a1c01916761bbb0352a41320317b90922c39f63e8c6b7d769c7617b3218603d70d5");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-13.687007118806614d) + "'", double3 == (-13.687007118806614d));
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.7826863634909486d + "'", double16 == 0.7826863634909486d);
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.0575952384920808d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5164993806856477d + "'", double1 == 1.5164993806856477d);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test445");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long13 = randomDataImpl0.nextPoisson(1.499039715843948d);
//        double double16 = randomDataImpl0.nextCauchy(0.08209350777524616d, 19.241467490659986d);
//        java.lang.String str18 = randomDataImpl0.nextSecureHexString(31);
//        try {
//            long long20 = randomDataImpl0.nextPoisson((-27.117635365851932d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -27.118 is smaller than, or equal to, the minimum (0): mean (-27.118)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.146323517809801d + "'", double3 == 8.146323517809801d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2L + "'", long13 == 2L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 18.24088577982193d + "'", double16 == 18.24088577982193d);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "a20d50ec54e2cc30077f9152a4cd04e" + "'", str18.equals("a20d50ec54e2cc30077f9152a4cd04e"));
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) 1);
        double double5 = normalDistributionImpl0.cumulativeProbability(0.8975852141610587d, 1.9802279607563054d);
        double double6 = normalDistributionImpl0.getStandardDeviation();
        double double8 = normalDistributionImpl0.density((-0.1521089696203987d));
        double double9 = normalDistributionImpl0.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.16086440265790714d + "'", double5 == 0.16086440265790714d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.39435368191090925d + "'", double8 == 0.39435368191090925d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-46.93738671994499d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test448");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(10.000000000000002d, (double) 32);
//        int[] intArray6 = randomDataImpl0.nextPermutation((int) '4', (int) (short) 1);
//        randomDataImpl0.reSeedSecure((long) 10);
//        int int11 = randomDataImpl0.nextSecureInt(0, (int) (short) 10);
//        long long13 = randomDataImpl0.nextPoisson(1.499039715843948d);
//        double double15 = randomDataImpl0.nextExponential(31.12235971802655d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.6843455575270863d + "'", double3 == 3.6843455575270863d);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 4L + "'", long13 == 4L);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 55.04079146555659d + "'", double15 == 55.04079146555659d);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8813735870195432d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6320021414540533d + "'", double1 == 0.6320021414540533d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable4, objArray6);
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable12, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("", objArray14);
        java.lang.String str17 = convergenceException16.getPattern();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException16);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray23 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable21, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray23);
        java.lang.String str26 = convergenceException25.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) (short) 1, number30, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10.0f };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable35, objArray37);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException32, localizable33, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException16, localizable27, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException7, "hi!", objArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException(49, localizable2, objArray37);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray37);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(localizable27);
        org.junit.Assert.assertNotNull(objArray37);
    }
}

