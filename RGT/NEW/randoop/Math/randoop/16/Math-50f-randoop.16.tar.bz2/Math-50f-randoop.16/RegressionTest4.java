import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.302585092994046d, (double) 31.999998f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.718511628891974d + "'", double2 == 33.718511628891974d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 2.0f, (-9.2011781863525376E18d), (double) (-9223372034707292160L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.219384835475456E16d + "'", double3 == 2.219384835475456E16d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 6990832826496134385L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 55, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 55.0f + "'", float2 == 55.0f);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 5, (float) 110L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 110.0f + "'", float2 == 110.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 1023, 11846.669319939707d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11890.757039650618d + "'", double2 == 11890.757039650618d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 4092L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) (-1L), false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.46842437619265676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5080498902988542d + "'", double1 == 0.5080498902988542d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 582);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 582.00006f + "'", float1 == 582.00006f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double5 = regulaFalsiSolver0.solve((int) (short) 0, univariateRealFunction3, (double) Float.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        org.apache.commons.math.util.MathUtils.checkFinite(0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.46842437619265676d, (double) 101L, (double) 10L);
        int int4 = regulaFalsiSolver3.getEvaluations();
        double double5 = regulaFalsiSolver3.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        try {
            double double9 = regulaFalsiSolver3.solve(10, univariateRealFunction7, 81.62268552636596d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 101.0d + "'", double5 == 101.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(1.6940658945086007E-21d, 0.0d, 101.0d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (int) (short) 1, (int) '#');
        java.lang.String str4 = dimensionMismatchException3.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.DimensionMismatchException: unparseable complex number: \"1\"" + "'", str4.equals("org.apache.commons.math.exception.DimensionMismatchException: unparseable complex number: \"1\""));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 1.513955751696327d, 0.0d, 128.3822417626363d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray27 = new double[] { 90.0d, 91.0d, (-1.0f), 10.0f };
        double[] doubleArray30 = new double[] { 100.0d, 1.0f };
        double[] doubleArray37 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray37);
        double[] doubleArray41 = new double[] { 100.0d, 1.0f };
        double[] doubleArray48 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray48);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 90.0d + "'", double38 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 90.0d + "'", double49 == 90.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 121.18168178400562d + "'", double51 == 121.18168178400562d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 91.0d + "'", double52 == 91.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(7, (-1021));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { 100.0d, 1.0f };
        double[] doubleArray32 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray20);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 101.00495037373169d + "'", double36 == 101.00495037373169d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) 1820, (double) (-533536015));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) 2000.0d, true);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        org.apache.commons.math.exception.MathInternalError mathInternalError6 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathInternalError6.getContext();
        java.util.Set<java.lang.String> strSet8 = exceptionContext7.getKeys();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)"));
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.37173886626E11d, 2.4429960546751954E7d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.46842437619265676d, (double) 101L, (double) 10L);
        int int4 = regulaFalsiSolver3.getEvaluations();
        double double5 = regulaFalsiSolver3.getStartValue();
        double double6 = regulaFalsiSolver3.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction8 = null;
        try {
            double double12 = regulaFalsiSolver3.solve(4092, univariateRealFunction8, (double) 90.0f, 1.2404101770619356d, 2.915768896081299E7d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((-0.5091110071604571d), (double) 137173886626L, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [137,173,886,626, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray14 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray28 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray28);
        double double30 = noBracketingException29.getLo();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext31 = noBracketingException29.getContext();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        float[] floatArray40 = new float[] { 1, (short) -1, 10.0f, (byte) 100 };
        float[] floatArray41 = null;
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray40, floatArray41);
        org.apache.commons.math.exception.MathInternalError mathInternalError43 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Object[] objArray45 = new java.lang.Object[] { floatArray41, mathInternalError43, "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException46 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray45);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException47 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (java.lang.Number) 35.000004f, objArray45);
        exceptionContext31.addMessage(localizable32, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray58 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException59 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats52, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray58);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException60 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats50, number51, objArray58);
        java.lang.Class<?> wildcardClass61 = objArray58.getClass();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) objArray45, localizable49, objArray58);
        org.apache.commons.math.exception.NoBracketingException noBracketingException63 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, 100.00499987500625d, (double) 1820, 1.3197768247158532d, 4.499809670330265d, objArray58);
        org.apache.commons.math.exception.NoBracketingException noBracketingException64 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, 0.020847887479787386d, (double) 319000847L, 4.644483341943245d, 11845.8278489549d, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray58);
        java.lang.Throwable[] throwableArray66 = mathIllegalArgumentException65.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_CLUSTER_IN_K_MEANS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(exceptionContext31);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(throwableArray66);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(2, (-533536015));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1067072030 + "'", int2 == 1067072030);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 3.15251974E17f, 1.2404101770619356d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1525197391593472E17d + "'", double2 == 3.1525197391593472E17d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) (-1768L), 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray27 = new double[] { 90.0d, 91.0d, (-1.0f), 10.0f };
        double[] doubleArray30 = new double[] { 100.0d, 1.0f };
        double[] doubleArray37 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray37);
        double[] doubleArray41 = new double[] { 100.0d, 1.0f };
        double[] doubleArray48 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray48);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) (-0.99999994f));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 90.0d + "'", double38 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 90.0d + "'", double49 == 90.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 121.18168178400562d + "'", double51 == 121.18168178400562d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 91.0d + "'", double52 == 91.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        double double1 = org.apache.commons.math.util.FastMath.log(0.08106152637093929d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.512546827821839d) + "'", double1 == (-2.512546827821839d));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2000.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 203.0d, 101.0d, 96.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = nonMonotonousSequenceException4.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats6);
        java.lang.Object[] objArray8 = null;
        exceptionContext5.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray26 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException27 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray26);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException28 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray26);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException29 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Number) 0, objArray26);
        org.apache.commons.math.exception.NoBracketingException noBracketingException30 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (double) 1820, (double) (short) 10, (double) (-3.9999998f), 7.629395440744702E-6d, objArray26);
        exceptionContext5.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray26);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.8464846872172499d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7024497005402738d + "'", double1 == 0.7024497005402738d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        incrementor0.incrementCount(0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 6);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 6.0000005f + "'", float1 == 6.0000005f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.6293945171871745E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.629365413504854E-6d + "'", double1 == 7.629365413504854E-6d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.020847887479787386d));
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-0.020847887479787386d) + "'", number2.equals((-0.020847887479787386d)));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 101L, (double) (byte) 0);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver2.solve(7, univariateRealFunction5, 2.220446049250313E-16d, (double) (-533536015L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray9 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException10 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray9);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray9);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException12 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2, 6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-4.4563601E16f));
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        try {
            double double7 = regulaFalsiSolver1.solve(0, univariateRealFunction3, (double) (-1768L), 2.4497924629330158E33d, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution6 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution6.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1768L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        double double1 = org.apache.commons.math.util.FastMath.signum((-29.169912013948824d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1023);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1023.0d + "'", double1 == 1023.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1428210985L), (java.lang.Number) 15.104412573075516d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 100, 1023);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getCount();
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray6 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray6);
        double double8 = noBracketingException7.getHi();
        double double9 = noBracketingException7.getFHi();
        double double10 = noBracketingException7.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount((-6));
        try {
            incrementor0.incrementCount((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (-6) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, (int) (byte) 100);
        try {
            int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, (-4));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext0 = new org.apache.commons.math.exception.util.ExceptionContext();
        exceptionContext0.setValue("org.apache.commons.math.exception.NoBracketingException: array sums to zero", (java.lang.Object) 5.925621140166186d);
        exceptionContext0.setValue("simplex must contain at least one point", (java.lang.Object) 0.579800154212869d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) 2000.0d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2000.0d + "'", number4.equals(2000.0d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-319000853));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        double double2 = org.apache.commons.math.util.FastMath.scalb(1.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getAbsoluteAccuracy();
        int int3 = regulaFalsiSolver1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 342559971);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double double2 = org.apache.commons.math.util.FastMath.hypot(49.0d, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3440585709080678E43d + "'", double2 == 1.3440585709080678E43d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.8446744073709552E19d, (double) 319000847L);
        double double3 = regulaFalsiSolver2.getMin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.534856945352157E22d, 9.617269008937367E67d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double8 = regulaFalsiSolver2.solve(0, univariateRealFunction4, 11890.757039650618d, 0.0d, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double[] doubleArray24 = new double[] { 100.0d, 1.0f };
        double[] doubleArray31 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray24);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray24, 10);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray35);
        double[] doubleArray39 = new double[] { 100.0d, 1.0f };
        double[] doubleArray46 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray46);
        double[] doubleArray50 = new double[] { 100.0d, 1.0f };
        double[] doubleArray57 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray57);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray46);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (-1.1752011016690305d));
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) (short) 1);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) 6442450941L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 90.0d + "'", double32 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 90.0d + "'", double47 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 90.0d + "'", double58 == 90.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 4092);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 4092);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 96);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (-18));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-18)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray11 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray11, 0);
        int[] intArray17 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray17, 0);
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray17);
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray17);
        int[] intArray25 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray25, 0);
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        int[] intArray32 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray32, 0);
        int[] intArray35 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int[] intArray37 = org.apache.commons.math.util.MathUtils.copyOf(intArray32, (int) (byte) 100);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray32);
        int[] intArray39 = org.apache.commons.math.util.MathUtils.copyOf(intArray27);
        try {
            int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) 2000.0d, true);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        org.apache.commons.math.exception.MathInternalError mathInternalError6 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathInternalError6.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.apache.commons.math.util.Incrementor incrementor11 = new org.apache.commons.math.util.Incrementor();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        double[] doubleArray15 = new double[] { 100.0d, 1.0f };
        double[] doubleArray22 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double23 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray22);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException27.getDirection();
        double[] doubleArray35 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray42 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray49 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray56 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[][] doubleArray57 = new double[][] { doubleArray35, doubleArray42, doubleArray49, doubleArray56 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray22, orderDirection28, doubleArray57);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) incrementor11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) doubleArray57);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException60 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) doubleArray57);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException61 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) doubleArray57);
        exceptionContext7.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) doubleArray57);
        java.lang.Object obj64 = null;
        exceptionContext7.setValue("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,399,733,632 and 1,399,733,633 are not decreasing (0 < 21.773)", obj64);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)"));
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 90.0d + "'", double23 == 90.0d);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 101L);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notPositiveException1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray4, 0);
        int[] intArray10 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, 0);
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray10);
        int[] intArray17 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray17, 0);
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray17, (int) (byte) 100);
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray17);
        try {
            double double24 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 55, 1399733632);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = nonMonotonousSequenceException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        double[] doubleArray9 = new double[] { 100.0d, 1.0f };
        double[] doubleArray16 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray16);
        double[] doubleArray20 = new double[] { 100.0d, 1.0f };
        double[] doubleArray27 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray20);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, 10);
        double[] doubleArray36 = new double[] { 90.0d, 91.0d, (-1.0f), 10.0f };
        double[] doubleArray39 = new double[] { 100.0d, 1.0f };
        double[] doubleArray46 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray46);
        double[] doubleArray50 = new double[] { 100.0d, 1.0f };
        double[] doubleArray57 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray57);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray57);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray57);
        exceptionContext4.setValue("org.apache.commons.math.exception.NotStrictlyPositiveException: 1.543 is smaller than, or equal to, the minimum (0)", (java.lang.Object) doubleArray31);
        java.util.Set<java.lang.String> strSet63 = exceptionContext4.getKeys();
        java.lang.Object obj65 = exceptionContext4.getValue("org.apache.commons.math.exception.NullArgumentException: overflow: gcd( , {1}) is 2^31");
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 90.0d + "'", double17 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 90.0d + "'", double28 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 90.0d + "'", double47 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 90.0d + "'", double58 == 90.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 121.18168178400562d + "'", double60 == 121.18168178400562d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(strSet63);
        org.junit.Assert.assertNull(obj65);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        org.apache.commons.math.util.MathUtils.checkFinite(0.020847887479787386d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, 10);
        double[] doubleArray27 = new double[] { 100.0d, 1.0f };
        double[] doubleArray34 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray34);
        double[] doubleArray38 = new double[] { 100.0d, 1.0f };
        double[] doubleArray45 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double46 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray38);
        double[] doubleArray52 = new double[] { 90.0d, 91.0d, (-1.0f), 10.0f };
        double[] doubleArray55 = new double[] { 100.0d, 1.0f };
        double[] doubleArray62 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray62);
        double[] doubleArray66 = new double[] { 100.0d, 1.0f };
        double[] doubleArray73 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray73);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray73);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray73);
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray27);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 90.0d + "'", double35 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 90.0d + "'", double46 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 90.0d + "'", double63 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 90.0d + "'", double74 == 90.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 121.18168178400562d + "'", double76 == 121.18168178400562d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 91.0d + "'", double77 == 91.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 179766209 + "'", int78 == 179766209);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray81);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException(number0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-319000853), (-1768));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0420382290916537E20d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver14 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        int int15 = regulaFalsiSolver14.getMaxEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution19 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double20 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction10, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver14, (double) (short) 10, 7.62939453125E-6d, (-1.0d), allowedSolution19);
        double double21 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(2, univariateRealFunction3, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, (double) (-1428210879), (double) (-583489541), (-0.12217304763960307d), allowedSolution19);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction26 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver30 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        int int31 = regulaFalsiSolver30.getMaxEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution35 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double36 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction26, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver30, (double) (short) 10, 7.62939453125E-6d, (-1.0d), allowedSolution35);
        double double37 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) ' ', univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 8.042194253527414E36d, (double) 100L, (-0.4119627100860633d), allowedSolution35);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution19 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution19.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-1.428210879E9d) + "'", double21 == (-1.428210879E9d));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution35 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution35.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 8.042194253527414E36d + "'", double37 == 8.042194253527414E36d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.192093E-7f + "'", float1 == 1.192093E-7f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(74.20321057778875d, 2.4429960546751954E7d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (-1.4282108789999998E9d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getCount();
        incrementor0.incrementCount();
        incrementor0.setMaximalCount((int) (byte) 1);
        incrementor0.setMaximalCount(2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 100, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.528752E7d + "'", double2 == 7.528752E7d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.534856945352157E22d, 9.617269008937367E67d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(0, univariateRealFunction4, 0.29100619138474915d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray27 = new double[] { 90.0d, 91.0d, (-1.0f), 10.0f };
        double[] doubleArray30 = new double[] { 100.0d, 1.0f };
        double[] doubleArray37 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray37);
        double[] doubleArray41 = new double[] { 100.0d, 1.0f };
        double[] doubleArray48 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray48);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) (short) 10);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 90.0d + "'", double38 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 90.0d + "'", double49 == 90.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 121.18168178400562d + "'", double51 == 121.18168178400562d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 91.0d + "'", double52 == 91.0d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 179766209 + "'", int53 == 179766209);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 100.00499987500625d + "'", double54 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 100.00499987500625d + "'", double55 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        float float2 = org.apache.commons.math.util.FastMath.min(0.99999994f, (float) 4092);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.99999994f + "'", float2 == 0.99999994f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 45.054566736396445d, (java.lang.Number) (-9201178186352538207L), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.111507638930571E-61d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        long long2 = org.apache.commons.math.util.MathUtils.pow(319000847L, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3246034656128425375L) + "'", long2 == (-3246034656128425375L));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray14 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray14);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 0.431159436143842d, 11846.669319939707d, 0.811048585625462d, 36.07140440247247d, objArray14);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.7776471048437088d, (java.lang.Number) 0.5309649148733837d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        double double1 = org.apache.commons.math.util.FastMath.cos(11890.757039650618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9853888424555444d) + "'", double1 == (-0.9853888424555444d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) (-1.42821094E9f), 2005.3522829578812d, 96.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 96L, (-4));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-6), 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 10, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-1023), (float) 4092, (-18));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        long long1 = org.apache.commons.math.util.MathUtils.sign(2147483647L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(9.617269008937367E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 10.000249990625546d, (double) 2.02219853E9f, 15.104412573075516d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 2.154434690031884d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "identical abscissas x[{0}] == x[{1}] == {2} cause division by zero" + "'", str1.equals("identical abscissas x[{0}] == x[{1}] == {2} cause division by zero"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.4119627100860633d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.3907763313470518d) + "'", double1 == (-0.3907763313470518d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1820.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((-0.9999999403953552d), (double) 7, 7.62939453125E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.9999924302101135d + "'", double3 == 5.9999924302101135d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, (double) (-319000864L), 1.428210816E9d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        float[] floatArray3 = new float[] { 0L, '4', 10 };
        float[] floatArray5 = new float[] { 7.6293945E-6f };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray3, floatArray5);
        float[] floatArray13 = new float[] { 52, 10, 1399733633, 44563605345380515L, 0, ' ' };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray5, floatArray13);
        float[] floatArray15 = null;
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(floatArray5, floatArray15);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        float float2 = org.apache.commons.math.util.FastMath.copySign(1.3997335E9f, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.3997335E9f + "'", float2 == 1.3997335E9f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(64, 4092);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(0.3796077390275217d, 74.20321057778875d, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3796077390275217d + "'", double3 == 0.3796077390275217d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.42821082E9f), 3.831008000716577E22d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1428210879), 1399733633);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,399,733,633, n = -1,428,210,879");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 18200L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 267.74489404101644d + "'", double1 == 267.74489404101644d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 9.2233715E18f, 595069.1624655712d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.2233714870989619E18d + "'", double2 == 9.2233714870989619E18d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getCount();
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getCount();
        int int6 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (10) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray11 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray11);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException13 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray11);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 1.0000000000291038d, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 7.507141079727608d, objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(98.0d, (double) 6, (-60));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (double) 1067072030, 1.934949401062422d, 1.2404101770619356d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.400130929177725d + "'", double4 == 2.400130929177725d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2147483647, (long) 582);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 128.3822417626363d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray13 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray13);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException16 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray13);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.exception.NoBracketingException noBracketingException18 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 7.570443517760318d, (double) 9223372036854775807L, 1.8270874753469164d, (-0.12217304763960307d), objArray13);
        double double19 = noBracketingException18.getFLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.8270874753469164d + "'", double19 == 1.8270874753469164d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        double double4 = regulaFalsiSolver3.getStartValue();
        int int5 = regulaFalsiSolver3.getEvaluations();
        int int6 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        java.lang.Object obj3 = exceptionContext1.getValue("hi!");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        java.lang.Object[] objArray5 = null;
        exceptionContext1.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray5);
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.5976000972965376d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 96, (double) 7920304393916482560L, (double) (-1768));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-9223372034707292160L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(7, (-583489541));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 583489548 + "'", int2 == 583489548);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 179766209);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 179766209 + "'", number2.equals(179766209));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', 64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-449079295) + "'", int2 == (-449079295));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-3.19000864E8f), (double) 1023L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.19000864E8d) + "'", double2 == (-3.19000864E8d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-533536015), 583489548);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray4, 0);
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray6);
        int[] intArray11 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray11, 0);
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray13);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray13);
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray17, 0);
        int[] intArray23 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray23, 0);
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray23);
        try {
            double double28 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = nonMonotonousSequenceException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats5);
        java.lang.Object[] objArray7 = null;
        exceptionContext4.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray20 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException21 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray20);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException22 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray20);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException23 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, (java.lang.Number) 1.0000000000291038d, objArray20);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException24 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray34 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException35 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats28, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray34);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException36 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray34);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException38 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) (-4.4563601E16f), objArray34);
        exceptionContext4.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, objArray34);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        double double2 = org.apache.commons.math.util.FastMath.copySign(0.43115943614384195d, 0.7853981633974484d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.43115943614384195d + "'", double2 == 0.43115943614384195d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        double double1 = org.apache.commons.math.util.FastMath.acos((-201.71315737027922d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 1399733537);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 128.0f + "'", float1 == 128.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(4.2514365942624575E52d, 0.0d, 0.020847887479787386d, 11013.232920103323d);
        double double5 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(52, (-2022198591));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 137173886626L, 4.12389349773832E54d, 1.192092895507813E-7d);
        double double4 = regulaFalsiSolver3.getStartValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray6 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray6);
        double double8 = noBracketingException7.getHi();
        double double9 = noBracketingException7.getFHi();
        double double10 = noBracketingException7.getFHi();
        double double11 = noBracketingException7.getFHi();
        double double12 = noBracketingException7.getLo();
        double double13 = noBracketingException7.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1768));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-319000847));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 319000847 + "'", int2 == 319000847);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        double double2 = org.apache.commons.math.util.FastMath.scalb(36.07140440247247d, 583489548);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 52.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 10, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-42L) + "'", long2 == (-42L));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.6929693744344998d, 2.718281828459045d, (-1.5707963236601088d), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray7 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray7);
        double double9 = noBracketingException8.getLo();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = noBracketingException8.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray18 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException19 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray18);
        exceptionContext10.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray18);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray18);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext22 = mathIllegalStateException21.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(exceptionContext22);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, 10);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray28 = new double[] { 100.0d, 1.0f };
        double[] doubleArray35 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray35);
        double[] doubleArray39 = new double[] { 100.0d, 1.0f };
        double[] doubleArray46 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray46);
        double[] doubleArray51 = new double[] { 100.0d, 1.0f };
        double[] doubleArray58 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray58);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray46);
        try {
            double[] doubleArray63 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, (-18));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 90.0d + "'", double36 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 90.0d + "'", double47 == 90.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 90.0d + "'", double59 == 90.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 90.0d + "'", double61 == 90.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 44563605345380515L);
        org.apache.commons.math.exception.NotPositiveException notPositiveException4 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 52.000004f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.1665256197155E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(7.534856945352157E22d, 9.617269008937367E67d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver2.solve(0, univariateRealFunction4, 683.2777499636513d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.401298464324817E-45d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) (-3246034656128425375L), 1.4740973835777769d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.62301732806421274E18d) + "'", double2 == (-1.62301732806421274E18d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 55, 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1399733632);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.059547792608207d + "'", double1 == 21.059547792608207d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 970L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.431159436143842d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1250189307226326d + "'", double1 == 1.1250189307226326d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 583489548, 1.3440585709080678E43d, (double) (-6));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [13,440,585,709,080,678,000,000,000,000,000,000,000,000,000, -6]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3258176636680326d + "'", double1 == 1.3258176636680326d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray13 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray13);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, number6, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray13);
        int int17 = nonMonotonousSequenceException3.getIndex();
        boolean boolean18 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException3.getDirection();
        boolean boolean20 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.15986829E9f, (float) (byte) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 4, 0.0f, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 92.13617560368711d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 101L, 0.0f, (float) (-2022198591));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943298E-17d + "'", double1 == 1.7453292519943298E-17d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.7302353474567127d), (double) 6990832826496134385L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.9908328264961341E18d + "'", double2 == 6.9908328264961341E18d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 97.0f, 80.90737774354389d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.552533589821149E160d + "'", double2 == 5.552533589821149E160d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.9853888424555444d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        int int6 = regulaFalsiSolver5.getMaxEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double11 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, (double) (short) 10, 7.62939453125E-6d, (-1.0d), allowedSolution10);
        double double12 = regulaFalsiSolver5.getMax();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) (-583489541), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.83489541E8d + "'", double2 == 5.83489541E8d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-6));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -6");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0420382290916537E20d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(128.0f, 5, 179766209);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 179,766,209, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1399733632, 2.302585092994046d, (-0.24156447527049035d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.881784197001252E-16d, (java.lang.Number) (-0.7949577687638787d), (int) (short) 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        int int1 = org.apache.commons.math.util.FastMath.abs((-60));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 60 + "'", int1 == 60);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(32.010217508994515d, (-3.0d), 3.1525197391593472E17d, (double) 7920304393916482560L, 57.85123252868652d, 0.6190355139458464d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.496891594197222E36d + "'", double6 == 2.496891594197222E36d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (-0.8813735870195429d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.08106152637093929d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7852528378162065E9d + "'", double2 == 2.7852528378162065E9d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray27 = new double[] { 90.0d, 91.0d, (-1.0f), 10.0f };
        double[] doubleArray30 = new double[] { 100.0d, 1.0f };
        double[] doubleArray37 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray37);
        double[] doubleArray41 = new double[] { 100.0d, 1.0f };
        double[] doubleArray48 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection53, false);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 90.0d + "'", double38 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 90.0d + "'", double49 == 90.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 121.18168178400562d + "'", double51 == 121.18168178400562d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 91.0d + "'", double52 == 91.0d);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 179766209 + "'", int56 == 179766209);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1820, 61880);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-60060) + "'", int2 == (-60060));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6196090252241403d, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6196090252241404d + "'", double2 == 0.6196090252241404d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval(1.2404101770619356d, (-0.2736239505345667d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1.24, -0.274]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) 6.0f, 130.74358769182624d, 4.1594462250996d, (double) 64, 0.24514724760709253d, (double) 1399733555L, (double) (-1428210885), 1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-2.0747754094813678E9d) + "'", double8 == (-2.0747754094813678E9d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, 10);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 10.0f);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.00499987500625d + "'", double26 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.00499987500625d + "'", double27 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1399733633, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 35);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray7 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException8 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray7);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = notFiniteNumberException9.getContext();
        java.util.Set<java.lang.String> strSet11 = exceptionContext10.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(strSet11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.7949577687638787d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5483996938409497d) + "'", double1 == (-0.5483996938409497d));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        float float2 = org.apache.commons.math.util.MathUtils.round((-10.0f), 4092);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        double double1 = org.apache.commons.math.util.FastMath.asin(21.059547792608207d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException5 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (int) (byte) -1, 0);
        java.lang.String str6 = dimensionMismatchException5.toString();
        java.lang.Throwable[] throwableArray7 = dimensionMismatchException5.getSuppressed();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException8 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.020847887479787386d, (java.lang.Object[]) throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.DimensionMismatchException: cannot discard a negative number of elements (-1)" + "'", str6.equals("org.apache.commons.math.exception.DimensionMismatchException: cannot discard a negative number of elements (-1)"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        float[] floatArray9 = new float[] { 1, (short) -1, 10.0f, (byte) 100 };
        float[] floatArray10 = null;
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray9, floatArray10);
        org.apache.commons.math.exception.MathInternalError mathInternalError12 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Object[] objArray14 = new java.lang.Object[] { floatArray10, mathInternalError12, "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException15 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray14);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException16 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 35.000004f, objArray14);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-3.999999761581421d), objArray14);
        org.apache.commons.math.exception.NotPositiveException notPositiveException20 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4.349219637305466E55d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, 10);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray42 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException43 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats36, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray42);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException44 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, number35, objArray42);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException45 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException32, (org.apache.commons.math.exception.util.Localizable) localizedFormats33, objArray42);
        int int46 = nonMonotonousSequenceException32.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = nonMonotonousSequenceException32.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = nonMonotonousSequenceException32.getDirection();
        boolean boolean51 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection48, false, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.00499987500625d + "'", double26 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-0.47588040642452506d), (-0.7949577687638787d), (-1.5707963236601088d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 31.999998f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 61880);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray11 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray11);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray11);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 0, objArray11);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.6881171418161356E43d, objArray11);
        java.lang.Number number16 = maxCountExceededException15.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2.6881171418161356E43d + "'", number16.equals(2.6881171418161356E43d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 21.059547792608207d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(900000.1371738866d, (double) 4, (-6.0d), 152.83185307179588d, 9000.001371738867d, 45.054566736396445d, (double) (-1428210873L), 595069.1624655712d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-8.498842440157575E14d) + "'", double8 == (-8.498842440157575E14d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        double[] doubleArray3 = new double[] { 100.0d, 1.0f };
        double[] doubleArray10 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException15.getDirection();
        double[] doubleArray23 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray30 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray37 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray44 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[][] doubleArray45 = new double[][] { doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, orderDirection16, doubleArray45);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) doubleArray45);
        java.lang.Class<?> wildcardClass48 = mathArithmeticException47.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(wildcardClass48);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 9.0d, (java.lang.Number) 6.283185307179586d, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.1920928955078128E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078128E-7d + "'", double1 == 1.1920928955078128E-7d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        int int4 = regulaFalsiSolver3.getMaxEvaluations();
        int int5 = regulaFalsiSolver3.getEvaluations();
        int int6 = regulaFalsiSolver3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 4.611079E31f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.047851163762139E29d + "'", double1 == 8.047851163762139E29d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.43115943614384195d, (java.lang.Number) 0.8464846872172499d, (-1023));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        double double1 = org.apache.commons.math.util.FastMath.abs(620845.5240300631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 620845.5240300631d + "'", double1 == 620845.5240300631d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 5.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.1594462250996d, 2.2250738585072014E-308d, 80.90737774354389d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        int int5 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.15144249379213048d, 0.0d);
        double double3 = regulaFalsiSolver2.getMax();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (short) 100, (double) 582);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        java.lang.Number number3 = maxCountExceededException1.getMax();
        java.lang.Number number4 = maxCountExceededException1.getMax();
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (byte) 0 + "'", number3.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 0 + "'", number4.equals((byte) 0));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        double[] doubleArray4 = new double[] { 100.0d, 1.0f };
        double[] doubleArray11 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException16.getDirection();
        double[] doubleArray24 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray31 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray38 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray45 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[][] doubleArray46 = new double[][] { doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, orderDirection17, doubleArray46);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException48 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.0d), (java.lang.Object[]) doubleArray46);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.3941359693811154E9d, (java.lang.Number) 0.8342233605065102d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(529620);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 11845.8278489549d, (java.lang.Number) 5.5663706143591725d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 207.8696877777818d);
        java.lang.Class<?> wildcardClass2 = maxCountExceededException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1780538303479458d + "'", double1 == 3.1780538303479458d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray14 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray14);
        org.apache.commons.math.exception.NoBracketingException noBracketingException17 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, 0.431159436143842d, 11846.669319939707d, 0.811048585625462d, 36.07140440247247d, objArray14);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException18 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray14);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException19 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.3362938564082754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.528493983111571d + "'", double1 == 1.528493983111571d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "empty selected row index array" + "'", str1.equals("empty selected row index array"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 60);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 6442450941L, 0.0f, 4.611079E31f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(100L, (long) 319000847);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31900084700L + "'", long2 == 31900084700L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 96L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 110.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.960486013832335E47d + "'", double1 == 2.960486013832335E47d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 319000847);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 319000847L + "'", long1 == 319000847L);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 7.629395E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.629395440670686E-6d + "'", double1 == 7.629395440670686E-6d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.6170319610900021d), number2, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 2147483647);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 4.499809670330265d, (double) 1399733633L, (double) 35, 1399733537);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) (-1428210827L), (float) (-449079295));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 582);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 2147483647, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 319000847, (-3246034656128425375L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getCount();
        incrementor0.incrementCount();
        incrementor0.setMaximalCount((int) (byte) 1);
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (1) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.0f), (float) (-44563605345380415L), (float) 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray25 = new double[] { 100.0d, 1.0f };
        double[] doubleArray32 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double[] doubleArray36 = new double[] { 100.0d, 1.0f };
        double[] doubleArray43 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray43);
        double[] doubleArray48 = new double[] { 100.0d, 1.0f };
        double[] doubleArray55 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray55);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray55);
        double[] doubleArray60 = null;
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray60);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 90.0d + "'", double44 == 90.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 91.0d + "'", double58 == 91.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(820240826, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(1.7145508592643157d, (double) 1399733633L, (double) 60);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 101.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        double[] doubleArray22 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray29 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray36 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray43 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[][] doubleArray44 = new double[][] { doubleArray22, doubleArray29, doubleArray36, doubleArray43 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray9, orderDirection15, doubleArray44);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray9);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0420382290916537E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.81869980293003187E18d + "'", double1 == 1.81869980293003187E18d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.1102230246251565E-16d, (double) 6L, 152.83185307179588d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-60));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        java.lang.Object obj0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray12 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray12);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 0, objArray12);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 2.6881171418161356E43d, objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        float[] floatArray25 = new float[] { 1, (short) -1, 10.0f, (byte) 100 };
        float[] floatArray26 = null;
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray25, floatArray26);
        org.apache.commons.math.exception.MathInternalError mathInternalError28 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Object[] objArray30 = new java.lang.Object[] { floatArray26, mathInternalError28, "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException31 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray30);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) 35.000004f, objArray30);
        java.lang.Object[] objArray33 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray30);
        java.lang.Class<?> wildcardClass34 = objArray33.getClass();
        org.apache.commons.math.exception.NullArgumentException nullArgumentException35 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray33);
        try {
            org.apache.commons.math.util.MathUtils.checkNotNull(obj0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function is not polynomial");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 10L, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2005.3522829578812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 100, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) (short) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 4092);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 100L);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) (short) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 4092);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        org.apache.commons.math.exception.NotPositiveException notPositiveException14 = new org.apache.commons.math.exception.NotPositiveException(localizable0, (java.lang.Number) bigInteger13);
        try {
            java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (-449079295));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-449,079,295)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        double double1 = org.apache.commons.math.util.FastMath.cos(57.85123252868652d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2650266521152759d + "'", double1 == 0.2650266521152759d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        double double1 = org.apache.commons.math.util.FastMath.tanh(57.85123252868652d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 4092);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 96);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1399733537);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray10 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, 0);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, (int) (byte) 100);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray10);
        java.lang.Class<?> wildcardClass17 = intArray5.getClass();
        int[] intArray21 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray21, 0);
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray23);
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray25);
        int[] intArray30 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray32 = org.apache.commons.math.util.MathUtils.copyOf(intArray30, 0);
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray32);
        int[] intArray37 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray39 = org.apache.commons.math.util.MathUtils.copyOf(intArray37, 0);
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray39);
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray39);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray39);
        int[] intArray43 = org.apache.commons.math.util.MathUtils.copyOf(intArray33);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray33);
        int[] intArray48 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray50 = org.apache.commons.math.util.MathUtils.copyOf(intArray48, 0);
        int[] intArray51 = org.apache.commons.math.util.MathUtils.copyOf(intArray50);
        int[] intArray55 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray57 = org.apache.commons.math.util.MathUtils.copyOf(intArray55, 0);
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray55);
        int[] intArray60 = org.apache.commons.math.util.MathUtils.copyOf(intArray55, (int) (byte) 100);
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray55);
        int[] intArray62 = org.apache.commons.math.util.MathUtils.copyOf(intArray55);
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray62);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1), (long) 342559971);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 342559971L + "'", long2 == 342559971L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.934949401062422d, (-0.020847887479787386d));
        double double3 = regulaFalsiSolver2.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.020847887479787386d) + "'", double4 == (-0.020847887479787386d));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 110.0f, 10.0d, 90.00555538409837d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [110, 10]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        double double2 = org.apache.commons.math.util.FastMath.atan2(7.173481126156159d, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.13708631668078652d + "'", double2 == 0.13708631668078652d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(74.20321057778875d, (-2.492698225135234E7d), (-6));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        double double6 = regulaFalsiSolver5.getStartValue();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double11 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 0.0d, 121.18168178400562d, (double) 7.6293945E-6f, allowedSolution10);
        int int12 = regulaFalsiSolver5.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9998151400298467d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9344065786069821d + "'", double1 == 0.9344065786069821d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-1.5707882345343058d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((-1.40000682809523728E17d), 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(3.8146972655139773E-6d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math.exception.NotPositiveException notPositiveException4 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.1780538303479458d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "first element is not 0: {0}" + "'", str1.equals("first element is not 0: {0}"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        double[] doubleArray4 = new double[] { 100.0d, 1.0f };
        double[] doubleArray11 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray11);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException16.getDirection();
        double[] doubleArray24 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray31 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray38 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray45 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[][] doubleArray46 = new double[][] { doubleArray24, doubleArray31, doubleArray38, doubleArray45 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, orderDirection17, doubleArray46);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException48 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.0d), (java.lang.Object[]) doubleArray46);
        java.lang.Number number49 = maxCountExceededException48.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 90.0d + "'", double12 == 90.0d);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + (-0.0d) + "'", number49.equals((-0.0d)));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction2 = null;
        try {
            double double5 = regulaFalsiSolver0.solve((int) ' ', univariateRealFunction2, 3.8146972655139773E-6d, (-0.9992790497916413d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.46842437619265676d, (double) 101L, (double) 10L);
        int int4 = regulaFalsiSolver3.getEvaluations();
        double double5 = regulaFalsiSolver3.getAbsoluteAccuracy();
        double double6 = regulaFalsiSolver3.getMin();
        double double7 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 101.0d + "'", double5 == 101.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-3.9999998f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-2022198591), 9.999999999996666E-7d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.0221984E9f) + "'", float2 == (-2.0221984E9f));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        long long1 = org.apache.commons.math.util.MathUtils.sign(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 0.99999994f, 4092.0d, (-2022198591));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, 10);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) (-319000757L));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.00499987500625d + "'", double26 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        int int4 = regulaFalsiSolver3.getMaxEvaluations();
        int int5 = regulaFalsiSolver3.getEvaluations();
        double double6 = regulaFalsiSolver3.getMax();
        double double7 = regulaFalsiSolver3.getRelativeAccuracy();
        double double8 = regulaFalsiSolver3.getAbsoluteAccuracy();
        java.lang.Class<?> wildcardClass9 = regulaFalsiSolver3.getClass();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        long long1 = org.apache.commons.math.util.FastMath.round(0.7455721187088916d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.46842437619265676d, (double) 101L, (double) 10L);
        double double4 = regulaFalsiSolver3.getAbsoluteAccuracy();
        int int5 = regulaFalsiSolver3.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        try {
            double double10 = regulaFalsiSolver3.solve(60, univariateRealFunction7, 4092.0d, 121.18168178400562d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 101.0d + "'", double4 == 101.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-533536015), 1399733537);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,399,733,537, n = -533,536,015");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1067072030, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1067072030 + "'", int2 == 1067072030);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        double double1 = org.apache.commons.math.util.FastMath.cos((-47.2479191611438d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9923182144324295d) + "'", double1 == (-0.9923182144324295d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        float[] floatArray0 = null;
        float[] floatArray4 = new float[] { 0L, '4', 10 };
        float[] floatArray6 = new float[] { 7.6293945E-6f };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray6);
        float[] floatArray8 = new float[] {};
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray8);
        float[] floatArray13 = new float[] { 0L, '4', 10 };
        float[] floatArray15 = new float[] { 7.6293945E-6f };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray13, floatArray15);
        float[] floatArray17 = new float[] {};
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray13, floatArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(floatArray8, floatArray17);
        float[] floatArray26 = new float[] { 10.0f, 35.000004f, (byte) 10, (-4.4563601E16f), (-1), (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray8, floatArray26);
        float[] floatArray31 = new float[] { 0L, '4', 10 };
        float[] floatArray33 = new float[] { 7.6293945E-6f };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray31, floatArray33);
        float[] floatArray38 = new float[] { (-1L), (-1), Float.POSITIVE_INFINITY };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(floatArray33, floatArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray26, floatArray33);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray26);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 32.000004f, (java.lang.Number) 7.629395440744702E-6d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32.000004f + "'", number4.equals(32.000004f));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) -1, (int) (short) 10);
        int int3 = dimensionMismatchException2.getDimension();
        int int4 = dimensionMismatchException2.getDimension();
        int int5 = dimensionMismatchException2.getDimension();
        int int6 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.1594462250996d, 2.2250738585072014E-308d, 80.90737774354389d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = null;
        try {
            double double11 = regulaFalsiSolver3.solve((-127), univariateRealFunction6, (-0.061086523819801536d), 1.570796207585607d, (-1.5707963220765706d), allowedSolution10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        int int2 = org.apache.commons.math.util.FastMath.min(35, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        float[] floatArray11 = new float[] { 1, (short) -1, 10.0f, (byte) 100 };
        float[] floatArray12 = null;
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray12);
        org.apache.commons.math.exception.MathInternalError mathInternalError14 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Object[] objArray16 = new java.lang.Object[] { floatArray12, mathInternalError14, "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException17 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray16);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) 35.000004f, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray27 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException28 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray27);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException30 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray27);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray27);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray39 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException40 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray39);
        double double41 = noBracketingException40.getLo();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext42 = noBracketingException40.getContext();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        float[] floatArray51 = new float[] { 1, (short) -1, 10.0f, (byte) 100 };
        float[] floatArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray51, floatArray52);
        org.apache.commons.math.exception.MathInternalError mathInternalError54 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Object[] objArray56 = new java.lang.Object[] { floatArray52, mathInternalError54, "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException57 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats46, objArray56);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException58 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, (java.lang.Number) 35.000004f, objArray56);
        exceptionContext42.addMessage(localizable43, objArray56);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray69 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException70 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats63, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray69);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException71 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats61, number62, objArray69);
        java.lang.Class<?> wildcardClass72 = objArray69.getClass();
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) objArray56, localizable60, objArray69);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException74 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 0.99999994f, objArray69);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException75 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray69);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) "first element is not 0: {0}", (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray69);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(exceptionContext42);
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats61.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats63.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(wildcardClass72);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.46842437619265676d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 9.617269008937367E67d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) ' ', 1.1752011936438014d, (double) 35.000004f, 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 37.606438196601644d + "'", double4 == 37.606438196601644d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-127), 583489548);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(49.0d, (double) 1428210816, 0.0d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        float float2 = org.apache.commons.math.util.FastMath.copySign(582.00006f, 1.15986829E9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 582.00006f + "'", float2 == 582.00006f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 1614905344);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.61490547E9f + "'", float1 == 1.61490547E9f);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 100, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError(throwable0);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = mathInternalError1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray10 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0, objArray10);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, objArray10);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = mathArithmeticException14.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext16 = mathArithmeticException14.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertNotNull(exceptionContext16);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction> univariateRealFunctionBracketedUnivariateRealSolver2 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = null;
        try {
            double double7 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(100, univariateRealFunction1, univariateRealFunctionBracketedUnivariateRealSolver2, 0.579800154212869d, (-0.999329299739067d), 0.0d, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.5483996938409497d), (java.lang.Number) (-4.9E-324d), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, 0.0d, (double) 100L, (double) (-1428210985L));
        double double5 = noBracketingException4.getFLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        org.apache.commons.math.util.MathUtils.checkFinite(1.7453292519943298E-17d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        double double2 = org.apache.commons.math.util.FastMath.scalb(4.349219637305466E55d, 583489548);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray14 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException15 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray14);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, number7, objArray14);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        float[] floatArray26 = new float[] { 1, (short) -1, 10.0f, (byte) 100 };
        float[] floatArray27 = null;
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray26, floatArray27);
        org.apache.commons.math.exception.MathInternalError mathInternalError29 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Object[] objArray31 = new java.lang.Object[] { floatArray27, mathInternalError29, "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException32 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray31);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException33 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, (java.lang.Number) 35.000004f, objArray31);
        java.lang.Object[] objArray34 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray31);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException36 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray31);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException37 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray31);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1784L), (long) (-127));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) (-1L), false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray11 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException12 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray11);
        double double13 = noBracketingException12.getLo();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) noBracketingException12);
        double double15 = noBracketingException12.getLo();
        java.lang.String str16 = noBracketingException12.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1L) + "'", number4.equals((-1L)));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: array sums to zero" + "'", str16.equals("org.apache.commons.math.exception.NoBracketingException: array sums to zero"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray25 = new double[] { 100.0d, 1.0f };
        double[] doubleArray32 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double[] doubleArray36 = new double[] { 100.0d, 1.0f };
        double[] doubleArray43 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray43);
        double[] doubleArray48 = new double[] { 100.0d, 1.0f };
        double[] doubleArray55 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray55);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 90.0d + "'", double44 == 90.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 91.0d + "'", double58 == 91.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 179766209 + "'", int59 == 179766209);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 179766209 + "'", int60 == 179766209);
        org.junit.Assert.assertNotNull(doubleArray62);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.24156447527049035d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.39973363E9f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 30 + "'", int1 == 30);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0f, 1.61490547E9f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        float[] floatArray8 = new float[] { 1, (short) -1, 10.0f, (byte) 100 };
        float[] floatArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray8, floatArray9);
        org.apache.commons.math.exception.MathInternalError mathInternalError11 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Object[] objArray13 = new java.lang.Object[] { floatArray9, mathInternalError11, "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException14 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 35.000004f, objArray13);
        java.lang.Object[] objArray16 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray13);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext18 = mathIllegalArgumentException17.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(exceptionContext18);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 7920304393916482560L);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        int int2 = org.apache.commons.math.util.MathUtils.pow(30, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10.0f, (java.lang.Number) 1.4210854715202004E-14d, (int) (byte) 100);
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray6 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray6);
        double double8 = noBracketingException7.getHi();
        double double9 = noBracketingException7.getFHi();
        double double10 = noBracketingException7.getFHi();
        double double11 = noBracketingException7.getFHi();
        double double12 = noBracketingException7.getFLo();
        double double13 = noBracketingException7.getFLo();
        double double14 = noBracketingException7.getHi();
        org.apache.commons.math.exception.MathInternalError mathInternalError15 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException7);
        double double16 = noBracketingException7.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { 100.0d, 1.0f };
        double[] doubleArray32 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1399733633, 1399733633L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1959254243351378689L + "'", long2 == 1959254243351378689L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        double[] doubleArray3 = new double[] { 100.0d, 1.0f };
        double[] doubleArray10 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException15.getDirection();
        double[] doubleArray23 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray30 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray37 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[] doubleArray44 = new double[] { 363.7393755555636d, (short) -1, 100L, (byte) 10, 90L, 10L };
        double[][] doubleArray45 = new double[][] { doubleArray23, doubleArray30, doubleArray37, doubleArray44 };
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray10, orderDirection16, doubleArray45);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException47 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) doubleArray45);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext48 = mathArithmeticException47.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext49 = mathArithmeticException47.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 90.0d + "'", double11 == 90.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(exceptionContext48);
        org.junit.Assert.assertNotNull(exceptionContext49);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray27 = new double[] { 90.0d, 91.0d, (-1.0f), 10.0f };
        double[] doubleArray30 = new double[] { 100.0d, 1.0f };
        double[] doubleArray37 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray37);
        double[] doubleArray41 = new double[] { 100.0d, 1.0f };
        double[] doubleArray48 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray48);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray48);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 10001.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 90.0d + "'", double38 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 90.0d + "'", double49 == 90.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 121.18168178400562d + "'", double51 == 121.18168178400562d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 91.0d + "'", double52 == 91.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.154434690031884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 35L, (double) (-319000853));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.999996f + "'", float2 == 34.999996f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.5514266812416906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009624211171012755d + "'", double1 == 0.009624211171012755d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray10 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, 0);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray12);
        int[] intArray19 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, 0);
        int[] intArray22 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int[] intArray26 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray26, 0);
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray26, (int) (byte) 100);
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray26);
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray21);
        int[] intArray34 = org.apache.commons.math.util.MathUtils.copyOf(intArray33);
        int int35 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray33);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) 2000.0d, true);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        org.apache.commons.math.exception.MathInternalError mathInternalError6 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean7 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 0.3796077390275217d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.4563605345380512E16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.64898031946962d + "'", double1 == 16.64898031946962d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 545807343345L, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570796326736268d + "'", double2 == 1.570796326736268d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) (byte) -1, (double) 2147483647, 3.1525197391593472E17d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0.5f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5235987755982989d + "'", double1 == 0.5235987755982989d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        double double2 = regulaFalsiSolver0.getMin();
        double double3 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(1.3197768247158532d, 10.072949219349693d, (double) 90.0f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        float float2 = org.apache.commons.math.util.FastMath.min((-4.4563601E16f), 9.2233715E18f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.4563601E16f) + "'", float2 == (-4.4563601E16f));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        long long2 = org.apache.commons.math.util.FastMath.min((-1428210873L), 98L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1428210873L) + "'", long2 == (-1428210873L));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        int int2 = org.apache.commons.math.util.FastMath.max(32, 2147483647);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.9999999403953552d), 13.71015130583219d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.07280971657113483d) + "'", double2 == (-0.07280971657113483d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5309649148733837d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 5.33691138229916d);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 97);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        double double1 = org.apache.commons.math.util.FastMath.abs(11013.23292010332d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.23292010332d + "'", double1 == 11013.23292010332d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-9223372034707292160L), 1.4210854715202105E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4210854715202105E-14d + "'", double2 == 1.4210854715202105E-14d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(96L, (-1023));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,023)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1159868416, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1159868316 + "'", int2 == 1159868316);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray8 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, objArray8);
        java.lang.Number number11 = maxCountExceededException10.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = maxCountExceededException10.getContext();
        java.lang.Class<?> wildcardClass13 = exceptionContext12.getClass();
        org.apache.commons.math.util.Incrementor incrementor15 = new org.apache.commons.math.util.Incrementor();
        incrementor15.setMaximalCount((int) (byte) 10);
        int int18 = incrementor15.getCount();
        incrementor15.setMaximalCount((-6));
        exceptionContext12.setValue("{0} != {1}", (java.lang.Object) (-6));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.4121184852417566d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41211848524175665d + "'", double1 == 0.41211848524175665d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(35.00000000000001d, (double) (byte) 100, (-2.492698225135234E7d), 81.62268552636596d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-2.0346037334234376E9d) + "'", double4 == (-2.0346037334234376E9d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-6L), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-10.0f) + "'", float2 == (-10.0f));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.1594462250996d, 2.2250738585072014E-308d, 80.90737774354389d);
        int int4 = regulaFalsiSolver3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 820240826, 0.008726646259971648d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.2310036088298982d) + "'", double2 == (-0.2310036088298982d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.934949401062422d, (-0.020847887479787386d));
        int int3 = regulaFalsiSolver2.getEvaluations();
        double double4 = regulaFalsiSolver2.getStartValue();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 6990832826496134385L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 426941776 + "'", int1 == 426941776);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 110L, 0.539040909144553d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 109.99999f + "'", float2 == 109.99999f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(44.0d, (double) 1067072030);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.00000000000001d + "'", double2 == 44.00000000000001d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double double1 = org.apache.commons.math.util.FastMath.floor(8.047851163762139E29d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.047851163762139E29d + "'", double1 == 8.047851163762139E29d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1159868316, (java.lang.Number) 0.43115943614384195d, false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(32.010217508994515d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5586836898114919d + "'", double1 == 0.5586836898114919d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.8446744073709552E19d, (double) 1.15986829E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8446744073709552E19d + "'", double2 == 1.8446744073709552E19d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.111507638930571E-61d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.776263578034403E-21d + "'", double1 == 6.776263578034403E-21d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        org.apache.commons.math.exception.MathInternalError mathInternalError1 = new org.apache.commons.math.exception.MathInternalError();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) (byte) -1, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray15 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray15);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException17 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray15);
        float[] floatArray21 = new float[] { 0L, '4', 10 };
        float[] floatArray23 = new float[] { 7.6293945E-6f };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray21, floatArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        java.lang.Object[] objArray28 = new java.lang.Object[] { notFiniteNumberException17, floatArray21, true, localizedFormats26, (-1L) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray28);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException30 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray39 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException40 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats33, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray39);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException41 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray39);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException42 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray39);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathInternalError1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray39);
        java.lang.Object[] objArray44 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray39);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException45 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.0000000000017797d, objArray39);
        org.apache.commons.math.exception.MathInternalError mathInternalError46 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notFiniteNumberException45);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats33.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1023);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        long long2 = org.apache.commons.math.util.FastMath.min(35L, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-9223372034707292160L), (double) 342559971L, (double) 35.000004f, 7.507141079727608d, (double) 32, 4.686762280773451d, 0.3941298715767986d, (double) (-1768L));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-3.159558056731541E27d) + "'", double8 == (-3.159558056731541E27d));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.560895660206908d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9403570645705135d + "'", double1 == 0.9403570645705135d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 194L, 179766209);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 6.0f, (double) 90.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray8 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        java.lang.Object[] objArray12 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        boolean boolean7 = nonMonotonousSequenceException6.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.505149978319906d, (java.lang.Number) 6.0f, 319000847, orderDirection8, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1614905344, 545807343345L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 35.000004f, (int) (byte) 0, orderDirection13, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.528752E7d, number4, 0, orderDirection13, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4740973835777769d, (java.lang.Number) (-1428210985L), 5, orderDirection13, false);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) (-1428210985L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1428210816L, (double) 32.000004f, (double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((-1.42821082E9f), (-201.71315737027922d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.42821069E9f) + "'", float2 == (-1.42821069E9f));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 4092);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 96);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 96);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) -1, (-3246034656128425375L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.629423635154472E-6d + "'", double1 == 7.629423635154472E-6d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -127");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 4092);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 100L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) (short) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 4092);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 100L);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (short) 0);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 4092);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger18);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 1159868416);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.960486013832335E47d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        long long2 = org.apache.commons.math.util.FastMath.max((-16L), (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) 61879.996f, true);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 61879.996f + "'", number5.equals(61879.996f));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 61879.996f + "'", number7.equals(61879.996f));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        int int2 = org.apache.commons.math.util.FastMath.min(52, (-60));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-60) + "'", int2 == (-60));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) (byte) -1, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray15 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray15);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException17 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray15);
        float[] floatArray21 = new float[] { 0L, '4', 10 };
        float[] floatArray23 = new float[] { 7.6293945E-6f };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray21, floatArray23);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        java.lang.Object[] objArray28 = new java.lang.Object[] { notFiniteNumberException17, floatArray21, true, localizedFormats26, (-1L) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.528493983111571d, (java.lang.Number) (-1428210979L), 52, orderDirection30, false);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 4092);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 96);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray15 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException16 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray15);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray15);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException19 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.4E-45f, objArray15);
        java.lang.Object[] objArray20 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray15);
        org.apache.commons.math.exception.NoBracketingException noBracketingException21 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, Double.NaN, 207.8696877777818d, 0.15144249379213048d, 2000.0d, objArray15);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException22 = new org.apache.commons.math.exception.NullArgumentException(localizable0, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        org.apache.commons.math.util.MathUtils.checkFinite(11843.80430403352d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1), (double) 1820L);
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        double double4 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((int) '4', univariateRealFunction6, 8.047851163762139E29d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1820.0d + "'", double4 == 1820.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray8 = null;
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray10 = org.apache.commons.math.util.MathUtils.copyOf(intArray7);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getMax();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.3754357009738063d, (java.lang.Number) 32.0f, 1399733632, orderDirection7, true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0E180d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        double double1 = org.apache.commons.math.util.FastMath.log(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        org.apache.commons.math.util.MathUtils.checkFinite(36.07140440247247d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(0.0d, 0.0d, (double) 100L, (double) (-1428210985L));
        double double5 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 35L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0E-14d);
        double double2 = regulaFalsiSolver1.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver1.solve((int) '4', univariateRealFunction4, (double) 6L, (-0.5483996938409497d), 2.960486013832335E47d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0993669172120534E25d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double6 = regulaFalsiSolver1.solve(1428210816, univariateRealFunction3, (double) (-319000864L), 15.104412573075516d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-201.71315737027922d), 1.8159743494233516E19d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1107709612436523E-17d) + "'", double2 == (-1.1107709612436523E-17d));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray10 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0, objArray10);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.4210854715202004E-14d, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray24 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray24);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray24);
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException28 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notFiniteNumberException14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BETA + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray10 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException11 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray10);
        double double12 = noBracketingException11.getLo();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = noBracketingException11.getContext();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        float[] floatArray22 = new float[] { 1, (short) -1, 10.0f, (byte) 100 };
        float[] floatArray23 = null;
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray22, floatArray23);
        org.apache.commons.math.exception.MathInternalError mathInternalError25 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Object[] objArray27 = new java.lang.Object[] { floatArray23, mathInternalError25, "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException28 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 35.000004f, objArray27);
        exceptionContext13.addMessage(localizable14, objArray27);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) notStrictlyPositiveException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray8 = null;
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray8);
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray7, 1023);
        int[] intArray15 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray15, 0);
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        int[] intArray20 = org.apache.commons.math.util.MathUtils.copyOf(intArray19);
        int[] intArray24 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray24, 0);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray26);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray19);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.008726646259971648d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray6 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray6);
        double double8 = noBracketingException7.getFLo();
        double double9 = noBracketingException7.getFLo();
        double double10 = noBracketingException7.getLo();
        double double11 = noBracketingException7.getHi();
        double double12 = noBracketingException7.getHi();
        double double13 = noBracketingException7.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 10, (java.lang.Number) (-1L), false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException9 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (int) (byte) -1, 0);
        java.lang.String str10 = dimensionMismatchException9.toString();
        java.lang.Throwable[] throwableArray11 = dimensionMismatchException9.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray11);
        java.lang.Number number13 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1L) + "'", number4.equals((-1L)));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.DimensionMismatchException: cannot discard a negative number of elements (-1)" + "'", str10.equals("org.apache.commons.math.exception.DimensionMismatchException: cannot discard a negative number of elements (-1)"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1L) + "'", number13.equals((-1L)));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-9201178186352538207L), (double) (-1.42821082E9f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.2011781863525386E18d) + "'", double2 == (-9.2011781863525386E18d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray13 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException14 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray13);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException15 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, number6, objArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray13);
        int int17 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        int int4 = regulaFalsiSolver3.getMaxEvaluations();
        int int5 = regulaFalsiSolver3.getEvaluations();
        double double6 = regulaFalsiSolver3.getMax();
        double double7 = regulaFalsiSolver3.getRelativeAccuracy();
        double double8 = regulaFalsiSolver3.getAbsoluteAccuracy();
        double double9 = regulaFalsiSolver3.getFunctionValueAccuracy();
        int int10 = regulaFalsiSolver3.getMaxEvaluations();
        double double11 = regulaFalsiSolver3.getStartValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 90.0d + "'", double7 == 90.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getCount();
        int int4 = incrementor0.getMaximalCount();
        int int5 = incrementor0.getCount();
        int int6 = incrementor0.getMaximalCount();
        incrementor0.incrementCount();
        try {
            incrementor0.incrementCount((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (10) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} points are required, got only {1}" + "'", str1.equals("{0} points are required, got only {1}"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0993669172120534E25d);
        double double2 = regulaFalsiSolver1.getStartValue();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.19000847E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.19000847E8d + "'", double1 == 3.19000847E8d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 52);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2.915768896081299E7d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.4121184852417566d, 0.5586836898114919d, 1.8159743494233516E19d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getCount();
        incrementor0.setMaximalCount((-6));
        incrementor0.incrementCount((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getMaximalCount();
        int int4 = incrementor0.getCount();
        try {
            incrementor0.incrementCount((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (10) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray10 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, 0);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12);
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray12);
        try {
            int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray12, (-1023));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) (byte) -1, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray12 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException13 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray12);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray12);
        float[] floatArray18 = new float[] { 0L, '4', 10 };
        float[] floatArray20 = new float[] { 7.6293945E-6f };
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray18, floatArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        java.lang.Object[] objArray25 = new java.lang.Object[] { notFiniteNumberException14, floatArray18, true, localizedFormats23, (-1L) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException3, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NaN, (java.lang.Number) (byte) -1, (int) (short) 0);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray40 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException41 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats34, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray40);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException42 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray40);
        float[] floatArray46 = new float[] { 0L, '4', 10 };
        float[] floatArray48 = new float[] { 7.6293945E-6f };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray46, floatArray48);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        java.lang.Object[] objArray53 = new java.lang.Object[] { notFiniteNumberException42, floatArray46, true, localizedFormats51, (-1L) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException54 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException31, (org.apache.commons.math.exception.util.Localizable) localizedFormats32, objArray53);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException55 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray53);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray65 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException66 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats59, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray65);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException67 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats58, objArray65);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException68 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats57, objArray65);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException69 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.4E-45f, objArray65);
        java.lang.Object[] objArray70 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray65);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) mathIllegalStateException26, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray70);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats51.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats59.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray70);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, (double) 96.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        java.lang.String str2 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RandomKeyMutation works only with RandomKeys, not {0}" + "'", str2.equals("RandomKeyMutation works only with RandomKeys, not {0}"));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        float[] floatArray3 = new float[] { 0L, '4', 10 };
        float[] floatArray5 = new float[] { 7.6293945E-6f };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray3, floatArray5);
        float[] floatArray10 = new float[] { 0L, '4', 10 };
        float[] floatArray12 = new float[] { 7.6293945E-6f };
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray10, floatArray12);
        float[] floatArray14 = new float[] {};
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray10, floatArray14);
        float[] floatArray19 = new float[] { 0L, '4', 10 };
        float[] floatArray21 = new float[] { 7.6293945E-6f };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray19, floatArray21);
        float[] floatArray23 = new float[] {};
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray19, floatArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(floatArray14, floatArray23);
        float[] floatArray29 = new float[] { 0L, '4', 10 };
        float[] floatArray31 = new float[] { 7.6293945E-6f };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray29, floatArray31);
        float[] floatArray39 = new float[] { 52, 10, 1399733633, 44563605345380515L, 0, ' ' };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray31, floatArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray23, floatArray31);
        float[] floatArray45 = new float[] { 0L, '4', 10 };
        float[] floatArray47 = new float[] { 7.6293945E-6f };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray45, floatArray47);
        float[] floatArray52 = new float[] { (-1L), (-1), Float.POSITIVE_INFINITY };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(floatArray47, floatArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(floatArray31, floatArray52);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray5, floatArray31);
        float[] floatArray59 = new float[] { 0L, '4', 10 };
        float[] floatArray61 = new float[] { 7.6293945E-6f };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray59, floatArray61);
        float[] floatArray63 = new float[] {};
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray59, floatArray63);
        float[] floatArray68 = new float[] { 0L, '4', 10 };
        float[] floatArray70 = new float[] { 7.6293945E-6f };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray68, floatArray70);
        float[] floatArray72 = new float[] {};
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray68, floatArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(floatArray63, floatArray72);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray5, floatArray72);
        float[] floatArray79 = new float[] { 0L, '4', 10 };
        float[] floatArray81 = new float[] { 7.6293945E-6f };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray79, floatArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray72, floatArray79);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(floatArray59);
        org.junit.Assert.assertNotNull(floatArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(floatArray68);
        org.junit.Assert.assertNotNull(floatArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(floatArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertNotNull(floatArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 529620, 6442450941L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6442450941L + "'", long2 == 6442450941L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1.4E-45f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray8 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException9 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray8);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException10 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext11 = maxCountExceededException10.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(7.6293945E-6f, (double) 90L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.629395E-6f + "'", float2 == 7.629395E-6f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        float[] floatArray0 = null;
        float[] floatArray2 = new float[] { ' ' };
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray2);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 179766209, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.79766208E8f + "'", float2 == 1.79766208E8f);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(529620);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6450734.1162167005d + "'", double1 == 6450734.1162167005d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray6 = org.apache.commons.math.util.MathUtils.copyOf(intArray5);
        int[] intArray10 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray12 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, 0);
        int[] intArray13 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        int[] intArray15 = org.apache.commons.math.util.MathUtils.copyOf(intArray10, (int) (byte) 100);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray10);
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray10);
        int[] intArray18 = org.apache.commons.math.util.MathUtils.copyOf(intArray17);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.NoBracketingException noBracketingException6 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 100, (double) 100.0f, 1.0d, 0.0d, objArray5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = noBracketingException6.getContext();
        java.lang.Object obj9 = exceptionContext7.getValue("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,399,733,632 and 1,399,733,633 are not decreasing (0 < 21.773)");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 583489548, (long) (-533536015));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 49953533L + "'", long2 == 49953533L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray6 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray6);
        double double8 = noBracketingException7.getLo();
        double double9 = noBracketingException7.getHi();
        double double10 = noBracketingException7.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 1.513955751696327d, (double) 582, (-2.492698225135234E7d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.4507503670287062E10d) + "'", double4 == (-1.4507503670287062E10d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 32);
        int[] intArray8 = null;
        try {
            int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(4.12389349773832E54d, (double) (byte) -1, (double) (-1.4E-45f));
        double double6 = regulaFalsiSolver5.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver15 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        int int16 = regulaFalsiSolver15.getMaxEvaluations();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution20 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double21 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction11, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver15, (double) (short) 10, 7.62939453125E-6d, (-1.0d), allowedSolution20);
        double double22 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) '4', univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, 0.7853981633974484d, (double) 529620, 6.691673596021348E41d, allowedSolution20);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.401298464324817E-45d) + "'", double6 == (-1.401298464324817E-45d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + allowedSolution20 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution20.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7853981633974484d + "'", double22 == 0.7853981633974484d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(11013.23292010332d, 1.401298464324817E-45d, 2.7522203923062136d, 15.104412573075516d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 41.5706722974248d + "'", double4 == 41.5706722974248d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1), 31900084700L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31900084700L + "'", long2 == 31900084700L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getCount();
        incrementor0.incrementCount();
        incrementor0.setMaximalCount((int) (byte) 1);
        int int7 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1399733633);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.399733633E9d + "'", double1 == 1.399733633E9d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-0.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, (-319000757L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-319,000,757)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.9998151400298467d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        float[] floatArray8 = new float[] { 1, (short) -1, 10.0f, (byte) 100 };
        float[] floatArray9 = null;
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray8, floatArray9);
        org.apache.commons.math.exception.MathInternalError mathInternalError11 = new org.apache.commons.math.exception.MathInternalError();
        java.lang.Object[] objArray13 = new java.lang.Object[] { floatArray9, mathInternalError11, "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" };
        org.apache.commons.math.exception.NullArgumentException nullArgumentException14 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray13);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1.4210854715202007E-14d, objArray13);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 2.0f, objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4210854715202007E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202108E-14d + "'", double1 == 1.4210854715202108E-14d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1399733633L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1399733633L + "'", long2 == 1399733633L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) (-0.0f), 4.2514365942624575E52d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1, 1067072030);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1067072030 + "'", int2 == 1067072030);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 61880);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.049482027010373145d) + "'", double1 == (-0.049482027010373145d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 5.9999924302101135d, (java.lang.Number) 128.0f, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) Float.NaN, (-0.7949577687638787d), 0.811048585625462d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver14 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.46842437619265676d, (double) 101L, (double) 10L);
        double double15 = regulaFalsiSolver14.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction20 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver24 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        double double25 = regulaFalsiSolver24.getStartValue();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution29 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double30 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction20, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver24, 0.0d, 121.18168178400562d, (double) 7.6293945E-6f, allowedSolution29);
        double double31 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 10, univariateRealFunction10, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver14, 0.024098155628168808d, (double) 10L, (double) ' ', allowedSolution29);
        try {
            double double32 = regulaFalsiSolver3.solve((-319000853), univariateRealFunction6, (double) 10.0f, 16.64898031946962d, allowedSolution29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.46842437619265676d + "'", double15 == 0.46842437619265676d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution29 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution29.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.024098155628168808d + "'", double31 == 0.024098155628168808d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 52, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test478");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, 10);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray26 = null;
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray26);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test479");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1083994112L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test480");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) (byte) 100, (int) (short) 100, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test481");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0000000000291038d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9103830456310187E-11d + "'", double1 == 2.9103830456310187E-11d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test482");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test483");
        double double1 = org.apache.commons.math.util.MathUtils.sign(21.059547792608207d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test484");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-449079295), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test485");
        double double2 = org.apache.commons.math.util.FastMath.max(32.010217508994515d, (double) 1.61490547E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.614905472E9d + "'", double2 == 1.614905472E9d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test486");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test487");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 48.5f, (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test488");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) 2000.0d, true);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        java.lang.Number number8 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 2000.0d + "'", number7.equals(2000.0d));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1.0f) + "'", number8.equals((-1.0f)));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test489");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException(localizable0, (java.lang.Number) (byte) 0);
        try {
            org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notPositiveException2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test490");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 5.298292365610485d, (java.lang.Number) 1.401298464324817E-45d, false);
        java.lang.Number number6 = numberIsTooLargeException5.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.401298464324817E-45d + "'", number6.equals(1.401298464324817E-45d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test491");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test492");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 100);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test493");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 9.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test494");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.192092895507813E-7d, (java.lang.Number) 5.0d, true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test495");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double[] doubleArray24 = new double[] { 100.0d, 1.0f };
        double[] doubleArray31 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray24);
        double[] doubleArray36 = new double[] { 100.0d, 1.0f };
        double[] doubleArray43 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[] doubleArray47 = new double[] { 100.0d, 1.0f };
        double[] doubleArray54 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray54);
        double[] doubleArray59 = new double[] { 100.0d, 1.0f };
        double[] doubleArray66 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray66);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 90.0d + "'", double32 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 90.0d + "'", double44 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 90.0d + "'", double55 == 90.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 90.0d + "'", double67 == 90.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 91.0d + "'", double69 == 91.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 179766209 + "'", int70 == 179766209);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 179766209 + "'", int71 == 179766209);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 100.00499987500625d + "'", double74 == 100.00499987500625d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test496");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1399733632, 1067072030);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: overflow in addition: 1,399,733,632 + 1,067,072,030");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test497");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test498");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.4282108789999998E9d), (java.lang.Number) (-60), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test499");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 1.0E-15d, true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test500");
        double double1 = org.apache.commons.math.util.FastMath.abs(10.95143792640201d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.95143792640201d + "'", double1 == 10.95143792640201d);
    }
}

