import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) (byte) 1, (double) 0.0f, (double) 10.0f, (double) 100L, (double) 1L, (double) 0.0f, (double) 100L, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2000.0d + "'", double8 == 2000.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int[] intArray5 = new int[] { 100, (byte) 100, (byte) -1, '4', 10 };
        int[] intArray7 = new int[] { (short) -1 };
        try {
            double double8 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-1.0d), (double) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray1 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-0.99999994f) + "'", float1 == (-0.99999994f));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_REGRESSORS));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double[] doubleArray4 = new double[] { 1.0d, 10L, (short) 100, (-1) };
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = null;
        try {
            boolean boolean8 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1.0f, 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SHAPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SHAPE));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (byte) -1, 0.0d, (double) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double[] doubleArray4 = new double[] { (byte) -1, 1.4210854715202004E-14d, 0.0d, 10.0d };
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = null;
        double[] doubleArray8 = new double[] { 0.0f, 10.0f };
        double[] doubleArray11 = new double[] { 0.0f, 10.0f };
        double[][] doubleArray12 = new double[][] { doubleArray8, doubleArray11 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray4, orderDirection5, doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 100L, (double) 100, (double) 0L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double0 = org.apache.commons.math.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        double[] doubleArray25 = new double[] { (short) 10 };
        double[] doubleArray27 = new double[] { (short) 10 };
        double[] doubleArray29 = new double[] { (short) 10 };
        double[] doubleArray31 = new double[] { (short) 10 };
        double[][] doubleArray32 = new double[][] { doubleArray25, doubleArray27, doubleArray29, doubleArray31 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray20, orderDirection23, doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 6");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.46842437619265676d + "'", double0 == 0.46842437619265676d);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_INTERPOLATION_POINTS));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long1 = org.apache.commons.math.util.FastMath.round(90.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 90L + "'", long1 == 90L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction> univariateRealFunctionBracketedUnivariateRealSolver2 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = null;
        try {
            double double7 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, univariateRealFunctionBracketedUnivariateRealSolver2, 6.283185307179586d, (double) 0, (double) (short) 10, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 0L, 0.0d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-1.0d), 2000.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) -1, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double2 = org.apache.commons.math.util.MathUtils.round(100.0d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = null;
        try {
            double double9 = regulaFalsiSolver3.solve((int) ' ', univariateRealFunction5, (-1.0d), (double) 'a', allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(101L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 6.283185307179586d, (double) 10, 6.283185307179586d, (double) 100, 0.0d, (double) (short) 1, 90.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 152.83185307179588d + "'", double8 == 152.83185307179588d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_SIZE));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000291038d + "'", double1 == 1.0000000000291038d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(0.46842437619265676d, (double) (short) 1, (double) 100);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math.exception.MathIllegalStateException();
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) ' ', 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double0 = org.apache.commons.math.util.MathUtils.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 35, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (short) 10, (double) (-1L), 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver5, (double) 0, (double) 'a', (double) (byte) 0, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(0.8623188722876839d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.43115943614384195d + "'", double2 == 0.43115943614384195d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 90L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 0, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.46842437619265676d, (double) (short) 1, (double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100L, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) (byte) -1, 32.0d, (double) 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 10, (double) (-1), (int) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '#', (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1820 + "'", int2 == 1820);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.0f, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.43115943614384195d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.431159436143842d + "'", double2 == 0.431159436143842d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(121.18168178400562d, (double) 32.0f, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MUCH_CANCELLATION));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double1 = org.apache.commons.math.util.FastMath.expm1(121.18168178400562d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.251436595606516E52d + "'", double1 == 4.251436595606516E52d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.251436595606516E52d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 121.18168178400562d + "'", double1 == 121.18168178400562d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (byte) 1, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CROSSING_BOUNDARY_LOOPS));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(0.0f, (double) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.4E-45f) + "'", float2 == (-1.4E-45f));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-0.99999994f), (double) (short) 1, 32.0d, 0.46842437619265676d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 13.989580097769661d + "'", double4 == 13.989580097769661d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_LINEAR_OPERATOR));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(4.251436595606516E52d, (double) 'a', (double) 1, (double) (short) 1, (double) (byte) -1, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.12389349773832E54d + "'", double6 == 4.12389349773832E54d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        float float1 = org.apache.commons.math.util.MathUtils.sign(32.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 'a', 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44563605345380415L) + "'", long2 == (-44563605345380415L));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 100, (-44563605345380415L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44563605345380515L + "'", long2 == 44563605345380515L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (byte) 0);
        org.apache.commons.math.exception.MathInternalError mathInternalError2 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) maxCountExceededException1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 10, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3028848683749714d + "'", double2 == 0.3028848683749714d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, (long) 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.util.MathUtils.checkFinite(32.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction2 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double7 = regulaFalsiSolver0.solve((int) '#', univariateRealFunction2, (double) 0L, (double) (short) -1, (double) 0L, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution6 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution6.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.014686439244896978d + "'", double1 == 0.014686439244896978d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math.exception.NullArgumentException();
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) ' ', (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '#', 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 1, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.atanh(91.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1399733633 + "'", int2 == 1399733633);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (byte) 100, (int) '4', 1399733633);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(0.8414709848078965d, (double) (byte) 1, 0.0d, 0.8623188722876839d, 0.8623188722876839d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-0.020847887479787386d) + "'", double6 == (-0.020847887479787386d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(32.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.000004f + "'", float1 == 32.000004f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int1 = org.apache.commons.math.util.MathUtils.sign(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-1.4E-45f), 90.0d, (double) 10L, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.2611686178923354E-43d) + "'", double4 == (-1.2611686178923354E-43d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 10L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException4.getDirection();
        try {
            boolean boolean8 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence(1.4210854715202004E-14d, (double) 0L, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [0, 0]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) 52L, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.5430806348152437d);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1.543 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1.543 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.atan(101.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.560895660206908d + "'", double1 == 1.560895660206908d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0f, (float) 1399733633, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 3.8146973E-6f, 0.0d, 363.7393755555636d, 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 1, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5845632502852868E29d + "'", double2 == 1.5845632502852868E29d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6940658945086007E-21d + "'", double1 == 1.6940658945086007E-21d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        long long1 = org.apache.commons.math.util.FastMath.round(101.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 101L + "'", long1 == 101L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202105E-14d + "'", double1 == 1.4210854715202105E-14d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException14.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection15, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 97, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 97, 0.8414709848078965d, (double) (-1.4E-45f), 1.0000000000291038d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 81.62268552636596d + "'", double4 == 81.62268552636596d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { 100.0d, 1.0f };
        double[] doubleArray32 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        double[] doubleArray37 = new double[] { 100.0d, 1.0f };
        double[] doubleArray44 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray44);
        double[] doubleArray48 = new double[] { 100.0d, 1.0f };
        double[] doubleArray55 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray48);
        try {
            double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 90.0d + "'", double45 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException26.getDirection();
        double[] doubleArray32 = new double[] { 0.0d, 0.46842437619265676d, '#', 121.18168178400562d };
        double[][] doubleArray33 = new double[][] { doubleArray32 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray13, orderDirection27, doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) (-1.4E-45f), 1.5845632502852868E29d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.000004f + "'", float1 == 35.000004f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 100, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double2 = org.apache.commons.math.util.FastMath.max(0.3028848683749714d, 4.251436595606516E52d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.251436595606516E52d + "'", double2 == 4.251436595606516E52d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (byte) -1, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(32.0f, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 31.999998f + "'", float2 == 31.999998f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) -1, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(1820);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11846.669319939707d + "'", double1 == 11846.669319939707d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) 2000.0d, true);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        boolean boolean6 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -1 is larger than the maximum (2,000)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 1L, 1399733633);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(35.000004f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 44563605345380515L, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.4563605345380512E16d + "'", double2 == 4.4563605345380512E16d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (byte) 1, 1.0000000000291038d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.42944819032518d + "'", double1 == 43.42944819032518d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-44563605345380415L), Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.43115943614384195d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.539040909144553d + "'", double1 == 0.539040909144553d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.5845632502852868E29d, 0.0d, (double) 52L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 52, 3.8146973E-6f, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, 0.0f, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int1 = org.apache.commons.math.util.MathUtils.hash(121.18168178400562d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-319000847) + "'", int1 == (-319000847));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.8623188722876839d, 1.4210854715202004E-14d, 2.6881171418161356E43d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.4210854715202004E-14d, 1.5845632502852868E29d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.46842437619265676d, (double) 101L, (double) 10L);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double10 = regulaFalsiSolver3.solve((int) (short) 10, univariateRealFunction5, (double) (byte) 0, (double) (short) 1, 0.0d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution6 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double7 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((int) (short) 10, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (double) (short) 10, Double.POSITIVE_INFINITY, 2.6881171418161356E43d, allowedSolution6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution6 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution6.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray9 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException10 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray9);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.0f, objArray9);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 101.0d, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(363.7393755555636d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 207.8696877777818d + "'", double2 == 207.8696877777818d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 97.0f, 0.0d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 10, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.96459430051421d + "'", double2 == 97.96459430051421d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray27 = new double[] { 90.0d, 91.0d, (-1.0f), 10.0f };
        double[] doubleArray30 = new double[] { 100.0d, 1.0f };
        double[] doubleArray37 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray37);
        double[] doubleArray41 = new double[] { 100.0d, 1.0f };
        double[] doubleArray48 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray48);
        double[] doubleArray55 = new double[] { 100.0d, 1.0f };
        double[] doubleArray62 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray62);
        double[] doubleArray66 = new double[] { 100.0d, 1.0f };
        double[] doubleArray73 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray73);
        try {
            double double76 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray2, doubleArray73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 6");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 90.0d + "'", double38 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 90.0d + "'", double49 == 90.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 121.18168178400562d + "'", double51 == 121.18168178400562d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 91.0d + "'", double52 == 91.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 90.0d + "'", double63 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 90.0d + "'", double74 == 90.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(52, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(6.283185307179586d, 2000.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179587d + "'", double2 == 6.283185307179587d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(13.989580097769661d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 595069.1624655712d + "'", double1 == 595069.1624655712d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 0, 2000.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 100L, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-0.020847887479787386d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-6) + "'", int1 == (-6));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (byte) 10);
        int int3 = incrementor0.getCount();
        try {
            incrementor0.incrementCount((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (10) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 2000.0d, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) ' ', (-6));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-44563605345380415L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 0, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97, (java.lang.Number) 35.000004f, (int) (byte) 0, orderDirection18, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection18, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) (byte) 1, 13.989580097769661d, 91.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 101L, (double) (byte) 0);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        double double4 = regulaFalsiSolver2.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver2.solve((-6), univariateRealFunction6, 0.0d, 0.0d, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 101.0d + "'", double4 == 101.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 101L, (double) (byte) 0);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver2.solve((int) ' ', univariateRealFunction5, 4.4563605345380512E16d, 1.4210854715202004E-14d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.251436595606516E52d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.Object[] objArray6 = new java.lang.Object[] { ' ' };
        org.apache.commons.math.exception.NoBracketingException noBracketingException7 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (double) 1L, 0.0d, 0.0d, (double) 10L, objArray6);
        double double8 = noBracketingException7.getHi();
        double double9 = noBracketingException7.getHi();
        double double10 = noBracketingException7.getFHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.6940658945086007E-21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) ' ', 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 1399733633, 1820);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.atan(43.42944819032518d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5477745439281119d + "'", double1 == 1.5477745439281119d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        float float2 = org.apache.commons.math.util.FastMath.scalb(97.0f, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 48.5f + "'", float2 == 48.5f);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 35.000004f, 0.0d, 6.283185307179587d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(6, (-6));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, (double) (byte) 10, (double) 97.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0d, (java.lang.Number) 0.0f, true);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: value 10 at index 0" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: value 10 at index 0"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = null;
        try {
            boolean boolean26 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection23, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) (short) 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((double) 97.0f, (double) 10, (double) (-44563605345380415L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [97, 10]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(81.62268552636596d, 0.0d, (double) 44563605345380515L, (double) 1L, (double) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.4563605345380512E16d + "'", double6 == 4.4563605345380512E16d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(100, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) (byte) -1, 1.5430806348152437d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 35.000004f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        float float2 = org.apache.commons.math.util.FastMath.max(3.8146973E-6f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.8146973E-6f + "'", float2 == 3.8146973E-6f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.4210854715202105E-14d, 363.7393755555636d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver4 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 101L, (double) (byte) 0);
        double double5 = regulaFalsiSolver4.getAbsoluteAccuracy();
        double double6 = regulaFalsiSolver4.getRelativeAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution10 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double11 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(0, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver4, (double) 'a', 0.539040909144553d, 152.83185307179588d, allowedSolution10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 101.0d + "'", double6 == 101.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution10 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution10.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1.1920929E-7f, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1920928955078128E-7d + "'", double2 == 1.1920928955078128E-7d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-0.0d));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(96, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(0.3028848683749714d, (double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15144249379213048d + "'", double2 == 0.15144249379213048d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 121.18168178400562d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 1.0f, (-319000847));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 101L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.sinh(43.42944819032518d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6319486988467031E18d + "'", double1 == 3.6319486988467031E18d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6929693744344998d + "'", double1 == 1.6929693744344998d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1820, 4.12389349773832E54d, (-1428210879));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} != {1}" + "'", str1.equals("{0} != {1}"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 96, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) (-1), 4.251436595606516E52d, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.2514365942624575E52d + "'", double3 == 4.2514365942624575E52d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (byte) 0, objArray1);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.111507638930571E-61d + "'", double1 == 3.111507638930571E-61d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(32.000004f, 7.6293945E-6f, 48.5f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-319000847));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.811048585625462d + "'", double1 == 0.811048585625462d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) (byte) -1);
        java.lang.Number number8 = notStrictlyPositiveException7.getMin();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException7);
        java.lang.String str10 = notStrictlyPositiveException7.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 100)"));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is larger than, or equal to, the maximum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -1 is larger than, or equal to, the maximum (0)"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 101L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 48.5f, 4.4563605345380512E16d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { 100.0d, 1.0f };
        double[] doubleArray32 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        double[] doubleArray37 = new double[] { 100.0d, 1.0f };
        double[] doubleArray44 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray44);
        double[] doubleArray48 = new double[] { 100.0d, 1.0f };
        double[] doubleArray55 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray48);
        try {
            double double58 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray32, doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 6 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 90.0d + "'", double45 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 90.0d + "'", double56 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 91.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 10, 1399733633);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) ' ', (float) 98L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1L, 44563605345380515L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 101.0d);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.sin(152.83185307179588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8939966636005526d + "'", double1 == 0.8939966636005526d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 1820, 1.4210854715202004E-14d, (double) 100L, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { 100.0d, 1.0f };
        double[] doubleArray32 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double[] doubleArray36 = new double[] { 100.0d, 1.0f };
        double[] doubleArray43 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray36);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36, 10);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray36);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        try {
            double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 90.0d + "'", double44 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.00499987500625d + "'", double49 == 100.00499987500625d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 1.1102230246251565E-16d, 0.43115943614384195d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        double double4 = regulaFalsiSolver3.getStartValue();
        double double5 = regulaFalsiSolver3.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        try {
            double double11 = regulaFalsiSolver3.solve((int) (short) 0, univariateRealFunction7, 0.0d, (-0.020847887479787386d), 3.948148009134034E13d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.1920928955078128E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.923689900271567d) + "'", double1 == (-6.923689900271567d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1399733633, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1399733537 + "'", int2 == 1399733537);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 6.283185307179586d, (double) 1.0f, (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1, (double) 1399733633);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int[] intArray3 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray3, 0);
        int[] intArray9 = new int[] { 'a', (byte) -1, (short) 1 };
        int[] intArray11 = org.apache.commons.math.util.MathUtils.copyOf(intArray9, 0);
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray13 = null;
        try {
            int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 98L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.1920928955078128E-7d, 121.18168178400562d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.192092895507813E-7d + "'", double2 == 1.192092895507813E-7d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1428210879));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1,428,210,879");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, (double) (byte) 0, 0.8939966636005526d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 101L, (double) (byte) 0);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double7 = regulaFalsiSolver2.solve((int) (short) 100, univariateRealFunction4, 91.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-1.4E-45f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13, 10);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray13);
        double[] doubleArray31 = new double[] { (-1.0f), 363.7393755555636d, 1.3440585709080678E43d, 1.5477745439281119d, Double.POSITIVE_INFINITY };
        double[] doubleArray37 = new double[] { (-1.0f), 363.7393755555636d, 1.3440585709080678E43d, 1.5477745439281119d, Double.POSITIVE_INFINITY };
        double[] doubleArray43 = new double[] { (-1.0f), 363.7393755555636d, 1.3440585709080678E43d, 1.5477745439281119d, Double.POSITIVE_INFINITY };
        double[][] doubleArray44 = new double[][] { doubleArray31, doubleArray37, doubleArray43 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 96.0d + "'", double1 == 96.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (-44563605345380415L), 1.5845632502852868E29d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.4563601E16f) + "'", float2 == (-4.4563601E16f));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.73937555556364d + "'", double1 == 363.73937555556364d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.acosh(595069.1624655712d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.989580097769661d + "'", double1 == 13.989580097769661d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(90.0d, (double) 10.0f, 1.0d);
        int int4 = regulaFalsiSolver3.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double9 = regulaFalsiSolver3.solve(0, univariateRealFunction6, 0.3028848683749714d, (double) (-6));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 1399733633, 595069.1624655712d, 0.0d, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { 100.0d, 1.0f };
        double[] doubleArray32 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        double[] doubleArray40 = new double[] { (-1.4E-45f), (-6), 96, 1.1102230246251565E-16d, (byte) 10 };
        double[] doubleArray46 = new double[] { (-1.4E-45f), (-6), 96, 1.1102230246251565E-16d, (byte) 10 };
        double[] doubleArray52 = new double[] { (-1.4E-45f), (-6), 96, 1.1102230246251565E-16d, (byte) 10 };
        double[][] doubleArray53 = new double[][] { doubleArray40, doubleArray46, doubleArray52 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray20, doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 6");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.111507638930571E-61d, (double) (-319000847), 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-44563605345380415L), 11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.232920103323d + "'", double2 == 11013.232920103323d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 90L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.499809670330265d + "'", double1 == 4.499809670330265d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) -1, 96);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 96, n = -1");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 1399733537);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.020847887479787386d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020847887479787386d + "'", double1 == 0.020847887479787386d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        try {
            double[] doubleArray24 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray20, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) (byte) 10, 0.0d, 0.15144249379213048d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 3.8146973E-6f, 81.62268552636596d, (-6.923689900271567d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.923693714968833d + "'", double3 == 6.923693714968833d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.07140440247247d + "'", double1 == 36.07140440247247d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, (-6));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-6)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.8146973E-6f, (-1.0f), 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (short) 10);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.505149978319906d + "'", double1 == 1.505149978319906d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1820, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1820L + "'", long2 == 1820L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray20);
        double[] doubleArray25 = new double[] { 100.0d, 1.0f };
        double[] doubleArray32 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        double[] doubleArray38 = new double[] { (-0.020847887479787386d), 1.4210854715202004E-14d, 1.192092895507813E-7d };
        try {
            double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 90.0d + "'", double33 == 90.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) Double.NaN);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 101L, (double) (byte) 0);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double7 = regulaFalsiSolver2.solve(0, univariateRealFunction5, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1399733537, 98L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 137173886626L + "'", long2 == 137173886626L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 98L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double[] doubleArray2 = new double[] { 100.0d, 1.0f };
        double[] doubleArray9 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0d, 1.0f };
        double[] doubleArray20 = new double[] { 10.0d, (byte) 0, 1.0f, 10.0f, (short) 1, 100.0f };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0f, (java.lang.Number) 1.0f, (int) (short) 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException29.getDirection();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        java.lang.Object[] objArray32 = null;
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) orderDirection30, (org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray32);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0d), (java.lang.Number) 1.0f, 0, orderDirection30, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection30, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 90.0d + "'", double10 == 90.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 90.0d + "'", double21 == 90.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 6, (float) 1399733633, 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1, (double) (short) 0);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver2.solve(0, univariateRealFunction4, (double) 32.0f, (double) Float.POSITIVE_INFINITY, 6.283185307179587d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0f, 0.0f, (-4.4563601E16f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 1.1102230246251565E-16d, 1.5430806348152437d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 100, (double) 90L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E180d + "'", double2 == 1.0E180d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(Float.POSITIVE_INFINITY, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 10, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(6, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 582 + "'", int2 == 582);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) -1, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.0f) + "'", float2 == (-0.0f));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.560895660206908d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.8263781176436d + "'", double2 == 51.8263781176436d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) -1, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) (-6));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-6)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-6), 1820);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(10L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }
}

