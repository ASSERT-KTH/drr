import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double2 = org.apache.commons.math.util.MathUtils.round(3.1622776601683795d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 10, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-204));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-203.99999999999997d) + "'", double1 == (-203.99999999999997d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) -1, (int) (byte) 10, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 'a', (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1L), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double3 = org.apache.commons.math.util.MathUtils.round(11013.232920103324d, 10, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 11013.2329201034d + "'", double3 == 11013.2329201034d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.288241522117258d + "'", double1 == 5.288241522117258d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.MathUtils.sign(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.atan((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-2.0d), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0d) + "'", double2 == (-2.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.6275174755083712d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray29);
        double[] doubleArray38 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray46 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 974002048);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray49);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int55 = nonMonotonousSequenceException54.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = nonMonotonousSequenceException54.getDirection();
        java.lang.Class<?> wildcardClass57 = orderDirection56.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49, orderDirection56, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (974,002,048 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1760676956 + "'", int30 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.4142135623730951d + "'", double39 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.6881171418161356E43d + "'", double47 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 100 + "'", int55 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection56 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection56.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass57);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 17310309456440L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.731030945644E13d + "'", double1 == 1.731030945644E13d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double1 = org.apache.commons.math.util.FastMath.ulp(11013.026041820607d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8189894035458565E-12d + "'", double1 == 1.8189894035458565E-12d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.3113358856836756E267d, 1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3113358856836754E267d + "'", double2 == 1.3113358856836754E267d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 2, 4L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) -1, 1552941056);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 152, 37L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5624L + "'", long2 == 5624L);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.7853981633974482d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.0d), 0.05586001084178062d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) '4', (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7067655527413216E89d + "'", double2 == 1.7067655527413216E89d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 204);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double2 = org.apache.commons.math.util.MathUtils.round(11013.026041820607d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.026041820607d + "'", double2 == 11013.026041820607d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 0, 31L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 1760676956);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1760676956L + "'", long2 == 1760676956L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 0);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.267831587699267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267831587699268d + "'", double1 == 5.267831587699268d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int int1 = org.apache.commons.math.util.FastMath.abs(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 31 + "'", int1 == 31);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(4.61512051684126d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.23024103368252d + "'", double2 == 9.23024103368252d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '#', (-204));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 52.0f, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 974002049 + "'", number6.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 52, 4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.6625219529419444d, 2.220446049250313E-16d, 0.37357877856093286d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        int int2 = org.apache.commons.math.util.FastMath.max(87, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 204.0d, (java.lang.Number) (byte) 10, 5044);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 204.0d + "'", number4.equals(204.0d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double2 = org.apache.commons.math.util.FastMath.min(0.09966865249116202d, 3.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09966865249116202d + "'", double2 == 0.09966865249116202d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(35, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.29554887507230054d, (double) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.9999999958776927d, (double) 31.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.415926531775625d + "'", double2 == 32.415926531775625d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int13 = nonMonotonousSequenceException12.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.9512437185814275d, (java.lang.Number) 36L, (int) '#', orderDirection14, true);
        java.lang.Class<?> wildcardClass21 = orderDirection14.getClass();
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1000602687), (long) 1760676956);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 760074269L + "'", long2 == 760074269L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.log(572.2646479502633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.34960155562218d + "'", double1 == 6.34960155562218d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.477888730288475d + "'", double1 == 2.477888730288475d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.ulp(104.9439511105971d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1.0f, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 10, (long) (-131385937));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1313859370L) + "'", long2 == (-1313859370L));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(Double.POSITIVE_INFINITY, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.384017341061263E11d + "'", double1 == 1.384017341061263E11d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.rint(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 99);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(52.0d, 11013.232920103324d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(37L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 10100L, 974002048);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.968123235826276E-35d) + "'", double2 == (-2.968123235826276E-35d));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray20 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray20);
        double[] doubleArray26 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double[] doubleArray34 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 974002048);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray37);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (974,002,048 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 204.0d + "'", double21 == 204.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.4142135623730951d + "'", double27 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.6881171418161356E43d + "'", double35 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(105.35837144511169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8544953854119172E45d + "'", double1 == 2.8544953854119172E45d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 10, 31L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-1925533311));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1L), 31, (-204));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) 100, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.max(11013.026041820607d, 1.505149978319906d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.026041820607d + "'", double2 == 11013.026041820607d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(10, 974002049);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.8622957433108482d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 10, 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) '#', 152);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.998146769788344E47d + "'", double2 == 1.998146769788344E47d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1552941156L, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray20 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray20);
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray30 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double[] doubleArray38 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray38);
        double[] doubleArray44 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray52 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray52);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) 974002048);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray24, doubleArray30);
        try {
            double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 204.0d + "'", double21 == 204.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1000602687) + "'", int25 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.4142135623730951d + "'", double31 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.6881171418161356E43d + "'", double39 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.4142135623730951d + "'", double45 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.6881171418161356E43d + "'", double53 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 9.0d + "'", double57 == 9.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        float float1 = org.apache.commons.math.util.MathUtils.sign(31.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5557.690612768986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.54992027339121d + "'", double1 == 74.54992027339121d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-172L), (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370515d + "'", double1 == 0.9075712110370515d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.003761536530132509d, 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.062077391215993656d) + "'", double2 == (-0.062077391215993656d));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1313859370L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1313859370L + "'", long1 == 1313859370L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-100L), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-102400.0d) + "'", double2 == (-102400.0d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int1 = org.apache.commons.math.util.FastMath.abs(99);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 99 + "'", int1 == 99);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.rint(572.2646479502633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.0d + "'", double1 == 572.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1000602687) + "'", int4 == (-1000602687));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double2 = org.apache.commons.math.util.FastMath.max((double) '4', (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1552941056);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.rint(104.9439511105971d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105.0d + "'", double1 == 105.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        long long2 = org.apache.commons.math.util.FastMath.min(974002049L, (long) 1552941056);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 974002049L + "'", long2 == 974002049L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        float float2 = org.apache.commons.math.util.FastMath.max((-1.0f), (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-204), (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-205) + "'", int2 == (-205));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-205), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray17);
        double[] doubleArray26 = new double[] { (byte) 10, 0.0d };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray32 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 10);
        double[] doubleArray41 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray45 = null;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray41);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray26);
        double[] doubleArray51 = new double[] { (byte) 10, 0.0d };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray57 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray57);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) 10);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double[] doubleArray67 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double[] doubleArray75 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray67, doubleArray75);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray75, (double) 974002048);
        double[] doubleArray83 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray83);
        double[] doubleArray91 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray83, doubleArray91);
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray78, doubleArray91);
        double double94 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray91);
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray91);
        double double96 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 974002049 + "'", int19 == 974002049);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1000602687) + "'", int27 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4142135623730951d + "'", double33 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.4142135623730951d + "'", double42 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 974002049 + "'", int43 == 974002049);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.4142135623730951d + "'", double44 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1000602687) + "'", int52 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.4142135623730951d + "'", double58 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 10.0d + "'", double62 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.4142135623730951d + "'", double68 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 2.6881171418161356E43d + "'", double76 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.4142135623730951d + "'", double84 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 2.6881171418161356E43d + "'", double92 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 2.6881171418161356E43d + "'", double93 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 2.6881171418161356E43d + "'", double94 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 2.6881171418161356E43d + "'", double95 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 2.6881171418161356E43d + "'", double96 == 2.6881171418161356E43d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(6.565119738485518E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.003761536530132509d + "'", double1 == 0.003761536530132509d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number17 = nonMonotonousSequenceException16.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number10, (java.lang.Number) (-1.7463811409905557E7d), (int) (short) 0, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.026041820607d, (java.lang.Number) 0.6440288952968115d, 1552941056, orderDirection18, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection18, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (1 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 974002049 + "'", number17.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 974002048);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 974002048L + "'", long1 == 974002048L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.MathUtils.sign(11.7910068511973d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        long long1 = org.apache.commons.math.util.FastMath.round(2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1552941056, 4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.15912713462618d + "'", double2 == 4.15912713462618d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1552941156L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.552941156E9d + "'", double1 == 1.552941156E9d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1552941156L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 100, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 97L, (int) ' ', (-131385937));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3132616875182228d + "'", double1 == 1.3132616875182228d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.9572960942883878E11d, (double) 5624L, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 31.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4524424832623713E13d + "'", double1 == 1.4524424832623713E13d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(4.944515159673473E42d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.944515159673473E42d + "'", double2 == 4.944515159673473E42d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray18);
        int[] intArray24 = new int[] { (byte) 0, 100, 0 };
        int[] intArray29 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray29);
        int[] intArray34 = new int[] { (byte) 0, 100, 0 };
        int[] intArray39 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray39);
        int[] intArray45 = new int[] { (byte) 0, 100, 0 };
        int[] intArray50 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray50);
        int[] intArray55 = new int[] { (byte) 0, 100, 0 };
        int[] intArray60 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray60);
        int[] intArray65 = new int[] { (byte) 0, 100, 0 };
        int[] intArray70 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray70);
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray70);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray60);
        int[] intArray77 = new int[] { (byte) 0, 100, 0 };
        int[] intArray82 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray82);
        int[] intArray87 = new int[] { (byte) 0, 100, 0 };
        int[] intArray92 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray87, intArray92);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray82, intArray92);
        int int95 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray82);
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray60);
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray18, intArray60);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 152 + "'", int30 == 152);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 152 + "'", int40 == 152);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 152 + "'", int51 == 152);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 152 + "'", int61 == 152);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 152 + "'", int71 == 152);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 99 + "'", int73 == 99);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 152 + "'", int83 == 152);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 152 + "'", int93 == 152);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1037659958) + "'", int1 == (-1037659958));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.944515159673473E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.223626578289051E21d + "'", double1 == 2.223626578289051E21d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 87);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.15051499783199063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4197071422138536d + "'", double1 == 1.4197071422138536d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-205), (-131385937));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray17);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 974002049 + "'", int19 == 974002049);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(105.0d, 11.7910068511973d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.752220392306214d + "'", double2 == 10.752220392306214d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 974002048);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray43);
        double[] doubleArray52 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray60 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray60);
        double[] doubleArray68 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray68);
        double[] doubleArray70 = null;
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray70);
        try {
            double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.4142135623730951d + "'", double53 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 204.0d + "'", double69 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 99, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-1313859370L), (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1073424338879928E-8d + "'", double1 == 2.1073424338879928E-8d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.rint(5044.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5044.0d + "'", double1 == 5044.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) -1, 10100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        int int1 = org.apache.commons.math.util.MathUtils.sign(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-307.6526555685888d) + "'", double1 == (-307.6526555685888d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-205), (float) (-1000602687));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.00060269E9f) + "'", float2 == (-1.00060269E9f));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-101L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.283185307179586d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.49714987269413385d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.40356321578642596d + "'", double1 == 0.40356321578642596d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-3.2362366308997543E35d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1552941156L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.55294118E9f + "'", float1 == 1.55294118E9f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int9 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        java.lang.String str13 = nonMonotonousSequenceException8.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-101L) + "'", number12.equals((-101L)));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.cosh(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1808787385219026E67d + "'", double1 == 2.1808787385219026E67d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray20 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray20);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray22);
        try {
            double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 2.8544953854119198E45d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 204.0d + "'", double21 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.acos((-3.2362366308997543E35d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(204);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.6881171418161356E43d, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10.0f, (double) 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.0038848218538872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(92.13617560368711d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double2 = org.apache.commons.math.util.FastMath.atan2(99.30685281944005d, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.470436647668219d + "'", double2 == 1.470436647668219d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10, (double) (-44563605345380415L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 100, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.41592653589793d + "'", double2 == 31.41592653589793d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 974002049L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int9 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        boolean boolean13 = nonMonotonousSequenceException8.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-101L) + "'", number12.equals((-101L)));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 0, (long) 1552941056);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 974002049 + "'", number6.equals(974002049));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 974002049 + "'", number7.equals(974002049));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(17310309456440L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 'a', (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-131385937), 35, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double2 = org.apache.commons.math.util.MathUtils.round((-3.2362366308997543E35d), 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.2362366308997543E35d) + "'", double2 == (-3.2362366308997543E35d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 974002048L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 760074269L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.448926710154215d + "'", double1 == 20.448926710154215d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-1.00060269E9f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1552941056, 1.5860134523134298E15d, (-1.0d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        try {
            double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (-0.7853981633974482d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) ' ', (int) (short) 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.sin((-102400.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.21094709796687366d) + "'", double1 == (-0.21094709796687366d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int2 = org.apache.commons.math.util.FastMath.max((-1000602687), (-1037659958));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1000602687) + "'", int2 == (-1000602687));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.asinh(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 0, 99, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3.6625219529419444d, 152);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.signum(9.740020490000001E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 101.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1), (int) 'a');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1760676956, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1760676956 + "'", int2 == 1760676956);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(4.9E-324d, 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NaN, 11013.232920103324d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 31);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 101.0f, 1.4210854715202004E-14d, 22026.465794806718d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1037659958));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8110582783206075E7d) + "'", double1 == (-1.8110582783206075E7d));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1410065408 + "'", int2 == 1410065408);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (byte) 0, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-131385937));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 87);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 97.0f, 4.15912713462618d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) 'a', (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9700 + "'", int2 == 9700);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        int int1 = org.apache.commons.math.util.FastMath.round(100.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.7853981633974482d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1037659958));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.log1p(572.2646479502633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.351347473876036d + "'", double1 == 6.351347473876036d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        int int1 = org.apache.commons.math.util.MathUtils.hash(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1694164182) + "'", int1 == (-1694164182));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.45593812776599624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        double[] doubleArray51 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray59 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray59);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 974002048);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray68 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray76 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray76);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) 974002048);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray79);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray62);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number87 = nonMonotonousSequenceException86.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection88 = nonMonotonousSequenceException86.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection88, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 > -101)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.6881171418161356E43d + "'", double45 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.6881171418161356E43d + "'", double46 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.4142135623730951d + "'", double52 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 2.6881171418161356E43d + "'", double60 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1760676956 + "'", int63 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.4142135623730951d + "'", double69 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 2.6881171418161356E43d + "'", double77 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1760676956 + "'", int80 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 2.6881171418161356E43d + "'", double82 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + number87 + "' != '" + 974002049 + "'", number87.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection88 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection88.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.8544953854119198E45d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.342747781256308E22d + "'", double1 == 5.342747781256308E22d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.9572960942883878E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1214480546016465E13d + "'", double1 == 1.1214480546016465E13d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1000602687), Float.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 9700);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.cos(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) 'a', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 974002079L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.7400205E8f + "'", float1 == 9.7400205E8f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(204);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(152, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 0, (float) 9700);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.1415925016813464d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4645918639552502d + "'", double1 == 1.4645918639552502d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 36.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5403023093369417d, 31.41592653589793d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 35, 37L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1694164182));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1694164182) + "'", int2 == (-1694164182));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double2 = org.apache.commons.math.util.FastMath.max(9.23024103368252d, 204.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 204.0d + "'", double2 == 204.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        int int1 = org.apache.commons.math.util.FastMath.abs(974002048);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 974002048 + "'", int1 == 974002048);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1024 + "'", int2 == 1024);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(32.415926531775625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.69349861963412d + "'", double1 == 5.69349861963412d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8813735870195429d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8813735870195429d + "'", double2 == 0.8813735870195429d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double2 = org.apache.commons.math.util.FastMath.max(11013.232920103324d, (double) 1760676956);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.760676956E9d + "'", double2 == 1.760676956E9d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1), 17310309456440L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17310309456439L + "'", long2 == 17310309456439L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.7853981633974482d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 4L, (float) (-204));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-204.0f) + "'", float2 == (-204.0f));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(7.896296018267969E13d, 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.89629601826797E13d + "'", double2 == 7.89629601826797E13d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '4', (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(9700, (-204));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 36L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3019272488946267d + "'", double1 == 3.3019272488946267d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int2 = org.apache.commons.math.util.FastMath.min(1410065408, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.319776824715853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3237787393690108d + "'", double1 == 1.3237787393690108d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1024);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.624618747740734d + "'", double1 == 7.624618747740734d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        long long1 = org.apache.commons.math.util.FastMath.round(1.3113358856836754E267d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(52, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int16 = nonMonotonousSequenceException15.getIndex();
        java.lang.Number number17 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-101L) + "'", number17.equals((-101L)));
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-1.00060269E9f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-506605058) + "'", int1 == (-506605058));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1182127744, 1, 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.6275174755083712d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray29);
        double[] doubleArray38 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray46 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray54 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray54);
        double[] doubleArray62 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray62);
        double[] doubleArray64 = null;
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray46, doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray46);
        double[] doubleArray69 = new double[] { (byte) 10, 0.0d };
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double[] doubleArray75 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray75);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) 10);
        double[] doubleArray84 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray84);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray84);
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray84);
        double[] doubleArray88 = null;
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray84, doubleArray88);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray69, doubleArray84);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray84);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1760676956 + "'", int30 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.4142135623730951d + "'", double39 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 974002049 + "'", int40 == 974002049);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.4142135623730951d + "'", double41 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.4142135623730951d + "'", double47 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.6881171418161356E43d + "'", double55 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 204.0d + "'", double63 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1000602687) + "'", int70 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.4142135623730951d + "'", double76 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 1.4142135623730951d + "'", double85 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 974002049 + "'", int86 == 974002049);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.4142135623730951d + "'", double87 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 9.0d + "'", double92 == 9.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) -1, (double) 1760676956, (-82.4580365563798d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1552941056, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1760676956);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(17310309456440L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17310309456475L + "'", long2 == 17310309456475L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3.2362366308997543E35d), (java.lang.Number) Double.POSITIVE_INFINITY, (int) (byte) 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (-506605058));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1037659958), (-1L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.5996388013001026d, 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.1920928955078125E-7d, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1920928955078125E-7d + "'", double2 == 1.1920928955078125E-7d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1), 974002079L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.718281828459045d, (double) (-1925533311));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9255333112112293E9d) + "'", double2 == (-1.9255333112112293E9d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray17);
        double[] doubleArray26 = new double[] { (byte) 10, 0.0d };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray32 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray40 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray40);
        double[] doubleArray46 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray54 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray54);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 974002048);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray32);
        try {
            double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 974002049 + "'", int19 == 974002049);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1000602687) + "'", int27 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4142135623730951d + "'", double33 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.6881171418161356E43d + "'", double41 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.4142135623730951d + "'", double47 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.6881171418161356E43d + "'", double55 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 9.0d + "'", double59 == 9.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1552941156L, (double) (-205));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-205.0d) + "'", double2 == (-205.0d));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.26548245743669d + "'", double2 == 50.26548245743669d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.acosh(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.043958477050381d + "'", double1 == 7.043958477050381d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) (short) 100, 974002048, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-203.99999999999997d), (java.lang.Number) 9.740020490000001E8d, (int) (short) 0, orderDirection9, true);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.4524424832623713E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.030032437811794512d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.030032437811794512d) + "'", double2 == (-0.030032437811794512d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(204, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 204L + "'", long2 == 204L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 31);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(99, (-1694164182));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1694164083) + "'", int2 == (-1694164083));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.1920928955078125E-7d, (double) 9.7400205E8f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2982325897788716d) + "'", double2 == (-1.2982325897788716d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.1808787385219026E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.sin(6.076030225056872E37d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9632260215147505d) + "'", double1 == (-0.9632260215147505d));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, (-1694164182));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1694164183 + "'", int2 == 1694164183);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double2 = org.apache.commons.math.util.FastMath.atan2(156.3608363030788d, 49.07455907494659d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2666779012127305d + "'", double2 == 1.2666779012127305d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.8110582783206075E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.5996388013001026d, (-0.7853981633974482d), (-3.2362366308997543E35d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        boolean boolean11 = nonMonotonousSequenceException8.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.09966865249116202d, (-1694164182));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.805422216363571E242d) + "'", double2 == (-6.805422216363571E242d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(974002048L, (-1694164182));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double3 = org.apache.commons.math.util.MathUtils.round((double) 9223372036854775807L, (int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.223372036854776E18d + "'", double3 == 9.223372036854776E18d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-1694164182));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 10, 1313859370L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1313859370L + "'", long2 == 1313859370L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-1.1752011936438014d), 1.760676956E9d, 104.9439511105971d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 974002049, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.exp(11.7910068511973d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 132059.36709719698d + "'", double1 == 132059.36709719698d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1552941156L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        long long1 = org.apache.commons.math.util.FastMath.round(11.7910068511973d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 12L + "'", long1 == 12L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 974002079L, (double) 101.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.cos(9.740020480000001E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9914479817464672d) + "'", double1 == (-0.9914479817464672d));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.225073858507202E-308d + "'", double1 == 2.225073858507202E-308d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1182127744);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.384017341061263E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.7853981633974482d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-101L), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 100, (long) (-1694164083));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1024);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.764725154011207d + "'", double1 == 0.764725154011207d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 12L, (float) 204);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 204.0f + "'", float2 == 204.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1694164183, 156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.23774391214507304d + "'", double2 == 0.23774391214507304d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(17310309456440L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17310309456440L + "'", long2 == 17310309456440L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.3113358856836756E267d, 50.26548245743669d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.225073858507202E-308d, (-307.6526555685888d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(2L, 17310309456439L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34620618912878L + "'", long2 == 34620618912878L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.1214480546016465E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3348802.852664884d + "'", double1 == 3348802.852664884d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray20 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray20);
        double[] doubleArray28 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray28);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray12);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4142135623730951d + "'", double13 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.6881171418161356E43d + "'", double21 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 204.0d + "'", double29 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.9572960942883878E11d, 105.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-44563605345380415L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5430256902014756d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-44563605345380415L), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44563605345380515L) + "'", long2 == (-44563605345380515L));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number51 = nonMonotonousSequenceException50.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException50.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException50.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection53, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (10 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.6881171418161356E43d + "'", double45 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.6881171418161356E43d + "'", double46 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 974002049 + "'", number51.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(31L, (-1925533311));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 37L, 6.346863764025602E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 37.00000000000001d + "'", double2 == 37.00000000000001d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9700, (java.lang.Number) 0.7615941559557649d, 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.4142135623730951d, 7.624618747740734d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.697398869552681d + "'", double2 == 7.697398869552681d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5364902654041583d, (double) 2L, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(88.03440747059399d, 50.26548245743669d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 50.33529562751647d + "'", double2 == 50.33529562751647d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(9.7400205E8f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-204.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) (short) 100, 974002048, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800L, (java.lang.Number) 97.0d, (int) (byte) 0, orderDirection9, false);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.9999999999999996d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1925533311));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1244.0858352682665d) + "'", double1 == (-1244.0858352682665d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.998146769788344E47d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07821925899367385d) + "'", double1 == (-0.07821925899367385d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 100, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 152);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.33680329744389d + "'", double1 == 5.33680329744389d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.9075712110370515d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-131385940) + "'", int1 == (-131385940));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        float float2 = org.apache.commons.math.util.FastMath.min(97.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-506605058));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.06605056E8f + "'", float1 == 5.06605056E8f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.6625219529419444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.466902669414953d + "'", double1 == 19.466902669414953d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double2 = org.apache.commons.math.util.FastMath.atan2(13.228920847762078d, (double) 31.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4033429968428506d + "'", double2 == 0.4033429968428506d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int7 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3113358856836756E267d, (java.lang.Number) (-205.0d), 257, orderDirection8, false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray11);
        double[] doubleArray13 = null;
        try {
            double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 100, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.atanh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        int int1 = org.apache.commons.math.util.MathUtils.sign(257);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.610125138662288d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1529388524411384d + "'", double1 == 2.1529388524411384d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(974002049, (-506605058));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 467396991 + "'", int2 == 467396991);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-2.968123235826276E-35d), (-82.45803655637981d), 31);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3628800L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1182127744, 3.3019272488946267d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.063122204630705E29d + "'", double2 == 9.063122204630705E29d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-205));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.5779249665883754d) + "'", double1 == (-3.5779249665883754d));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double3 = org.apache.commons.math.util.MathUtils.round(3.0000000000000004d, 99, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0000000000000004d + "'", double3 == 3.0000000000000004d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152442d + "'", double1 == 1.5430806348152442d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.61512051684126d, 0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-506605058));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 5624L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5624L + "'", long2 == 5624L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        float float1 = org.apache.commons.math.util.FastMath.abs((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.rint(7.697398869552681d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(9.0d, 1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.999999999999998d + "'", double2 == 8.999999999999998d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9227673888116062d) + "'", double1 == (-0.9227673888116062d));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1694164083), 760074269L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.5403023058681398d, (double) 5624L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5403023058681399d + "'", double2 == 0.5403023058681399d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.552941156E9d, (java.lang.Number) 1.5430806348152442d, 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-6.053272382792838d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.09966865249116202d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.MathUtils.sign(5.33680329744389d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) 0, 9700);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1313859370L), (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1760676956L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.864073558457564d + "'", double1 == 10.864073558457564d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.3754263876807227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8520158336976604d + "'", double1 == 1.8520158336976604d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        int int2 = org.apache.commons.math.util.FastMath.min((-506605058), 974002049);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-506605058) + "'", int2 == (-506605058));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double1 = org.apache.commons.math.util.FastMath.cos(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964192d) + "'", double1 == (-0.9251475365964192d));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-131385937));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395465E155d + "'", double1 == 9.332621544395465E155d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-102400.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) (short) 100, 974002048, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-203.99999999999997d), (java.lang.Number) 9.740020490000001E8d, (int) (short) 0, orderDirection9, true);
        java.lang.Class<?> wildcardClass16 = nonMonotonousSequenceException15.getClass();
        java.lang.String str17 = nonMonotonousSequenceException15.toString();
        boolean boolean18 = nonMonotonousSequenceException15.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (974,002,049 >= -204)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (974,002,049 >= -204)"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.4524424832623713E13d, (double) (-172L), 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.cos(11.7910068511973d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7141664558621691d + "'", double1 == 0.7141664558621691d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int2 = org.apache.commons.math.util.FastMath.max((-1000602687), 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.552941156E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-506605058), 1552941056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        java.lang.Number number3 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 5.288241522117258d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 42901.69723267129d, (int) (short) 100, orderDirection6, false);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 42901.69723267129d + "'", number11.equals(42901.69723267129d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) 10, 0.0d };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 10);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray18);
        double[] doubleArray27 = new double[] { (byte) 10, 0.0d };
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray33 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) 10);
        double[] doubleArray42 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray46 = null;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray42);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray27);
        try {
            double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1000602687) + "'", int4 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4142135623730951d + "'", double10 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 974002049 + "'", int20 == 974002049);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1000602687) + "'", int28 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.4142135623730951d + "'", double34 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.4142135623730951d + "'", double43 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 974002049 + "'", int44 == 974002049);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.4142135623730951d + "'", double45 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 204);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.21094709796687366d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0036817214070489815d) + "'", double1 == (-0.0036817214070489815d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.067661995777765d + "'", double1 == 10.067661995777765d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int int1 = org.apache.commons.math.util.FastMath.round(Float.NaN);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 1552941156L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.55294118E9f + "'", float2 == 1.55294118E9f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 5044);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int2 = org.apache.commons.math.util.FastMath.max(204, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 204 + "'", int2 == 204);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 1694164183);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1760676956, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(52.0d, (double) '4', (-1.2982325897788716d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 10, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 310 + "'", int2 == 310);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1024);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.6783606624401571d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (byte) 0, 100, 0 };
        int[] intArray9 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray14 = new int[] { (byte) 0, 100, 0 };
        int[] intArray19 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray19);
        int[] intArray24 = new int[] { (byte) 0, 100, 0 };
        int[] intArray29 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray29);
        int[] intArray34 = new int[] { (byte) 0, 100, 0 };
        int[] intArray39 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray39);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray29);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray29);
        int[] intArray47 = new int[] { (-205), (short) -1, 1 };
        int[] intArray51 = new int[] { (byte) 0, 100, 0 };
        int[] intArray56 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray56);
        int[] intArray61 = new int[] { (byte) 0, 100, 0 };
        int[] intArray66 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray66);
        int[] intArray71 = new int[] { (byte) 0, 100, 0 };
        int[] intArray76 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray76);
        int[] intArray81 = new int[] { (byte) 0, 100, 0 };
        int[] intArray86 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray81, intArray86);
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray76, intArray86);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray76);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray76);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray76);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray76);
        try {
            int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 152 + "'", int10 == 152);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 152 + "'", int20 == 152);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 152 + "'", int30 == 152);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 152 + "'", int40 == 152);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 99 + "'", int42 == 99);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 111.83022847155415d + "'", double43 == 111.83022847155415d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 152 + "'", int57 == 152);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 152 + "'", int67 == 152);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 152 + "'", int77 == 152);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 152 + "'", int87 == 152);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 99 + "'", int89 == 99);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 111.83022847155415d + "'", double90 == 111.83022847155415d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 257 + "'", int91 == 257);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1313859370L, 0.0d, 6.346863764025602E8d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-101L), 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.718281828459045d, 22026.465794806718d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-1.8110582783206075E7d), (-506605058));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.070580386413807E160d) + "'", double2 == (-6.070580386413807E160d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(10100L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10090L + "'", long2 == 10090L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-1.00060269E9f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 152);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.717016880593469d + "'", double1 == 5.717016880593469d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10100L, (java.lang.Number) 3.0d, (int) (short) 100);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-172L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-131385937), 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.31385937E8d) + "'", double2 == (-1.31385937E8d));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 172L, 1.552941156E9d, (double) 97.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 32.0f, 0.0d, (double) 257);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5430256902014756d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18837315679539754d + "'", double1 == 0.18837315679539754d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int int2 = org.apache.commons.math.util.FastMath.max(152, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 152 + "'", int2 == 152);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double2 = org.apache.commons.math.util.MathUtils.log(92.13617560368711d, 7.043958477050381d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4315840772398932d + "'", double2 == 0.4315840772398932d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 974002048);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray43);
        double[] doubleArray52 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray60 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 974002048);
        double[] doubleArray68 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray76 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray76);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray76);
        java.lang.Class<?> wildcardClass80 = doubleArray76.getClass();
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.4142135623730951d + "'", double53 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.4142135623730951d + "'", double69 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 2.6881171418161356E43d + "'", double77 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.6881171418161356E43d + "'", double78 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.6881171418161356E43d + "'", double81 == 2.6881171418161356E43d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.9251475365964192d), (double) 12L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.141592653589793d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.982441812995697E30d + "'", double2 == 3.982441812995697E30d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1552941056, (long) 310);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1552941056L + "'", long2 == 1552941056L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d };
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray15);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9700, (java.lang.Number) 0.7615941559557649d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException23.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection24, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1000602687) + "'", int16 == (-1000602687));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1000602687) + "'", int17 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(99, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 974002048);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray43);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.6881171418161356E43d + "'", double48 == 2.6881171418161356E43d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 10, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        int int8 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 974002049 + "'", number6.equals(974002049));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 31L, 31.41592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.0d + "'", double2 == 31.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.1214480546016465E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22383.41708588723d + "'", double1 == 22383.41708588723d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        long long2 = org.apache.commons.math.util.FastMath.min(5624L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(974002079L, 34620618912878L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        int int2 = org.apache.commons.math.util.MathUtils.pow(99, 31L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1563278539 + "'", int2 == 1563278539);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.6275174755083712d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray29);
        java.lang.Class<?> wildcardClass34 = doubleArray29.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int39 = nonMonotonousSequenceException38.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = nonMonotonousSequenceException38.getDirection();
        java.lang.Class<?> wildcardClass41 = orderDirection40.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection40, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (974,002,048 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1760676956 + "'", int30 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 100 + "'", int39 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(74.54992027339121d, 5044, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09698324645938282d) + "'", double1 == (-0.09698324645938282d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.61512051684126d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double1 = org.apache.commons.math.util.FastMath.floor(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.lang.Number number3 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 5.288241522117258d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 42901.69723267129d, (int) (short) 100, orderDirection6, false);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (42,901.697 > 1)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (42,901.697 > 1)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 42901.69723267129d + "'", number12.equals(42901.69723267129d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1182127744, 17310309456475L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(467396991, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.371184979049348E80d + "'", double2 == 1.371184979049348E80d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1694164183);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.FastMath.abs(7.043958477050381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.043958477050381d + "'", double1 == 7.043958477050381d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-131385940));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 97L, 0.18837315679539754d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.99999999999999d + "'", double2 == 96.99999999999999d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(9700);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double1 = org.apache.commons.math.util.FastMath.sinh(31.41592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.201575293031599E13d + "'", double1 == 2.201575293031599E13d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray33 = new int[] { (byte) 0, 100, 0 };
        int[] intArray38 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray38);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        int[] intArray45 = new int[] { (byte) 0, 100, 0 };
        int[] intArray50 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray50);
        int[] intArray55 = new int[] { (byte) 0, 100, 0 };
        int[] intArray60 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray60);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray60);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray50);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray28);
        java.lang.Class<?> wildcardClass65 = intArray28.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152 + "'", int39 == 152);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 99 + "'", int41 == 99);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 152 + "'", int51 == 152);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 152 + "'", int61 == 152);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 99 + "'", int64 == 99);
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440618722340037d) + "'", double1 == (-0.5440618722340037d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1182127744, 1024);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math.util.FastMath.log(0.37357877856093286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9846263768078726d) + "'", double1 == (-0.9846263768078726d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2L, (java.lang.Number) 2L, (int) ' ');
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2L + "'", number4.equals(2L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.9251475365964192d), (double) 17310309456439L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

